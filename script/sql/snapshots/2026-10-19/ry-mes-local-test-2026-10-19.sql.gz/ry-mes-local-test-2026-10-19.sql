/*
 Navicat Premium Data Transfer

 Source Server         : whbuild
 Source Server Type    : MySQL
 Source Server Version : 50720
 Source Host           : localhost:3306
 Source Schema         : ry-mes

 Target Server Type    : MySQL
 Target Server Version : 50720
 File Encoding         : 65001

 Date: 19/10/2026 20:15:00
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for bak_20260922_mes_firmware
-- ----------------------------
DROP TABLE IF EXISTS `bak_20260922_mes_firmware`;
CREATE TABLE `bak_20260922_mes_firmware`  (
  `firmware_id` bigint(20) NOT NULL COMMENT '固件ID',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '000000' COMMENT '租户ID',
  `firmware_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '固件编码(自动编码 MES_FW_CODE)',
  `firmware_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '固件名称',
  `material_id` bigint(20) NOT NULL COMMENT '适用物料ID(产品)',
  `material_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '适用物料编码',
  `material_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '适用物料名称',
  `version` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '版本号(如 1.2.3)',
  `build_no` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '构建号',
  `oss_id` bigint(20) NULL DEFAULT NULL COMMENT '固件文件OSS文件ID(sys_oss)',
  `file_md5` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '固件文件MD5',
  `file_size` bigint(20) NULL DEFAULT NULL COMMENT '固件文件大小(字节)',
  `release_note` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT '发布说明',
  `status` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'DRAFT' COMMENT '状态: DRAFT/IN_REVIEW/RELEASED/ARCHIVED',
  `is_default` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0' COMMENT '是否物料默认版本(0否/1是, 物料内唯一)',
  `select_flow_id` bigint(20) NULL DEFAULT NULL COMMENT '审批流配置ID(wf_custom_form.id)',
  `published_by` bigint(20) NULL DEFAULT NULL COMMENT '发布人ID',
  `publish_time` datetime(0) NULL DEFAULT NULL COMMENT '发布时间',
  `create_dept` bigint(20) NULL DEFAULT NULL COMMENT '创建部门',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建人',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新人',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0' COMMENT '删除标志(0存在/2删除)',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '备注'
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of bak_20260922_mes_firmware
-- ----------------------------
INSERT INTO `bak_20260922_mes_firmware` VALUES (1, '000000', 'FW20260914001', '智能路由器 WR-1200主控固件', 14, 'IF20260914014', '智能路由器 WR-1200', 'V1.0.0', 'BUILD001', NULL, 'md50000000000000000000000000001', 262144, '初始版本固件', '1', '1', NULL, 1, '2026-09-14 15:07:27', 103, 1, '2026-09-14 15:07:27', NULL, '2026-09-14 15:07:27', '0', NULL);
INSERT INTO `bak_20260922_mes_firmware` VALUES (2, '000000', 'FW20260914002', '变频电风扇主控固件', 15, 'IF20260914015', '变频电风扇', 'V1.0.0', 'BUILD002', NULL, 'md50000000000000000000000000002', 262144, '初始版本固件', '1', '1', NULL, 1, '2026-09-14 15:07:27', 103, 1, '2026-09-14 15:07:27', NULL, '2026-09-14 15:07:27', '0', NULL);
INSERT INTO `bak_20260922_mes_firmware` VALUES (3, '000000', 'FW20260914003', '开关电源模组 SMPS-60主控固件', 16, 'IF20260914016', '开关电源模组 SMPS-60', 'V1.0.0', 'BUILD003', NULL, 'md50000000000000000000000000003', 262144, '初始版本固件', '1', '1', NULL, 1, '2026-09-14 15:07:27', 103, 1, '2026-09-14 15:07:27', NULL, '2026-09-14 15:07:27', '0', NULL);
INSERT INTO `bak_20260922_mes_firmware` VALUES (4, '000000', 'FW20260914004', '无刷直流电机 BLDC-45主控固件', 17, 'IF20260914017', '无刷直流电机 BLDC-45', 'V1.0.0', 'BUILD004', NULL, 'md50000000000000000000000000004', 262144, '初始版本固件', '1', '1', NULL, 1, '2026-09-14 15:07:27', 103, 1, '2026-09-14 15:07:27', NULL, '2026-09-14 15:07:27', '0', NULL);
INSERT INTO `bak_20260922_mes_firmware` VALUES (5, '000000', 'FW20260914005', '温度传感器模组 TS-100主控固件', 18, 'IF20260914018', '温度传感器模组 TS-100', 'V1.0.0', 'BUILD005', NULL, 'md50000000000000000000000000005', 262144, '初始版本固件', '1', '1', NULL, 1, '2026-09-14 15:07:27', 103, 1, '2026-09-14 15:07:27', NULL, '2026-09-14 15:07:27', '0', NULL);
INSERT INTO `bak_20260922_mes_firmware` VALUES (6, '000000', 'FW20260914006', 'LED 护眼台灯主控固件', 26, 'IF20260914026', 'LED 护眼台灯', 'V1.0.0', 'BUILD006', NULL, 'md50000000000000000000000000006', 262144, '初始版本固件', '1', '1', NULL, 1, '2026-09-14 15:07:27', 103, 1, '2026-09-14 15:07:27', NULL, '2026-09-14 15:07:27', '0', NULL);
INSERT INTO `bak_20260922_mes_firmware` VALUES (7, '000000', 'FW20260914007', '智能网关 GW-1000主控固件', 27, 'IF20260914027', '智能网关 GW-1000', 'V1.0.0', 'BUILD007', NULL, 'md50000000000000000000000000007', 262144, '初始版本固件', '1', '1', NULL, 1, '2026-09-14 15:07:27', 103, 1, '2026-09-14 15:07:27', NULL, '2026-09-14 15:07:27', '0', NULL);
INSERT INTO `bak_20260922_mes_firmware` VALUES (8, '000000', 'FW20260914008', '锂电池包 48V20Ah主控固件', 30, 'IF20260914030', '锂电池包 48V20Ah', 'V1.0.0', 'BUILD008', NULL, 'md50000000000000000000000000008', 262144, '初始版本固件', '1', '1', NULL, 1, '2026-09-14 15:07:27', 103, 1, '2026-09-14 15:07:27', NULL, '2026-09-14 15:07:27', '0', NULL);
INSERT INTO `bak_20260922_mes_firmware` VALUES (9, '000000', 'FW20260914009', '交流充电桩 AC-7kW主控固件', 31, 'IF20260914031', '交流充电桩 AC-7kW', 'V1.0.0', 'BUILD009', NULL, 'md50000000000000000000000000009', 262144, '初始版本固件', '1', '1', NULL, 1, '2026-09-14 15:07:27', 103, 1, '2026-09-14 15:07:27', NULL, '2026-09-14 15:07:27', '0', NULL);
INSERT INTO `bak_20260922_mes_firmware` VALUES (10, '000000', 'FW20260914010', '六轴机械臂 RB-6主控固件', 33, 'IF20260914033', '六轴机械臂 RB-6', 'V1.0.0', 'BUILD010', NULL, 'md50000000000000000000000000010', 262144, '初始版本固件', '1', '1', NULL, 1, '2026-09-14 15:07:27', 103, 1, '2026-09-14 15:07:27', NULL, '2026-09-14 15:07:27', '0', NULL);
INSERT INTO `bak_20260922_mes_firmware` VALUES (11, '000000', 'FW20260914011', '智能手环 BAND-3主控固件', 34, 'IF20260914034', '智能手环 BAND-3', 'V1.0.0', 'BUILD011', NULL, 'md50000000000000000000000000011', 262144, '初始版本固件', '1', '1', NULL, 1, '2026-09-14 15:07:27', 103, 1, '2026-09-14 15:07:27', NULL, '2026-09-14 15:07:27', '0', NULL);
INSERT INTO `bak_20260922_mes_firmware` VALUES (12, '000000', 'FW20260914012', '手持 POS 机 POS-8主控固件', 35, 'IF20260914035', '手持 POS 机 POS-8', 'V1.0.0', 'BUILD012', NULL, 'md50000000000000000000000000012', 262144, '初始版本固件', '1', '1', NULL, 1, '2026-09-14 15:07:27', 103, 1, '2026-09-14 15:07:27', NULL, '2026-09-14 15:07:27', '0', NULL);
INSERT INTO `bak_20260922_mes_firmware` VALUES (13, '000000', 'FW20260914013', '网络摄像机 IPC-300主控固件', 36, 'IF20260914036', '网络摄像机 IPC-300', 'V1.0.0', 'BUILD013', NULL, 'md50000000000000000000000000013', 262144, '初始版本固件', '1', '1', NULL, 1, '2026-09-14 15:07:27', 103, 1, '2026-09-14 15:07:27', NULL, '2026-09-14 15:07:27', '0', NULL);
INSERT INTO `bak_20260922_mes_firmware` VALUES (14, '000000', 'FW20260914014', '无线蓝牙音箱 SPK-20主控固件', 37, 'IF20260914037', '无线蓝牙音箱 SPK-20', 'V1.0.0', 'BUILD014', NULL, 'md50000000000000000000000000014', 262144, '初始版本固件', '1', '1', NULL, 1, '2026-09-14 15:07:27', 103, 1, '2026-09-14 15:07:27', NULL, '2026-09-14 15:07:27', '0', NULL);

-- ----------------------------
-- Table structure for bak_20260922_qc_inspect_template
-- ----------------------------
DROP TABLE IF EXISTS `bak_20260922_qc_inspect_template`;
CREATE TABLE `bak_20260922_qc_inspect_template`  (
  `template_id` bigint(20) NOT NULL COMMENT '检验模板ID(主键)',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '000000' COMMENT '租户ID',
  `template_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '模板编码(唯一)',
  `template_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '模板名称',
  `template_type` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '模板类型: IQC/IPQC/OQC',
  `material_id` bigint(20) NULL DEFAULT NULL COMMENT '物料ID(空=通用模板)',
  `material_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '物料编码(冗余)',
  `material_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '物料名称(冗余)',
  `process_id` bigint(20) NULL DEFAULT NULL COMMENT '工序ID(IPQC维度,空=不限工序)',
  `customer_id` bigint(20) NULL DEFAULT NULL COMMENT '客户ID(客户专属模板维度,空=不限客户)',
  `version_no` int(11) NOT NULL DEFAULT 1 COMMENT '版本号',
  `status` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT 'DRAFT' COMMENT '状态: DRAFT/ACTIVE',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '备注',
  `create_dept` bigint(20) NULL DEFAULT NULL COMMENT '创建部门',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT '0' COMMENT '删除标志'
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of bak_20260922_qc_inspect_template
-- ----------------------------
INSERT INTO `bak_20260922_qc_inspect_template` VALUES (1, '000000', 'QC20260914001', '高强度螺栓组套 M12成品检验规范', 'OQC', 1, 'IF20260914001', '高强度螺栓组套 M12', NULL, NULL, 1, '1', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `bak_20260922_qc_inspect_template` VALUES (2, '000000', 'QC20260914002', '精密齿轮箱总成成品检验规范', 'OQC', 2, 'IF20260914002', '精密齿轮箱总成', NULL, NULL, 1, '1', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `bak_20260922_qc_inspect_template` VALUES (3, '000000', 'QC20260914003', '压缩弹簧组成品检验规范', 'OQC', 3, 'IF20260914003', '压缩弹簧组', NULL, NULL, 1, '1', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `bak_20260922_qc_inspect_template` VALUES (4, '000000', 'QC20260914004', '设备钣金机箱成品检验规范', 'OQC', 4, 'IF20260914004', '设备钣金机箱', NULL, NULL, 1, '1', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `bak_20260922_qc_inspect_template` VALUES (5, '000000', 'QC20260914005', '钢结构支架总成成品检验规范', 'OQC', 5, 'IF20260914005', '钢结构支架总成', NULL, NULL, 1, '1', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `bak_20260922_qc_inspect_template` VALUES (6, '000000', 'QC20260914006', '注塑模具成品检验规范', 'OQC', 6, 'IF20260914006', '注塑模具', NULL, NULL, 1, '1', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `bak_20260922_qc_inspect_template` VALUES (7, '000000', 'QC20260914007', '棘轮扳手组套成品检验规范', 'OQC', 7, 'IF20260914007', '棘轮扳手组套', NULL, NULL, 1, '1', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `bak_20260922_qc_inspect_template` VALUES (8, '000000', 'QC20260914008', '齿轮减速机 JZQ-350成品检验规范', 'OQC', 8, 'IF20260914008', '齿轮减速机 JZQ-350', NULL, NULL, 1, '1', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `bak_20260922_qc_inspect_template` VALUES (9, '000000', 'QC20260914009', '单级离心泵成品检验规范', 'OQC', 9, 'IF20260914009', '单级离心泵', NULL, NULL, 1, '1', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `bak_20260922_qc_inspect_template` VALUES (10, '000000', 'QC20260914010', '数控铣床 XK714成品检验规范', 'OQC', 10, 'IF20260914010', '数控铣床 XK714', NULL, NULL, 1, '1', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `bak_20260922_qc_inspect_template` VALUES (11, '000000', 'QC20260914011', '皮带输送线成品检验规范', 'OQC', 11, 'IF20260914011', '皮带输送线', NULL, NULL, 1, '1', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `bak_20260922_qc_inspect_template` VALUES (12, '000000', 'QC20260914012', '螺杆式空压机成品检验规范', 'OQC', 12, 'IF20260914012', '螺杆式空压机', NULL, NULL, 1, '1', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `bak_20260922_qc_inspect_template` VALUES (13, '000000', 'QC20260914013', '双层 PCB 板成品检验规范', 'OQC', 13, 'IF20260914013', '双层 PCB 板', NULL, NULL, 1, '1', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `bak_20260922_qc_inspect_template` VALUES (14, '000000', 'QC20260914014', '智能路由器 WR-1200成品检验规范', 'OQC', 14, 'IF20260914014', '智能路由器 WR-1200', NULL, NULL, 1, '1', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `bak_20260922_qc_inspect_template` VALUES (15, '000000', 'QC20260914015', '变频电风扇成品检验规范', 'OQC', 15, 'IF20260914015', '变频电风扇', NULL, NULL, 1, '1', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `bak_20260922_qc_inspect_template` VALUES (16, '000000', 'QC20260914016', '开关电源模组 SMPS-60成品检验规范', 'OQC', 16, 'IF20260914016', '开关电源模组 SMPS-60', NULL, NULL, 1, '1', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `bak_20260922_qc_inspect_template` VALUES (17, '000000', 'QC20260914017', '无刷直流电机 BLDC-45成品检验规范', 'OQC', 17, 'IF20260914017', '无刷直流电机 BLDC-45', NULL, NULL, 1, '1', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `bak_20260922_qc_inspect_template` VALUES (18, '000000', 'QC20260914018', '温度传感器模组 TS-100成品检验规范', 'OQC', 18, 'IF20260914018', '温度传感器模组 TS-100', NULL, NULL, 1, '1', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `bak_20260922_qc_inspect_template` VALUES (19, '000000', 'QC20260914019', '数字万用表 DM-800成品检验规范', 'OQC', 19, 'IF20260914019', '数字万用表 DM-800', NULL, NULL, 1, '1', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `bak_20260922_qc_inspect_template` VALUES (20, '000000', 'QC20260914020', '汽车门锁总成成品检验规范', 'OQC', 20, 'IF20260914020', '汽车门锁总成', NULL, NULL, 1, '1', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `bak_20260922_qc_inspect_template` VALUES (21, '000000', 'QC20260914021', '城市通勤自行车成品检验规范', 'OQC', 21, 'IF20260914021', '城市通勤自行车', NULL, NULL, 1, '1', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `bak_20260922_qc_inspect_template` VALUES (22, '000000', 'QC20260914022', '四轴无人机机架成品检验规范', 'OQC', 22, 'IF20260914022', '四轴无人机机架', NULL, NULL, 1, '1', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `bak_20260922_qc_inspect_template` VALUES (23, '000000', 'QC20260914023', '不锈钢手术剪成品检验规范', 'OQC', 23, 'IF20260914023', '不锈钢手术剪', NULL, NULL, 1, '1', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `bak_20260922_qc_inspect_template` VALUES (24, '000000', 'QC20260914024', '手动轮椅成品检验规范', 'OQC', 24, 'IF20260914024', '手动轮椅', NULL, NULL, 1, '1', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `bak_20260922_qc_inspect_template` VALUES (25, '000000', 'QC20260914025', '简易金属工具架 RACK-001成品检验规范', 'OQC', 25, 'IF20260914025', '简易金属工具架 RACK-001', NULL, NULL, 1, '1', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `bak_20260922_qc_inspect_template` VALUES (26, '000000', 'QC20260914026', 'LED 护眼台灯成品检验规范', 'OQC', 26, 'IF20260914026', 'LED 护眼台灯', NULL, NULL, 1, '1', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `bak_20260922_qc_inspect_template` VALUES (27, '000000', 'QC20260914027', '智能网关 GW-1000成品检验规范', 'OQC', 27, 'IF20260914027', '智能网关 GW-1000', NULL, NULL, 1, '1', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `bak_20260922_qc_inspect_template` VALUES (28, '000000', 'QC20260914028', '精密塑料外壳 PC-200成品检验规范', 'OQC', 28, 'IF20260914028', '精密塑料外壳 PC-200', NULL, NULL, 1, '1', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `bak_20260922_qc_inspect_template` VALUES (29, '000000', 'QC20260914029', '硅胶密封圈组成品检验规范', 'OQC', 29, 'IF20260914029', '硅胶密封圈组', NULL, NULL, 1, '1', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `bak_20260922_qc_inspect_template` VALUES (30, '000000', 'QC20260914030', '锂电池包 48V20Ah成品检验规范', 'OQC', 30, 'IF20260914030', '锂电池包 48V20Ah', NULL, NULL, 1, '1', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `bak_20260922_qc_inspect_template` VALUES (31, '000000', 'QC20260914031', '交流充电桩 AC-7kW成品检验规范', 'OQC', 31, 'IF20260914031', '交流充电桩 AC-7kW', NULL, NULL, 1, '1', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `bak_20260922_qc_inspect_template` VALUES (32, '000000', 'QC20260914032', '光伏组件 450W成品检验规范', 'OQC', 32, 'IF20260914032', '光伏组件 450W', NULL, NULL, 1, '1', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `bak_20260922_qc_inspect_template` VALUES (33, '000000', 'QC20260914033', '六轴机械臂 RB-6成品检验规范', 'OQC', 33, 'IF20260914033', '六轴机械臂 RB-6', NULL, NULL, 1, '1', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `bak_20260922_qc_inspect_template` VALUES (34, '000000', 'QC20260914034', '智能手环 BAND-3成品检验规范', 'OQC', 34, 'IF20260914034', '智能手环 BAND-3', NULL, NULL, 1, '1', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `bak_20260922_qc_inspect_template` VALUES (35, '000000', 'QC20260914035', '手持 POS 机 POS-8成品检验规范', 'OQC', 35, 'IF20260914035', '手持 POS 机 POS-8', NULL, NULL, 1, '1', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `bak_20260922_qc_inspect_template` VALUES (36, '000000', 'QC20260914036', '网络摄像机 IPC-300成品检验规范', 'OQC', 36, 'IF20260914036', '网络摄像机 IPC-300', NULL, NULL, 1, '1', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `bak_20260922_qc_inspect_template` VALUES (37, '000000', 'QC20260914037', '无线蓝牙音箱 SPK-20成品检验规范', 'OQC', 37, 'IF20260914037', '无线蓝牙音箱 SPK-20', NULL, NULL, 1, '1', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');

-- ----------------------------
-- Table structure for dc_collection_point
-- ----------------------------
DROP TABLE IF EXISTS `dc_collection_point`;
CREATE TABLE `dc_collection_point`  (
  `point_id` bigint(20) NOT NULL COMMENT '采集点ID(主键)',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '000000',
  `point_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '采集点编码',
  `point_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '采集点名称',
  `point_type` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'MANUAL/AUTO',
  `equipment_id` bigint(20) NULL DEFAULT NULL COMMENT '关联设备ID',
  `iot_device_id` bigint(20) NULL DEFAULT NULL COMMENT '关联 IoT 设备 ID（AUTO 类型必填）',
  `iot_property_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT 'IoT 属性编码（对应 iot_device_data.property_code）',
  `process_id` bigint(20) NULL DEFAULT NULL COMMENT '关联工序ID',
  `data_type` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT 'NUMERIC/TEXT/ENUM',
  `unit` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '单位',
  `frequency` int(11) NULL DEFAULT NULL COMMENT '采集频率(秒)',
  `status` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT 'ACTIVE' COMMENT 'ACTIVE/INACTIVE',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '备注',
  `last_archive_time` datetime(0) NULL DEFAULT NULL COMMENT '最后成功归档时间（数据补偿游标）',
  `create_dept` bigint(20) NULL DEFAULT NULL COMMENT '创建部门',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT '0' COMMENT '删除标志',
  PRIMARY KEY (`point_id`) USING BTREE,
  UNIQUE INDEX `uk_point_code`(`tenant_id`, `point_code`) USING BTREE,
  INDEX `idx_status`(`status`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = 'MES数据采集点' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for dc_data_record
-- ----------------------------
DROP TABLE IF EXISTS `dc_data_record`;
CREATE TABLE `dc_data_record`  (
  `record_id` bigint(20) NOT NULL COMMENT '记录ID(主键)',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '000000',
  `point_id` bigint(20) NOT NULL COMMENT '采集点ID',
  `point_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '采集点编码(冗余)',
  `property_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT 'IoT 属性编码（source=IoT 时填充）',
  `mes_wo_id` bigint(20) NULL DEFAULT NULL COMMENT '关联MES工单ID',
  `card_id` bigint(20) NULL DEFAULT NULL COMMENT '关联流转卡ID',
  `step_record_id` bigint(20) NULL DEFAULT NULL COMMENT '关联工序记录ID',
  `numeric_value` decimal(14, 4) NULL DEFAULT NULL COMMENT '数值',
  `text_value` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '文本值',
  `collect_time` datetime(0) NOT NULL COMMENT '采集时间',
  `collect_by` bigint(20) NULL DEFAULT NULL COMMENT '采集人(手动时)',
  `source` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT 'MANUAL' COMMENT 'MANUAL/IoT',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '备注',
  `create_dept` bigint(20) NULL DEFAULT NULL COMMENT '创建部门',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT '0' COMMENT '删除标志',
  PRIMARY KEY (`record_id`) USING BTREE,
  UNIQUE INDEX `uk_point_collect_time`(`tenant_id`, `point_id`, `collect_time`) USING BTREE,
  INDEX `idx_point_id`(`point_id`) USING BTREE,
  INDEX `idx_mes_wo_id`(`mes_wo_id`) USING BTREE,
  INDEX `idx_collect_time`(`collect_time`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = 'MES采集数据记录' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for dhr_record
-- ----------------------------
DROP TABLE IF EXISTS `dhr_record`;
CREATE TABLE `dhr_record`  (
  `dhr_id` bigint(20) NOT NULL COMMENT 'DHR主键',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '000000' COMMENT '租户ID',
  `dhr_no` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT 'DHR编号',
  `work_order_id` bigint(20) NULL DEFAULT NULL COMMENT 'MES工单ID(pro_work_order.mes_wo_id)',
  `work_order_no` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '工单编号(冗余快照)',
  `material_id` bigint(20) NULL DEFAULT NULL COMMENT '产品物料ID',
  `material_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '产品物料编码(冗余快照)',
  `material_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '产品物料名称(冗余快照)',
  `lot_no` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '批次号',
  `sn` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT 'SN序列号',
  `planned_qty` decimal(14, 4) NULL DEFAULT NULL COMMENT '计划数量',
  `completed_qty` decimal(14, 4) NULL DEFAULT NULL COMMENT '完成数量',
  `scrap_qty` decimal(14, 4) NULL DEFAULT NULL COMMENT '报废数量',
  `status` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT 'DRAFT' COMMENT '状态: DRAFT/SUBMITTED/RELEASED/REJECTED/ARCHIVED',
  `snapshot_hash` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '快照总哈希(SM3)',
  `frozen_at` datetime(0) NULL DEFAULT NULL COMMENT '冻结时间(提交时写入)',
  `frozen_by` bigint(20) NULL DEFAULT NULL COMMENT '冻结人',
  `submitted_at` datetime(0) NULL DEFAULT NULL COMMENT '提交时间',
  `submitted_by` bigint(20) NULL DEFAULT NULL COMMENT '提交人',
  `submit_signature_id` bigint(20) NULL DEFAULT NULL COMMENT '提交签名ID(es_signature, biz_type=DHR_SUBMIT)',
  `released_at` datetime(0) NULL DEFAULT NULL COMMENT '放行时间',
  `released_by` bigint(20) NULL DEFAULT NULL COMMENT '放行人',
  `release_signature_id` bigint(20) NULL DEFAULT NULL COMMENT '放行签名ID(biz_type=DHR_RELEASE)',
  `rejected_at` datetime(0) NULL DEFAULT NULL COMMENT '驳回时间',
  `rejected_by` bigint(20) NULL DEFAULT NULL COMMENT '驳回人',
  `reject_reason` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '驳回原因',
  `reject_signature_id` bigint(20) NULL DEFAULT NULL COMMENT '驳回签名ID(biz_type=DHR_REJECT)',
  `archived_at` datetime(0) NULL DEFAULT NULL COMMENT '归档时间',
  `version` int(11) NULL DEFAULT 1 COMMENT '版本号(每次状态流转+1)',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '备注',
  `create_dept` bigint(20) NULL DEFAULT NULL COMMENT '创建部门',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT '0' COMMENT '删除标志(0正常 1删除,仅DRAFT可删)',
  PRIMARY KEY (`dhr_id`) USING BTREE,
  UNIQUE INDEX `uk_dhr_no`(`tenant_id`, `dhr_no`) USING BTREE,
  INDEX `idx_dhr_wo`(`tenant_id`, `work_order_id`) USING BTREE,
  INDEX `idx_dhr_status`(`tenant_id`, `status`) USING BTREE,
  INDEX `idx_dhr_lot`(`tenant_id`, `lot_no`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = 'DHR批记录主表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for dhr_section
-- ----------------------------
DROP TABLE IF EXISTS `dhr_section`;
CREATE TABLE `dhr_section`  (
  `section_id` bigint(20) NOT NULL COMMENT '分册主键',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '000000' COMMENT '租户ID',
  `dhr_id` bigint(20) NOT NULL COMMENT '所属DHR主表ID',
  `section_code` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '分册编码(10个固定值)',
  `section_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '分册名称',
  `item_count` int(11) NULL DEFAULT 0 COMMENT '条目数(无数据时为0,分册仍落库)',
  `content_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT '分册条目JSON',
  `content_hash` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '正文哈希SM3(content_json)',
  `sort_order` int(11) NULL DEFAULT 0 COMMENT '排序号(1基)',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '写入时间',
  PRIMARY KEY (`section_id`) USING BTREE,
  UNIQUE INDEX `uk_dhr_section`(`tenant_id`, `dhr_id`, `section_code`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = 'DHR批记录分册(append-only)' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for eq_equipment
-- ----------------------------
DROP TABLE IF EXISTS `eq_equipment`;
CREATE TABLE `eq_equipment`  (
  `equipment_id` bigint(20) NOT NULL COMMENT '设备ID(主键)',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '000000',
  `equipment_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '设备编码',
  `equipment_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '设备名称',
  `equipment_type` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '设备类型',
  `model` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '型号',
  `manufacturer` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '制造商',
  `serial_no` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '出厂编号',
  `workcenter_id` bigint(20) NULL DEFAULT NULL COMMENT '工作中心ID(ERP bd_workstation.workstation_id)',
  `workcenter_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '工作中心编码(冗余)',
  `location` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '安装位置',
  `purchase_date` date NULL DEFAULT NULL COMMENT '购置日期',
  `warranty_date` date NULL DEFAULT NULL COMMENT '保修到期',
  `status` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT 'NORMAL' COMMENT 'NORMAL/MAINTENANCE/FAULT/SCRAPPED',
  `inspection_items` json NULL COMMENT '点检项目及标准(JSON)',
  `last_inspection` json NULL COMMENT '最近一次点检结果(JSON)',
  `iot_device_id` bigint(20) NULL DEFAULT NULL COMMENT '关联IoT设备ID(预留,无外键)',
  `planned_minutes_per_day` decimal(10, 2) NULL DEFAULT NULL COMMENT '计划生产时长(分钟/天), 供OEE聚合; 空则取 nexus.mes.eq.oee.planned-minutes-per-day(默认480)',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '备注',
  `create_dept` bigint(20) NULL DEFAULT NULL COMMENT '创建部门',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT '0' COMMENT '删除标志',
  PRIMARY KEY (`equipment_id`) USING BTREE,
  UNIQUE INDEX `uk_equipment_code`(`tenant_id`, `equipment_code`) USING BTREE,
  UNIQUE INDEX `uk_tenant_iot_device`(`tenant_id`, `iot_device_id`) USING BTREE,
  INDEX `idx_status`(`status`) USING BTREE,
  INDEX `idx_workcenter_id`(`workcenter_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = 'MES设备台账' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of eq_equipment
-- ----------------------------
INSERT INTO `eq_equipment` VALUES (1, '000000', 'EQ0001', '激光切割机', 'LASER', 'MODEL-LASER', '浙江智能装备制造有限公司', 'SN202609140001', 1, 'GZZ0001', '下料车间', NULL, NULL, 'NORMAL', NULL, NULL, NULL, NULL, '由工位台账自动生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `eq_equipment` VALUES (2, '000000', 'EQ0002', '等离子切割机', 'PLASMA', 'MODEL-PLASMA', '浙江智能装备制造有限公司', 'SN202609140002', 2, 'GZZ0002', '下料车间', NULL, NULL, 'NORMAL', NULL, NULL, NULL, NULL, '由工位台账自动生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `eq_equipment` VALUES (3, '000000', 'EQ0003', '剪板机', 'SHEAR', 'MODEL-SHEAR', '浙江智能装备制造有限公司', 'SN202609140003', 3, 'GZZ0003', '下料车间', NULL, NULL, 'NORMAL', NULL, NULL, NULL, NULL, '由工位台账自动生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `eq_equipment` VALUES (4, '000000', 'EQ0004', '锯床', 'SAW', 'MODEL-SAW', '浙江智能装备制造有限公司', 'SN202609140004', 4, 'GZZ0004', '下料车间', NULL, NULL, 'NORMAL', NULL, NULL, NULL, NULL, '由工位台账自动生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `eq_equipment` VALUES (5, '000000', 'EQ0005', '数控车床A', 'CNC', 'MODEL-CNC', '浙江智能装备制造有限公司', 'SN202609140005', 5, 'GZZ0005', '机加车间', NULL, NULL, 'OFFLINE', NULL, NULL, 1, NULL, '由工位台账自动生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `eq_equipment` VALUES (6, '000000', 'EQ0006', '数控车床B', 'CNC', 'MODEL-CNC', '浙江智能装备制造有限公司', 'SN202609140006', 6, 'GZZ0006', '机加车间', NULL, NULL, 'OFFLINE', NULL, NULL, 2, NULL, '由工位台账自动生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `eq_equipment` VALUES (7, '000000', 'EQ0007', '加工中心A', 'CNC', 'MODEL-CNC', '浙江智能装备制造有限公司', 'SN202609140007', 7, 'GZZ0007', '机加车间', NULL, NULL, 'OFFLINE', NULL, NULL, 3, NULL, '由工位台账自动生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `eq_equipment` VALUES (8, '000000', 'EQ0008', '铣床', 'MILL', 'MODEL-MILL', '浙江智能装备制造有限公司', 'SN202609140008', 8, 'GZZ0008', '机加车间', NULL, NULL, 'OFFLINE', NULL, NULL, 4, NULL, '由工位台账自动生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `eq_equipment` VALUES (9, '000000', 'EQ0009', '磨床', 'GRIND', 'MODEL-GRIND', '浙江智能装备制造有限公司', 'SN202609140009', 9, 'GZZ0009', '机加车间', NULL, NULL, 'OFFLINE', NULL, NULL, 5, NULL, '由工位台账自动生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `eq_equipment` VALUES (10, '000000', 'EQ0010', '钻床', 'DRILL', 'MODEL-DRILL', '浙江智能装备制造有限公司', 'SN202609140010', 10, 'GZZ0010', '机加车间', NULL, NULL, 'NORMAL', NULL, NULL, NULL, NULL, '由工位台账自动生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `eq_equipment` VALUES (11, '000000', 'EQ0011', '滚齿机', 'GENERAL', 'MODEL-GEN', '浙江智能装备制造有限公司', 'SN202609140011', 11, 'GZZ0011', '机加车间', NULL, NULL, 'NORMAL', NULL, NULL, NULL, NULL, '由工位台账自动生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `eq_equipment` VALUES (12, '000000', 'EQ0012', '冲床A', 'PUNCH', 'MODEL-PUNCH', '浙江智能装备制造有限公司', 'SN202609140012', 12, 'GZZ0012', '冲压车间', NULL, NULL, 'NORMAL', NULL, NULL, NULL, NULL, '由工位台账自动生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `eq_equipment` VALUES (13, '000000', 'EQ0013', '冲床B', 'PUNCH', 'MODEL-PUNCH', '浙江智能装备制造有限公司', 'SN202609140013', 13, 'GZZ0013', '冲压车间', NULL, NULL, 'NORMAL', NULL, NULL, NULL, NULL, '由工位台账自动生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `eq_equipment` VALUES (14, '000000', 'EQ0014', '折弯机', 'BEND', 'MODEL-BEND', '浙江智能装备制造有限公司', 'SN202609140014', 14, 'GZZ0014', '冲压车间', NULL, NULL, 'NORMAL', NULL, NULL, NULL, NULL, '由工位台账自动生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `eq_equipment` VALUES (15, '000000', 'EQ0015', '油压机', 'PRESS', 'MODEL-PRESS', '浙江智能装备制造有限公司', 'SN202609140015', 15, 'GZZ0015', '冲压车间', NULL, NULL, 'NORMAL', NULL, NULL, NULL, NULL, '由工位台账自动生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `eq_equipment` VALUES (16, '000000', 'EQ0016', '锻造机', 'GENERAL', 'MODEL-GEN', '浙江智能装备制造有限公司', 'SN202609140016', 16, 'GZZ0016', '冲压车间', NULL, NULL, 'NORMAL', NULL, NULL, NULL, NULL, '由工位台账自动生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `eq_equipment` VALUES (17, '000000', 'EQ0017', '折弯工位', 'GENERAL', 'MODEL-GEN', '浙江智能装备制造有限公司', 'SN202609140017', 17, 'GZZ0017', '钣金车间', NULL, NULL, 'NORMAL', NULL, NULL, NULL, NULL, '由工位台账自动生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `eq_equipment` VALUES (18, '000000', 'EQ0018', '卷圆工位', 'ROLL', 'MODEL-ROLL', '浙江智能装备制造有限公司', 'SN202609140018', 18, 'GZZ0018', '钣金车间', NULL, NULL, 'NORMAL', NULL, NULL, NULL, NULL, '由工位台账自动生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `eq_equipment` VALUES (19, '000000', 'EQ0019', '冲孔工位', 'PUNCH', 'MODEL-PUNCH', '浙江智能装备制造有限公司', 'SN202609140019', 19, 'GZZ0019', '钣金车间', NULL, NULL, 'NORMAL', NULL, NULL, NULL, NULL, '由工位台账自动生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `eq_equipment` VALUES (20, '000000', 'EQ0020', '氩弧焊工位', 'WELDING', 'MODEL-WELDING', '浙江智能装备制造有限公司', 'SN202609140020', 20, 'GZZ0020', '焊接车间', NULL, NULL, 'OFFLINE', NULL, NULL, 6, NULL, '由工位台账自动生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `eq_equipment` VALUES (21, '000000', 'EQ0021', '二保焊工位', 'WELDING', 'MODEL-WELDING', '浙江智能装备制造有限公司', 'SN202609140021', 21, 'GZZ0021', '焊接车间', NULL, NULL, 'OFFLINE', NULL, NULL, 7, NULL, '由工位台账自动生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `eq_equipment` VALUES (22, '000000', 'EQ0022', '点焊工位', 'WELDING', 'MODEL-WELDING', '浙江智能装备制造有限公司', 'SN202609140022', 22, 'GZZ0022', '焊接车间', NULL, NULL, 'OFFLINE', NULL, NULL, 8, NULL, '由工位台账自动生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `eq_equipment` VALUES (23, '000000', 'EQ0023', '打磨工位', 'GRIND', 'MODEL-GRIND', '浙江智能装备制造有限公司', 'SN202609140023', 23, 'GZZ0023', '焊接车间', NULL, NULL, 'OFFLINE', NULL, NULL, 9, NULL, '由工位台账自动生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `eq_equipment` VALUES (24, '000000', 'EQ0024', '注塑机A', 'INJECT', 'MODEL-INJECT', '浙江智能装备制造有限公司', 'SN202609140024', 24, 'GZZ0024', '注塑车间', NULL, NULL, 'OFFLINE', NULL, NULL, 10, NULL, '由工位台账自动生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `eq_equipment` VALUES (25, '000000', 'EQ0025', '注塑机B', 'INJECT', 'MODEL-INJECT', '浙江智能装备制造有限公司', 'SN202609140025', 25, 'GZZ0025', '注塑车间', NULL, NULL, 'OFFLINE', NULL, NULL, 11, NULL, '由工位台账自动生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `eq_equipment` VALUES (26, '000000', 'EQ0026', '注塑机C', 'INJECT', 'MODEL-INJECT', '浙江智能装备制造有限公司', 'SN202609140026', 26, 'GZZ0026', '注塑车间', NULL, NULL, 'OFFLINE', NULL, NULL, 12, NULL, '由工位台账自动生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `eq_equipment` VALUES (27, '000000', 'EQ0027', '去毛刺工位', 'DEBURR', 'MODEL-DEBURR', '浙江智能装备制造有限公司', 'SN202609140027', 27, 'GZZ0027', '注塑车间', NULL, NULL, 'NORMAL', NULL, NULL, NULL, NULL, '由工位台账自动生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `eq_equipment` VALUES (28, '000000', 'EQ0028', '熔炼炉', 'FURNACE', 'MODEL-FURNACE', '浙江智能装备制造有限公司', 'SN202609140028', 28, 'GZZ0028', '铸造车间', NULL, NULL, 'OFFLINE', NULL, NULL, 13, NULL, '由工位台账自动生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `eq_equipment` VALUES (29, '000000', 'EQ0029', '压铸机', 'DIE_CAST', 'MODEL-DIE_CAST', '浙江智能装备制造有限公司', 'SN202609140029', 29, 'GZZ0029', '铸造车间', NULL, NULL, 'NORMAL', NULL, NULL, NULL, NULL, '由工位台账自动生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `eq_equipment` VALUES (30, '000000', 'EQ0030', '清砂工位', 'CLEAN', 'MODEL-CLEAN', '浙江智能装备制造有限公司', 'SN202609140030', 30, 'GZZ0030', '铸造车间', NULL, NULL, 'NORMAL', NULL, NULL, NULL, NULL, '由工位台账自动生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `eq_equipment` VALUES (31, '000000', 'EQ0031', '淬火炉', 'FURNACE', 'MODEL-FURNACE', '浙江智能装备制造有限公司', 'SN202609140031', 31, 'GZZ0031', '热处理车间', NULL, NULL, 'OFFLINE', NULL, NULL, 14, NULL, '由工位台账自动生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `eq_equipment` VALUES (32, '000000', 'EQ0032', '回火炉', 'FURNACE', 'MODEL-FURNACE', '浙江智能装备制造有限公司', 'SN202609140032', 32, 'GZZ0032', '热处理车间', NULL, NULL, 'OFFLINE', NULL, NULL, 15, NULL, '由工位台账自动生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `eq_equipment` VALUES (33, '000000', 'EQ0033', '渗碳炉', 'FURNACE', 'MODEL-FURNACE', '浙江智能装备制造有限公司', 'SN202609140033', 33, 'GZZ0033', '热处理车间', NULL, NULL, 'OFFLINE', NULL, NULL, 16, NULL, '由工位台账自动生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `eq_equipment` VALUES (34, '000000', 'EQ0034', '电镀线', 'PLATING', 'MODEL-PLATING', '浙江智能装备制造有限公司', 'SN202609140034', 34, 'GZZ0034', '表面处理车间', NULL, NULL, 'NORMAL', NULL, NULL, NULL, NULL, '由工位台账自动生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `eq_equipment` VALUES (35, '000000', 'EQ0035', '阳极氧化线', 'ANODIZE', 'MODEL-ANODIZE', '浙江智能装备制造有限公司', 'SN202609140035', 35, 'GZZ0035', '表面处理车间', NULL, NULL, 'NORMAL', NULL, NULL, NULL, NULL, '由工位台账自动生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `eq_equipment` VALUES (36, '000000', 'EQ0036', '喷塑线', 'COATING', 'MODEL-COATING', '浙江智能装备制造有限公司', 'SN202609140036', 36, 'GZZ0036', '表面处理车间', NULL, NULL, 'NORMAL', NULL, NULL, NULL, NULL, '由工位台账自动生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `eq_equipment` VALUES (37, '000000', 'EQ0037', '喷漆房', 'COATING', 'MODEL-COATING', '浙江智能装备制造有限公司', 'SN202609140037', 37, 'GZZ0037', '表面处理车间', NULL, NULL, 'NORMAL', NULL, NULL, NULL, NULL, '由工位台账自动生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `eq_equipment` VALUES (38, '000000', 'EQ0038', '丝印工位', 'GENERAL', 'MODEL-GEN', '浙江智能装备制造有限公司', 'SN202609140038', 38, 'GZZ0038', '表面处理车间', NULL, NULL, 'NORMAL', NULL, NULL, NULL, NULL, '由工位台账自动生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `eq_equipment` VALUES (39, '000000', 'EQ0039', 'SMT贴片线', 'SMT', 'MODEL-SMT', '浙江智能装备制造有限公司', 'SN202609140039', 39, 'GZZ0039', '电子车间', NULL, NULL, 'OFFLINE', NULL, NULL, 17, NULL, '由工位台账自动生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `eq_equipment` VALUES (40, '000000', 'EQ0040', '插件线', 'INSERT', 'MODEL-INSERT', '浙江智能装备制造有限公司', 'SN202609140040', 40, 'GZZ0040', '电子车间', NULL, NULL, 'NORMAL', NULL, NULL, NULL, NULL, '由工位台账自动生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `eq_equipment` VALUES (41, '000000', 'EQ0041', '波峰焊', 'WAVE', 'MODEL-WAVE', '浙江智能装备制造有限公司', 'SN202609140041', 41, 'GZZ0041', '电子车间', NULL, NULL, 'NORMAL', NULL, NULL, NULL, NULL, '由工位台账自动生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `eq_equipment` VALUES (42, '000000', 'EQ0042', '手工焊工位', 'SOLDERING', 'MODEL-SOLDERING', '浙江智能装备制造有限公司', 'SN202609140042', 42, 'GZZ0042', '电子车间', NULL, NULL, 'NORMAL', NULL, NULL, NULL, NULL, '由工位台账自动生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `eq_equipment` VALUES (43, '000000', 'EQ0043', '绕线机', 'WINDING', 'MODEL-WINDING', '浙江智能装备制造有限公司', 'SN202609140043', 43, 'GZZ0043', '电机车间', NULL, NULL, 'NORMAL', NULL, NULL, NULL, NULL, '由工位台账自动生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `eq_equipment` VALUES (44, '000000', 'EQ0044', '浸漆工位', 'VARNISH', 'MODEL-VARNISH', '浙江智能装备制造有限公司', 'SN202609140044', 44, 'GZZ0044', '电机车间', NULL, NULL, 'NORMAL', NULL, NULL, NULL, NULL, '由工位台账自动生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `eq_equipment` VALUES (45, '000000', 'EQ0045', '动平衡机', 'BALANCE', 'MODEL-BALANCE', '浙江智能装备制造有限公司', 'SN202609140045', 45, 'GZZ0045', '电机车间', NULL, NULL, 'NORMAL', NULL, NULL, NULL, NULL, '由工位台账自动生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `eq_equipment` VALUES (46, '000000', 'EQ0046', '装配线A', 'ASSEMBLY', 'MODEL-ASSEMBLY', '浙江智能装备制造有限公司', 'SN202609140046', 46, 'GZZ0046', '装配车间', NULL, NULL, 'OFFLINE', NULL, NULL, 18, NULL, '由工位台账自动生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `eq_equipment` VALUES (47, '000000', 'EQ0047', '装配线B', 'ASSEMBLY', 'MODEL-ASSEMBLY', '浙江智能装备制造有限公司', 'SN202609140047', 47, 'GZZ0047', '装配车间', NULL, NULL, 'OFFLINE', NULL, NULL, 19, NULL, '由工位台账自动生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `eq_equipment` VALUES (48, '000000', 'EQ0048', '调试工位', 'DEBUG', 'MODEL-DEBUG', '浙江智能装备制造有限公司', 'SN202609140048', 48, 'GZZ0048', '装配车间', NULL, NULL, 'NORMAL', NULL, NULL, NULL, NULL, '由工位台账自动生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `eq_equipment` VALUES (49, '000000', 'EQ0049', '功能测试工位', 'TEST', 'MODEL-TEST', '浙江智能装备制造有限公司', 'SN202609140049', 49, 'GZZ0049', '测试车间', NULL, NULL, 'OFFLINE', NULL, NULL, 20, NULL, '由工位台账自动生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `eq_equipment` VALUES (50, '000000', 'EQ0050', '老化房', 'AGING', 'MODEL-AGING', '浙江智能装备制造有限公司', 'SN202609140050', 50, 'GZZ0050', '测试车间', NULL, NULL, 'NORMAL', NULL, NULL, NULL, NULL, '由工位台账自动生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `eq_equipment` VALUES (51, '000000', 'EQ0051', '气密测试台', 'TEST', 'MODEL-TEST', '浙江智能装备制造有限公司', 'SN202609140051', 51, 'GZZ0051', '测试车间', NULL, NULL, 'OFFLINE', NULL, NULL, 21, NULL, '由工位台账自动生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `eq_equipment` VALUES (52, '000000', 'EQ0052', '精度检验台', 'INSPECTION', 'MODEL-INSPECTION', '浙江智能装备制造有限公司', 'SN202609140052', 52, 'GZZ0052', '测试车间', NULL, NULL, 'NORMAL', NULL, NULL, NULL, NULL, '由工位台账自动生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `eq_equipment` VALUES (53, '000000', 'EQ0053', '包装线A', 'PACKAGING', 'MODEL-PACKAGING', '浙江智能装备制造有限公司', 'SN202609140053', 53, 'GZZ0053', '包装车间', NULL, NULL, 'OFFLINE', NULL, NULL, 22, NULL, '由工位台账自动生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `eq_equipment` VALUES (54, '000000', 'EQ0054', '包装线B', 'PACKAGING', 'MODEL-PACKAGING', '浙江智能装备制造有限公司', 'SN202609140054', 54, 'GZZ0054', '包装车间', NULL, NULL, 'OFFLINE', NULL, NULL, 23, NULL, '由工位台账自动生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `eq_equipment` VALUES (55, '000000', 'EQ0055', '打包工位', 'PACKAGING', 'MODEL-PACKAGING', '浙江智能装备制造有限公司', 'SN202609140055', 55, 'GZZ0055', '包装车间', NULL, NULL, 'OFFLINE', NULL, NULL, 24, NULL, '由工位台账自动生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `eq_equipment` VALUES (56, '000000', 'EQ0056', '电火花机', 'EDM', 'MODEL-EDM', '浙江智能装备制造有限公司', 'SN202609140056', 56, 'GZZ0056', '模具车间', NULL, NULL, 'NORMAL', NULL, NULL, NULL, NULL, '由工位台账自动生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `eq_equipment` VALUES (57, '000000', 'EQ0057', '线切割机', 'WEDM', 'MODEL-WEDM', '浙江智能装备制造有限公司', 'SN202609140057', 57, 'GZZ0057', '模具车间', NULL, NULL, 'NORMAL', NULL, NULL, NULL, NULL, '由工位台账自动生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `eq_equipment` VALUES (58, '000000', 'EQ0058', '抛光工位', 'POLISH', 'MODEL-POLISH', '浙江智能装备制造有限公司', 'SN202609140058', 58, 'GZZ0058', '模具车间', NULL, NULL, 'NORMAL', NULL, NULL, NULL, NULL, '由工位台账自动生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');

-- ----------------------------
-- Table structure for eq_health_record
-- ----------------------------
DROP TABLE IF EXISTS `eq_health_record`;
CREATE TABLE `eq_health_record`  (
  `record_id` bigint(20) NOT NULL COMMENT '记录ID',
  `equipment_id` bigint(20) NOT NULL COMMENT '设备ID',
  `equipment_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '设备编码',
  `equipment_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '设备名称',
  `iot_device_id` bigint(20) NULL DEFAULT NULL COMMENT 'IoT设备ID',
  `score` int(11) NOT NULL COMMENT '健康评分(0-100)',
  `grade` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '等级: HIGH(>=80)/MEDIUM(>=60)/LOW(<60)',
  `anomaly_points` int(11) NULL DEFAULT 0 COMMENT '24h异常数据点数(z>3)',
  `repair_count_90d` int(11) NULL DEFAULT 0 COMMENT '90天内维修单数',
  `open_repair_count` int(11) NULL DEFAULT 0 COMMENT '未闭环维修单数',
  `detail_json` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT '明细JSON[{propertyCode,propertyName,mean,std,anomalyPoints}]',
  `prev_score` int(11) NULL DEFAULT NULL COMMENT '前次评分(对比趋势)',
  `score_change` int(11) NULL DEFAULT NULL COMMENT '评分变化(本次-前次)',
  `record_date` date NOT NULL COMMENT '评分日期',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT '000000' COMMENT '租户ID',
  `create_dept` bigint(20) NULL DEFAULT NULL COMMENT '创建部门',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建人',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新人',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT '0' COMMENT '删除标志',
  PRIMARY KEY (`record_id`) USING BTREE,
  UNIQUE INDEX `uk_tenant_eq_date`(`tenant_id`, `equipment_id`, `record_date`) USING BTREE,
  INDEX `idx_ehr_equipment`(`equipment_id`) USING BTREE,
  INDEX `idx_ehr_date`(`record_date`) USING BTREE,
  INDEX `idx_ehr_tenant`(`tenant_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '设备健康评分记录表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of eq_health_record
-- ----------------------------
INSERT INTO `eq_health_record` VALUES (2101691868394872835, 5, 'EQ0005', '数控车床A', 1, 100, 'HIGH', 0, 0, 0, '[]', NULL, NULL, '2026-09-20', '000000', -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_health_record` VALUES (2101691868461981698, 6, 'EQ0006', '数控车床B', 2, 100, 'HIGH', 0, 0, 0, '[]', NULL, NULL, '2026-09-20', '000000', -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_health_record` VALUES (2101691868461981700, 7, 'EQ0007', '加工中心A', 3, 100, 'HIGH', 0, 0, 0, '[]', NULL, NULL, '2026-09-20', '000000', -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_health_record` VALUES (2101691868524896260, 8, 'EQ0008', '铣床', 4, 100, 'HIGH', 0, 0, 0, '[]', NULL, NULL, '2026-09-20', '000000', -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_health_record` VALUES (2101691868587810818, 9, 'EQ0009', '磨床', 5, 100, 'HIGH', 0, 0, 0, '[]', NULL, NULL, '2026-09-20', '000000', -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_health_record` VALUES (2101691868654919681, 20, 'EQ0020', '氩弧焊工位', 6, 100, 'HIGH', 0, 0, 0, '[]', NULL, NULL, '2026-09-20', '000000', -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_health_record` VALUES (2101691868654919683, 21, 'EQ0021', '二保焊工位', 7, 100, 'HIGH', 0, 0, 0, '[]', NULL, NULL, '2026-09-20', '000000', -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_health_record` VALUES (2101691868722028546, 22, 'EQ0022', '点焊工位', 8, 100, 'HIGH', 0, 0, 0, '[]', NULL, NULL, '2026-09-20', '000000', -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_health_record` VALUES (2101691868784943105, 23, 'EQ0023', '打磨工位', 9, 100, 'HIGH', 0, 0, 0, '[]', NULL, NULL, '2026-09-20', '000000', -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_health_record` VALUES (2101691868784943107, 24, 'EQ0024', '注塑机A', 10, 100, 'HIGH', 0, 0, 0, '[]', NULL, NULL, '2026-09-20', '000000', -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_health_record` VALUES (2101691868847857666, 25, 'EQ0025', '注塑机B', 11, 100, 'HIGH', 0, 0, 0, '[]', NULL, NULL, '2026-09-20', '000000', -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_health_record` VALUES (2101691868914966529, 26, 'EQ0026', '注塑机C', 12, 100, 'HIGH', 0, 0, 0, '[]', NULL, NULL, '2026-09-20', '000000', -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_health_record` VALUES (2101691868914966532, 28, 'EQ0028', '熔炼炉', 13, 100, 'HIGH', 0, 0, 0, '[]', NULL, NULL, '2026-09-20', '000000', -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_health_record` VALUES (2101691868977881091, 31, 'EQ0031', '淬火炉', 14, 100, 'HIGH', 0, 0, 0, '[]', NULL, NULL, '2026-09-20', '000000', -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_health_record` VALUES (2101691869040795650, 32, 'EQ0032', '回火炉', 15, 100, 'HIGH', 0, 0, 0, '[]', NULL, NULL, '2026-09-20', '000000', -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_health_record` VALUES (2101691869040795653, 33, 'EQ0033', '渗碳炉', 16, 100, 'HIGH', 0, 0, 0, '[]', NULL, NULL, '2026-09-20', '000000', -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_health_record` VALUES (2101691869103710210, 39, 'EQ0039', 'SMT贴片线', 17, 100, 'HIGH', 0, 0, 0, '[]', NULL, NULL, '2026-09-20', '000000', -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_health_record` VALUES (2101691869166624770, 46, 'EQ0046', '装配线A', 18, 100, 'HIGH', 0, 0, 0, '[]', NULL, NULL, '2026-09-20', '000000', -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_health_record` VALUES (2101691869166624773, 47, 'EQ0047', '装配线B', 19, 100, 'HIGH', 0, 0, 0, '[]', NULL, NULL, '2026-09-20', '000000', -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_health_record` VALUES (2101691869233733635, 49, 'EQ0049', '功能测试工位', 20, 100, 'HIGH', 0, 0, 0, '[]', NULL, NULL, '2026-09-20', '000000', -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_health_record` VALUES (2101691869233733638, 51, 'EQ0051', '气密测试台', 21, 100, 'HIGH', 0, 0, 0, '[]', NULL, NULL, '2026-09-20', '000000', -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_health_record` VALUES (2101691869300842499, 53, 'EQ0053', '包装线A', 22, 100, 'HIGH', 0, 0, 0, '[]', NULL, NULL, '2026-09-20', '000000', -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_health_record` VALUES (2101691869367951361, 54, 'EQ0054', '包装线B', 23, 100, 'HIGH', 0, 0, 0, '[]', NULL, NULL, '2026-09-20', '000000', -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_health_record` VALUES (2101691869367951364, 55, 'EQ0055', '打包工位', 24, 100, 'HIGH', 0, 0, 0, '[]', NULL, NULL, '2026-09-20', '000000', -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_health_record` VALUES (2106157277633249281, 5, 'EQ0005', '数控车床A', 1, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-03', '000000', -1, -1, '2026-10-03 07:00:00', -1, '2026-10-03 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2106157277683580929, 6, 'EQ0006', '数控车床B', 2, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-03', '000000', -1, -1, '2026-10-03 07:00:00', -1, '2026-10-03 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2106157277725523970, 7, 'EQ0007', '加工中心A', 3, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-03', '000000', -1, -1, '2026-10-03 07:00:00', -1, '2026-10-03 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2106157277771661313, 8, 'EQ0008', '铣床', 4, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-03', '000000', -1, -1, '2026-10-03 07:00:00', -1, '2026-10-03 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2106157277809410050, 9, 'EQ0009', '磨床', 5, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-03', '000000', -1, -1, '2026-10-03 07:00:00', -1, '2026-10-03 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2106157277855547393, 20, 'EQ0020', '氩弧焊工位', 6, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-03', '000000', -1, -1, '2026-10-03 07:00:00', -1, '2026-10-03 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2106157277914267649, 21, 'EQ0021', '二保焊工位', 7, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-03', '000000', -1, -1, '2026-10-03 07:00:00', -1, '2026-10-03 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2106157277960404994, 22, 'EQ0022', '点焊工位', 8, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-03', '000000', -1, -1, '2026-10-03 07:00:00', -1, '2026-10-03 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2106157277993959425, 23, 'EQ0023', '打磨工位', 9, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-03', '000000', -1, -1, '2026-10-03 07:00:00', -1, '2026-10-03 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2106157278035902466, 24, 'EQ0024', '注塑机A', 10, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-03', '000000', -1, -1, '2026-10-03 07:00:00', -1, '2026-10-03 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2106157278086234114, 25, 'EQ0025', '注塑机B', 11, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-03', '000000', -1, -1, '2026-10-03 07:00:00', -1, '2026-10-03 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2106157278123982849, 26, 'EQ0026', '注塑机C', 12, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-03', '000000', -1, -1, '2026-10-03 07:00:00', -1, '2026-10-03 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2106157278165925889, 28, 'EQ0028', '熔炼炉', 13, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-03', '000000', -1, -1, '2026-10-03 07:00:00', -1, '2026-10-03 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2106157278207868929, 31, 'EQ0031', '淬火炉', 14, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-03', '000000', -1, -1, '2026-10-03 07:00:00', -1, '2026-10-03 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2106157278249811969, 32, 'EQ0032', '回火炉', 15, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-03', '000000', -1, -1, '2026-10-03 07:00:00', -1, '2026-10-03 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2106157278287560706, 33, 'EQ0033', '渗碳炉', 16, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-03', '000000', -1, -1, '2026-10-03 07:00:00', -1, '2026-10-03 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2106157278329503746, 39, 'EQ0039', 'SMT贴片线', 17, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-03', '000000', -1, -1, '2026-10-03 07:00:00', -1, '2026-10-03 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2106157278379835394, 46, 'EQ0046', '装配线A', 18, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-03', '000000', -1, -1, '2026-10-03 07:00:00', -1, '2026-10-03 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2106157278421778434, 47, 'EQ0047', '装配线B', 19, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-03', '000000', -1, -1, '2026-10-03 07:00:00', -1, '2026-10-03 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2106157278455332866, 49, 'EQ0049', '功能测试工位', 20, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-03', '000000', -1, -1, '2026-10-03 07:00:00', -1, '2026-10-03 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2106157278497275906, 51, 'EQ0051', '气密测试台', 21, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-03', '000000', -1, -1, '2026-10-03 07:00:00', -1, '2026-10-03 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2106157278535024642, 53, 'EQ0053', '包装线A', 22, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-03', '000000', -1, -1, '2026-10-03 07:00:00', -1, '2026-10-03 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2106157278572773378, 54, 'EQ0054', '包装线B', 23, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-03', '000000', -1, -1, '2026-10-03 07:00:00', -1, '2026-10-03 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2106157278623105025, 55, 'EQ0055', '打包工位', 24, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-03', '000000', -1, -1, '2026-10-03 07:00:00', -1, '2026-10-03 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2107244440974221314, 5, 'EQ0005', '数控车床A', 1, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-06', '000000', -1, -1, '2026-10-06 07:00:00', -1, '2026-10-06 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2107244441016164353, 6, 'EQ0006', '数控车床B', 2, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-06', '000000', -1, -1, '2026-10-06 07:00:00', -1, '2026-10-06 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2107244441058107394, 7, 'EQ0007', '加工中心A', 3, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-06', '000000', -1, -1, '2026-10-06 07:00:00', -1, '2026-10-06 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2107244441100050434, 8, 'EQ0008', '铣床', 4, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-06', '000000', -1, -1, '2026-10-06 07:00:00', -1, '2026-10-06 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2107244441141993474, 9, 'EQ0009', '磨床', 5, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-06', '000000', -1, -1, '2026-10-06 07:00:00', -1, '2026-10-06 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2107244441188130817, 20, 'EQ0020', '氩弧焊工位', 6, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-06', '000000', -1, -1, '2026-10-06 07:00:00', -1, '2026-10-06 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2107244441225879554, 21, 'EQ0021', '二保焊工位', 7, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-06', '000000', -1, -1, '2026-10-06 07:00:00', -1, '2026-10-06 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2107244441263628289, 22, 'EQ0022', '点焊工位', 8, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-06', '000000', -1, -1, '2026-10-06 07:00:00', -1, '2026-10-06 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2107244441305571329, 23, 'EQ0023', '打磨工位', 9, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-06', '000000', -1, -1, '2026-10-06 07:00:00', -1, '2026-10-06 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2107244441347514369, 24, 'EQ0024', '注塑机A', 10, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-06', '000000', -1, -1, '2026-10-06 07:00:00', -1, '2026-10-06 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2107244441389457409, 25, 'EQ0025', '注塑机B', 11, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-06', '000000', -1, -1, '2026-10-06 07:00:00', -1, '2026-10-06 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2107244441423011841, 26, 'EQ0026', '注塑机C', 12, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-06', '000000', -1, -1, '2026-10-06 07:00:00', -1, '2026-10-06 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2107244441464954882, 28, 'EQ0028', '熔炼炉', 13, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-06', '000000', -1, -1, '2026-10-06 07:00:00', -1, '2026-10-06 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2107244441511092225, 31, 'EQ0031', '淬火炉', 14, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-06', '000000', -1, -1, '2026-10-06 07:00:00', -1, '2026-10-06 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2107244441557229569, 32, 'EQ0032', '回火炉', 15, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-06', '000000', -1, -1, '2026-10-06 07:00:00', -1, '2026-10-06 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2107244441599172609, 33, 'EQ0033', '渗碳炉', 16, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-06', '000000', -1, -1, '2026-10-06 07:00:00', -1, '2026-10-06 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2107244441636921346, 39, 'EQ0039', 'SMT贴片线', 17, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-06', '000000', -1, -1, '2026-10-06 07:00:00', -1, '2026-10-06 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2107244441678864386, 46, 'EQ0046', '装配线A', 18, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-06', '000000', -1, -1, '2026-10-06 07:00:00', -1, '2026-10-06 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2107244441720807426, 47, 'EQ0047', '装配线B', 19, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-06', '000000', -1, -1, '2026-10-06 07:00:00', -1, '2026-10-06 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2107244441754361857, 49, 'EQ0049', '功能测试工位', 20, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-06', '000000', -1, -1, '2026-10-06 07:00:00', -1, '2026-10-06 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2107244441800499201, 51, 'EQ0051', '气密测试台', 21, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-06', '000000', -1, -1, '2026-10-06 07:00:00', -1, '2026-10-06 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2107244441834053633, 53, 'EQ0053', '包装线A', 22, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-06', '000000', -1, -1, '2026-10-06 07:00:00', -1, '2026-10-06 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2107244441875996673, 54, 'EQ0054', '包装线B', 23, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-06', '000000', -1, -1, '2026-10-06 07:00:00', -1, '2026-10-06 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2107244441913745409, 55, 'EQ0055', '打包工位', 24, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-06', '000000', -1, -1, '2026-10-06 07:00:00', -1, '2026-10-06 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2107606828739166210, 5, 'EQ0005', '数控车床A', 1, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-07', '000000', -1, -1, '2026-10-07 07:00:00', -1, '2026-10-07 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2107606828776914946, 6, 'EQ0006', '数控车床B', 2, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-07', '000000', -1, -1, '2026-10-07 07:00:00', -1, '2026-10-07 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2107606828818857985, 7, 'EQ0007', '加工中心A', 3, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-07', '000000', -1, -1, '2026-10-07 07:00:00', -1, '2026-10-07 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2107606828860801025, 8, 'EQ0008', '铣床', 4, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-07', '000000', -1, -1, '2026-10-07 07:00:00', -1, '2026-10-07 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2107606828902744066, 9, 'EQ0009', '磨床', 5, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-07', '000000', -1, -1, '2026-10-07 07:00:00', -1, '2026-10-07 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2107606828940492801, 20, 'EQ0020', '氩弧焊工位', 6, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-07', '000000', -1, -1, '2026-10-07 07:00:00', -1, '2026-10-07 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2107606828982435841, 21, 'EQ0021', '二保焊工位', 7, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-07', '000000', -1, -1, '2026-10-07 07:00:00', -1, '2026-10-07 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2107606829020184577, 22, 'EQ0022', '点焊工位', 8, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-07', '000000', -1, -1, '2026-10-07 07:00:00', -1, '2026-10-07 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2107606829057933314, 23, 'EQ0023', '打磨工位', 9, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-07', '000000', -1, -1, '2026-10-07 07:00:00', -1, '2026-10-07 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2107606829104070657, 24, 'EQ0024', '注塑机A', 10, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-07', '000000', -1, -1, '2026-10-07 07:00:00', -1, '2026-10-07 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2107606829137625089, 25, 'EQ0025', '注塑机B', 11, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-07', '000000', -1, -1, '2026-10-07 07:00:00', -1, '2026-10-07 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2107606829175373826, 26, 'EQ0026', '注塑机C', 12, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-07', '000000', -1, -1, '2026-10-07 07:00:00', -1, '2026-10-07 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2107606829217316865, 28, 'EQ0028', '熔炼炉', 13, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-07', '000000', -1, -1, '2026-10-07 07:00:00', -1, '2026-10-07 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2107606829255065601, 31, 'EQ0031', '淬火炉', 14, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-07', '000000', -1, -1, '2026-10-07 07:00:00', -1, '2026-10-07 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2107606829297008641, 32, 'EQ0032', '回火炉', 15, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-07', '000000', -1, -1, '2026-10-07 07:00:00', -1, '2026-10-07 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2107606829343145986, 33, 'EQ0033', '渗碳炉', 16, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-07', '000000', -1, -1, '2026-10-07 07:00:00', -1, '2026-10-07 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2107606829380894722, 39, 'EQ0039', 'SMT贴片线', 17, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-07', '000000', -1, -1, '2026-10-07 07:00:00', -1, '2026-10-07 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2107606829418643457, 46, 'EQ0046', '装配线A', 18, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-07', '000000', -1, -1, '2026-10-07 07:00:00', -1, '2026-10-07 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2107606829464780802, 47, 'EQ0047', '装配线B', 19, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-07', '000000', -1, -1, '2026-10-07 07:00:00', -1, '2026-10-07 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2107606829506723841, 49, 'EQ0049', '功能测试工位', 20, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-07', '000000', -1, -1, '2026-10-07 07:00:00', -1, '2026-10-07 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2107606829552861185, 51, 'EQ0051', '气密测试台', 21, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-07', '000000', -1, -1, '2026-10-07 07:00:00', -1, '2026-10-07 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2107606829590609921, 53, 'EQ0053', '包装线A', 22, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-07', '000000', -1, -1, '2026-10-07 07:00:00', -1, '2026-10-07 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2107606829628358658, 54, 'EQ0054', '包装线B', 23, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-07', '000000', -1, -1, '2026-10-07 07:00:00', -1, '2026-10-07 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2107606829666107394, 55, 'EQ0055', '打包工位', 24, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-07', '000000', -1, -1, '2026-10-07 07:00:00', -1, '2026-10-07 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2107969217045131265, 5, 'EQ0005', '数控车床A', 1, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-08', '000000', -1, -1, '2026-10-08 07:00:00', -1, '2026-10-08 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2107969217133211649, 6, 'EQ0006', '数控车床B', 2, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-08', '000000', -1, -1, '2026-10-08 07:00:00', -1, '2026-10-08 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2107969217196126209, 7, 'EQ0007', '加工中心A', 3, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-08', '000000', -1, -1, '2026-10-08 07:00:00', -1, '2026-10-08 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2107969217275817986, 8, 'EQ0008', '铣床', 4, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-08', '000000', -1, -1, '2026-10-08 07:00:00', -1, '2026-10-08 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2107969217347121154, 9, 'EQ0009', '磨床', 5, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-08', '000000', -1, -1, '2026-10-08 07:00:00', -1, '2026-10-08 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2107969217426812929, 20, 'EQ0020', '氩弧焊工位', 6, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-08', '000000', -1, -1, '2026-10-08 07:00:00', -1, '2026-10-08 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2107969217519087618, 21, 'EQ0021', '二保焊工位', 7, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-08', '000000', -1, -1, '2026-10-08 07:00:00', -1, '2026-10-08 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2107969217602973697, 22, 'EQ0022', '点焊工位', 8, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-08', '000000', -1, -1, '2026-10-08 07:00:00', -1, '2026-10-08 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2107969217691054081, 23, 'EQ0023', '打磨工位', 9, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-08', '000000', -1, -1, '2026-10-08 07:00:00', -1, '2026-10-08 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2107969217787523073, 24, 'EQ0024', '注塑机A', 10, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-08', '000000', -1, -1, '2026-10-08 07:00:00', -1, '2026-10-08 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2107969217871409153, 25, 'EQ0025', '注塑机B', 11, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-08', '000000', -1, -1, '2026-10-08 07:00:00', -1, '2026-10-08 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2107969217951100929, 26, 'EQ0026', '注塑机C', 12, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-08', '000000', -1, -1, '2026-10-08 07:00:00', -1, '2026-10-08 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2107969218030792705, 28, 'EQ0028', '熔炼炉', 13, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-08', '000000', -1, -1, '2026-10-08 07:00:00', -1, '2026-10-08 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2107969218110484482, 31, 'EQ0031', '淬火炉', 14, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-08', '000000', -1, -1, '2026-10-08 07:00:00', -1, '2026-10-08 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2107969218194370562, 32, 'EQ0032', '回火炉', 15, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-08', '000000', -1, -1, '2026-10-08 07:00:00', -1, '2026-10-08 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2107969218261479426, 33, 'EQ0033', '渗碳炉', 16, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-08', '000000', -1, -1, '2026-10-08 07:00:00', -1, '2026-10-08 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2107969218345365505, 39, 'EQ0039', 'SMT贴片线', 17, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-08', '000000', -1, -1, '2026-10-08 07:00:00', -1, '2026-10-08 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2107969218425057282, 46, 'EQ0046', '装配线A', 18, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-08', '000000', -1, -1, '2026-10-08 07:00:01', -1, '2026-10-08 07:00:01', '0');
INSERT INTO `eq_health_record` VALUES (2107969218504749058, 47, 'EQ0047', '装配线B', 19, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-08', '000000', -1, -1, '2026-10-08 07:00:01', -1, '2026-10-08 07:00:01', '0');
INSERT INTO `eq_health_record` VALUES (2107969218609606658, 49, 'EQ0049', '功能测试工位', 20, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-08', '000000', -1, -1, '2026-10-08 07:00:01', -1, '2026-10-08 07:00:01', '0');
INSERT INTO `eq_health_record` VALUES (2107969218701881346, 51, 'EQ0051', '气密测试台', 21, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-08', '000000', -1, -1, '2026-10-08 07:00:01', -1, '2026-10-08 07:00:01', '0');
INSERT INTO `eq_health_record` VALUES (2107969218810933250, 53, 'EQ0053', '包装线A', 22, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-08', '000000', -1, -1, '2026-10-08 07:00:01', -1, '2026-10-08 07:00:01', '0');
INSERT INTO `eq_health_record` VALUES (2107969218932568066, 54, 'EQ0054', '包装线B', 23, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-08', '000000', -1, -1, '2026-10-08 07:00:01', -1, '2026-10-08 07:00:01', '0');
INSERT INTO `eq_health_record` VALUES (2107969219020648450, 55, 'EQ0055', '打包工位', 24, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-08', '000000', -1, -1, '2026-10-08 07:00:01', -1, '2026-10-08 07:00:01', '0');
INSERT INTO `eq_health_record` VALUES (2108331604810100738, 5, 'EQ0005', '数控车床A', 1, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-09', '000000', -1, -1, '2026-10-09 07:00:00', -1, '2026-10-09 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2108331604856238082, 6, 'EQ0006', '数控车床B', 2, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-09', '000000', -1, -1, '2026-10-09 07:00:00', -1, '2026-10-09 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2108331604898181121, 7, 'EQ0007', '加工中心A', 3, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-09', '000000', -1, -1, '2026-10-09 07:00:00', -1, '2026-10-09 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2108331604927541249, 8, 'EQ0008', '铣床', 4, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-09', '000000', -1, -1, '2026-10-09 07:00:00', -1, '2026-10-09 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2108331604969484290, 9, 'EQ0009', '磨床', 5, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-09', '000000', -1, -1, '2026-10-09 07:00:00', -1, '2026-10-09 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2108331605003038722, 20, 'EQ0020', '氩弧焊工位', 6, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-09', '000000', -1, -1, '2026-10-09 07:00:00', -1, '2026-10-09 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2108331605036593153, 21, 'EQ0021', '二保焊工位', 7, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-09', '000000', -1, -1, '2026-10-09 07:00:00', -1, '2026-10-09 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2108331605074341890, 22, 'EQ0022', '点焊工位', 8, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-09', '000000', -1, -1, '2026-10-09 07:00:00', -1, '2026-10-09 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2108331605107896322, 23, 'EQ0023', '打磨工位', 9, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-09', '000000', -1, -1, '2026-10-09 07:00:00', -1, '2026-10-09 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2108331605149839362, 24, 'EQ0024', '注塑机A', 10, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-09', '000000', -1, -1, '2026-10-09 07:00:00', -1, '2026-10-09 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2108331605179199489, 25, 'EQ0025', '注塑机B', 11, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-09', '000000', -1, -1, '2026-10-09 07:00:00', -1, '2026-10-09 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2108331605216948225, 26, 'EQ0026', '注塑机C', 12, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-09', '000000', -1, -1, '2026-10-09 07:00:00', -1, '2026-10-09 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2108331605246308353, 28, 'EQ0028', '熔炼炉', 13, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-09', '000000', -1, -1, '2026-10-09 07:00:00', -1, '2026-10-09 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2108331605284057090, 31, 'EQ0031', '淬火炉', 14, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-09', '000000', -1, -1, '2026-10-09 07:00:00', -1, '2026-10-09 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2108331605326000130, 32, 'EQ0032', '回火炉', 15, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-09', '000000', -1, -1, '2026-10-09 07:00:00', -1, '2026-10-09 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2108331605359554561, 33, 'EQ0033', '渗碳炉', 16, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-09', '000000', -1, -1, '2026-10-09 07:00:00', -1, '2026-10-09 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2108331605393108994, 39, 'EQ0039', 'SMT贴片线', 17, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-09', '000000', -1, -1, '2026-10-09 07:00:00', -1, '2026-10-09 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2108331605430857730, 46, 'EQ0046', '装配线A', 18, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-09', '000000', -1, -1, '2026-10-09 07:00:00', -1, '2026-10-09 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2108331605464412162, 47, 'EQ0047', '装配线B', 19, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-09', '000000', -1, -1, '2026-10-09 07:00:00', -1, '2026-10-09 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2108331605502160897, 49, 'EQ0049', '功能测试工位', 20, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-09', '000000', -1, -1, '2026-10-09 07:00:00', -1, '2026-10-09 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2108331605531521025, 51, 'EQ0051', '气密测试台', 21, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-09', '000000', -1, -1, '2026-10-09 07:00:00', -1, '2026-10-09 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2108331605565075457, 53, 'EQ0053', '包装线A', 22, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-09', '000000', -1, -1, '2026-10-09 07:00:00', -1, '2026-10-09 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2108331605607018498, 54, 'EQ0054', '包装线B', 23, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-09', '000000', -1, -1, '2026-10-09 07:00:00', -1, '2026-10-09 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2108331605636378625, 55, 'EQ0055', '打包工位', 24, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-09', '000000', -1, -1, '2026-10-09 07:00:00', -1, '2026-10-09 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2111593095311024130, 5, 'EQ0005', '数控车床A', 1, 95, 'HIGH', 0, 1, 0, '[]', 100, -5, '2026-10-18', '000000', -1, -1, '2026-10-18 07:00:00', -1, '2026-10-18 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2111593095373938689, 6, 'EQ0006', '数控车床B', 2, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-18', '000000', -1, -1, '2026-10-18 07:00:00', -1, '2026-10-18 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2111593095373938690, 7, 'EQ0007', '加工中心A', 3, 95, 'HIGH', 0, 1, 0, '[]', 100, -5, '2026-10-18', '000000', -1, -1, '2026-10-18 07:00:00', -1, '2026-10-18 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2111593095441047553, 8, 'EQ0008', '铣床', 4, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-18', '000000', -1, -1, '2026-10-18 07:00:00', -1, '2026-10-18 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2111593095503962113, 9, 'EQ0009', '磨床', 5, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-18', '000000', -1, -1, '2026-10-18 07:00:00', -1, '2026-10-18 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2111593095503962114, 20, 'EQ0020', '氩弧焊工位', 6, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-18', '000000', -1, -1, '2026-10-18 07:00:00', -1, '2026-10-18 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2111593095571070977, 21, 'EQ0021', '二保焊工位', 7, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-18', '000000', -1, -1, '2026-10-18 07:00:00', -1, '2026-10-18 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2111593095638179842, 22, 'EQ0022', '点焊工位', 8, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-18', '000000', -1, -1, '2026-10-18 07:00:00', -1, '2026-10-18 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2111593095638179843, 23, 'EQ0023', '打磨工位', 9, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-18', '000000', -1, -1, '2026-10-18 07:00:00', -1, '2026-10-18 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2111593095701094401, 24, 'EQ0024', '注塑机A', 10, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-18', '000000', -1, -1, '2026-10-18 07:00:00', -1, '2026-10-18 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2111593095768203265, 25, 'EQ0025', '注塑机B', 11, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-18', '000000', -1, -1, '2026-10-18 07:00:00', -1, '2026-10-18 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2111593095768203266, 26, 'EQ0026', '注塑机C', 12, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-18', '000000', -1, -1, '2026-10-18 07:00:00', -1, '2026-10-18 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2111593095835312130, 28, 'EQ0028', '熔炼炉', 13, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-18', '000000', -1, -1, '2026-10-18 07:00:00', -1, '2026-10-18 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2111593095898226690, 31, 'EQ0031', '淬火炉', 14, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-18', '000000', -1, -1, '2026-10-18 07:00:00', -1, '2026-10-18 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2111593095898226691, 32, 'EQ0032', '回火炉', 15, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-18', '000000', -1, -1, '2026-10-18 07:00:00', -1, '2026-10-18 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2111593095961141249, 33, 'EQ0033', '渗碳炉', 16, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-18', '000000', -1, -1, '2026-10-18 07:00:00', -1, '2026-10-18 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2111593096036638721, 39, 'EQ0039', 'SMT贴片线', 17, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-18', '000000', -1, -1, '2026-10-18 07:00:00', -1, '2026-10-18 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2111593096036638722, 46, 'EQ0046', '装配线A', 18, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-18', '000000', -1, -1, '2026-10-18 07:00:00', -1, '2026-10-18 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2111593096095358977, 47, 'EQ0047', '装配线B', 19, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-18', '000000', -1, -1, '2026-10-18 07:00:00', -1, '2026-10-18 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2111593096162467841, 49, 'EQ0049', '功能测试工位', 20, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-18', '000000', -1, -1, '2026-10-18 07:00:00', -1, '2026-10-18 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2111593096162467842, 51, 'EQ0051', '气密测试台', 21, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-18', '000000', -1, -1, '2026-10-18 07:00:00', -1, '2026-10-18 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2111593096229576705, 53, 'EQ0053', '包装线A', 22, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-18', '000000', -1, -1, '2026-10-18 07:00:00', -1, '2026-10-18 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2111593096292491265, 54, 'EQ0054', '包装线B', 23, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-18', '000000', -1, -1, '2026-10-18 07:00:00', -1, '2026-10-18 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2111593096292491266, 55, 'EQ0055', '打包工位', 24, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-18', '000000', -1, -1, '2026-10-18 07:00:00', -1, '2026-10-18 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2111955483143127041, 5, 'EQ0005', '数控车床A', 1, 95, 'HIGH', 0, 1, 0, '[]', 95, 0, '2026-10-19', '000000', -1, -1, '2026-10-19 07:00:00', -1, '2026-10-19 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2111955483210235905, 6, 'EQ0006', '数控车床B', 2, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-19', '000000', -1, -1, '2026-10-19 07:00:00', -1, '2026-10-19 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2111955483210235906, 7, 'EQ0007', '加工中心A', 3, 95, 'HIGH', 0, 1, 0, '[]', 95, 0, '2026-10-19', '000000', -1, -1, '2026-10-19 07:00:00', -1, '2026-10-19 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2111955483281539073, 8, 'EQ0008', '铣床', 4, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-19', '000000', -1, -1, '2026-10-19 07:00:00', -1, '2026-10-19 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2111955483281539074, 9, 'EQ0009', '磨床', 5, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-19', '000000', -1, -1, '2026-10-19 07:00:00', -1, '2026-10-19 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2111955483340259329, 20, 'EQ0020', '氩弧焊工位', 6, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-19', '000000', -1, -1, '2026-10-19 07:00:00', -1, '2026-10-19 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2111955483403173889, 21, 'EQ0021', '二保焊工位', 7, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-19', '000000', -1, -1, '2026-10-19 07:00:00', -1, '2026-10-19 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2111955483403173890, 22, 'EQ0022', '点焊工位', 8, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-19', '000000', -1, -1, '2026-10-19 07:00:00', -1, '2026-10-19 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2111955483470282753, 23, 'EQ0023', '打磨工位', 9, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-19', '000000', -1, -1, '2026-10-19 07:00:00', -1, '2026-10-19 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2111955483470282754, 24, 'EQ0024', '注塑机A', 10, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-19', '000000', -1, -1, '2026-10-19 07:00:00', -1, '2026-10-19 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2111955483533197313, 25, 'EQ0025', '注塑机B', 11, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-19', '000000', -1, -1, '2026-10-19 07:00:00', -1, '2026-10-19 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2111955483533197314, 26, 'EQ0026', '注塑机C', 12, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-19', '000000', -1, -1, '2026-10-19 07:00:00', -1, '2026-10-19 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2111955483596111873, 28, 'EQ0028', '熔炼炉', 13, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-19', '000000', -1, -1, '2026-10-19 07:00:00', -1, '2026-10-19 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2111955483596111874, 31, 'EQ0031', '淬火炉', 14, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-19', '000000', -1, -1, '2026-10-19 07:00:00', -1, '2026-10-19 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2111955483663220738, 32, 'EQ0032', '回火炉', 15, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-19', '000000', -1, -1, '2026-10-19 07:00:00', -1, '2026-10-19 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2111955483726135297, 33, 'EQ0033', '渗碳炉', 16, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-19', '000000', -1, -1, '2026-10-19 07:00:00', -1, '2026-10-19 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2111955483726135298, 39, 'EQ0039', 'SMT贴片线', 17, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-19', '000000', -1, -1, '2026-10-19 07:00:00', -1, '2026-10-19 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2111955483789049857, 46, 'EQ0046', '装配线A', 18, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-19', '000000', -1, -1, '2026-10-19 07:00:00', -1, '2026-10-19 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2111955483789049858, 47, 'EQ0047', '装配线B', 19, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-19', '000000', -1, -1, '2026-10-19 07:00:00', -1, '2026-10-19 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2111955483851964417, 49, 'EQ0049', '功能测试工位', 20, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-19', '000000', -1, -1, '2026-10-19 07:00:00', -1, '2026-10-19 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2111955483851964418, 51, 'EQ0051', '气密测试台', 21, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-19', '000000', -1, -1, '2026-10-19 07:00:00', -1, '2026-10-19 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2111955483919073282, 53, 'EQ0053', '包装线A', 22, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-19', '000000', -1, -1, '2026-10-19 07:00:00', -1, '2026-10-19 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2111955483919073283, 54, 'EQ0054', '包装线B', 23, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-19', '000000', -1, -1, '2026-10-19 07:00:00', -1, '2026-10-19 07:00:00', '0');
INSERT INTO `eq_health_record` VALUES (2111955483981987841, 55, 'EQ0055', '打包工位', 24, 100, 'HIGH', 0, 0, 0, '[]', 100, 0, '2026-10-19', '000000', -1, -1, '2026-10-19 07:00:00', -1, '2026-10-19 07:00:00', '0');

-- ----------------------------
-- Table structure for eq_inspection_record
-- ----------------------------
DROP TABLE IF EXISTS `eq_inspection_record`;
CREATE TABLE `eq_inspection_record`  (
  `record_id` bigint(20) NOT NULL COMMENT '记录ID',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '000000' COMMENT '租户ID',
  `equipment_id` bigint(20) NOT NULL COMMENT '设备ID',
  `station_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '工位编码(工位终端提交时留痕)',
  `inspector_id` bigint(20) NULL DEFAULT NULL COMMENT '点检人ID',
  `inspector_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '点检人姓名',
  `operator_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '点检人工号(设备通道免登录留痕)',
  `inspect_time` datetime(0) NOT NULL COMMENT '点检时间',
  `results` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '逐项点检明细 JSON: [{item,standard,actual,pass}]',
  `overall_pass` varchar(8) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '总判定: Y合格/N不合格',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '备注',
  `create_dept` bigint(20) NULL DEFAULT NULL,
  `create_by` bigint(20) NULL DEFAULT NULL,
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP,
  `update_by` bigint(20) NULL DEFAULT NULL,
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP(0),
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '删除标志',
  PRIMARY KEY (`record_id`) USING BTREE,
  INDEX `idx_equipment_id`(`equipment_id`) USING BTREE,
  INDEX `idx_inspect_time`(`inspect_time`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '设备点检记录(历史留痕, PC端与工位终端共用)' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for eq_maintenance_plan
-- ----------------------------
DROP TABLE IF EXISTS `eq_maintenance_plan`;
CREATE TABLE `eq_maintenance_plan`  (
  `plan_id` bigint(20) NOT NULL COMMENT '计划ID(主键)',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '000000',
  `plan_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '计划名称',
  `equipment_id` bigint(20) NOT NULL COMMENT '设备ID',
  `maintenance_type` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'DAILY/WEEKLY/MONTHLY/QUARTERLY/YEARLY',
  `cycle_days` int(11) NULL DEFAULT NULL COMMENT '周期(天)',
  `next_date` date NULL DEFAULT NULL COMMENT '下次保养日期(自动计算)',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT '保养内容',
  `responsible_id` bigint(20) NULL DEFAULT NULL COMMENT '负责人ID',
  `responsible_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '负责人姓名',
  `status` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT 'ACTIVE' COMMENT 'ACTIVE/INACTIVE',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '备注',
  `create_dept` bigint(20) NULL DEFAULT NULL COMMENT '创建部门',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT '0' COMMENT '删除标志',
  PRIMARY KEY (`plan_id`) USING BTREE,
  INDEX `idx_equipment_id`(`equipment_id`) USING BTREE,
  INDEX `idx_next_date`(`next_date`) USING BTREE,
  INDEX `idx_status`(`status`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = 'MES设备保养计划' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for eq_maintenance_record
-- ----------------------------
DROP TABLE IF EXISTS `eq_maintenance_record`;
CREATE TABLE `eq_maintenance_record`  (
  `record_id` bigint(20) NOT NULL COMMENT '记录ID(主键)',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '000000',
  `plan_id` bigint(20) NULL DEFAULT NULL COMMENT '关联保养计划ID(可空)',
  `equipment_id` bigint(20) NOT NULL COMMENT '设备ID',
  `maintenance_type` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '保养类型(冗余)',
  `executor_id` bigint(20) NULL DEFAULT NULL COMMENT '执行人ID',
  `executor_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '执行人姓名',
  `execute_time` datetime(0) NULL DEFAULT NULL COMMENT '执行时间',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT '保养内容/执行情况',
  `result` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT 'NORMAL' COMMENT 'NORMAL/ABNORMAL',
  `duration_minutes` decimal(10, 2) NULL DEFAULT NULL COMMENT '保养占用时长(分钟), 供OEE的maintenance_minutes真实汇总',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `create_dept` bigint(20) NULL DEFAULT NULL,
  `create_by` bigint(20) NULL DEFAULT NULL,
  `create_time` datetime(0) NULL DEFAULT NULL,
  `update_by` bigint(20) NULL DEFAULT NULL,
  `update_time` datetime(0) NULL DEFAULT NULL,
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT '0',
  PRIMARY KEY (`record_id`) USING BTREE,
  INDEX `idx_equipment_id`(`equipment_id`) USING BTREE,
  INDEX `idx_plan_id`(`plan_id`) USING BTREE,
  INDEX `idx_execute_time`(`execute_time`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = 'MES设备保养执行记录' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for eq_oee_record
-- ----------------------------
DROP TABLE IF EXISTS `eq_oee_record`;
CREATE TABLE `eq_oee_record`  (
  `record_id` bigint(20) NOT NULL COMMENT '记录ID(主键)',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '000000',
  `equipment_id` bigint(20) NOT NULL COMMENT '设备ID',
  `equipment_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '设备编码(冗余)',
  `equipment_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '设备名称(冗余)',
  `equipment_type` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '设备类型(冗余)',
  `workcenter_id` bigint(20) NULL DEFAULT NULL COMMENT '工作中心ID(冗余, 车间级聚合用)',
  `stat_date` date NOT NULL COMMENT '统计日期(日粒度)',
  `planned_minutes` decimal(10, 2) NULL DEFAULT 480.00 COMMENT '计划生产时长(分钟, 首版默认480=8h单班)',
  `downtime_minutes` decimal(10, 2) NULL DEFAULT 0.00 COMMENT '停机时长(分钟, 来自 eq_repair.downtime_hours 求和)',
  `maintenance_minutes` decimal(10, 2) NULL DEFAULT 0.00 COMMENT '保养占用时长(分钟, 预留, 首版0)',
  `run_minutes` decimal(10, 2) NULL DEFAULT 0.00 COMMENT '运行时长(分钟, = planned - downtime - maintenance)',
  `fault_count` int(11) NULL DEFAULT 0 COMMENT '故障次数(eq_repair 当日报修数)',
  `availability` decimal(6, 4) NULL DEFAULT 0.0000 COMMENT '可用率/稼动率(0~1), = run/planned',
  `performance_rate` decimal(6, 4) NULL DEFAULT 1.0000 COMMENT '表现率(首版占位1.0, 待工单报工数据补全)',
  `quality_rate` decimal(6, 4) NULL DEFAULT 1.0000 COMMENT '质量率(首版占位1.0, 待质量数据补全)',
  `oee` decimal(6, 4) NULL DEFAULT 0.0000 COMMENT 'OEE = availability * performance * quality',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `create_dept` bigint(20) NULL DEFAULT NULL,
  `create_by` bigint(20) NULL DEFAULT NULL,
  `create_time` datetime(0) NULL DEFAULT NULL,
  `update_by` bigint(20) NULL DEFAULT NULL,
  `update_time` datetime(0) NULL DEFAULT NULL,
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT '0',
  PRIMARY KEY (`record_id`) USING BTREE,
  UNIQUE INDEX `uk_tenant_eq_date`(`tenant_id`, `equipment_id`, `stat_date`) USING BTREE,
  INDEX `idx_equipment_id`(`equipment_id`) USING BTREE,
  INDEX `idx_stat_date`(`stat_date`) USING BTREE,
  INDEX `idx_workcenter_id`(`workcenter_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = 'MES设备 OEE 聚合记录(日粒度)' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of eq_oee_record
-- ----------------------------
INSERT INTO `eq_oee_record` VALUES (2101691868394872834, '000000', 1, 'EQ0001', '激光切割机', 'LASER', 1, '2026-09-19', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, NULL, -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_oee_record` VALUES (2101691868394872836, '000000', 2, 'EQ0002', '等离子切割机', 'PLASMA', 2, '2026-09-19', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, NULL, -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_oee_record` VALUES (2101691868461981699, '000000', 3, 'EQ0003', '剪板机', 'SHEAR', 3, '2026-09-19', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, NULL, -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_oee_record` VALUES (2101691868524896258, '000000', 4, 'EQ0004', '锯床', 'SAW', 4, '2026-09-19', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, NULL, -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_oee_record` VALUES (2101691868524896259, '000000', 5, 'EQ0005', '数控车床A', 'CNC', 5, '2026-09-19', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, NULL, -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_oee_record` VALUES (2101691868587810819, '000000', 6, 'EQ0006', '数控车床B', 'CNC', 6, '2026-09-19', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, NULL, -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_oee_record` VALUES (2101691868587810820, '000000', 7, 'EQ0007', '加工中心A', 'CNC', 7, '2026-09-19', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, NULL, -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_oee_record` VALUES (2101691868654919682, '000000', 8, 'EQ0008', '铣床', 'MILL', 8, '2026-09-19', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, NULL, -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_oee_record` VALUES (2101691868654919684, '000000', 9, 'EQ0009', '磨床', 'GRIND', 9, '2026-09-19', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, NULL, -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_oee_record` VALUES (2101691868722028545, '000000', 10, 'EQ0010', '钻床', 'DRILL', 10, '2026-09-19', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, NULL, -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_oee_record` VALUES (2101691868722028547, '000000', 11, 'EQ0011', '滚齿机', 'GENERAL', 11, '2026-09-19', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, NULL, -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_oee_record` VALUES (2101691868784943106, '000000', 12, 'EQ0012', '冲床A', 'PUNCH', 12, '2026-09-19', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, NULL, -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_oee_record` VALUES (2101691868784943108, '000000', 13, 'EQ0013', '冲床B', 'PUNCH', 13, '2026-09-19', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, NULL, -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_oee_record` VALUES (2101691868847857665, '000000', 14, 'EQ0014', '折弯机', 'BEND', 14, '2026-09-19', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, NULL, -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_oee_record` VALUES (2101691868847857667, '000000', 15, 'EQ0015', '油压机', 'PRESS', 15, '2026-09-19', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, NULL, -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_oee_record` VALUES (2101691868914966530, '000000', 16, 'EQ0016', '锻造机', 'GENERAL', 16, '2026-09-19', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, NULL, -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_oee_record` VALUES (2101691868914966531, '000000', 17, 'EQ0017', '折弯工位', 'GENERAL', 17, '2026-09-19', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, NULL, -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_oee_record` VALUES (2101691868977881090, '000000', 18, 'EQ0018', '卷圆工位', 'ROLL', 18, '2026-09-19', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, NULL, -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_oee_record` VALUES (2101691868977881092, '000000', 19, 'EQ0019', '冲孔工位', 'PUNCH', 19, '2026-09-19', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, NULL, -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_oee_record` VALUES (2101691869040795651, '000000', 20, 'EQ0020', '氩弧焊工位', 'WELDING', 20, '2026-09-19', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, NULL, -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_oee_record` VALUES (2101691869040795652, '000000', 21, 'EQ0021', '二保焊工位', 'WELDING', 21, '2026-09-19', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, NULL, -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_oee_record` VALUES (2101691869103710209, '000000', 22, 'EQ0022', '点焊工位', 'WELDING', 22, '2026-09-19', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, NULL, -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_oee_record` VALUES (2101691869103710211, '000000', 23, 'EQ0023', '打磨工位', 'GRIND', 23, '2026-09-19', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, NULL, -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_oee_record` VALUES (2101691869166624771, '000000', 24, 'EQ0024', '注塑机A', 'INJECT', 24, '2026-09-19', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, NULL, -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_oee_record` VALUES (2101691869166624772, '000000', 25, 'EQ0025', '注塑机B', 'INJECT', 25, '2026-09-19', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, NULL, -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_oee_record` VALUES (2101691869233733634, '000000', 26, 'EQ0026', '注塑机C', 'INJECT', 26, '2026-09-19', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, NULL, -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_oee_record` VALUES (2101691869233733636, '000000', 27, 'EQ0027', '去毛刺工位', 'DEBURR', 27, '2026-09-19', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, NULL, -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_oee_record` VALUES (2101691869233733637, '000000', 28, 'EQ0028', '熔炼炉', 'FURNACE', 28, '2026-09-19', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, NULL, -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_oee_record` VALUES (2101691869300842498, '000000', 29, 'EQ0029', '压铸机', 'DIE_CAST', 29, '2026-09-19', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, NULL, -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_oee_record` VALUES (2101691869300842500, '000000', 30, 'EQ0030', '清砂工位', 'CLEAN', 30, '2026-09-19', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, NULL, -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_oee_record` VALUES (2101691869367951362, '000000', 31, 'EQ0031', '淬火炉', 'FURNACE', 31, '2026-09-19', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, NULL, -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_oee_record` VALUES (2101691869367951363, '000000', 32, 'EQ0032', '回火炉', 'FURNACE', 32, '2026-09-19', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, NULL, -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_oee_record` VALUES (2101691869435060225, '000000', 33, 'EQ0033', '渗碳炉', 'FURNACE', 33, '2026-09-19', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, NULL, -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_oee_record` VALUES (2101691869435060226, '000000', 34, 'EQ0034', '电镀线', 'PLATING', 34, '2026-09-19', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, NULL, -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_oee_record` VALUES (2101691869497974785, '000000', 35, 'EQ0035', '阳极氧化线', 'ANODIZE', 35, '2026-09-19', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, NULL, -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_oee_record` VALUES (2101691869497974786, '000000', 36, 'EQ0036', '喷塑线', 'COATING', 36, '2026-09-19', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, NULL, -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_oee_record` VALUES (2101691869497974787, '000000', 37, 'EQ0037', '喷漆房', 'COATING', 37, '2026-09-19', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, NULL, -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_oee_record` VALUES (2101691869560889346, '000000', 38, 'EQ0038', '丝印工位', 'GENERAL', 38, '2026-09-19', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, NULL, -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_oee_record` VALUES (2101691869560889347, '000000', 39, 'EQ0039', 'SMT贴片线', 'SMT', 39, '2026-09-19', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, NULL, -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_oee_record` VALUES (2101691869623803905, '000000', 40, 'EQ0040', '插件线', 'INSERT', 40, '2026-09-19', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, NULL, -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_oee_record` VALUES (2101691869623803906, '000000', 41, 'EQ0041', '波峰焊', 'WAVE', 41, '2026-09-19', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, NULL, -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_oee_record` VALUES (2101691869690912770, '000000', 42, 'EQ0042', '手工焊工位', 'SOLDERING', 42, '2026-09-19', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, NULL, -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_oee_record` VALUES (2101691869690912771, '000000', 43, 'EQ0043', '绕线机', 'WINDING', 43, '2026-09-19', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, NULL, -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_oee_record` VALUES (2101691869690912772, '000000', 44, 'EQ0044', '浸漆工位', 'VARNISH', 44, '2026-09-19', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, NULL, -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_oee_record` VALUES (2101691869820936194, '000000', 45, 'EQ0045', '动平衡机', 'BALANCE', 45, '2026-09-19', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, NULL, -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_oee_record` VALUES (2101691870080983041, '000000', 46, 'EQ0046', '装配线A', 'ASSEMBLY', 46, '2026-09-19', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, NULL, -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_oee_record` VALUES (2101691870206812162, '000000', 47, 'EQ0047', '装配线B', 'ASSEMBLY', 47, '2026-09-19', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, NULL, -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_oee_record` VALUES (2101691870273921025, '000000', 48, 'EQ0048', '调试工位', 'DEBUG', 48, '2026-09-19', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, NULL, -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_oee_record` VALUES (2101691870336835586, '000000', 49, 'EQ0049', '功能测试工位', 'TEST', 49, '2026-09-19', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, NULL, -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_oee_record` VALUES (2101691870399750145, '000000', 50, 'EQ0050', '老化房', 'AGING', 50, '2026-09-19', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, NULL, -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_oee_record` VALUES (2101691870462664705, '000000', 51, 'EQ0051', '气密测试台', 'TEST', 51, '2026-09-19', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, NULL, -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_oee_record` VALUES (2101691870462664706, '000000', 52, 'EQ0052', '精度检验台', 'INSPECTION', 52, '2026-09-19', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, NULL, -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_oee_record` VALUES (2101691870529773570, '000000', 53, 'EQ0053', '包装线A', 'PACKAGING', 53, '2026-09-19', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, NULL, -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_oee_record` VALUES (2101691870592688129, '000000', 54, 'EQ0054', '包装线B', 'PACKAGING', 54, '2026-09-19', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, NULL, -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_oee_record` VALUES (2101691870592688130, '000000', 55, 'EQ0055', '打包工位', 'PACKAGING', 55, '2026-09-19', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, NULL, -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_oee_record` VALUES (2101691870659796994, '000000', 56, 'EQ0056', '电火花机', 'EDM', 56, '2026-09-19', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, NULL, -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_oee_record` VALUES (2101691870722711553, '000000', 57, 'EQ0057', '线切割机', 'WEDM', 57, '2026-09-19', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, NULL, -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_oee_record` VALUES (2101691870722711554, '000000', 58, 'EQ0058', '抛光工位', 'POLISH', 58, '2026-09-19', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, NULL, -1, -1, '2026-09-20 23:16:04', -1, '2026-09-20 23:16:04', '0');
INSERT INTO `eq_oee_record` VALUES (2105341905061531649, '000000', 1, 'EQ0001', '激光切割机', 'LASER', 1, '2026-09-30', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-01 01:00:00', -1, '2026-10-01 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2105341905128640513, '000000', 2, 'EQ0002', '等离子切割机', 'PLASMA', 2, '2026-09-30', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-01 01:00:00', -1, '2026-10-01 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2105341905187360770, '000000', 3, 'EQ0003', '剪板机', 'SHEAR', 3, '2026-09-30', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-01 01:00:00', -1, '2026-10-01 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2105341905241886721, '000000', 4, 'EQ0004', '锯床', 'SAW', 4, '2026-09-30', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-01 01:00:00', -1, '2026-10-01 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2105341905300606977, '000000', 5, 'EQ0005', '数控车床A', 'CNC', 5, '2026-09-30', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-01 01:00:00', -1, '2026-10-01 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2105341905376104449, '000000', 6, 'EQ0006', '数控车床B', 'CNC', 6, '2026-09-30', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-01 01:00:00', -1, '2026-10-01 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2105341905439019009, '000000', 7, 'EQ0007', '加工中心A', 'CNC', 7, '2026-09-30', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-01 01:00:00', -1, '2026-10-01 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2105341905501933569, '000000', 8, 'EQ0008', '铣床', 'MILL', 8, '2026-09-30', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-01 01:00:00', -1, '2026-10-01 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2105341905560653825, '000000', 9, 'EQ0009', '磨床', 'GRIND', 9, '2026-09-30', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-01 01:00:00', -1, '2026-10-01 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2105341905627762690, '000000', 10, 'EQ0010', '钻床', 'DRILL', 10, '2026-09-30', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-01 01:00:00', -1, '2026-10-01 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2105341905686482945, '000000', 11, 'EQ0011', '滚齿机', 'GENERAL', 11, '2026-09-30', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-01 01:00:00', -1, '2026-10-01 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2105341905749397506, '000000', 12, 'EQ0012', '冲床A', 'PUNCH', 12, '2026-09-30', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-01 01:00:00', -1, '2026-10-01 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2105341905816506369, '000000', 13, 'EQ0013', '冲床B', 'PUNCH', 13, '2026-09-30', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-01 01:00:00', -1, '2026-10-01 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2105341905879420929, '000000', 14, 'EQ0014', '折弯机', 'BEND', 14, '2026-09-30', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-01 01:00:00', -1, '2026-10-01 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2105341905946529794, '000000', 15, 'EQ0015', '油压机', 'PRESS', 15, '2026-09-30', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-01 01:00:00', -1, '2026-10-01 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2105341906017832961, '000000', 16, 'EQ0016', '锻造机', 'GENERAL', 16, '2026-09-30', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-01 01:00:00', -1, '2026-10-01 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2105341906089136130, '000000', 17, 'EQ0017', '折弯工位', 'GENERAL', 17, '2026-09-30', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-01 01:00:00', -1, '2026-10-01 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2105341906143662081, '000000', 18, 'EQ0018', '卷圆工位', 'ROLL', 18, '2026-09-30', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-01 01:00:00', -1, '2026-10-01 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2105341906210770945, '000000', 19, 'EQ0019', '冲孔工位', 'PUNCH', 19, '2026-09-30', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-01 01:00:00', -1, '2026-10-01 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2105341906273685506, '000000', 20, 'EQ0020', '氩弧焊工位', 'WELDING', 20, '2026-09-30', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-01 01:00:00', -1, '2026-10-01 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2105341906328211457, '000000', 21, 'EQ0021', '二保焊工位', 'WELDING', 21, '2026-09-30', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-01 01:00:00', -1, '2026-10-01 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2105341906399514625, '000000', 22, 'EQ0022', '点焊工位', 'WELDING', 22, '2026-09-30', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-01 01:00:01', -1, '2026-10-01 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2105341906454040577, '000000', 23, 'EQ0023', '打磨工位', 'GRIND', 23, '2026-09-30', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-01 01:00:01', -1, '2026-10-01 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2105341906512760834, '000000', 24, 'EQ0024', '注塑机A', 'INJECT', 24, '2026-09-30', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-01 01:00:01', -1, '2026-10-01 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2105341906575675393, '000000', 25, 'EQ0025', '注塑机B', 'INJECT', 25, '2026-09-30', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-01 01:00:01', -1, '2026-10-01 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2105341906630201346, '000000', 26, 'EQ0026', '注塑机C', 'INJECT', 26, '2026-09-30', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-01 01:00:01', -1, '2026-10-01 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2105341906693115905, '000000', 27, 'EQ0027', '去毛刺工位', 'DEBURR', 27, '2026-09-30', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-01 01:00:01', -1, '2026-10-01 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2105341906743447554, '000000', 28, 'EQ0028', '熔炼炉', 'FURNACE', 28, '2026-09-30', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-01 01:00:01', -1, '2026-10-01 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2105341906806362114, '000000', 29, 'EQ0029', '压铸机', 'DIE_CAST', 29, '2026-09-30', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-01 01:00:01', -1, '2026-10-01 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2105341906869276673, '000000', 30, 'EQ0030', '清砂工位', 'CLEAN', 30, '2026-09-30', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-01 01:00:01', -1, '2026-10-01 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2105341906919608322, '000000', 31, 'EQ0031', '淬火炉', 'FURNACE', 31, '2026-09-30', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-01 01:00:01', -1, '2026-10-01 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2105341906978328578, '000000', 32, 'EQ0032', '回火炉', 'FURNACE', 32, '2026-09-30', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-01 01:00:01', -1, '2026-10-01 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2105341907032854529, '000000', 33, 'EQ0033', '渗碳炉', 'FURNACE', 33, '2026-09-30', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-01 01:00:01', -1, '2026-10-01 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2105341907091574785, '000000', 34, 'EQ0034', '电镀线', 'PLATING', 34, '2026-09-30', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-01 01:00:01', -1, '2026-10-01 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2105341907150295042, '000000', 35, 'EQ0035', '阳极氧化线', 'ANODIZE', 35, '2026-09-30', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-01 01:00:01', -1, '2026-10-01 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2105341907200626690, '000000', 36, 'EQ0036', '喷塑线', 'COATING', 36, '2026-09-30', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-01 01:00:01', -1, '2026-10-01 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2105341907259346946, '000000', 37, 'EQ0037', '喷漆房', 'COATING', 37, '2026-09-30', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-01 01:00:01', -1, '2026-10-01 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2105341907318067202, '000000', 38, 'EQ0038', '丝印工位', 'GENERAL', 38, '2026-09-30', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-01 01:00:01', -1, '2026-10-01 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2105341907376787457, '000000', 39, 'EQ0039', 'SMT贴片线', 'SMT', 39, '2026-09-30', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-01 01:00:01', -1, '2026-10-01 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2105341907427119105, '000000', 40, 'EQ0040', '插件线', 'INSERT', 40, '2026-09-30', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-01 01:00:01', -1, '2026-10-01 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2105341907481645057, '000000', 41, 'EQ0041', '波峰焊', 'WAVE', 41, '2026-09-30', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-01 01:00:01', -1, '2026-10-01 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2105341907540365313, '000000', 42, 'EQ0042', '手工焊工位', 'SOLDERING', 42, '2026-09-30', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-01 01:00:01', -1, '2026-10-01 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2105341907599085570, '000000', 43, 'EQ0043', '绕线机', 'WINDING', 43, '2026-09-30', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-01 01:00:01', -1, '2026-10-01 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2105341907657805826, '000000', 44, 'EQ0044', '浸漆工位', 'VARNISH', 44, '2026-09-30', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-01 01:00:01', -1, '2026-10-01 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2105341907716526082, '000000', 45, 'EQ0045', '动平衡机', 'BALANCE', 45, '2026-09-30', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-01 01:00:01', -1, '2026-10-01 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2105341907787829249, '000000', 46, 'EQ0046', '装配线A', 'ASSEMBLY', 46, '2026-09-30', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-01 01:00:01', -1, '2026-10-01 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2105341907846549505, '000000', 47, 'EQ0047', '装配线B', 'ASSEMBLY', 47, '2026-09-30', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-01 01:00:01', -1, '2026-10-01 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2105341907909464065, '000000', 48, 'EQ0048', '调试工位', 'DEBUG', 48, '2026-09-30', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-01 01:00:01', -1, '2026-10-01 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2105341907963990018, '000000', 49, 'EQ0049', '功能测试工位', 'TEST', 49, '2026-09-30', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-01 01:00:01', -1, '2026-10-01 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2105341908031098882, '000000', 50, 'EQ0050', '老化房', 'AGING', 50, '2026-09-30', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-01 01:00:01', -1, '2026-10-01 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2105341908089819137, '000000', 51, 'EQ0051', '气密测试台', 'TEST', 51, '2026-09-30', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-01 01:00:01', -1, '2026-10-01 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2105341908144345089, '000000', 52, 'EQ0052', '精度检验台', 'INSPECTION', 52, '2026-09-30', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-01 01:00:01', -1, '2026-10-01 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2105341908211453954, '000000', 53, 'EQ0053', '包装线A', 'PACKAGING', 53, '2026-09-30', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-01 01:00:01', -1, '2026-10-01 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2105341908265979906, '000000', 54, 'EQ0054', '包装线B', 'PACKAGING', 54, '2026-09-30', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-01 01:00:01', -1, '2026-10-01 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2105341908316311553, '000000', 55, 'EQ0055', '打包工位', 'PACKAGING', 55, '2026-09-30', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-01 01:00:01', -1, '2026-10-01 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2105341908375031810, '000000', 56, 'EQ0056', '电火花机', 'EDM', 56, '2026-09-30', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-01 01:00:01', -1, '2026-10-01 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2105341908437946370, '000000', 57, 'EQ0057', '线切割机', 'WEDM', 57, '2026-09-30', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-01 01:00:01', -1, '2026-10-01 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2105341908500860929, '000000', 58, 'EQ0058', '抛光工位', 'POLISH', 58, '2026-09-30', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-01 01:00:01', -1, '2026-10-01 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2105704292994211841, '000000', 1, 'EQ0001', '激光切割机', 'LASER', 1, '2026-10-01', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-02 01:00:00', -1, '2026-10-02 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2105704293061320705, '000000', 2, 'EQ0002', '等离子切割机', 'PLASMA', 2, '2026-10-01', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-02 01:00:00', -1, '2026-10-02 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2105704293107458050, '000000', 3, 'EQ0003', '剪板机', 'SHEAR', 3, '2026-10-01', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-02 01:00:00', -1, '2026-10-02 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2105704293161984002, '000000', 4, 'EQ0004', '锯床', 'SAW', 4, '2026-10-01', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-02 01:00:00', -1, '2026-10-02 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2105704293212315649, '000000', 5, 'EQ0005', '数控车床A', 'CNC', 5, '2026-10-01', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算)', -1, -1, '2026-10-02 01:00:00', -1, '2026-10-02 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2105704293254258690, '000000', 6, 'EQ0006', '数控车床B', 'CNC', 6, '2026-10-01', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-02 01:00:00', -1, '2026-10-02 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2105704293300396033, '000000', 7, 'EQ0007', '加工中心A', 'CNC', 7, '2026-10-01', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-02 01:00:00', -1, '2026-10-02 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2105704293354921985, '000000', 8, 'EQ0008', '铣床', 'MILL', 8, '2026-10-01', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-02 01:00:00', -1, '2026-10-02 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2105704293405253633, '000000', 9, 'EQ0009', '磨床', 'GRIND', 9, '2026-10-01', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-02 01:00:00', -1, '2026-10-02 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2105704293455585282, '000000', 10, 'EQ0010', '钻床', 'DRILL', 10, '2026-10-01', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-02 01:00:00', -1, '2026-10-02 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2105704293510111234, '000000', 11, 'EQ0011', '滚齿机', 'GENERAL', 11, '2026-10-01', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-02 01:00:00', -1, '2026-10-02 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2105704293556248577, '000000', 12, 'EQ0012', '冲床A', 'PUNCH', 12, '2026-10-01', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-02 01:00:00', -1, '2026-10-02 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2105704293598191618, '000000', 13, 'EQ0013', '冲床B', 'PUNCH', 13, '2026-10-01', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-02 01:00:00', -1, '2026-10-02 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2105704293644328962, '000000', 14, 'EQ0014', '折弯机', 'BEND', 14, '2026-10-01', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-02 01:00:00', -1, '2026-10-02 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2105704293690466306, '000000', 15, 'EQ0015', '油压机', 'PRESS', 15, '2026-10-01', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-02 01:00:00', -1, '2026-10-02 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2105704293744992258, '000000', 16, 'EQ0016', '锻造机', 'GENERAL', 16, '2026-10-01', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算)', -1, -1, '2026-10-02 01:00:00', -1, '2026-10-02 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2105704293791129602, '000000', 17, 'EQ0017', '折弯工位', 'GENERAL', 17, '2026-10-01', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-02 01:00:00', -1, '2026-10-02 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2105704293837266946, '000000', 18, 'EQ0018', '卷圆工位', 'ROLL', 18, '2026-10-01', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-02 01:00:00', -1, '2026-10-02 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2105704293891792898, '000000', 19, 'EQ0019', '冲孔工位', 'PUNCH', 19, '2026-10-01', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-02 01:00:00', -1, '2026-10-02 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2105704293933735938, '000000', 20, 'EQ0020', '氩弧焊工位', 'WELDING', 20, '2026-10-01', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-02 01:00:00', -1, '2026-10-02 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2105704293984067585, '000000', 21, 'EQ0021', '二保焊工位', 'WELDING', 21, '2026-10-01', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-02 01:00:00', -1, '2026-10-02 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2105704294034399234, '000000', 22, 'EQ0022', '点焊工位', 'WELDING', 22, '2026-10-01', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-02 01:00:00', -1, '2026-10-02 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2105704294080536577, '000000', 23, 'EQ0023', '打磨工位', 'GRIND', 23, '2026-10-01', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-02 01:00:00', -1, '2026-10-02 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2105704294130868225, '000000', 24, 'EQ0024', '注塑机A', 'INJECT', 24, '2026-10-01', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-02 01:00:00', -1, '2026-10-02 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2105704294177005570, '000000', 25, 'EQ0025', '注塑机B', 'INJECT', 25, '2026-10-01', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-02 01:00:00', -1, '2026-10-02 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2105704294218948610, '000000', 26, 'EQ0026', '注塑机C', 'INJECT', 26, '2026-10-01', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-02 01:00:00', -1, '2026-10-02 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2105704294269280258, '000000', 27, 'EQ0027', '去毛刺工位', 'DEBURR', 27, '2026-10-01', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-02 01:00:01', -1, '2026-10-02 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2105704294319611906, '000000', 28, 'EQ0028', '熔炼炉', 'FURNACE', 28, '2026-10-01', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-02 01:00:01', -1, '2026-10-02 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2105704294504161281, '000000', 29, 'EQ0029', '压铸机', 'DIE_CAST', 29, '2026-10-01', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-02 01:00:01', -1, '2026-10-02 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2105704294554492929, '000000', 30, 'EQ0030', '清砂工位', 'CLEAN', 30, '2026-10-01', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-02 01:00:01', -1, '2026-10-02 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2105704294604824578, '000000', 31, 'EQ0031', '淬火炉', 'FURNACE', 31, '2026-10-01', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算)', -1, -1, '2026-10-02 01:00:01', -1, '2026-10-02 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2105704294663544834, '000000', 32, 'EQ0032', '回火炉', 'FURNACE', 32, '2026-10-01', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算)', -1, -1, '2026-10-02 01:00:01', -1, '2026-10-02 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2105704294709682177, '000000', 33, 'EQ0033', '渗碳炉', 'FURNACE', 33, '2026-10-01', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-02 01:00:01', -1, '2026-10-02 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2105704294760013826, '000000', 34, 'EQ0034', '电镀线', 'PLATING', 34, '2026-10-01', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算)', -1, -1, '2026-10-02 01:00:01', -1, '2026-10-02 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2105704294806151170, '000000', 35, 'EQ0035', '阳极氧化线', 'ANODIZE', 35, '2026-10-01', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-02 01:00:01', -1, '2026-10-02 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2105704294864871425, '000000', 36, 'EQ0036', '喷塑线', 'COATING', 36, '2026-10-01', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-02 01:00:01', -1, '2026-10-02 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2105704294906814465, '000000', 37, 'EQ0037', '喷漆房', 'COATING', 37, '2026-10-01', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-02 01:00:01', -1, '2026-10-02 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2105704294957146113, '000000', 38, 'EQ0038', '丝印工位', 'GENERAL', 38, '2026-10-01', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-02 01:00:01', -1, '2026-10-02 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2105704295007477762, '000000', 39, 'EQ0039', 'SMT贴片线', 'SMT', 39, '2026-10-01', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-02 01:00:01', -1, '2026-10-02 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2105704295053615105, '000000', 40, 'EQ0040', '插件线', 'INSERT', 40, '2026-10-01', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-02 01:00:01', -1, '2026-10-02 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2105704295103946754, '000000', 41, 'EQ0041', '波峰焊', 'WAVE', 41, '2026-10-01', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-02 01:00:01', -1, '2026-10-02 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2105704295158472705, '000000', 42, 'EQ0042', '手工焊工位', 'SOLDERING', 42, '2026-10-01', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-02 01:00:01', -1, '2026-10-02 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2105704295212998657, '000000', 43, 'EQ0043', '绕线机', 'WINDING', 43, '2026-10-01', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-02 01:00:01', -1, '2026-10-02 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2105704295263330306, '000000', 44, 'EQ0044', '浸漆工位', 'VARNISH', 44, '2026-10-01', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-02 01:00:01', -1, '2026-10-02 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2105704295305273346, '000000', 45, 'EQ0045', '动平衡机', 'BALANCE', 45, '2026-10-01', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-02 01:00:01', -1, '2026-10-02 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2105704295355604994, '000000', 46, 'EQ0046', '装配线A', 'ASSEMBLY', 46, '2026-10-01', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-02 01:00:01', -1, '2026-10-02 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2105704295397548033, '000000', 47, 'EQ0047', '装配线B', 'ASSEMBLY', 47, '2026-10-01', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-02 01:00:01', -1, '2026-10-02 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2105704295447879682, '000000', 48, 'EQ0048', '调试工位', 'DEBUG', 48, '2026-10-01', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-02 01:00:01', -1, '2026-10-02 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2105704295494017025, '000000', 49, 'EQ0049', '功能测试工位', 'TEST', 49, '2026-10-01', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-02 01:00:01', -1, '2026-10-02 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2105704295544348673, '000000', 50, 'EQ0050', '老化房', 'AGING', 50, '2026-10-01', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-02 01:00:01', -1, '2026-10-02 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2105704295594680322, '000000', 51, 'EQ0051', '气密测试台', 'TEST', 51, '2026-10-01', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-02 01:00:01', -1, '2026-10-02 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2105704295653400578, '000000', 52, 'EQ0052', '精度检验台', 'INSPECTION', 52, '2026-10-01', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算)', -1, -1, '2026-10-02 01:00:01', -1, '2026-10-02 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2105704295712120834, '000000', 53, 'EQ0053', '包装线A', 'PACKAGING', 53, '2026-10-01', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算)', -1, -1, '2026-10-02 01:00:01', -1, '2026-10-02 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2105704295758258178, '000000', 54, 'EQ0054', '包装线B', 'PACKAGING', 54, '2026-10-01', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-02 01:00:01', -1, '2026-10-02 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2105704295808589825, '000000', 55, 'EQ0055', '打包工位', 'PACKAGING', 55, '2026-10-01', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-02 01:00:01', -1, '2026-10-02 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2105704295854727169, '000000', 56, 'EQ0056', '电火花机', 'EDM', 56, '2026-10-01', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-02 01:00:01', -1, '2026-10-02 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2105704295900864514, '000000', 57, 'EQ0057', '线切割机', 'WEDM', 57, '2026-10-01', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-02 01:00:01', -1, '2026-10-02 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2105704295942807553, '000000', 58, 'EQ0058', '抛光工位', 'POLISH', 58, '2026-10-01', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-02 01:00:01', -1, '2026-10-02 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2106066680780095489, '000000', 1, 'EQ0001', '激光切割机', 'LASER', 1, '2026-10-02', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-03 01:00:00', -1, '2026-10-03 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2106066680884953089, '000000', 2, 'EQ0002', '等离子切割机', 'PLASMA', 2, '2026-10-02', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-03 01:00:00', -1, '2026-10-03 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2106066680947867649, '000000', 3, 'EQ0003', '剪板机', 'SHEAR', 3, '2026-10-02', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-03 01:00:00', -1, '2026-10-03 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2106066681014976514, '000000', 4, 'EQ0004', '锯床', 'SAW', 4, '2026-10-02', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-03 01:00:00', -1, '2026-10-03 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2106066681073696770, '000000', 5, 'EQ0005', '数控车床A', 'CNC', 5, '2026-10-02', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-03 01:00:00', -1, '2026-10-03 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2106066681132417025, '000000', 6, 'EQ0006', '数控车床B', 'CNC', 6, '2026-10-02', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-03 01:00:00', -1, '2026-10-03 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2106066681199525889, '000000', 7, 'EQ0007', '加工中心A', 'CNC', 7, '2026-10-02', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-03 01:00:00', -1, '2026-10-03 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2106066681266634753, '000000', 8, 'EQ0008', '铣床', 'MILL', 8, '2026-10-02', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-03 01:00:00', -1, '2026-10-03 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2106066681325355009, '000000', 9, 'EQ0009', '磨床', 'GRIND', 9, '2026-10-02', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-03 01:00:00', -1, '2026-10-03 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2106066681396658177, '000000', 10, 'EQ0010', '钻床', 'DRILL', 10, '2026-10-02', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-03 01:00:00', -1, '2026-10-03 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2106066681493127170, '000000', 11, 'EQ0011', '滚齿机', 'GENERAL', 11, '2026-10-02', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-03 01:00:00', -1, '2026-10-03 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2106066681543458818, '000000', 12, 'EQ0012', '冲床A', 'PUNCH', 12, '2026-10-02', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-03 01:00:00', -1, '2026-10-03 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2106066681602179073, '000000', 13, 'EQ0013', '冲床B', 'PUNCH', 13, '2026-10-02', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-03 01:00:00', -1, '2026-10-03 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2106066681677676545, '000000', 14, 'EQ0014', '折弯机', 'BEND', 14, '2026-10-02', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-03 01:00:00', -1, '2026-10-03 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2106066681761562626, '000000', 15, 'EQ0015', '油压机', 'PRESS', 15, '2026-10-02', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-03 01:00:00', -1, '2026-10-03 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2106066681828671490, '000000', 16, 'EQ0016', '锻造机', 'GENERAL', 16, '2026-10-02', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-03 01:00:00', -1, '2026-10-03 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2106066681887391746, '000000', 17, 'EQ0017', '折弯工位', 'GENERAL', 17, '2026-10-02', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-03 01:00:00', -1, '2026-10-03 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2106066681950306306, '000000', 18, 'EQ0018', '卷圆工位', 'ROLL', 18, '2026-10-02', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-03 01:00:00', -1, '2026-10-03 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2106066682029998081, '000000', 19, 'EQ0019', '冲孔工位', 'PUNCH', 19, '2026-10-02', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-03 01:00:00', -1, '2026-10-03 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2106066682092912642, '000000', 20, 'EQ0020', '氩弧焊工位', 'WELDING', 20, '2026-10-02', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-03 01:00:00', -1, '2026-10-03 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2106066682151632898, '000000', 21, 'EQ0021', '二保焊工位', 'WELDING', 21, '2026-10-02', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-03 01:00:01', -1, '2026-10-03 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2106066682218741761, '000000', 22, 'EQ0022', '点焊工位', 'WELDING', 22, '2026-10-02', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-03 01:00:01', -1, '2026-10-03 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2106066682285850626, '000000', 23, 'EQ0023', '打磨工位', 'GRIND', 23, '2026-10-02', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-03 01:00:01', -1, '2026-10-03 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2106066682352959490, '000000', 24, 'EQ0024', '注塑机A', 'INJECT', 24, '2026-10-02', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-03 01:00:01', -1, '2026-10-03 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2106066682411679745, '000000', 25, 'EQ0025', '注塑机B', 'INJECT', 25, '2026-10-02', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-03 01:00:01', -1, '2026-10-03 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2106066682474594306, '000000', 26, 'EQ0026', '注塑机C', 'INJECT', 26, '2026-10-02', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-03 01:00:01', -1, '2026-10-03 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2106066682541703170, '000000', 27, 'EQ0027', '去毛刺工位', 'DEBURR', 27, '2026-10-02', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-03 01:00:01', -1, '2026-10-03 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2106066682604617729, '000000', 28, 'EQ0028', '熔炼炉', 'FURNACE', 28, '2026-10-02', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-03 01:00:01', -1, '2026-10-03 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2106066682671726594, '000000', 29, 'EQ0029', '压铸机', 'DIE_CAST', 29, '2026-10-02', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-03 01:00:01', -1, '2026-10-03 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2106066682734641154, '000000', 30, 'EQ0030', '清砂工位', 'CLEAN', 30, '2026-10-02', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-03 01:00:01', -1, '2026-10-03 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2106066682805944321, '000000', 31, 'EQ0031', '淬火炉', 'FURNACE', 31, '2026-10-02', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-03 01:00:01', -1, '2026-10-03 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2106066682873053185, '000000', 32, 'EQ0032', '回火炉', 'FURNACE', 32, '2026-10-02', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-03 01:00:01', -1, '2026-10-03 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2106066682931773441, '000000', 33, 'EQ0033', '渗碳炉', 'FURNACE', 33, '2026-10-02', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-03 01:00:01', -1, '2026-10-03 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2106066682994688001, '000000', 34, 'EQ0034', '电镀线', 'PLATING', 34, '2026-10-02', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-03 01:00:01', -1, '2026-10-03 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2106066683057602562, '000000', 35, 'EQ0035', '阳极氧化线', 'ANODIZE', 35, '2026-10-02', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-03 01:00:01', -1, '2026-10-03 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2106066683103739906, '000000', 36, 'EQ0036', '喷塑线', 'COATING', 36, '2026-10-02', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-03 01:00:01', -1, '2026-10-03 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2106066683154071554, '000000', 37, 'EQ0037', '喷漆房', 'COATING', 37, '2026-10-02', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-03 01:00:01', -1, '2026-10-03 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2106066683221180418, '000000', 38, 'EQ0038', '丝印工位', 'GENERAL', 38, '2026-10-02', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-03 01:00:01', -1, '2026-10-03 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2106066683275706369, '000000', 39, 'EQ0039', 'SMT贴片线', 'SMT', 39, '2026-10-02', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-03 01:00:01', -1, '2026-10-03 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2106066683326038017, '000000', 40, 'EQ0040', '插件线', 'INSERT', 40, '2026-10-02', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-03 01:00:01', -1, '2026-10-03 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2106066683393146882, '000000', 41, 'EQ0041', '波峰焊', 'WAVE', 41, '2026-10-02', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-03 01:00:01', -1, '2026-10-03 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2106066683456061441, '000000', 42, 'EQ0042', '手工焊工位', 'SOLDERING', 42, '2026-10-02', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-03 01:00:01', -1, '2026-10-03 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2106066683556724737, '000000', 43, 'EQ0043', '绕线机', 'WINDING', 43, '2026-10-02', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-03 01:00:01', -1, '2026-10-03 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2106066683623833601, '000000', 44, 'EQ0044', '浸漆工位', 'VARNISH', 44, '2026-10-02', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-03 01:00:01', -1, '2026-10-03 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2106066683699331073, '000000', 45, 'EQ0045', '动平衡机', 'BALANCE', 45, '2026-10-02', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-03 01:00:01', -1, '2026-10-03 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2106066683753857026, '000000', 46, 'EQ0046', '装配线A', 'ASSEMBLY', 46, '2026-10-02', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-03 01:00:01', -1, '2026-10-03 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2106066683816771585, '000000', 47, 'EQ0047', '装配线B', 'ASSEMBLY', 47, '2026-10-02', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-03 01:00:01', -1, '2026-10-03 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2106066683871297538, '000000', 48, 'EQ0048', '调试工位', 'DEBUG', 48, '2026-10-02', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-03 01:00:01', -1, '2026-10-03 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2106066683934212098, '000000', 49, 'EQ0049', '功能测试工位', 'TEST', 49, '2026-10-02', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-03 01:00:01', -1, '2026-10-03 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2106066683992932353, '000000', 50, 'EQ0050', '老化房', 'AGING', 50, '2026-10-02', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-03 01:00:01', -1, '2026-10-03 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2106066684043264001, '000000', 51, 'EQ0051', '气密测试台', 'TEST', 51, '2026-10-02', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-03 01:00:01', -1, '2026-10-03 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2106066684110372865, '000000', 52, 'EQ0052', '精度检验台', 'INSPECTION', 52, '2026-10-02', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-03 01:00:01', -1, '2026-10-03 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2106066684181676034, '000000', 53, 'EQ0053', '包装线A', 'PACKAGING', 53, '2026-10-02', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-03 01:00:01', -1, '2026-10-03 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2106066684236201986, '000000', 54, 'EQ0054', '包装线B', 'PACKAGING', 54, '2026-10-02', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-03 01:00:01', -1, '2026-10-03 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2106066684294922242, '000000', 55, 'EQ0055', '打包工位', 'PACKAGING', 55, '2026-10-02', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-03 01:00:01', -1, '2026-10-03 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2106066684366225409, '000000', 56, 'EQ0056', '电火花机', 'EDM', 56, '2026-10-02', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-03 01:00:01', -1, '2026-10-03 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2106066684429139970, '000000', 57, 'EQ0057', '线切割机', 'WEDM', 57, '2026-10-02', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-03 01:00:01', -1, '2026-10-03 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2106066684487860226, '000000', 58, 'EQ0058', '抛光工位', 'POLISH', 58, '2026-10-02', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-03 01:00:01', -1, '2026-10-03 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2106791456259657730, '000000', 1, 'EQ0001', '激光切割机', 'LASER', 1, '2026-10-04', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-05 01:00:00', -1, '2026-10-05 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2106791456318377985, '000000', 2, 'EQ0002', '等离子切割机', 'PLASMA', 2, '2026-10-04', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-05 01:00:00', -1, '2026-10-05 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2106791456364515329, '000000', 3, 'EQ0003', '剪板机', 'SHEAR', 3, '2026-10-04', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-05 01:00:00', -1, '2026-10-05 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2106791456431624194, '000000', 4, 'EQ0004', '锯床', 'SAW', 4, '2026-10-04', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-05 01:00:00', -1, '2026-10-05 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2106791456481955841, '000000', 5, 'EQ0005', '数控车床A', 'CNC', 5, '2026-10-04', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-05 01:00:00', -1, '2026-10-05 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2106791456532287490, '000000', 6, 'EQ0006', '数控车床B', 'CNC', 6, '2026-10-04', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-05 01:00:00', -1, '2026-10-05 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2106791456574230529, '000000', 7, 'EQ0007', '加工中心A', 'CNC', 7, '2026-10-04', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-05 01:00:00', -1, '2026-10-05 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2106791456632950785, '000000', 8, 'EQ0008', '铣床', 'MILL', 8, '2026-10-04', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-05 01:00:00', -1, '2026-10-05 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2106791456695865345, '000000', 9, 'EQ0009', '磨床', 'GRIND', 9, '2026-10-04', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-05 01:00:00', -1, '2026-10-05 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2106791456746196994, '000000', 10, 'EQ0010', '钻床', 'DRILL', 10, '2026-10-04', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-05 01:00:00', -1, '2026-10-05 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2106791456796528641, '000000', 11, 'EQ0011', '滚齿机', 'GENERAL', 11, '2026-10-04', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-05 01:00:00', -1, '2026-10-05 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2106791456846860290, '000000', 12, 'EQ0012', '冲床A', 'PUNCH', 12, '2026-10-04', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-05 01:00:00', -1, '2026-10-05 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2106791456901386241, '000000', 13, 'EQ0013', '冲床B', 'PUNCH', 13, '2026-10-04', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-05 01:00:00', -1, '2026-10-05 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2106791456955912194, '000000', 14, 'EQ0014', '折弯机', 'BEND', 14, '2026-10-04', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-05 01:00:00', -1, '2026-10-05 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2106791456997855233, '000000', 15, 'EQ0015', '油压机', 'PRESS', 15, '2026-10-04', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-05 01:00:00', -1, '2026-10-05 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2106791457060769793, '000000', 16, 'EQ0016', '锻造机', 'GENERAL', 16, '2026-10-04', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-05 01:00:00', -1, '2026-10-05 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2106791457102712834, '000000', 17, 'EQ0017', '折弯工位', 'GENERAL', 17, '2026-10-04', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-05 01:00:00', -1, '2026-10-05 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2106791457153044481, '000000', 18, 'EQ0018', '卷圆工位', 'ROLL', 18, '2026-10-04', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-05 01:00:00', -1, '2026-10-05 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2106791457203376129, '000000', 19, 'EQ0019', '冲孔工位', 'PUNCH', 19, '2026-10-04', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-05 01:00:00', -1, '2026-10-05 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2106791457249513474, '000000', 20, 'EQ0020', '氩弧焊工位', 'WELDING', 20, '2026-10-04', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-05 01:00:00', -1, '2026-10-05 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2106791457304039425, '000000', 21, 'EQ0021', '二保焊工位', 'WELDING', 21, '2026-10-04', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-05 01:00:00', -1, '2026-10-05 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2106791457354371073, '000000', 22, 'EQ0022', '点焊工位', 'WELDING', 22, '2026-10-04', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-05 01:00:00', -1, '2026-10-05 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2106791457404702721, '000000', 23, 'EQ0023', '打磨工位', 'GRIND', 23, '2026-10-04', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-05 01:00:00', -1, '2026-10-05 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2106791457455034370, '000000', 24, 'EQ0024', '注塑机A', 'INJECT', 24, '2026-10-04', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-05 01:00:00', -1, '2026-10-05 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2106791457501171714, '000000', 25, 'EQ0025', '注塑机B', 'INJECT', 25, '2026-10-04', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-05 01:00:00', -1, '2026-10-05 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2106791457555697666, '000000', 26, 'EQ0026', '注塑机C', 'INJECT', 26, '2026-10-04', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-05 01:00:00', -1, '2026-10-05 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2106791457614417921, '000000', 27, 'EQ0027', '去毛刺工位', 'DEBURR', 27, '2026-10-04', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-05 01:00:00', -1, '2026-10-05 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2106791457660555266, '000000', 28, 'EQ0028', '熔炼炉', 'FURNACE', 28, '2026-10-04', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-05 01:00:00', -1, '2026-10-05 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2106791457706692609, '000000', 29, 'EQ0029', '压铸机', 'DIE_CAST', 29, '2026-10-04', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-05 01:00:00', -1, '2026-10-05 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2106791457752829953, '000000', 30, 'EQ0030', '清砂工位', 'CLEAN', 30, '2026-10-04', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-05 01:00:00', -1, '2026-10-05 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2106791457811550209, '000000', 31, 'EQ0031', '淬火炉', 'FURNACE', 31, '2026-10-04', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-05 01:00:00', -1, '2026-10-05 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2106791457866076161, '000000', 32, 'EQ0032', '回火炉', 'FURNACE', 32, '2026-10-04', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-05 01:00:01', -1, '2026-10-05 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2106791457920602114, '000000', 33, 'EQ0033', '渗碳炉', 'FURNACE', 33, '2026-10-04', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-05 01:00:01', -1, '2026-10-05 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2106791457970933762, '000000', 34, 'EQ0034', '电镀线', 'PLATING', 34, '2026-10-04', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-05 01:00:01', -1, '2026-10-05 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2106791458025459713, '000000', 35, 'EQ0035', '阳极氧化线', 'ANODIZE', 35, '2026-10-04', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-05 01:00:01', -1, '2026-10-05 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2106791458067402753, '000000', 36, 'EQ0036', '喷塑线', 'COATING', 36, '2026-10-04', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-05 01:00:01', -1, '2026-10-05 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2106791458117734402, '000000', 37, 'EQ0037', '喷漆房', 'COATING', 37, '2026-10-04', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-05 01:00:01', -1, '2026-10-05 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2106791458176454657, '000000', 38, 'EQ0038', '丝印工位', 'GENERAL', 38, '2026-10-04', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-05 01:00:01', -1, '2026-10-05 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2106791458230980609, '000000', 39, 'EQ0039', 'SMT贴片线', 'SMT', 39, '2026-10-04', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-05 01:00:01', -1, '2026-10-05 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2106791458302283778, '000000', 40, 'EQ0040', '插件线', 'INSERT', 40, '2026-10-04', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-05 01:00:01', -1, '2026-10-05 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2106791458377781249, '000000', 41, 'EQ0041', '波峰焊', 'WAVE', 41, '2026-10-04', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-05 01:00:01', -1, '2026-10-05 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2106791458449084417, '000000', 42, 'EQ0042', '手工焊工位', 'SOLDERING', 42, '2026-10-04', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-05 01:00:01', -1, '2026-10-05 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2106791458516193282, '000000', 43, 'EQ0043', '绕线机', 'WINDING', 43, '2026-10-04', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-05 01:00:01', -1, '2026-10-05 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2106791458566524929, '000000', 44, 'EQ0044', '浸漆工位', 'VARNISH', 44, '2026-10-04', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-05 01:00:01', -1, '2026-10-05 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2106791458621050881, '000000', 45, 'EQ0045', '动平衡机', 'BALANCE', 45, '2026-10-04', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-05 01:00:01', -1, '2026-10-05 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2106791458675576833, '000000', 46, 'EQ0046', '装配线A', 'ASSEMBLY', 46, '2026-10-04', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-05 01:00:01', -1, '2026-10-05 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2106791458725908482, '000000', 47, 'EQ0047', '装配线B', 'ASSEMBLY', 47, '2026-10-04', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-05 01:00:01', -1, '2026-10-05 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2106791458772045825, '000000', 48, 'EQ0048', '调试工位', 'DEBUG', 48, '2026-10-04', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-05 01:00:01', -1, '2026-10-05 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2106791458822377473, '000000', 49, 'EQ0049', '功能测试工位', 'TEST', 49, '2026-10-04', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-05 01:00:01', -1, '2026-10-05 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2106791458881097729, '000000', 50, 'EQ0050', '老化房', 'AGING', 50, '2026-10-04', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-05 01:00:01', -1, '2026-10-05 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2106791458927235074, '000000', 51, 'EQ0051', '气密测试台', 'TEST', 51, '2026-10-04', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-05 01:00:01', -1, '2026-10-05 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2106791458977566722, '000000', 52, 'EQ0052', '精度检验台', 'INSPECTION', 52, '2026-10-04', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-05 01:00:01', -1, '2026-10-05 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2106791459027898369, '000000', 53, 'EQ0053', '包装线A', 'PACKAGING', 53, '2026-10-04', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-05 01:00:01', -1, '2026-10-05 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2106791459082424321, '000000', 54, 'EQ0054', '包装线B', 'PACKAGING', 54, '2026-10-04', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-05 01:00:01', -1, '2026-10-05 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2106791459128561666, '000000', 55, 'EQ0055', '打包工位', 'PACKAGING', 55, '2026-10-04', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-05 01:00:01', -1, '2026-10-05 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2106791459183087617, '000000', 56, 'EQ0056', '电火花机', 'EDM', 56, '2026-10-04', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-05 01:00:01', -1, '2026-10-05 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2106791459237613569, '000000', 57, 'EQ0057', '线切割机', 'WEDM', 57, '2026-10-04', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-05 01:00:01', -1, '2026-10-05 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2106791459296333825, '000000', 58, 'EQ0058', '抛光工位', 'POLISH', 58, '2026-10-04', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-05 01:00:01', -1, '2026-10-05 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107153844146233345, '000000', 1, 'EQ0001', '激光切割机', 'LASER', 1, '2026-10-05', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-06 01:00:00', -1, '2026-10-06 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107153844209147906, '000000', 2, 'EQ0002', '等离子切割机', 'PLASMA', 2, '2026-10-05', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-06 01:00:00', -1, '2026-10-06 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107153844251090946, '000000', 3, 'EQ0003', '剪板机', 'SHEAR', 3, '2026-10-05', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-06 01:00:00', -1, '2026-10-06 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107153844305616898, '000000', 4, 'EQ0004', '锯床', 'SAW', 4, '2026-10-05', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-06 01:00:00', -1, '2026-10-06 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107153844355948545, '000000', 5, 'EQ0005', '数控车床A', 'CNC', 5, '2026-10-05', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-06 01:00:00', -1, '2026-10-06 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107153844402085889, '000000', 6, 'EQ0006', '数控车床B', 'CNC', 6, '2026-10-05', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-06 01:00:00', -1, '2026-10-06 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107153844460806146, '000000', 7, 'EQ0007', '加工中心A', 'CNC', 7, '2026-10-05', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-06 01:00:00', -1, '2026-10-06 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107153844511137794, '000000', 8, 'EQ0008', '铣床', 'MILL', 8, '2026-10-05', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-06 01:00:00', -1, '2026-10-06 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107153844557275137, '000000', 9, 'EQ0009', '磨床', 'GRIND', 9, '2026-10-05', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-06 01:00:00', -1, '2026-10-06 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107153844603412482, '000000', 10, 'EQ0010', '钻床', 'DRILL', 10, '2026-10-05', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-06 01:00:00', -1, '2026-10-06 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107153844662132738, '000000', 11, 'EQ0011', '滚齿机', 'GENERAL', 11, '2026-10-05', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-06 01:00:00', -1, '2026-10-06 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107153844712464386, '000000', 12, 'EQ0012', '冲床A', 'PUNCH', 12, '2026-10-05', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-06 01:00:00', -1, '2026-10-06 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107153844766990337, '000000', 13, 'EQ0013', '冲床B', 'PUNCH', 13, '2026-10-05', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-06 01:00:00', -1, '2026-10-06 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107153844817321986, '000000', 14, 'EQ0014', '折弯机', 'BEND', 14, '2026-10-05', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-06 01:00:00', -1, '2026-10-06 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107153844867653634, '000000', 15, 'EQ0015', '油压机', 'PRESS', 15, '2026-10-05', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-06 01:00:00', -1, '2026-10-06 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107153844917985282, '000000', 16, 'EQ0016', '锻造机', 'GENERAL', 16, '2026-10-05', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-06 01:00:00', -1, '2026-10-06 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107153844968316930, '000000', 17, 'EQ0017', '折弯工位', 'GENERAL', 17, '2026-10-05', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-06 01:00:00', -1, '2026-10-06 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107153845022842882, '000000', 18, 'EQ0018', '卷圆工位', 'ROLL', 18, '2026-10-05', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-06 01:00:00', -1, '2026-10-06 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107153845068980226, '000000', 19, 'EQ0019', '冲孔工位', 'PUNCH', 19, '2026-10-05', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-06 01:00:00', -1, '2026-10-06 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107153845123506178, '000000', 20, 'EQ0020', '氩弧焊工位', 'WELDING', 20, '2026-10-05', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-06 01:00:00', -1, '2026-10-06 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107153845178032129, '000000', 21, 'EQ0021', '二保焊工位', 'WELDING', 21, '2026-10-05', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-06 01:00:00', -1, '2026-10-06 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107153845236752386, '000000', 22, 'EQ0022', '点焊工位', 'WELDING', 22, '2026-10-05', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-06 01:00:00', -1, '2026-10-06 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107153845278695425, '000000', 23, 'EQ0023', '打磨工位', 'GRIND', 23, '2026-10-05', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-06 01:00:00', -1, '2026-10-06 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107153845362581505, '000000', 24, 'EQ0024', '注塑机A', 'INJECT', 24, '2026-10-05', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-06 01:00:00', -1, '2026-10-06 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107153845412913154, '000000', 25, 'EQ0025', '注塑机B', 'INJECT', 25, '2026-10-05', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-06 01:00:00', -1, '2026-10-06 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107153845467439106, '000000', 26, 'EQ0026', '注塑机C', 'INJECT', 26, '2026-10-05', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-06 01:00:00', -1, '2026-10-06 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107153845521965057, '000000', 27, 'EQ0027', '去毛刺工位', 'DEBURR', 27, '2026-10-05', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-06 01:00:00', -1, '2026-10-06 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107153845572296705, '000000', 28, 'EQ0028', '熔炼炉', 'FURNACE', 28, '2026-10-05', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-06 01:00:00', -1, '2026-10-06 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107153845622628353, '000000', 29, 'EQ0029', '压铸机', 'DIE_CAST', 29, '2026-10-05', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-06 01:00:00', -1, '2026-10-06 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107153845668765697, '000000', 30, 'EQ0030', '清砂工位', 'CLEAN', 30, '2026-10-05', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-06 01:00:00', -1, '2026-10-06 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107153845723291650, '000000', 31, 'EQ0031', '淬火炉', 'FURNACE', 31, '2026-10-05', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-06 01:00:01', -1, '2026-10-06 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107153845773623297, '000000', 32, 'EQ0032', '回火炉', 'FURNACE', 32, '2026-10-05', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-06 01:00:01', -1, '2026-10-06 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107153845815566337, '000000', 33, 'EQ0033', '渗碳炉', 'FURNACE', 33, '2026-10-05', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-06 01:00:01', -1, '2026-10-06 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107153845861703682, '000000', 34, 'EQ0034', '电镀线', 'PLATING', 34, '2026-10-05', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-06 01:00:01', -1, '2026-10-06 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107153845916229634, '000000', 35, 'EQ0035', '阳极氧化线', 'ANODIZE', 35, '2026-10-05', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-06 01:00:01', -1, '2026-10-06 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107153845970755585, '000000', 36, 'EQ0036', '喷塑线', 'COATING', 36, '2026-10-05', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-06 01:00:01', -1, '2026-10-06 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107153846021087233, '000000', 37, 'EQ0037', '喷漆房', 'COATING', 37, '2026-10-05', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-06 01:00:01', -1, '2026-10-06 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107153846071418881, '000000', 38, 'EQ0038', '丝印工位', 'GENERAL', 38, '2026-10-05', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-06 01:00:01', -1, '2026-10-06 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107153846121750529, '000000', 39, 'EQ0039', 'SMT贴片线', 'SMT', 39, '2026-10-05', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-06 01:00:01', -1, '2026-10-06 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107153846176276482, '000000', 40, 'EQ0040', '插件线', 'INSERT', 40, '2026-10-05', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-06 01:00:01', -1, '2026-10-06 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107153846222413825, '000000', 41, 'EQ0041', '波峰焊', 'WAVE', 41, '2026-10-05', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-06 01:00:01', -1, '2026-10-06 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107153846268551169, '000000', 42, 'EQ0042', '手工焊工位', 'SOLDERING', 42, '2026-10-05', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-06 01:00:01', -1, '2026-10-06 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107153846339854338, '000000', 43, 'EQ0043', '绕线机', 'WINDING', 43, '2026-10-05', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-06 01:00:01', -1, '2026-10-06 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107153846390185985, '000000', 44, 'EQ0044', '浸漆工位', 'VARNISH', 44, '2026-10-05', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-06 01:00:01', -1, '2026-10-06 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107153846444711937, '000000', 45, 'EQ0045', '动平衡机', 'BALANCE', 45, '2026-10-05', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-06 01:00:01', -1, '2026-10-06 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107153846490849281, '000000', 46, 'EQ0046', '装配线A', 'ASSEMBLY', 46, '2026-10-05', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算)', -1, -1, '2026-10-06 01:00:01', -1, '2026-10-06 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107153846545375234, '000000', 47, 'EQ0047', '装配线B', 'ASSEMBLY', 47, '2026-10-05', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-06 01:00:01', -1, '2026-10-06 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107153846591512577, '000000', 48, 'EQ0048', '调试工位', 'DEBUG', 48, '2026-10-05', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-06 01:00:01', -1, '2026-10-06 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107153846641844226, '000000', 49, 'EQ0049', '功能测试工位', 'TEST', 49, '2026-10-05', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-06 01:00:01', -1, '2026-10-06 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107153846683787265, '000000', 50, 'EQ0050', '老化房', 'AGING', 50, '2026-10-05', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-06 01:00:01', -1, '2026-10-06 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107153846738313218, '000000', 51, 'EQ0051', '气密测试台', 'TEST', 51, '2026-10-05', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-06 01:00:01', -1, '2026-10-06 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107153846788644866, '000000', 52, 'EQ0052', '精度检验台', 'INSPECTION', 52, '2026-10-05', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算)', -1, -1, '2026-10-06 01:00:01', -1, '2026-10-06 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107153846838976514, '000000', 53, 'EQ0053', '包装线A', 'PACKAGING', 53, '2026-10-05', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-06 01:00:01', -1, '2026-10-06 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107153846889308162, '000000', 54, 'EQ0054', '包装线B', 'PACKAGING', 54, '2026-10-05', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-06 01:00:01', -1, '2026-10-06 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107153846943834114, '000000', 55, 'EQ0055', '打包工位', 'PACKAGING', 55, '2026-10-05', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-06 01:00:01', -1, '2026-10-06 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107153846989971458, '000000', 56, 'EQ0056', '电火花机', 'EDM', 56, '2026-10-05', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-06 01:00:01', -1, '2026-10-06 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107153847040303106, '000000', 57, 'EQ0057', '线切割机', 'WEDM', 57, '2026-10-05', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-06 01:00:01', -1, '2026-10-06 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107153847090634754, '000000', 58, 'EQ0058', '抛光工位', 'POLISH', 58, '2026-10-05', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-06 01:00:01', -1, '2026-10-06 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107516231831486465, '000000', 1, 'EQ0001', '激光切割机', 'LASER', 1, '2026-10-06', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-07 01:00:00', -1, '2026-10-07 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107516231890206721, '000000', 2, 'EQ0002', '等离子切割机', 'PLASMA', 2, '2026-10-06', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-07 01:00:00', -1, '2026-10-07 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107516231940538370, '000000', 3, 'EQ0003', '剪板机', 'SHEAR', 3, '2026-10-06', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-07 01:00:00', -1, '2026-10-07 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107516231982481410, '000000', 4, 'EQ0004', '锯床', 'SAW', 4, '2026-10-06', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-07 01:00:00', -1, '2026-10-07 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107516232028618753, '000000', 5, 'EQ0005', '数控车床A', 'CNC', 5, '2026-10-06', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-07 01:00:00', -1, '2026-10-07 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107516232070561794, '000000', 6, 'EQ0006', '数控车床B', 'CNC', 6, '2026-10-06', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-07 01:00:00', -1, '2026-10-07 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107516232129282049, '000000', 7, 'EQ0007', '加工中心A', 'CNC', 7, '2026-10-06', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-07 01:00:00', -1, '2026-10-07 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107516232171225090, '000000', 8, 'EQ0008', '铣床', 'MILL', 8, '2026-10-06', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-07 01:00:00', -1, '2026-10-07 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107516232238333953, '000000', 9, 'EQ0009', '磨床', 'GRIND', 9, '2026-10-06', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-07 01:00:00', -1, '2026-10-07 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107516232284471297, '000000', 10, 'EQ0010', '钻床', 'DRILL', 10, '2026-10-06', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-07 01:00:00', -1, '2026-10-07 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107516232326414337, '000000', 11, 'EQ0011', '滚齿机', 'GENERAL', 11, '2026-10-06', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-07 01:00:00', -1, '2026-10-07 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107516232389328897, '000000', 12, 'EQ0012', '冲床A', 'PUNCH', 12, '2026-10-06', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-07 01:00:00', -1, '2026-10-07 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107516232443854849, '000000', 13, 'EQ0013', '冲床B', 'PUNCH', 13, '2026-10-06', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-07 01:00:00', -1, '2026-10-07 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107516232502575105, '000000', 14, 'EQ0014', '折弯机', 'BEND', 14, '2026-10-06', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-07 01:00:00', -1, '2026-10-07 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107516232548712450, '000000', 15, 'EQ0015', '油压机', 'PRESS', 15, '2026-10-06', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-07 01:00:00', -1, '2026-10-07 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107516232603238401, '000000', 16, 'EQ0016', '锻造机', 'GENERAL', 16, '2026-10-06', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-07 01:00:00', -1, '2026-10-07 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107516232661958658, '000000', 17, 'EQ0017', '折弯工位', 'GENERAL', 17, '2026-10-06', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-07 01:00:00', -1, '2026-10-07 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107516232703901697, '000000', 18, 'EQ0018', '卷圆工位', 'ROLL', 18, '2026-10-06', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-07 01:00:00', -1, '2026-10-07 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107516232754233346, '000000', 19, 'EQ0019', '冲孔工位', 'PUNCH', 19, '2026-10-06', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-07 01:00:00', -1, '2026-10-07 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107516232808759298, '000000', 20, 'EQ0020', '氩弧焊工位', 'WELDING', 20, '2026-10-06', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-07 01:00:00', -1, '2026-10-07 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107516232846508033, '000000', 21, 'EQ0021', '二保焊工位', 'WELDING', 21, '2026-10-06', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-07 01:00:00', -1, '2026-10-07 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107516232888451074, '000000', 22, 'EQ0022', '点焊工位', 'WELDING', 22, '2026-10-06', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-07 01:00:00', -1, '2026-10-07 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107516232938782722, '000000', 23, 'EQ0023', '打磨工位', 'GRIND', 23, '2026-10-06', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-07 01:00:00', -1, '2026-10-07 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107516232989114370, '000000', 24, 'EQ0024', '注塑机A', 'INJECT', 24, '2026-10-06', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-07 01:00:00', -1, '2026-10-07 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107516233031057409, '000000', 25, 'EQ0025', '注塑机B', 'INJECT', 25, '2026-10-06', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-07 01:00:00', -1, '2026-10-07 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107516233073000449, '000000', 26, 'EQ0026', '注塑机C', 'INJECT', 26, '2026-10-06', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-07 01:00:00', -1, '2026-10-07 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107516233119137794, '000000', 27, 'EQ0027', '去毛刺工位', 'DEBURR', 27, '2026-10-06', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-07 01:00:00', -1, '2026-10-07 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107516233169469441, '000000', 28, 'EQ0028', '熔炼炉', 'FURNACE', 28, '2026-10-06', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-07 01:00:00', -1, '2026-10-07 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107516233219801090, '000000', 29, 'EQ0029', '压铸机', 'DIE_CAST', 29, '2026-10-06', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-07 01:00:00', -1, '2026-10-07 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107516233270132738, '000000', 30, 'EQ0030', '清砂工位', 'CLEAN', 30, '2026-10-06', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-07 01:00:00', -1, '2026-10-07 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107516233316270081, '000000', 31, 'EQ0031', '淬火炉', 'FURNACE', 31, '2026-10-06', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-07 01:00:00', -1, '2026-10-07 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107516233379184642, '000000', 32, 'EQ0032', '回火炉', 'FURNACE', 32, '2026-10-06', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-07 01:00:00', -1, '2026-10-07 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107516233429516290, '000000', 33, 'EQ0033', '渗碳炉', 'FURNACE', 33, '2026-10-06', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-07 01:00:00', -1, '2026-10-07 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107516233479847937, '000000', 34, 'EQ0034', '电镀线', 'PLATING', 34, '2026-10-06', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-07 01:00:00', -1, '2026-10-07 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107516233525985282, '000000', 35, 'EQ0035', '阳极氧化线', 'ANODIZE', 35, '2026-10-06', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-07 01:00:00', -1, '2026-10-07 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107516233584705538, '000000', 36, 'EQ0036', '喷塑线', 'COATING', 36, '2026-10-06', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-07 01:00:01', -1, '2026-10-07 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107516233626648578, '000000', 37, 'EQ0037', '喷漆房', 'COATING', 37, '2026-10-06', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-07 01:00:01', -1, '2026-10-07 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107516233672785921, '000000', 38, 'EQ0038', '丝印工位', 'GENERAL', 38, '2026-10-06', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-07 01:00:01', -1, '2026-10-07 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107516233727311874, '000000', 39, 'EQ0039', 'SMT贴片线', 'SMT', 39, '2026-10-06', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-07 01:00:01', -1, '2026-10-07 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107516233773449217, '000000', 40, 'EQ0040', '插件线', 'INSERT', 40, '2026-10-06', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-07 01:00:01', -1, '2026-10-07 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107516233819586562, '000000', 41, 'EQ0041', '波峰焊', 'WAVE', 41, '2026-10-06', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-07 01:00:01', -1, '2026-10-07 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107516233869918209, '000000', 42, 'EQ0042', '手工焊工位', 'SOLDERING', 42, '2026-10-06', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-07 01:00:01', -1, '2026-10-07 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107516233924444162, '000000', 43, 'EQ0043', '绕线机', 'WINDING', 43, '2026-10-06', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-07 01:00:01', -1, '2026-10-07 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107516233974775810, '000000', 44, 'EQ0044', '浸漆工位', 'VARNISH', 44, '2026-10-06', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-07 01:00:01', -1, '2026-10-07 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107516234025107458, '000000', 45, 'EQ0045', '动平衡机', 'BALANCE', 45, '2026-10-06', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-07 01:00:01', -1, '2026-10-07 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107516234079633410, '000000', 46, 'EQ0046', '装配线A', 'ASSEMBLY', 46, '2026-10-06', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算)', -1, -1, '2026-10-07 01:00:01', -1, '2026-10-07 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107516234125770754, '000000', 47, 'EQ0047', '装配线B', 'ASSEMBLY', 47, '2026-10-06', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-07 01:00:01', -1, '2026-10-07 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107516234176102402, '000000', 48, 'EQ0048', '调试工位', 'DEBUG', 48, '2026-10-06', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-07 01:00:01', -1, '2026-10-07 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107516234222239745, '000000', 49, 'EQ0049', '功能测试工位', 'TEST', 49, '2026-10-06', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-07 01:00:01', -1, '2026-10-07 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107516234280960001, '000000', 50, 'EQ0050', '老化房', 'AGING', 50, '2026-10-06', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-07 01:00:01', -1, '2026-10-07 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107516234327097346, '000000', 51, 'EQ0051', '气密测试台', 'TEST', 51, '2026-10-06', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-07 01:00:01', -1, '2026-10-07 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107516234377428994, '000000', 52, 'EQ0052', '精度检验台', 'INSPECTION', 52, '2026-10-06', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算)', -1, -1, '2026-10-07 01:00:01', -1, '2026-10-07 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107516234423566338, '000000', 53, 'EQ0053', '包装线A', 'PACKAGING', 53, '2026-10-06', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-07 01:00:01', -1, '2026-10-07 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107516234473897985, '000000', 54, 'EQ0054', '包装线B', 'PACKAGING', 54, '2026-10-06', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-07 01:00:01', -1, '2026-10-07 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107516234524229633, '000000', 55, 'EQ0055', '打包工位', 'PACKAGING', 55, '2026-10-06', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-07 01:00:01', -1, '2026-10-07 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107516234574561281, '000000', 56, 'EQ0056', '电火花机', 'EDM', 56, '2026-10-06', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-07 01:00:01', -1, '2026-10-07 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107516234616504321, '000000', 57, 'EQ0057', '线切割机', 'WEDM', 57, '2026-10-06', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-07 01:00:01', -1, '2026-10-07 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107516234666835970, '000000', 58, 'EQ0058', '抛光工位', 'POLISH', 58, '2026-10-06', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-07 01:00:01', -1, '2026-10-07 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107878620716298242, '000000', 1, 'EQ0001', '激光切割机', 'LASER', 1, '2026-10-07', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-08 01:00:00', -1, '2026-10-08 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107878620942790658, '000000', 2, 'EQ0002', '等离子切割机', 'PLASMA', 2, '2026-10-07', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-08 01:00:00', -1, '2026-10-08 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107878620967956481, '000000', 3, 'EQ0003', '剪板机', 'SHEAR', 3, '2026-10-07', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-08 01:00:00', -1, '2026-10-08 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107878621165088769, '000000', 4, 'EQ0004', '锯床', 'SAW', 4, '2026-10-07', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-08 01:00:00', -1, '2026-10-08 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107878621253169153, '000000', 5, 'EQ0005', '数控车床A', 'CNC', 5, '2026-10-07', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-08 01:00:00', -1, '2026-10-08 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107878621399969794, '000000', 6, 'EQ0006', '数控车床B', 'CNC', 6, '2026-10-07', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-08 01:00:00', -1, '2026-10-08 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2107878621529993217, '000000', 7, 'EQ0007', '加工中心A', 'CNC', 7, '2026-10-07', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-08 01:00:01', -1, '2026-10-08 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107878621794234370, '000000', 8, 'EQ0008', '铣床', 'MILL', 8, '2026-10-07', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-08 01:00:01', -1, '2026-10-08 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107878621911674882, '000000', 9, 'EQ0009', '磨床', 'GRIND', 9, '2026-10-07', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-08 01:00:01', -1, '2026-10-08 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107878622016532481, '000000', 10, 'EQ0010', '钻床', 'DRILL', 10, '2026-10-07', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-08 01:00:01', -1, '2026-10-08 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107878622117195777, '000000', 11, 'EQ0011', '滚齿机', 'GENERAL', 11, '2026-10-07', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-08 01:00:01', -1, '2026-10-08 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107878622268190721, '000000', 12, 'EQ0012', '冲床A', 'PUNCH', 12, '2026-10-07', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-08 01:00:01', -1, '2026-10-08 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107878622352076802, '000000', 13, 'EQ0013', '冲床B', 'PUNCH', 13, '2026-10-07', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-08 01:00:01', -1, '2026-10-08 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107878622586957826, '000000', 14, 'EQ0014', '折弯机', 'BEND', 14, '2026-10-07', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-08 01:00:01', -1, '2026-10-08 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107878622637289474, '000000', 15, 'EQ0015', '油压机', 'PRESS', 15, '2026-10-07', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-08 01:00:01', -1, '2026-10-08 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107878622830227458, '000000', 16, 'EQ0016', '锻造机', 'GENERAL', 16, '2026-10-07', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-08 01:00:01', -1, '2026-10-08 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107878623148994562, '000000', 17, 'EQ0017', '折弯工位', 'GENERAL', 17, '2026-10-07', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-08 01:00:01', -1, '2026-10-08 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107878623350321153, '000000', 18, 'EQ0018', '卷圆工位', 'ROLL', 18, '2026-10-07', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-08 01:00:01', -1, '2026-10-08 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107878623526481921, '000000', 19, 'EQ0019', '冲孔工位', 'PUNCH', 19, '2026-10-07', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-08 01:00:01', -1, '2026-10-08 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107878623526481922, '000000', 20, 'EQ0020', '氩弧焊工位', 'WELDING', 20, '2026-10-07', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-08 01:00:01', -1, '2026-10-08 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107878623719419905, '000000', 21, 'EQ0021', '二保焊工位', 'WELDING', 21, '2026-10-07', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-08 01:00:01', -1, '2026-10-08 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107878623807500289, '000000', 22, 'EQ0022', '点焊工位', 'WELDING', 22, '2026-10-07', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-08 01:00:01', -1, '2026-10-08 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107878623958495234, '000000', 23, 'EQ0023', '打磨工位', 'GRIND', 23, '2026-10-07', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-08 01:00:01', -1, '2026-10-08 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107878624004632577, '000000', 24, 'EQ0024', '注塑机A', 'INJECT', 24, '2026-10-07', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-08 01:00:01', -1, '2026-10-08 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107878624151433217, '000000', 25, 'EQ0025', '注塑机B', 'INJECT', 25, '2026-10-07', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-08 01:00:01', -1, '2026-10-08 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107878624268873729, '000000', 26, 'EQ0026', '注塑机C', 'INJECT', 26, '2026-10-07', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-08 01:00:01', -1, '2026-10-08 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107878624445034497, '000000', 27, 'EQ0027', '去毛刺工位', 'DEBURR', 27, '2026-10-07', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-08 01:00:01', -1, '2026-10-08 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107878624545697794, '000000', 28, 'EQ0028', '熔炼炉', 'FURNACE', 28, '2026-10-07', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-08 01:00:01', -1, '2026-10-08 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107878624617000962, '000000', 29, 'EQ0029', '压铸机', 'DIE_CAST', 29, '2026-10-07', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-08 01:00:01', -1, '2026-10-08 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107878624696692737, '000000', 30, 'EQ0030', '清砂工位', 'CLEAN', 30, '2026-10-07', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-08 01:00:01', -1, '2026-10-08 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107878624772190210, '000000', 31, 'EQ0031', '淬火炉', 'FURNACE', 31, '2026-10-07', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-08 01:00:01', -1, '2026-10-08 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107878624856076290, '000000', 32, 'EQ0032', '回火炉', 'FURNACE', 32, '2026-10-07', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-08 01:00:01', -1, '2026-10-08 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107878624898019330, '000000', 33, 'EQ0033', '渗碳炉', 'FURNACE', 33, '2026-10-07', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-08 01:00:01', -1, '2026-10-08 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107878624998682626, '000000', 34, 'EQ0034', '电镀线', 'PLATING', 34, '2026-10-07', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-08 01:00:01', -1, '2026-10-08 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107878625061597186, '000000', 35, 'EQ0035', '阳极氧化线', 'ANODIZE', 35, '2026-10-07', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-08 01:00:01', -1, '2026-10-08 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107878625141288962, '000000', 36, 'EQ0036', '喷塑线', 'COATING', 36, '2026-10-07', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-08 01:00:01', -1, '2026-10-08 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107878625200009217, '000000', 37, 'EQ0037', '喷漆房', 'COATING', 37, '2026-10-07', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-08 01:00:01', -1, '2026-10-08 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107878625283895298, '000000', 38, 'EQ0038', '丝印工位', 'GENERAL', 38, '2026-10-07', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-08 01:00:01', -1, '2026-10-08 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107878625363587074, '000000', 39, 'EQ0039', 'SMT贴片线', 'SMT', 39, '2026-10-07', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-08 01:00:01', -1, '2026-10-08 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107878625439084546, '000000', 40, 'EQ0040', '插件线', 'INSERT', 40, '2026-10-07', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-08 01:00:01', -1, '2026-10-08 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107878625514582017, '000000', 41, 'EQ0041', '波峰焊', 'WAVE', 41, '2026-10-07', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-08 01:00:01', -1, '2026-10-08 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107878625590079489, '000000', 42, 'EQ0042', '手工焊工位', 'SOLDERING', 42, '2026-10-07', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-08 01:00:01', -1, '2026-10-08 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2107878625682354177, '000000', 43, 'EQ0043', '绕线机', 'WINDING', 43, '2026-10-07', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-08 01:00:02', -1, '2026-10-08 01:00:02', '0');
INSERT INTO `eq_oee_record` VALUES (2107878625741074434, '000000', 44, 'EQ0044', '浸漆工位', 'VARNISH', 44, '2026-10-07', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-08 01:00:02', -1, '2026-10-08 01:00:02', '0');
INSERT INTO `eq_oee_record` VALUES (2107878625799794690, '000000', 45, 'EQ0045', '动平衡机', 'BALANCE', 45, '2026-10-07', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-08 01:00:02', -1, '2026-10-08 01:00:02', '0');
INSERT INTO `eq_oee_record` VALUES (2107878625871097858, '000000', 46, 'EQ0046', '装配线A', 'ASSEMBLY', 46, '2026-10-07', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算)', -1, -1, '2026-10-08 01:00:02', -1, '2026-10-08 01:00:02', '0');
INSERT INTO `eq_oee_record` VALUES (2107878625934012418, '000000', 47, 'EQ0047', '装配线B', 'ASSEMBLY', 47, '2026-10-07', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-08 01:00:02', -1, '2026-10-08 01:00:02', '0');
INSERT INTO `eq_oee_record` VALUES (2107878626005315586, '000000', 48, 'EQ0048', '调试工位', 'DEBUG', 48, '2026-10-07', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-08 01:00:02', -1, '2026-10-08 01:00:02', '0');
INSERT INTO `eq_oee_record` VALUES (2107878626072424449, '000000', 49, 'EQ0049', '功能测试工位', 'TEST', 49, '2026-10-07', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-08 01:00:02', -1, '2026-10-08 01:00:02', '0');
INSERT INTO `eq_oee_record` VALUES (2107878626135339009, '000000', 50, 'EQ0050', '老化房', 'AGING', 50, '2026-10-07', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-08 01:00:02', -1, '2026-10-08 01:00:02', '0');
INSERT INTO `eq_oee_record` VALUES (2107878626202447873, '000000', 51, 'EQ0051', '气密测试台', 'TEST', 51, '2026-10-07', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-08 01:00:02', -1, '2026-10-08 01:00:02', '0');
INSERT INTO `eq_oee_record` VALUES (2107878626256973825, '000000', 52, 'EQ0052', '精度检验台', 'INSPECTION', 52, '2026-10-07', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算)', -1, -1, '2026-10-08 01:00:02', -1, '2026-10-08 01:00:02', '0');
INSERT INTO `eq_oee_record` VALUES (2107878626319888385, '000000', 53, 'EQ0053', '包装线A', 'PACKAGING', 53, '2026-10-07', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-08 01:00:02', -1, '2026-10-08 01:00:02', '0');
INSERT INTO `eq_oee_record` VALUES (2107878626374414338, '000000', 54, 'EQ0054', '包装线B', 'PACKAGING', 54, '2026-10-07', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-08 01:00:02', -1, '2026-10-08 01:00:02', '0');
INSERT INTO `eq_oee_record` VALUES (2107878626441523202, '000000', 55, 'EQ0055', '打包工位', 'PACKAGING', 55, '2026-10-07', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-08 01:00:02', -1, '2026-10-08 01:00:02', '0');
INSERT INTO `eq_oee_record` VALUES (2107878626504437762, '000000', 56, 'EQ0056', '电火花机', 'EDM', 56, '2026-10-07', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-08 01:00:02', -1, '2026-10-08 01:00:02', '0');
INSERT INTO `eq_oee_record` VALUES (2107878626584129537, '000000', 57, 'EQ0057', '线切割机', 'WEDM', 57, '2026-10-07', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-08 01:00:02', -1, '2026-10-08 01:00:02', '0');
INSERT INTO `eq_oee_record` VALUES (2107878626655432705, '000000', 58, 'EQ0058', '抛光工位', 'POLISH', 58, '2026-10-07', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-08 01:00:02', -1, '2026-10-08 01:00:02', '0');
INSERT INTO `eq_oee_record` VALUES (2111140110680387587, '000000', 1, 'EQ0001', '激光切割机', 'LASER', 1, '2026-10-16', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-17 01:00:00', -1, '2026-10-17 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111140110747496449, '000000', 2, 'EQ0002', '等离子切割机', 'PLASMA', 2, '2026-10-16', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-17 01:00:00', -1, '2026-10-17 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111140110810411010, '000000', 3, 'EQ0003', '剪板机', 'SHEAR', 3, '2026-10-16', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-17 01:00:00', -1, '2026-10-17 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111140110877519873, '000000', 4, 'EQ0004', '锯床', 'SAW', 4, '2026-10-16', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-17 01:00:00', -1, '2026-10-17 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111140110877519874, '000000', 5, 'EQ0005', '数控车床A', 'CNC', 5, '2026-10-16', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-17 01:00:00', -1, '2026-10-17 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111140110940434434, '000000', 6, 'EQ0006', '数控车床B', 'CNC', 6, '2026-10-16', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-17 01:00:00', -1, '2026-10-17 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111140111007543298, '000000', 7, 'EQ0007', '加工中心A', 'CNC', 7, '2026-10-16', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-17 01:00:00', -1, '2026-10-17 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111140111007543299, '000000', 8, 'EQ0008', '铣床', 'MILL', 8, '2026-10-16', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-17 01:00:00', -1, '2026-10-17 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111140111083040770, '000000', 9, 'EQ0009', '磨床', 'GRIND', 9, '2026-10-16', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-17 01:00:00', -1, '2026-10-17 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111140111083040771, '000000', 10, 'EQ0010', '钻床', 'DRILL', 10, '2026-10-16', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-17 01:00:00', -1, '2026-10-17 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111140111137566721, '000000', 11, 'EQ0011', '滚齿机', 'GENERAL', 11, '2026-10-16', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-17 01:00:00', -1, '2026-10-17 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111140111204675585, '000000', 12, 'EQ0012', '冲床A', 'PUNCH', 12, '2026-10-16', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-17 01:00:00', -1, '2026-10-17 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111140111204675586, '000000', 13, 'EQ0013', '冲床B', 'PUNCH', 13, '2026-10-16', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-17 01:00:00', -1, '2026-10-17 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111140111267590146, '000000', 14, 'EQ0014', '折弯机', 'BEND', 14, '2026-10-16', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-17 01:00:00', -1, '2026-10-17 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111140111267590147, '000000', 15, 'EQ0015', '油压机', 'PRESS', 15, '2026-10-16', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-17 01:00:00', -1, '2026-10-17 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111140111334699009, '000000', 16, 'EQ0016', '锻造机', 'GENERAL', 16, '2026-10-16', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-17 01:00:00', -1, '2026-10-17 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111140111334699010, '000000', 17, 'EQ0017', '折弯工位', 'GENERAL', 17, '2026-10-16', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-17 01:00:00', -1, '2026-10-17 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111140111397613570, '000000', 18, 'EQ0018', '卷圆工位', 'ROLL', 18, '2026-10-16', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-17 01:00:00', -1, '2026-10-17 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111140111397613571, '000000', 19, 'EQ0019', '冲孔工位', 'PUNCH', 19, '2026-10-16', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-17 01:00:00', -1, '2026-10-17 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111140111464722433, '000000', 20, 'EQ0020', '氩弧焊工位', 'WELDING', 20, '2026-10-16', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-17 01:00:00', -1, '2026-10-17 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111140111464722434, '000000', 21, 'EQ0021', '二保焊工位', 'WELDING', 21, '2026-10-16', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-17 01:00:00', -1, '2026-10-17 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111140111527636994, '000000', 22, 'EQ0022', '点焊工位', 'WELDING', 22, '2026-10-16', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-17 01:00:00', -1, '2026-10-17 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111140111527636995, '000000', 23, 'EQ0023', '打磨工位', 'GRIND', 23, '2026-10-16', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-17 01:00:00', -1, '2026-10-17 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111140111607328770, '000000', 24, 'EQ0024', '注塑机A', 'INJECT', 24, '2026-10-16', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-17 01:00:00', -1, '2026-10-17 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111140111607328771, '000000', 25, 'EQ0025', '注塑机B', 'INJECT', 25, '2026-10-16', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-17 01:00:00', -1, '2026-10-17 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111140111657660417, '000000', 26, 'EQ0026', '注塑机C', 'INJECT', 26, '2026-10-16', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-17 01:00:00', -1, '2026-10-17 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111140111657660418, '000000', 27, 'EQ0027', '去毛刺工位', 'DEBURR', 27, '2026-10-16', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-17 01:00:00', -1, '2026-10-17 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111140111724769282, '000000', 28, 'EQ0028', '熔炼炉', 'FURNACE', 28, '2026-10-16', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-17 01:00:00', -1, '2026-10-17 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111140111724769283, '000000', 29, 'EQ0029', '压铸机', 'DIE_CAST', 29, '2026-10-16', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-17 01:00:00', -1, '2026-10-17 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111140111791878146, '000000', 30, 'EQ0030', '清砂工位', 'CLEAN', 30, '2026-10-16', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-17 01:00:00', -1, '2026-10-17 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111140111791878147, '000000', 31, 'EQ0031', '淬火炉', 'FURNACE', 31, '2026-10-16', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-17 01:00:00', -1, '2026-10-17 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111140111863181314, '000000', 32, 'EQ0032', '回火炉', 'FURNACE', 32, '2026-10-16', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-17 01:00:00', -1, '2026-10-17 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111140111863181315, '000000', 33, 'EQ0033', '渗碳炉', 'FURNACE', 33, '2026-10-16', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-17 01:00:00', -1, '2026-10-17 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111140111921901569, '000000', 34, 'EQ0034', '电镀线', 'PLATING', 34, '2026-10-16', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-17 01:00:00', -1, '2026-10-17 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111140111921901570, '000000', 35, 'EQ0035', '阳极氧化线', 'ANODIZE', 35, '2026-10-16', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-17 01:00:00', -1, '2026-10-17 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111140111989010433, '000000', 36, 'EQ0036', '喷塑线', 'COATING', 36, '2026-10-16', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-17 01:00:00', -1, '2026-10-17 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111140111989010434, '000000', 37, 'EQ0037', '喷漆房', 'COATING', 37, '2026-10-16', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-17 01:00:00', -1, '2026-10-17 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111140112051924994, '000000', 38, 'EQ0038', '丝印工位', 'GENERAL', 38, '2026-10-16', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-17 01:00:00', -1, '2026-10-17 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111140112051924995, '000000', 39, 'EQ0039', 'SMT贴片线', 'SMT', 39, '2026-10-16', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-17 01:00:00', -1, '2026-10-17 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111140112131616769, '000000', 40, 'EQ0040', '插件线', 'INSERT', 40, '2026-10-16', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-17 01:00:00', -1, '2026-10-17 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111140112131616770, '000000', 41, 'EQ0041', '波峰焊', 'WAVE', 41, '2026-10-16', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-17 01:00:00', -1, '2026-10-17 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111140112186142721, '000000', 42, 'EQ0042', '手工焊工位', 'SOLDERING', 42, '2026-10-16', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-17 01:00:00', -1, '2026-10-17 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111140112249057282, '000000', 43, 'EQ0043', '绕线机', 'WINDING', 43, '2026-10-16', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-17 01:00:01', -1, '2026-10-17 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111140112249057283, '000000', 44, 'EQ0044', '浸漆工位', 'VARNISH', 44, '2026-10-16', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-17 01:00:01', -1, '2026-10-17 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111140112311971841, '000000', 45, 'EQ0045', '动平衡机', 'BALANCE', 45, '2026-10-16', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-17 01:00:01', -1, '2026-10-17 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111140112311971842, '000000', 46, 'EQ0046', '装配线A', 'ASSEMBLY', 46, '2026-10-16', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-17 01:00:01', -1, '2026-10-17 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111140112379080705, '000000', 47, 'EQ0047', '装配线B', 'ASSEMBLY', 47, '2026-10-16', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-17 01:00:01', -1, '2026-10-17 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111140112379080706, '000000', 48, 'EQ0048', '调试工位', 'DEBUG', 48, '2026-10-16', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-17 01:00:01', -1, '2026-10-17 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111140112441995265, '000000', 49, 'EQ0049', '功能测试工位', 'TEST', 49, '2026-10-16', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-17 01:00:01', -1, '2026-10-17 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111140112441995266, '000000', 50, 'EQ0050', '老化房', 'AGING', 50, '2026-10-16', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-17 01:00:01', -1, '2026-10-17 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111140112504909826, '000000', 51, 'EQ0051', '气密测试台', 'TEST', 51, '2026-10-16', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-17 01:00:01', -1, '2026-10-17 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111140112504909827, '000000', 52, 'EQ0052', '精度检验台', 'INSPECTION', 52, '2026-10-16', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-17 01:00:01', -1, '2026-10-17 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111140112572018689, '000000', 53, 'EQ0053', '包装线A', 'PACKAGING', 53, '2026-10-16', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-17 01:00:01', -1, '2026-10-17 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111140112572018690, '000000', 54, 'EQ0054', '包装线B', 'PACKAGING', 54, '2026-10-16', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-17 01:00:01', -1, '2026-10-17 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111140112639127553, '000000', 55, 'EQ0055', '打包工位', 'PACKAGING', 55, '2026-10-16', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-17 01:00:01', -1, '2026-10-17 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111140112639127554, '000000', 56, 'EQ0056', '电火花机', 'EDM', 56, '2026-10-16', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-17 01:00:01', -1, '2026-10-17 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111140112706236417, '000000', 57, 'EQ0057', '线切割机', 'WEDM', 57, '2026-10-16', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-17 01:00:01', -1, '2026-10-17 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111140112706236418, '000000', 58, 'EQ0058', '抛光工位', 'POLISH', 58, '2026-10-16', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-17 01:00:01', -1, '2026-10-17 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111502499175096321, '000000', 1, 'EQ0001', '激光切割机', 'LASER', 1, '2026-10-17', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-18 01:00:00', -1, '2026-10-18 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111502499242205185, '000000', 2, 'EQ0002', '等离子切割机', 'PLASMA', 2, '2026-10-17', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-18 01:00:00', -1, '2026-10-18 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111502499305119745, '000000', 3, 'EQ0003', '剪板机', 'SHEAR', 3, '2026-10-17', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-18 01:00:00', -1, '2026-10-18 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111502499372228609, '000000', 4, 'EQ0004', '锯床', 'SAW', 4, '2026-10-17', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-18 01:00:00', -1, '2026-10-18 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111502499439337474, '000000', 5, 'EQ0005', '数控车床A', 'CNC', 5, '2026-10-17', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-18 01:00:00', -1, '2026-10-18 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111502499502252033, '000000', 6, 'EQ0006', '数控车床B', 'CNC', 6, '2026-10-17', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-18 01:00:00', -1, '2026-10-18 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111502499569360898, '000000', 7, 'EQ0007', '加工中心A', 'CNC', 7, '2026-10-17', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-18 01:00:00', -1, '2026-10-18 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111502499632275457, '000000', 8, 'EQ0008', '铣床', 'MILL', 8, '2026-10-17', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-18 01:00:00', -1, '2026-10-18 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111502499695190018, '000000', 9, 'EQ0009', '磨床', 'GRIND', 9, '2026-10-17', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-18 01:00:00', -1, '2026-10-18 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111502499758104578, '000000', 10, 'EQ0010', '钻床', 'DRILL', 10, '2026-10-17', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-18 01:00:00', -1, '2026-10-18 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111502499825213441, '000000', 11, 'EQ0011', '滚齿机', 'GENERAL', 11, '2026-10-17', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-18 01:00:00', -1, '2026-10-18 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111502499892322305, '000000', 12, 'EQ0012', '冲床A', 'PUNCH', 12, '2026-10-17', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-18 01:00:00', -1, '2026-10-18 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111502499955236866, '000000', 13, 'EQ0013', '冲床B', 'PUNCH', 13, '2026-10-17', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-18 01:00:00', -1, '2026-10-18 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111502499955236867, '000000', 14, 'EQ0014', '折弯机', 'BEND', 14, '2026-10-17', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-18 01:00:00', -1, '2026-10-18 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111502500018151425, '000000', 15, 'EQ0015', '油压机', 'PRESS', 15, '2026-10-17', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-18 01:00:00', -1, '2026-10-18 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111502500089454594, '000000', 16, 'EQ0016', '锻造机', 'GENERAL', 16, '2026-10-17', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-18 01:00:01', -1, '2026-10-18 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111502500152369154, '000000', 17, 'EQ0017', '折弯工位', 'GENERAL', 17, '2026-10-17', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-18 01:00:01', -1, '2026-10-18 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111502500219478017, '000000', 18, 'EQ0018', '卷圆工位', 'ROLL', 18, '2026-10-17', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-18 01:00:01', -1, '2026-10-18 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111502500282392578, '000000', 19, 'EQ0019', '冲孔工位', 'PUNCH', 19, '2026-10-17', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-18 01:00:01', -1, '2026-10-18 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111502500345307137, '000000', 20, 'EQ0020', '氩弧焊工位', 'WELDING', 20, '2026-10-17', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-18 01:00:01', -1, '2026-10-18 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111502500408221697, '000000', 21, 'EQ0021', '二保焊工位', 'WELDING', 21, '2026-10-17', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-18 01:00:01', -1, '2026-10-18 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111502500475330561, '000000', 22, 'EQ0022', '点焊工位', 'WELDING', 22, '2026-10-17', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-18 01:00:01', -1, '2026-10-18 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111502500542439426, '000000', 23, 'EQ0023', '打磨工位', 'GRIND', 23, '2026-10-17', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-18 01:00:01', -1, '2026-10-18 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111502500609548289, '000000', 24, 'EQ0024', '注塑机A', 'INJECT', 24, '2026-10-17', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-18 01:00:01', -1, '2026-10-18 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111502500609548290, '000000', 25, 'EQ0025', '注塑机B', 'INJECT', 25, '2026-10-17', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-18 01:00:01', -1, '2026-10-18 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111502500680851457, '000000', 26, 'EQ0026', '注塑机C', 'INJECT', 26, '2026-10-17', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-18 01:00:01', -1, '2026-10-18 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111502500735377410, '000000', 27, 'EQ0027', '去毛刺工位', 'DEBURR', 27, '2026-10-17', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-18 01:00:01', -1, '2026-10-18 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111502500802486273, '000000', 28, 'EQ0028', '熔炼炉', 'FURNACE', 28, '2026-10-17', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-18 01:00:01', -1, '2026-10-18 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111502500802486274, '000000', 29, 'EQ0029', '压铸机', 'DIE_CAST', 29, '2026-10-17', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-18 01:00:01', -1, '2026-10-18 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111502500869595137, '000000', 30, 'EQ0030', '清砂工位', 'CLEAN', 30, '2026-10-17', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-18 01:00:01', -1, '2026-10-18 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111502500932509698, '000000', 31, 'EQ0031', '淬火炉', 'FURNACE', 31, '2026-10-17', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-18 01:00:01', -1, '2026-10-18 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111502500999618561, '000000', 32, 'EQ0032', '回火炉', 'FURNACE', 32, '2026-10-17', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-18 01:00:01', -1, '2026-10-18 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111502501062533121, '000000', 33, 'EQ0033', '渗碳炉', 'FURNACE', 33, '2026-10-17', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-18 01:00:01', -1, '2026-10-18 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111502501129641986, '000000', 34, 'EQ0034', '电镀线', 'PLATING', 34, '2026-10-17', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-18 01:00:01', -1, '2026-10-18 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111502501221916674, '000000', 35, 'EQ0035', '阳极氧化线', 'ANODIZE', 35, '2026-10-17', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-18 01:00:01', -1, '2026-10-18 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111502501263859713, '000000', 36, 'EQ0036', '喷塑线', 'COATING', 36, '2026-10-17', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-18 01:00:01', -1, '2026-10-18 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111502501326774274, '000000', 37, 'EQ0037', '喷漆房', 'COATING', 37, '2026-10-17', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-18 01:00:01', -1, '2026-10-18 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111502501389688834, '000000', 38, 'EQ0038', '丝印工位', 'GENERAL', 38, '2026-10-17', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-18 01:00:01', -1, '2026-10-18 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111502501389688835, '000000', 39, 'EQ0039', 'SMT贴片线', 'SMT', 39, '2026-10-17', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-18 01:00:01', -1, '2026-10-18 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111502501456797698, '000000', 40, 'EQ0040', '插件线', 'INSERT', 40, '2026-10-17', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-18 01:00:01', -1, '2026-10-18 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111502501523906561, '000000', 41, 'EQ0041', '波峰焊', 'WAVE', 41, '2026-10-17', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-18 01:00:01', -1, '2026-10-18 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111502501586821122, '000000', 42, 'EQ0042', '手工焊工位', 'SOLDERING', 42, '2026-10-17', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-18 01:00:01', -1, '2026-10-18 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111502501649735681, '000000', 43, 'EQ0043', '绕线机', 'WINDING', 43, '2026-10-17', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-18 01:00:01', -1, '2026-10-18 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111502501649735682, '000000', 44, 'EQ0044', '浸漆工位', 'VARNISH', 44, '2026-10-17', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-18 01:00:01', -1, '2026-10-18 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111502501716844546, '000000', 45, 'EQ0045', '动平衡机', 'BALANCE', 45, '2026-10-17', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-18 01:00:01', -1, '2026-10-18 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111502501783953410, '000000', 46, 'EQ0046', '装配线A', 'ASSEMBLY', 46, '2026-10-17', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-18 01:00:01', -1, '2026-10-18 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111502501846867969, '000000', 47, 'EQ0047', '装配线B', 'ASSEMBLY', 47, '2026-10-17', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-18 01:00:01', -1, '2026-10-18 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111502501913976833, '000000', 48, 'EQ0048', '调试工位', 'DEBUG', 48, '2026-10-17', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-18 01:00:01', -1, '2026-10-18 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111502501976891393, '000000', 49, 'EQ0049', '功能测试工位', 'TEST', 49, '2026-10-17', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-18 01:00:01', -1, '2026-10-18 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111502502044000258, '000000', 50, 'EQ0050', '老化房', 'AGING', 50, '2026-10-17', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-18 01:00:01', -1, '2026-10-18 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111502502106914817, '000000', 51, 'EQ0051', '气密测试台', 'TEST', 51, '2026-10-17', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-18 01:00:01', -1, '2026-10-18 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111502502174023682, '000000', 52, 'EQ0052', '精度检验台', 'INSPECTION', 52, '2026-10-17', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-18 01:00:01', -1, '2026-10-18 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111502502174023683, '000000', 53, 'EQ0053', '包装线A', 'PACKAGING', 53, '2026-10-17', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-18 01:00:01', -1, '2026-10-18 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111502502236938242, '000000', 54, 'EQ0054', '包装线B', 'PACKAGING', 54, '2026-10-17', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-18 01:00:01', -1, '2026-10-18 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111502502299852802, '000000', 55, 'EQ0055', '打包工位', 'PACKAGING', 55, '2026-10-17', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-18 01:00:01', -1, '2026-10-18 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111502502366961666, '000000', 56, 'EQ0056', '电火花机', 'EDM', 56, '2026-10-17', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-18 01:00:01', -1, '2026-10-18 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111502502429876225, '000000', 57, 'EQ0057', '线切割机', 'WEDM', 57, '2026-10-17', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-18 01:00:01', -1, '2026-10-18 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111502502429876226, '000000', 58, 'EQ0058', '抛光工位', 'POLISH', 58, '2026-10-17', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-18 01:00:01', -1, '2026-10-18 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111864886612934658, '000000', 1, 'EQ0001', '激光切割机', 'LASER', 1, '2026-10-18', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-19 01:00:00', -1, '2026-10-19 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111864886680043521, '000000', 2, 'EQ0002', '等离子切割机', 'PLASMA', 2, '2026-10-18', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-19 01:00:00', -1, '2026-10-19 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111864886742958082, '000000', 3, 'EQ0003', '剪板机', 'SHEAR', 3, '2026-10-18', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-19 01:00:00', -1, '2026-10-19 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111864886742958083, '000000', 4, 'EQ0004', '锯床', 'SAW', 4, '2026-10-18', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-19 01:00:00', -1, '2026-10-19 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111864886805872641, '000000', 5, 'EQ0005', '数控车床A', 'CNC', 5, '2026-10-18', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-19 01:00:00', -1, '2026-10-19 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111864886805872642, '000000', 6, 'EQ0006', '数控车床B', 'CNC', 6, '2026-10-18', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-19 01:00:00', -1, '2026-10-19 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111864886872981505, '000000', 7, 'EQ0007', '加工中心A', 'CNC', 7, '2026-10-18', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-19 01:00:00', -1, '2026-10-19 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111864886872981506, '000000', 8, 'EQ0008', '铣床', 'MILL', 8, '2026-10-18', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-19 01:00:00', -1, '2026-10-19 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111864886940090369, '000000', 9, 'EQ0009', '磨床', 'GRIND', 9, '2026-10-18', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-19 01:00:00', -1, '2026-10-19 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111864886940090370, '000000', 10, 'EQ0010', '钻床', 'DRILL', 10, '2026-10-18', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-19 01:00:00', -1, '2026-10-19 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111864887011393538, '000000', 11, 'EQ0011', '滚齿机', 'GENERAL', 11, '2026-10-18', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-19 01:00:00', -1, '2026-10-19 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111864887011393539, '000000', 12, 'EQ0012', '冲床A', 'PUNCH', 12, '2026-10-18', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-19 01:00:00', -1, '2026-10-19 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111864887070113793, '000000', 13, 'EQ0013', '冲床B', 'PUNCH', 13, '2026-10-18', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-19 01:00:00', -1, '2026-10-19 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111864887070113794, '000000', 14, 'EQ0014', '折弯机', 'BEND', 14, '2026-10-18', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-19 01:00:00', -1, '2026-10-19 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111864887133028354, '000000', 15, 'EQ0015', '油压机', 'PRESS', 15, '2026-10-18', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-19 01:00:00', -1, '2026-10-19 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111864887195942914, '000000', 16, 'EQ0016', '锻造机', 'GENERAL', 16, '2026-10-18', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-19 01:00:00', -1, '2026-10-19 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111864887195942915, '000000', 17, 'EQ0017', '折弯工位', 'GENERAL', 17, '2026-10-18', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-19 01:00:00', -1, '2026-10-19 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111864887195942916, '000000', 18, 'EQ0018', '卷圆工位', 'ROLL', 18, '2026-10-18', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-19 01:00:00', -1, '2026-10-19 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111864887263051777, '000000', 19, 'EQ0019', '冲孔工位', 'PUNCH', 19, '2026-10-18', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-19 01:00:00', -1, '2026-10-19 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111864887334354945, '000000', 20, 'EQ0020', '氩弧焊工位', 'WELDING', 20, '2026-10-18', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-19 01:00:00', -1, '2026-10-19 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111864887334354946, '000000', 21, 'EQ0021', '二保焊工位', 'WELDING', 21, '2026-10-18', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-19 01:00:00', -1, '2026-10-19 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111864887393075202, '000000', 22, 'EQ0022', '点焊工位', 'WELDING', 22, '2026-10-18', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-19 01:00:00', -1, '2026-10-19 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111864887393075203, '000000', 23, 'EQ0023', '打磨工位', 'GRIND', 23, '2026-10-18', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-19 01:00:00', -1, '2026-10-19 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111864887460184065, '000000', 24, 'EQ0024', '注塑机A', 'INJECT', 24, '2026-10-18', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-19 01:00:00', -1, '2026-10-19 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111864887460184066, '000000', 25, 'EQ0025', '注塑机B', 'INJECT', 25, '2026-10-18', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-19 01:00:00', -1, '2026-10-19 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111864887527292930, '000000', 26, 'EQ0026', '注塑机C', 'INJECT', 26, '2026-10-18', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-19 01:00:00', -1, '2026-10-19 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111864887527292931, '000000', 27, 'EQ0027', '去毛刺工位', 'DEBURR', 27, '2026-10-18', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-19 01:00:00', -1, '2026-10-19 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111864887590207489, '000000', 28, 'EQ0028', '熔炼炉', 'FURNACE', 28, '2026-10-18', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-19 01:00:00', -1, '2026-10-19 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111864887590207490, '000000', 29, 'EQ0029', '压铸机', 'DIE_CAST', 29, '2026-10-18', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-19 01:00:00', -1, '2026-10-19 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111864887657316354, '000000', 30, 'EQ0030', '清砂工位', 'CLEAN', 30, '2026-10-18', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-19 01:00:00', -1, '2026-10-19 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111864887657316355, '000000', 31, 'EQ0031', '淬火炉', 'FURNACE', 31, '2026-10-18', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-19 01:00:00', -1, '2026-10-19 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111864887720230913, '000000', 32, 'EQ0032', '回火炉', 'FURNACE', 32, '2026-10-18', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-19 01:00:00', -1, '2026-10-19 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111864887720230914, '000000', 33, 'EQ0033', '渗碳炉', 'FURNACE', 33, '2026-10-18', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-19 01:00:00', -1, '2026-10-19 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111864887783145474, '000000', 34, 'EQ0034', '电镀线', 'PLATING', 34, '2026-10-18', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-19 01:00:00', -1, '2026-10-19 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111864887783145475, '000000', 35, 'EQ0035', '阳极氧化线', 'ANODIZE', 35, '2026-10-18', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-19 01:00:00', -1, '2026-10-19 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111864887850254337, '000000', 36, 'EQ0036', '喷塑线', 'COATING', 36, '2026-10-18', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-19 01:00:00', -1, '2026-10-19 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111864887850254338, '000000', 37, 'EQ0037', '喷漆房', 'COATING', 37, '2026-10-18', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-19 01:00:00', -1, '2026-10-19 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111864887917363202, '000000', 38, 'EQ0038', '丝印工位', 'GENERAL', 38, '2026-10-18', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-19 01:00:00', -1, '2026-10-19 01:00:00', '0');
INSERT INTO `eq_oee_record` VALUES (2111864887917363203, '000000', 39, 'EQ0039', 'SMT贴片线', 'SMT', 39, '2026-10-18', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-19 01:00:01', -1, '2026-10-19 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111864887984472065, '000000', 40, 'EQ0040', '插件线', 'INSERT', 40, '2026-10-18', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-19 01:00:01', -1, '2026-10-19 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111864887984472066, '000000', 41, 'EQ0041', '波峰焊', 'WAVE', 41, '2026-10-18', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-19 01:00:01', -1, '2026-10-19 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111864888047386625, '000000', 42, 'EQ0042', '手工焊工位', 'SOLDERING', 42, '2026-10-18', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-19 01:00:01', -1, '2026-10-19 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111864888114495489, '000000', 43, 'EQ0043', '绕线机', 'WINDING', 43, '2026-10-18', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-19 01:00:01', -1, '2026-10-19 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111864888114495490, '000000', 44, 'EQ0044', '浸漆工位', 'VARNISH', 44, '2026-10-18', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-19 01:00:01', -1, '2026-10-19 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111864888181604353, '000000', 45, 'EQ0045', '动平衡机', 'BALANCE', 45, '2026-10-18', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-19 01:00:01', -1, '2026-10-19 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111864888181604354, '000000', 46, 'EQ0046', '装配线A', 'ASSEMBLY', 46, '2026-10-18', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-19 01:00:01', -1, '2026-10-19 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111864888181604355, '000000', 47, 'EQ0047', '装配线B', 'ASSEMBLY', 47, '2026-10-18', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-19 01:00:01', -1, '2026-10-19 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111864888244518914, '000000', 48, 'EQ0048', '调试工位', 'DEBUG', 48, '2026-10-18', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-19 01:00:01', -1, '2026-10-19 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111864888244518915, '000000', 49, 'EQ0049', '功能测试工位', 'TEST', 49, '2026-10-18', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-19 01:00:01', -1, '2026-10-19 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111864888315822082, '000000', 50, 'EQ0050', '老化房', 'AGING', 50, '2026-10-18', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-19 01:00:01', -1, '2026-10-19 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111864888315822083, '000000', 51, 'EQ0051', '气密测试台', 'TEST', 51, '2026-10-18', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-19 01:00:01', -1, '2026-10-19 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111864888378736642, '000000', 52, 'EQ0052', '精度检验台', 'INSPECTION', 52, '2026-10-18', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-19 01:00:01', -1, '2026-10-19 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111864888378736643, '000000', 53, 'EQ0053', '包装线A', 'PACKAGING', 53, '2026-10-18', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-19 01:00:01', -1, '2026-10-19 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111864888441651201, '000000', 54, 'EQ0054', '包装线B', 'PACKAGING', 54, '2026-10-18', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-19 01:00:01', -1, '2026-10-19 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111864888441651202, '000000', 55, 'EQ0055', '打包工位', 'PACKAGING', 55, '2026-10-18', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-19 01:00:01', -1, '2026-10-19 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111864888508760065, '000000', 56, 'EQ0056', '电火花机', 'EDM', 56, '2026-10-18', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-19 01:00:01', -1, '2026-10-19 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111864888508760066, '000000', 57, 'EQ0057', '线切割机', 'WEDM', 57, '2026-10-18', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-19 01:00:01', -1, '2026-10-19 01:00:01', '0');
INSERT INTO `eq_oee_record` VALUES (2111864888575868930, '000000', 58, 'EQ0058', '抛光工位', 'POLISH', 58, '2026-10-18', 480.00, 0.00, 0.00, 480.00, 0, 1.0000, 1.0000, 1.0000, 1.0000, '表现率无数据源(占位, 按1参与计算); 质量率无报工数据(占位, 按1参与计算)', -1, -1, '2026-10-19 01:00:01', -1, '2026-10-19 01:00:01', '0');

-- ----------------------------
-- Table structure for eq_patrol_record
-- ----------------------------
DROP TABLE IF EXISTS `eq_patrol_record`;
CREATE TABLE `eq_patrol_record`  (
  `record_id` bigint(20) NOT NULL COMMENT '记录ID(主键)',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '000000',
  `task_id` bigint(20) NULL DEFAULT NULL COMMENT '关联任务ID(可空, 手动巡检无任务)',
  `route_id` bigint(20) NULL DEFAULT NULL COMMENT '关联路线ID(冗余)',
  `equipment_id` bigint(20) NOT NULL COMMENT '设备ID',
  `equipment_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '设备编码(冗余)',
  `equipment_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '设备名称(冗余)',
  `check_item` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '检查项目',
  `actual_value` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '实际值/读数',
  `result` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT 'NORMAL' COMMENT 'NORMAL/ABNORMAL',
  `photo_oss_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '照片ossId',
  `executor_id` bigint(20) NULL DEFAULT NULL COMMENT '执行人ID',
  `executor_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '执行人姓名',
  `execute_time` datetime(0) NULL DEFAULT NULL COMMENT '执行时间',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `create_dept` bigint(20) NULL DEFAULT NULL,
  `create_by` bigint(20) NULL DEFAULT NULL,
  `create_time` datetime(0) NULL DEFAULT NULL,
  `update_by` bigint(20) NULL DEFAULT NULL,
  `update_time` datetime(0) NULL DEFAULT NULL,
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT '0',
  PRIMARY KEY (`record_id`) USING BTREE,
  INDEX `idx_task_id`(`task_id`) USING BTREE,
  INDEX `idx_equipment_id`(`equipment_id`) USING BTREE,
  INDEX `idx_execute_time`(`execute_time`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = 'MES巡检记录' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for eq_patrol_route
-- ----------------------------
DROP TABLE IF EXISTS `eq_patrol_route`;
CREATE TABLE `eq_patrol_route`  (
  `route_id` bigint(20) NOT NULL COMMENT '路线ID(主键)',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '000000',
  `route_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '路线名称',
  `description` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '路线描述',
  `equipment_ids` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT '设备ID列表(JSON数组)',
  `check_items` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT '通用检查项(JSON数组)',
  `frequency` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT 'DAILY' COMMENT '频率 DAILY/WEEKLY/MONTHLY',
  `status` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT 'ACTIVE' COMMENT 'ACTIVE/INACTIVE',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `create_dept` bigint(20) NULL DEFAULT NULL,
  `create_by` bigint(20) NULL DEFAULT NULL,
  `create_time` datetime(0) NULL DEFAULT NULL,
  `update_by` bigint(20) NULL DEFAULT NULL,
  `update_time` datetime(0) NULL DEFAULT NULL,
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT '0',
  PRIMARY KEY (`route_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = 'MES巡检路线' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for eq_patrol_task
-- ----------------------------
DROP TABLE IF EXISTS `eq_patrol_task`;
CREATE TABLE `eq_patrol_task`  (
  `task_id` bigint(20) NOT NULL COMMENT '任务ID(主键)',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '000000',
  `route_id` bigint(20) NOT NULL COMMENT '关联路线ID',
  `route_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '路线名称(冗余)',
  `plan_date` date NOT NULL COMMENT '计划巡检日期',
  `actual_date` datetime(0) NULL DEFAULT NULL COMMENT '实际完成时间',
  `assigned_to_id` bigint(20) NULL DEFAULT NULL COMMENT '指派人ID',
  `assigned_to_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '指派人姓名',
  `status` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT 'PENDING' COMMENT 'PENDING/IN_PROGRESS/COMPLETED/CANCELLED',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `create_dept` bigint(20) NULL DEFAULT NULL,
  `create_by` bigint(20) NULL DEFAULT NULL,
  `create_time` datetime(0) NULL DEFAULT NULL,
  `update_by` bigint(20) NULL DEFAULT NULL,
  `update_time` datetime(0) NULL DEFAULT NULL,
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT '0',
  PRIMARY KEY (`task_id`) USING BTREE,
  INDEX `idx_route_id`(`route_id`) USING BTREE,
  INDEX `idx_plan_date`(`plan_date`) USING BTREE,
  INDEX `idx_status`(`status`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = 'MES巡检任务' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for eq_repair
-- ----------------------------
DROP TABLE IF EXISTS `eq_repair`;
CREATE TABLE `eq_repair`  (
  `repair_id` bigint(20) NOT NULL COMMENT '维修ID(主键)',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '000000',
  `repair_no` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '维修单号',
  `equipment_id` bigint(20) NOT NULL COMMENT '设备ID',
  `fault_type` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '故障类型',
  `fault_desc` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '故障描述',
  `reporter_id` bigint(20) NULL DEFAULT NULL COMMENT '报修人ID',
  `reporter_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '报修人姓名',
  `repairer_id` bigint(20) NULL DEFAULT NULL COMMENT '维修人ID',
  `repairer_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '维修人姓名',
  `repair_start` datetime(0) NULL DEFAULT NULL COMMENT '维修开始时间',
  `repair_end` datetime(0) NULL DEFAULT NULL COMMENT '维修结束时间',
  `downtime_hours` decimal(10, 2) NULL DEFAULT NULL COMMENT '停机时长(小时)',
  `repair_cost` decimal(14, 2) NULL DEFAULT NULL COMMENT '维修成本',
  `status` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT 'REPORTED' COMMENT 'REPORTED/REPAIRING/COMPLETED',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '备注',
  `create_dept` bigint(20) NULL DEFAULT NULL COMMENT '创建部门',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT '0' COMMENT '删除标志',
  PRIMARY KEY (`repair_id`) USING BTREE,
  UNIQUE INDEX `uk_repair_no`(`tenant_id`, `repair_no`) USING BTREE,
  INDEX `idx_equipment_id`(`equipment_id`) USING BTREE,
  INDEX `idx_status`(`status`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = 'MES设备维修记录' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of eq_repair
-- ----------------------------
INSERT INTO `eq_repair` VALUES (2108785078500806657, '000000', 'RP-20261010-001', 4, 'WEAR', '锯床送料传动轴承磨损、同步带齿面裂纹，检查后更换传动组件。', 1, 'admin', 1, 'admin', '2026-10-10 13:01:57', '2026-10-10 13:01:57', 1.50, 279.50, 'COMPLETED', '锯床传动组件修复；功能恢复，替换件已清点。', 103, 1, '2026-10-10 13:01:57', 1, '2026-10-10 13:01:57', '0');
INSERT INTO `eq_repair` VALUES (2108785103310114818, '000000', 'RP-20261010-002', 5, 'SENSOR_FAILURE', '工件夹紧气路响应迟缓，限位接近开关信号不稳定，检修气阀和过滤组件。', 1, 'admin', 1, 'admin', '2026-10-10 13:02:03', '2026-10-10 13:02:03', 2.00, 780.00, 'COMPLETED', '数控车床气路与限位修复；功能恢复，替换件已清点。', 103, 1, '2026-10-10 13:02:03', 1, '2026-10-10 13:02:03', '0');
INSERT INTO `eq_repair` VALUES (2108785134721257474, '000000', 'RP-20261010-003', 7, 'ELECTRICAL', '辅助控制接触器触点烧蚀，气动机构卡滞，联动检查轴承与执行气缸。', 1, 'admin', 1, 'admin', '2026-10-10 13:02:10', '2026-10-10 13:02:10', 2.50, 769.50, 'COMPLETED', '加工中心辅助机构检修；功能恢复，替换件已清点。', 103, 1, '2026-10-10 13:02:10', 1, '2026-10-10 13:02:10', '0');

-- ----------------------------
-- Table structure for eq_repair_spare
-- ----------------------------
DROP TABLE IF EXISTS `eq_repair_spare`;
CREATE TABLE `eq_repair_spare`  (
  `id` bigint(20) NOT NULL COMMENT '主键',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '000000',
  `repair_id` bigint(20) NOT NULL COMMENT '维修单ID',
  `spare_id` bigint(20) NOT NULL COMMENT '备件ID',
  `spare_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '备件编码(冗余)',
  `spare_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '备件名称(冗余)',
  `spec` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '规格(冗余)',
  `unit` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '单位(冗余)',
  `quantity` decimal(14, 4) NOT NULL COMMENT '领用数量',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `create_dept` bigint(20) NULL DEFAULT NULL,
  `create_by` bigint(20) NULL DEFAULT NULL,
  `create_time` datetime(0) NULL DEFAULT NULL,
  `update_by` bigint(20) NULL DEFAULT NULL,
  `update_time` datetime(0) NULL DEFAULT NULL,
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx_repair_id`(`repair_id`) USING BTREE,
  INDEX `idx_spare_id`(`spare_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = 'MES维修领用备件明细' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of eq_repair_spare
-- ----------------------------
INSERT INTO `eq_repair_spare` VALUES (2108785079616491522, '000000', 2108785078500806657, 2108783861921959937, 'SP20261010001', '深沟球轴承 6204-2RS', '20×47×14 mm 双面密封', '件', 5.0000, '锯床传动组件修复', 103, 1, '2026-10-10 13:01:57', 1, '2026-10-10 17:41:35', '0');
INSERT INTO `eq_repair_spare` VALUES (2108785079763292161, '000000', 2108785078500806657, 2108783866107875329, 'SP20261010003', '同步带 550-5M-15', '周长550 mm 齿距5 mm 宽15 mm', '条', 3.0000, '锯床传动组件修复', 103, 1, '2026-10-10 13:01:57', 1, '2026-10-10 17:41:35', '0');
INSERT INTO `eq_repair_spare` VALUES (2108785104245444609, '000000', 2108785103310114818, 2108783867789791234, 'SP20261010004', '电感式接近开关 M12', 'DC24V PNP常开 检测距离4 mm', '件', 2.0000, '数控车床气路与限位修复', 103, 1, '2026-10-10 13:02:03', 1, '2026-10-10 17:41:36', '0');
INSERT INTO `eq_repair_spare` VALUES (2108785104329330690, '000000', 2108785103310114818, 2108783869656256513, 'SP20261010005', '二位五通电磁阀 5V210-08', 'G1/4接口 DC24V线圈', '件', 4.0000, '数控车床气路与限位修复', 103, 1, '2026-10-10 13:02:03', 1, '2026-10-10 17:41:36', '0');
INSERT INTO `eq_repair_spare` VALUES (2108785104417411073, '000000', 2108785103310114818, 2108783873410158593, 'SP20261010007', '过滤减压阀 AFR2000', 'G1/4接口 0.05-0.85 MPa', '件', 2.0000, '数控车床气路与限位修复', 103, 1, '2026-10-10 13:02:03', 1, '2026-10-10 17:41:36', '0');
INSERT INTO `eq_repair_spare` VALUES (2108785135513980930, '000000', 2108785134721257474, 2108783874987216898, 'SP20261010008', '交流接触器 25A', '三极25A 线圈AC220V', '件', 3.0000, '加工中心辅助机构检修', 103, 1, '2026-10-10 13:02:10', 1, '2026-10-10 17:41:37', '0');
INSERT INTO `eq_repair_spare` VALUES (2108785135581089794, '000000', 2108785134721257474, 2108783864115580929, 'SP20261010002', '深沟球轴承 6205-2RS', '25×52×15 mm 双面密封', '件', 3.0000, '加工中心辅助机构检修', 103, 1, '2026-10-10 13:02:10', 1, '2026-10-10 17:41:35', '0');
INSERT INTO `eq_repair_spare` VALUES (2108785135648198658, '000000', 2108785134721257474, 2108783871535304705, 'SP20261010006', '标准气缸 SC32×100', '缸径32 mm 行程100 mm', '件', 2.0000, '加工中心辅助机构检修', 103, 1, '2026-10-10 13:02:10', 1, '2026-10-10 17:41:36', '0');

-- ----------------------------
-- Table structure for eq_spare_erp_sync
-- ----------------------------
DROP TABLE IF EXISTS `eq_spare_erp_sync`;
CREATE TABLE `eq_spare_erp_sync`  (
  `sync_id` bigint(20) NOT NULL COMMENT '同步台账ID(主键)',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '000000',
  `biz_key` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '业务幂等键 EQSP:<tenantId>:<logId>',
  `spare_id` bigint(20) NOT NULL COMMENT '备件ID',
  `spare_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '备件编码(冗余)',
  `material_id` bigint(20) NULL DEFAULT NULL COMMENT 'ERP物料ID',
  `warehouse_id` bigint(20) NULL DEFAULT NULL COMMENT 'ERP仓库ID',
  `transaction_type` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'IN/OUT/REPAIR_USE/RETURN',
  `quantity` decimal(14, 4) NOT NULL COMMENT '变动数量(正数)',
  `ref_type` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '关联单据类型',
  `ref_id` bigint(20) NULL DEFAULT NULL COMMENT '关联单据ID',
  `log_id` bigint(20) NULL DEFAULT NULL COMMENT 'MES库存流水ID(eq_spare_stock_log.log_id)',
  `sync_status` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT 'PENDING' COMMENT 'PENDING/SENT/SYNCED/FAILED',
  `retry_count` int(11) NULL DEFAULT 0 COMMENT '重投次数',
  `last_error` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '最近一次失败原因',
  `last_publish_time` datetime(0) NULL DEFAULT NULL COMMENT '最近一次投递时间',
  `erp_available_after` decimal(14, 4) NULL DEFAULT NULL COMMENT 'ERP过账后可用量快照',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `create_dept` bigint(20) NULL DEFAULT NULL,
  `create_by` bigint(20) NULL DEFAULT NULL,
  `create_time` datetime(0) NULL DEFAULT NULL,
  `update_by` bigint(20) NULL DEFAULT NULL,
  `update_time` datetime(0) NULL DEFAULT NULL,
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT '0',
  PRIMARY KEY (`sync_id`) USING BTREE,
  UNIQUE INDEX `uk_tenant_biz_key`(`tenant_id`, `biz_key`) USING BTREE,
  INDEX `idx_spare_id`(`spare_id`) USING BTREE,
  INDEX `idx_sync_status`(`sync_status`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = 'MES备件→ERP过账同步台账' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of eq_spare_erp_sync
-- ----------------------------
INSERT INTO `eq_spare_erp_sync` VALUES (2108783914535309314, '000000', 'EQSP:000000:2108783914464006146', 2108783861921959937, 'SP20261010001', 2108783860164546561, 2108783857954148353, 'IN', 24.0000, 'MANUAL', NULL, 2108783914464006146, 'SYNCED', 0, NULL, '2026-10-10 12:57:20', 24.0000, '维修备件库期初清点入库；规格和单位按备件主数据办理。', 103, 1, '2026-10-10 12:57:19', 1, '2026-10-10 17:41:35', '0');
INSERT INTO `eq_spare_erp_sync` VALUES (2108783918209519617, '000000', 'EQSP:000000:2108783918201131009', 2108783864115580929, 'SP20261010002', 2108783863096365058, 2108783857954148353, 'IN', 20.0000, 'MANUAL', NULL, 2108783918201131009, 'SYNCED', 0, NULL, '2026-10-10 12:57:21', 20.0000, '维修备件库期初清点入库；规格和单位按备件主数据办理。', 103, 1, '2026-10-10 12:57:20', 1, '2026-10-10 17:41:35', '0');
INSERT INTO `eq_spare_erp_sync` VALUES (2108783924064768001, '000000', 'EQSP:000000:2108783924047990785', 2108783866107875329, 'SP20261010003', 2108783865059299329, 2108783857954148353, 'IN', 16.0000, 'MANUAL', NULL, 2108783924047990785, 'SYNCED', 0, NULL, '2026-10-10 12:57:22', 16.0000, '维修备件库期初清点入库；规格和单位按备件主数据办理。', 103, 1, '2026-10-10 12:57:21', 1, '2026-10-10 17:41:35', '0');
INSERT INTO `eq_spare_erp_sync` VALUES (2108783932398850049, '000000', 'EQSP:000000:2108783932390461442', 2108783867789791234, 'SP20261010004', 2108783866938347521, 2108783857954148353, 'IN', 12.0000, 'MANUAL', NULL, 2108783932390461442, 'SYNCED', 0, NULL, '2026-10-10 12:57:24', 12.0000, '维修备件库期初清点入库；规格和单位按备件主数据办理。', 103, 1, '2026-10-10 12:57:23', 1, '2026-10-10 17:41:36', '0');
INSERT INTO `eq_spare_erp_sync` VALUES (2108783942440013825, '000000', 'EQSP:000000:2108783942427430914', 2108783869656256513, 'SP20261010005', 2108783868733509633, 2108783857954148353, 'IN', 18.0000, 'MANUAL', NULL, 2108783942427430914, 'SYNCED', 0, NULL, '2026-10-10 12:57:27', 18.0000, '维修备件库期初清点入库；规格和单位按备件主数据办理。', 103, 1, '2026-10-10 12:57:26', 1, '2026-10-10 17:41:36', '0');
INSERT INTO `eq_spare_erp_sync` VALUES (2108783954867736577, '000000', 'EQSP:000000:2108783954855153665', 2108783871535304705, 'SP20261010006', 2108783870507700226, 2108783857954148353, 'IN', 8.0000, 'MANUAL', NULL, 2108783954855153665, 'SYNCED', 0, NULL, '2026-10-10 12:57:29', 8.0000, '维修备件库期初清点入库；规格和单位按备件主数据办理。', 103, 1, '2026-10-10 12:57:29', 1, '2026-10-10 17:41:36', '0');
INSERT INTO `eq_spare_erp_sync` VALUES (2108783969589743617, '000000', 'EQSP:000000:2108783969577160706', 2108783873410158593, 'SP20261010007', 2108783872487411714, 2108783857954148353, 'IN', 10.0000, 'MANUAL', NULL, 2108783969577160706, 'SYNCED', 0, NULL, '2026-10-10 12:57:33', 10.0000, '维修备件库期初清点入库；规格和单位按备件主数据办理。', 103, 1, '2026-10-10 12:57:32', 1, '2026-10-10 17:41:36', '0');
INSERT INTO `eq_spare_erp_sync` VALUES (2108783988065652737, '000000', 'EQSP:000000:2108783988057264129', 2108783874987216898, 'SP20261010008', 2108783874236436481, 2108783857954148353, 'IN', 6.0000, 'MANUAL', NULL, 2108783988057264129, 'SYNCED', 0, NULL, '2026-10-10 12:57:37', 6.0000, '维修备件库期初清点入库；规格和单位按备件主数据办理。', 103, 1, '2026-10-10 12:57:37', 1, '2026-10-10 17:41:37', '0');
INSERT INTO `eq_spare_erp_sync` VALUES (2108785079591325698, '000000', 'EQSP:000000:2108785079587131394', 2108783861921959937, 'SP20261010001', 2108783860164546561, 2108783857954148353, 'REPAIR_USE', 5.0000, 'REPAIR', 2108785078500806657, 2108785079587131394, 'SYNCED', 0, NULL, '2026-10-10 13:01:58', 19.0000, '锯床传动组件修复', 103, 1, '2026-10-10 13:01:57', 1, '2026-10-10 17:41:35', '0');
INSERT INTO `eq_spare_erp_sync` VALUES (2108785079746514945, '000000', 'EQSP:000000:2108785079738126338', 2108783866107875329, 'SP20261010003', 2108783865059299329, 2108783857954148353, 'REPAIR_USE', 3.0000, 'REPAIR', 2108785078500806657, 2108785079738126338, 'SYNCED', 0, NULL, '2026-10-10 13:01:58', 13.0000, '锯床传动组件修复', 103, 1, '2026-10-10 13:01:57', 1, '2026-10-10 17:41:35', '0');
INSERT INTO `eq_spare_erp_sync` VALUES (2108785104228667394, '000000', 'EQSP:000000:2108785104216084481', 2108783867789791234, 'SP20261010004', 2108783866938347521, 2108783857954148353, 'REPAIR_USE', 2.0000, 'REPAIR', 2108785103310114818, 2108785104216084481, 'SYNCED', 0, NULL, '2026-10-10 13:02:04', 10.0000, '数控车床气路与限位修复', 103, 1, '2026-10-10 13:02:03', 1, '2026-10-10 17:41:36', '0');
INSERT INTO `eq_spare_erp_sync` VALUES (2108785104312553474, '000000', 'EQSP:000000:2108785104308359169', 2108783869656256513, 'SP20261010005', 2108783868733509633, 2108783857954148353, 'REPAIR_USE', 4.0000, 'REPAIR', 2108785103310114818, 2108785104308359169, 'SYNCED', 0, NULL, '2026-10-10 13:02:04', 14.0000, '数控车床气路与限位修复', 103, 1, '2026-10-10 13:02:03', 1, '2026-10-10 17:41:36', '0');
INSERT INTO `eq_spare_erp_sync` VALUES (2108785104400633858, '000000', 'EQSP:000000:2108785104392245250', 2108783873410158593, 'SP20261010007', 2108783872487411714, 2108783857954148353, 'REPAIR_USE', 2.0000, 'REPAIR', 2108785103310114818, 2108785104392245250, 'SYNCED', 0, NULL, '2026-10-10 13:02:05', 8.0000, '数控车床气路与限位修复', 103, 1, '2026-10-10 13:02:03', 1, '2026-10-10 17:41:36', '0');
INSERT INTO `eq_spare_erp_sync` VALUES (2108785135497203714, '000000', 'EQSP:000000:2108785135484620801', 2108783874987216898, 'SP20261010008', 2108783874236436481, 2108783857954148353, 'REPAIR_USE', 3.0000, 'REPAIR', 2108785134721257474, 2108785135484620801, 'SYNCED', 0, NULL, '2026-10-10 13:02:12', 3.0000, '加工中心辅助机构检修', 103, 1, '2026-10-10 13:02:10', 1, '2026-10-10 17:41:37', '0');
INSERT INTO `eq_spare_erp_sync` VALUES (2108785135568506882, '000000', 'EQSP:000000:2108785135560118273', 2108783864115580929, 'SP20261010002', 2108783863096365058, 2108783857954148353, 'REPAIR_USE', 3.0000, 'REPAIR', 2108785134721257474, 2108785135560118273, 'SYNCED', 0, NULL, '2026-10-10 13:02:11', 17.0000, '加工中心辅助机构检修', 103, 1, '2026-10-10 13:02:10', 1, '2026-10-10 17:41:35', '0');
INSERT INTO `eq_spare_erp_sync` VALUES (2108785135635615746, '000000', 'EQSP:000000:2108785135623032834', 2108783871535304705, 'SP20261010006', 2108783870507700226, 2108783857954148353, 'REPAIR_USE', 2.0000, 'REPAIR', 2108785134721257474, 2108785135623032834, 'SYNCED', 0, NULL, '2026-10-10 13:02:12', 6.0000, '加工中心辅助机构检修', 103, 1, '2026-10-10 13:02:10', 1, '2026-10-10 17:41:36', '0');
INSERT INTO `eq_spare_erp_sync` VALUES (2108785172197363713, '000000', 'EQSP:000000:2108785172151226370', 2108783867789791234, 'SP20261010004', 2108783866938347521, 2108783857954148353, 'OUT', 1.0000, 'MANUAL', NULL, 2108785172151226370, 'SYNCED', 0, NULL, '2026-10-10 13:02:20', 9.0000, '电气巡检现场领用，限位器维护备用。', 103, 1, '2026-10-10 13:02:19', 1, '2026-10-10 17:41:36', '0');
INSERT INTO `eq_spare_erp_sync` VALUES (2108790827289374721, '000000', 'EQSP:000000:2108790827255820289', 2108790517854597122, 'SP20261010009', 2108790516185264129, 2108783857954148353, 'IN', 30.0000, 'MANUAL', NULL, 2108790827255820289, 'SYNCED', 0, NULL, '2026-10-10 13:24:48', 30.0000, '维修备件库期初清点入库；规格和单位按备件主数据办理。', 103, 1, '2026-10-10 13:24:47', 1, '2026-10-10 17:41:37', '0');
INSERT INTO `eq_spare_erp_sync` VALUES (2108790872868876290, '000000', 'EQSP:000000:2108790872856293377', 2108783861921959937, 'SP20261010001', 2108783860164546561, 2108783857954148353, 'RETURN', 2.0000, 'SPARE_RETURN', 2108785370189484033, 2108790872856293377, 'SYNCED', 0, NULL, '2026-10-10 13:24:59', 21.0000, 'RP-20261010-001 维修余料退回', 103, 1, '2026-10-10 13:24:58', 1, '2026-10-10 17:41:35', '0');
INSERT INTO `eq_spare_erp_sync` VALUES (2108790872940179458, '000000', 'EQSP:000000:2108790872935985154', 2108783866107875329, 'SP20261010003', 2108783865059299329, 2108783857954148353, 'RETURN', 1.0000, 'SPARE_RETURN', 2108785370189484033, 2108790872935985154, 'SYNCED', 0, NULL, '2026-10-10 13:24:59', 14.0000, 'RP-20261010-001 维修余料退回', 103, 1, '2026-10-10 13:24:58', 1, '2026-10-10 17:41:35', '0');
INSERT INTO `eq_spare_erp_sync` VALUES (2108790920969154561, '000000', 'EQSP:000000:2108790920956571650', 2108783869656256513, 'SP20261010005', 2108783868733509633, 2108783857954148353, 'RETURN', 1.0000, 'SPARE_RETURN', 2108790920151265281, 2108790920956571650, 'SYNCED', 0, NULL, '2026-10-10 13:25:10', 15.0000, 'RP-20261010-002 维修余料退回', 103, 1, '2026-10-10 13:25:10', 1, '2026-10-10 17:41:36', '0');

-- ----------------------------
-- Table structure for eq_spare_part
-- ----------------------------
DROP TABLE IF EXISTS `eq_spare_part`;
CREATE TABLE `eq_spare_part`  (
  `spare_id` bigint(20) NOT NULL COMMENT '备件ID(主键)',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '000000',
  `spare_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '备件编码(唯一)',
  `spare_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '备件名称',
  `spec` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '规格型号',
  `model` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '型号',
  `unit` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '单位',
  `category` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '分类(字典 mes_spare_category)',
  `safety_stock` decimal(14, 4) NULL DEFAULT 0.0000 COMMENT '安全库存',
  `current_stock` decimal(14, 4) NULL DEFAULT 0.0000 COMMENT '当前库存(ERP库存的派生冗余缓存; 权威账本在 wm_material_stock, 可用量=在库-已预留且frozen_flag=0)',
  `material_id` bigint(20) NULL DEFAULT NULL COMMENT 'ERP物料ID(bd_material.material_id), NULL=未映射',
  `warehouse_id` bigint(20) NULL DEFAULT NULL COMMENT 'ERP仓库ID(wm_warehouse.warehouse_id), 过账目标仓库',
  `unit_cost` decimal(18, 4) NULL DEFAULT 0.0000 COMMENT '备件参考单价(人工维护; 出入库过账时由服务端读库填入 MQ, 供 ERP 移动平均计价)',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `create_dept` bigint(20) NULL DEFAULT NULL,
  `create_by` bigint(20) NULL DEFAULT NULL,
  `create_time` datetime(0) NULL DEFAULT NULL,
  `update_by` bigint(20) NULL DEFAULT NULL,
  `update_time` datetime(0) NULL DEFAULT NULL,
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT '0',
  PRIMARY KEY (`spare_id`) USING BTREE,
  UNIQUE INDEX `uk_tenant_code`(`tenant_id`, `spare_code`) USING BTREE,
  INDEX `idx_category`(`category`) USING BTREE,
  INDEX `idx_material_id`(`material_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = 'MES备件主数据' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of eq_spare_part
-- ----------------------------
INSERT INTO `eq_spare_part` VALUES (2108783861921959937, '000000', 'SP20261010001', '深沟球轴承 6204-2RS', '20×47×14 mm 双面密封', '6204-2RS', '件', 'MECHANICAL', 5.0000, 21.0000, 2108783860164546561, 2108783857954148353, 42.5000, '设备维修常备件；领用按维修单或现场领用记录办理。', 103, 1, '2026-10-10 12:57:07', 1, '2026-10-10 17:41:35', '0');
INSERT INTO `eq_spare_part` VALUES (2108783864115580929, '000000', 'SP20261010002', '深沟球轴承 6205-2RS', '25×52×15 mm 双面密封', '6205-2RS', '件', 'MECHANICAL', 5.0000, 17.0000, 2108783863096365058, 2108783857954148353, 58.0000, '设备维修常备件；领用按维修单或现场领用记录办理。', 103, 1, '2026-10-10 12:57:07', 1, '2026-10-10 17:41:35', '0');
INSERT INTO `eq_spare_part` VALUES (2108783866107875329, '000000', 'SP20261010003', '同步带 550-5M-15', '周长550 mm 齿距5 mm 宽15 mm', '550-5M-15', '条', 'CONSUMABLE', 6.0000, 14.0000, 2108783865059299329, 2108783857954148353, 76.0000, '设备维修常备件；领用按维修单或现场领用记录办理。', 103, 1, '2026-10-10 12:57:08', 1, '2026-10-10 17:41:35', '0');
INSERT INTO `eq_spare_part` VALUES (2108783867789791234, '000000', 'SP20261010004', '电感式接近开关 M12', 'DC24V PNP常开 检测距离4 mm', 'M12-PNP-NO', '件', 'ELECTRICAL', 4.0000, 9.0000, 2108783866938347521, 2108783857954148353, 128.0000, '设备维修常备件；领用按维修单或现场领用记录办理。', 103, 1, '2026-10-10 12:57:08', 1, '2026-10-10 17:41:36', '0');
INSERT INTO `eq_spare_part` VALUES (2108783869656256513, '000000', 'SP20261010005', '二位五通电磁阀 5V210-08', 'G1/4接口 DC24V线圈', '5V210-08', '件', 'HYDRAULIC', 5.0000, 15.0000, 2108783868733509633, 2108783857954148353, 96.0000, '设备维修常备件；领用按维修单或现场领用记录办理。', 103, 1, '2026-10-10 12:57:08', 1, '2026-10-10 17:41:36', '0');
INSERT INTO `eq_spare_part` VALUES (2108783871535304705, '000000', 'SP20261010006', '标准气缸 SC32×100', '缸径32 mm 行程100 mm', 'SC32X100', '件', 'HYDRAULIC', 3.0000, 6.0000, 2108783870507700226, 2108783857954148353, 168.0000, '设备维修常备件；领用按维修单或现场领用记录办理。', 103, 1, '2026-10-10 12:57:09', 1, '2026-10-10 17:41:36', '0');
INSERT INTO `eq_spare_part` VALUES (2108783873410158593, '000000', 'SP20261010007', '过滤减压阀 AFR2000', 'G1/4接口 0.05-0.85 MPa', 'AFR2000', '件', 'HYDRAULIC', 3.0000, 8.0000, 2108783872487411714, 2108783857954148353, 118.0000, '设备维修常备件；领用按维修单或现场领用记录办理。', 103, 1, '2026-10-10 12:57:09', 1, '2026-10-10 17:41:36', '0');
INSERT INTO `eq_spare_part` VALUES (2108783874987216898, '000000', 'SP20261010008', '交流接触器 25A', '三极25A 线圈AC220V', 'CJX2-2510', '件', 'ELECTRICAL', 4.0000, 3.0000, 2108783874236436481, 2108783857954148353, 86.5000, '设备维修常备件；领用按维修单或现场领用记录办理。', 103, 1, '2026-10-10 12:57:10', 1, '2026-10-10 17:41:37', '0');
INSERT INTO `eq_spare_part` VALUES (2108790517854597122, '000000', 'SP20261010009', '旋转轴唇形密封圈 TC25×47×7', '内径25 mm 外径47 mm 厚7 mm 丁腈橡胶', 'TC25X47X7', '件', 'CONSUMABLE', 5.0000, 30.0000, 2108790516185264129, 2108783857954148353, 12.8000, '设备维修常备件；领用按维修单或现场领用记录办理。', 103, 1, '2026-10-10 13:23:34', 1, '2026-10-10 17:41:37', '0');

-- ----------------------------
-- Table structure for eq_spare_return
-- ----------------------------
DROP TABLE IF EXISTS `eq_spare_return`;
CREATE TABLE `eq_spare_return`  (
  `return_id` bigint(20) NOT NULL COMMENT '退库单ID(主键)',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '000000',
  `return_no` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '退库单号 MESRT+yyyyMMdd+4位当日序号',
  `warehouse_id` bigint(20) NULL DEFAULT NULL COMMENT '退库目标ERP仓库ID(wm_warehouse.warehouse_id)',
  `return_date` datetime(0) NULL DEFAULT NULL COMMENT '退库日期',
  `return_type` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT 'REPAIR_RETURN/EXCESS_RETURN/OTHER',
  `status` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT 'DRAFT' COMMENT 'DRAFT/CONFIRMED/CANCELLED',
  `total_qty` decimal(14, 4) NULL DEFAULT 0.0000 COMMENT '明细数量合计',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `confirm_by` bigint(20) NULL DEFAULT NULL COMMENT '确认人ID',
  `confirm_time` datetime(0) NULL DEFAULT NULL COMMENT '确认时间',
  `version` int(11) NULL DEFAULT 0 COMMENT '版本号(确认时CAS自增)',
  `create_dept` bigint(20) NULL DEFAULT NULL,
  `create_by` bigint(20) NULL DEFAULT NULL,
  `create_time` datetime(0) NULL DEFAULT NULL,
  `update_by` bigint(20) NULL DEFAULT NULL,
  `update_time` datetime(0) NULL DEFAULT NULL,
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT '0',
  PRIMARY KEY (`return_id`) USING BTREE,
  UNIQUE INDEX `uk_spare_return_no`(`tenant_id`, `return_no`) USING BTREE,
  INDEX `idx_spare_return_status`(`tenant_id`, `status`) USING BTREE,
  INDEX `idx_spare_return_date`(`tenant_id`, `return_date`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = 'MES备件退库单' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of eq_spare_return
-- ----------------------------
INSERT INTO `eq_spare_return` VALUES (2108785370189484033, '000000', 'MESRT202610100001', 2108783857954148353, '2026-10-10 00:00:00', 'REPAIR_RETURN', 'CONFIRMED', 3.0000, 'RP-20261010-001 余料清点退库', 1, '2026-10-10 13:24:58', 1, 103, 1, '2026-10-10 13:03:06', 1, '2026-10-10 13:03:06', '0');
INSERT INTO `eq_spare_return` VALUES (2108790920151265281, '000000', 'MESRT202610100002', 2108783857954148353, '2026-10-10 00:00:00', 'EXCESS_RETURN', 'CONFIRMED', 1.0000, 'RP-20261010-002 余料清点退库', 1, '2026-10-10 13:25:10', 1, 103, 1, '2026-10-10 13:25:09', 1, '2026-10-10 13:25:09', '0');
INSERT INTO `eq_spare_return` VALUES (2108790967618203649, '000000', 'MESRT202610100003', 2108783857954148353, '2026-10-10 00:00:00', 'EXCESS_RETURN', 'DRAFT', 1.0000, 'RP-20261010-003 气缸余料待包装复核，暂未确认过账', NULL, NULL, 1, 103, 1, '2026-10-10 13:25:21', 1, '2026-10-10 13:25:21', '0');

-- ----------------------------
-- Table structure for eq_spare_return_line
-- ----------------------------
DROP TABLE IF EXISTS `eq_spare_return_line`;
CREATE TABLE `eq_spare_return_line`  (
  `line_id` bigint(20) NOT NULL COMMENT '明细行ID(主键)',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '000000',
  `return_id` bigint(20) NOT NULL COMMENT '退库单ID',
  `spare_id` bigint(20) NOT NULL COMMENT '备件ID',
  `spare_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '备件编码(冗余)',
  `spare_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '备件名称(冗余)',
  `return_qty` decimal(14, 4) NOT NULL COMMENT '退库数量(>0)',
  `unit_cost` decimal(18, 4) NULL DEFAULT NULL COMMENT '备件参考单价快照(服务端从eq_spare_part读取)',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `create_dept` bigint(20) NULL DEFAULT NULL,
  `create_by` bigint(20) NULL DEFAULT NULL,
  `create_time` datetime(0) NULL DEFAULT NULL,
  `update_by` bigint(20) NULL DEFAULT NULL,
  `update_time` datetime(0) NULL DEFAULT NULL,
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT '0',
  PRIMARY KEY (`line_id`) USING BTREE,
  INDEX `idx_spare_return_line`(`tenant_id`, `return_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = 'MES备件退库单明细' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of eq_spare_return_line
-- ----------------------------
INSERT INTO `eq_spare_return_line` VALUES (2108785370206261250, '000000', 2108785370189484033, 2108783861921959937, 'SP20261010001', '深沟球轴承 6204-2RS', 2.0000, 42.5000, 'RP-20261010-001 维修余料退回', 103, 1, '2026-10-10 13:03:06', 1, '2026-10-10 17:41:35', '0');
INSERT INTO `eq_spare_return_line` VALUES (2108785370264981505, '000000', 2108785370189484033, 2108783866107875329, 'SP20261010003', '同步带 550-5M-15', 1.0000, 76.0000, 'RP-20261010-001 维修余料退回', 103, 1, '2026-10-10 13:03:06', 1, '2026-10-10 17:41:35', '0');
INSERT INTO `eq_spare_return_line` VALUES (2108790920168042498, '000000', 2108790920151265281, 2108783869656256513, 'SP20261010005', '二位五通电磁阀 5V210-08', 1.0000, 96.0000, 'RP-20261010-002 维修余料退回', 103, 1, '2026-10-10 13:25:09', 1, '2026-10-10 17:41:36', '0');
INSERT INTO `eq_spare_return_line` VALUES (2108790967672729601, '000000', 2108790967618203649, 2108783871535304705, 'SP20261010006', '标准气缸 SC32×100', 1.0000, 168.0000, 'RP-20261010-003 维修余料退回', 103, 1, '2026-10-10 13:25:21', 1, '2026-10-10 13:25:21', '1');
INSERT INTO `eq_spare_return_line` VALUES (2108790968406732801, '000000', 2108790967618203649, 2108783871535304705, 'SP20261010006', '标准气缸 SC32×100', 1.0000, 168.0000, 'RP-20261010-003 待复核余料', 103, 1, '2026-10-10 13:25:21', 1, '2026-10-10 17:41:36', '0');

-- ----------------------------
-- Table structure for eq_spare_stock_log
-- ----------------------------
DROP TABLE IF EXISTS `eq_spare_stock_log`;
CREATE TABLE `eq_spare_stock_log`  (
  `log_id` bigint(20) NOT NULL COMMENT '流水ID(主键)',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '000000',
  `spare_id` bigint(20) NOT NULL COMMENT '备件ID',
  `spare_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '备件编码(冗余)',
  `spare_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '备件名称(冗余)',
  `transaction_type` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'IN/OUT/REPAIR_USE',
  `quantity` decimal(14, 4) NOT NULL COMMENT '变动数量(正数)',
  `before_qty` decimal(14, 4) NULL DEFAULT NULL COMMENT '变动前库存',
  `after_qty` decimal(14, 4) NULL DEFAULT NULL COMMENT '变动后库存',
  `ref_type` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '关联单据类型 MANUAL/REPAIR',
  `ref_id` bigint(20) NULL DEFAULT NULL COMMENT '关联单据ID',
  `operator_id` bigint(20) NULL DEFAULT NULL COMMENT '操作人ID',
  `operator_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '操作人姓名',
  `operate_time` datetime(0) NULL DEFAULT NULL COMMENT '操作时间',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `create_dept` bigint(20) NULL DEFAULT NULL,
  `create_by` bigint(20) NULL DEFAULT NULL,
  `create_time` datetime(0) NULL DEFAULT NULL,
  `update_by` bigint(20) NULL DEFAULT NULL,
  `update_time` datetime(0) NULL DEFAULT NULL,
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT '0',
  PRIMARY KEY (`log_id`) USING BTREE,
  INDEX `idx_spare_id`(`spare_id`) USING BTREE,
  INDEX `idx_operate_time`(`operate_time`) USING BTREE,
  INDEX `idx_ref`(`ref_type`, `ref_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = 'MES备件库存流水' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of eq_spare_stock_log
-- ----------------------------
INSERT INTO `eq_spare_stock_log` VALUES (2108783914464006146, '000000', 2108783861921959937, 'SP20261010001', '深沟球轴承 6204-2RS', 'IN', 24.0000, 0.0000, 24.0000, 'MANUAL', NULL, 1, 'admin', '2026-10-10 12:57:19', '维修备件库期初清点入库；规格和单位按备件主数据办理。', 103, 1, '2026-10-10 12:57:19', 1, '2026-10-10 17:41:35', '0');
INSERT INTO `eq_spare_stock_log` VALUES (2108783918201131009, '000000', 2108783864115580929, 'SP20261010002', '深沟球轴承 6205-2RS', 'IN', 20.0000, 0.0000, 20.0000, 'MANUAL', NULL, 1, 'admin', '2026-10-10 12:57:20', '维修备件库期初清点入库；规格和单位按备件主数据办理。', 103, 1, '2026-10-10 12:57:20', 1, '2026-10-10 17:41:35', '0');
INSERT INTO `eq_spare_stock_log` VALUES (2108783924047990785, '000000', 2108783866107875329, 'SP20261010003', '同步带 550-5M-15', 'IN', 16.0000, 0.0000, 16.0000, 'MANUAL', NULL, 1, 'admin', '2026-10-10 12:57:21', '维修备件库期初清点入库；规格和单位按备件主数据办理。', 103, 1, '2026-10-10 12:57:21', 1, '2026-10-10 17:41:35', '0');
INSERT INTO `eq_spare_stock_log` VALUES (2108783932390461442, '000000', 2108783867789791234, 'SP20261010004', '电感式接近开关 M12', 'IN', 12.0000, 0.0000, 12.0000, 'MANUAL', NULL, 1, 'admin', '2026-10-10 12:57:23', '维修备件库期初清点入库；规格和单位按备件主数据办理。', 103, 1, '2026-10-10 12:57:23', 1, '2026-10-10 17:41:36', '0');
INSERT INTO `eq_spare_stock_log` VALUES (2108783942427430914, '000000', 2108783869656256513, 'SP20261010005', '二位五通电磁阀 5V210-08', 'IN', 18.0000, 0.0000, 18.0000, 'MANUAL', NULL, 1, 'admin', '2026-10-10 12:57:26', '维修备件库期初清点入库；规格和单位按备件主数据办理。', 103, 1, '2026-10-10 12:57:26', 1, '2026-10-10 17:41:36', '0');
INSERT INTO `eq_spare_stock_log` VALUES (2108783954855153665, '000000', 2108783871535304705, 'SP20261010006', '标准气缸 SC32×100', 'IN', 8.0000, 0.0000, 8.0000, 'MANUAL', NULL, 1, 'admin', '2026-10-10 12:57:29', '维修备件库期初清点入库；规格和单位按备件主数据办理。', 103, 1, '2026-10-10 12:57:29', 1, '2026-10-10 17:41:36', '0');
INSERT INTO `eq_spare_stock_log` VALUES (2108783969577160706, '000000', 2108783873410158593, 'SP20261010007', '过滤减压阀 AFR2000', 'IN', 10.0000, 0.0000, 10.0000, 'MANUAL', NULL, 1, 'admin', '2026-10-10 12:57:32', '维修备件库期初清点入库；规格和单位按备件主数据办理。', 103, 1, '2026-10-10 12:57:32', 1, '2026-10-10 17:41:36', '0');
INSERT INTO `eq_spare_stock_log` VALUES (2108783988057264129, '000000', 2108783874987216898, 'SP20261010008', '交流接触器 25A', 'IN', 6.0000, 0.0000, 6.0000, 'MANUAL', NULL, 1, 'admin', '2026-10-10 12:57:37', '维修备件库期初清点入库；规格和单位按备件主数据办理。', 103, 1, '2026-10-10 12:57:37', 1, '2026-10-10 17:41:37', '0');
INSERT INTO `eq_spare_stock_log` VALUES (2108785079587131394, '000000', 2108783861921959937, 'SP20261010001', '深沟球轴承 6204-2RS', 'REPAIR_USE', 5.0000, 24.0000, 19.0000, 'REPAIR', 2108785078500806657, 1, 'admin', '2026-10-10 13:01:57', '锯床传动组件修复', 103, 1, '2026-10-10 13:01:57', 1, '2026-10-10 17:41:35', '0');
INSERT INTO `eq_spare_stock_log` VALUES (2108785079738126338, '000000', 2108783866107875329, 'SP20261010003', '同步带 550-5M-15', 'REPAIR_USE', 3.0000, 16.0000, 13.0000, 'REPAIR', 2108785078500806657, 1, 'admin', '2026-10-10 13:01:57', '锯床传动组件修复', 103, 1, '2026-10-10 13:01:57', 1, '2026-10-10 17:41:35', '0');
INSERT INTO `eq_spare_stock_log` VALUES (2108785104216084481, '000000', 2108783867789791234, 'SP20261010004', '电感式接近开关 M12', 'REPAIR_USE', 2.0000, 12.0000, 10.0000, 'REPAIR', 2108785103310114818, 1, 'admin', '2026-10-10 13:02:03', '数控车床气路与限位修复', 103, 1, '2026-10-10 13:02:03', 1, '2026-10-10 17:41:36', '0');
INSERT INTO `eq_spare_stock_log` VALUES (2108785104308359169, '000000', 2108783869656256513, 'SP20261010005', '二位五通电磁阀 5V210-08', 'REPAIR_USE', 4.0000, 18.0000, 14.0000, 'REPAIR', 2108785103310114818, 1, 'admin', '2026-10-10 13:02:03', '数控车床气路与限位修复', 103, 1, '2026-10-10 13:02:03', 1, '2026-10-10 17:41:36', '0');
INSERT INTO `eq_spare_stock_log` VALUES (2108785104392245250, '000000', 2108783873410158593, 'SP20261010007', '过滤减压阀 AFR2000', 'REPAIR_USE', 2.0000, 10.0000, 8.0000, 'REPAIR', 2108785103310114818, 1, 'admin', '2026-10-10 13:02:03', '数控车床气路与限位修复', 103, 1, '2026-10-10 13:02:03', 1, '2026-10-10 17:41:36', '0');
INSERT INTO `eq_spare_stock_log` VALUES (2108785135484620801, '000000', 2108783874987216898, 'SP20261010008', '交流接触器 25A', 'REPAIR_USE', 3.0000, 6.0000, 3.0000, 'REPAIR', 2108785134721257474, 1, 'admin', '2026-10-10 13:02:10', '加工中心辅助机构检修', 103, 1, '2026-10-10 13:02:10', 1, '2026-10-10 17:41:37', '0');
INSERT INTO `eq_spare_stock_log` VALUES (2108785135560118273, '000000', 2108783864115580929, 'SP20261010002', '深沟球轴承 6205-2RS', 'REPAIR_USE', 3.0000, 20.0000, 17.0000, 'REPAIR', 2108785134721257474, 1, 'admin', '2026-10-10 13:02:10', '加工中心辅助机构检修', 103, 1, '2026-10-10 13:02:10', 1, '2026-10-10 17:41:35', '0');
INSERT INTO `eq_spare_stock_log` VALUES (2108785135623032834, '000000', 2108783871535304705, 'SP20261010006', '标准气缸 SC32×100', 'REPAIR_USE', 2.0000, 8.0000, 6.0000, 'REPAIR', 2108785134721257474, 1, 'admin', '2026-10-10 13:02:10', '加工中心辅助机构检修', 103, 1, '2026-10-10 13:02:10', 1, '2026-10-10 17:41:36', '0');
INSERT INTO `eq_spare_stock_log` VALUES (2108785172151226370, '000000', 2108783867789791234, 'SP20261010004', '电感式接近开关 M12', 'OUT', 1.0000, 10.0000, 9.0000, 'MANUAL', NULL, 1, 'admin', '2026-10-10 13:02:19', '电气巡检现场领用，限位器维护备用。', 103, 1, '2026-10-10 13:02:19', 1, '2026-10-10 17:41:36', '0');
INSERT INTO `eq_spare_stock_log` VALUES (2108790827255820289, '000000', 2108790517854597122, 'SP20261010009', '旋转轴唇形密封圈 TC25×47×7', 'IN', 30.0000, 0.0000, 30.0000, 'MANUAL', NULL, 1, 'admin', '2026-10-10 13:24:47', '维修备件库期初清点入库；规格和单位按备件主数据办理。', 103, 1, '2026-10-10 13:24:47', 1, '2026-10-10 17:41:37', '0');
INSERT INTO `eq_spare_stock_log` VALUES (2108790872856293377, '000000', 2108783861921959937, 'SP20261010001', '深沟球轴承 6204-2RS', 'RETURN', 2.0000, 19.0000, 21.0000, 'SPARE_RETURN', 2108785370189484033, 1, 'admin', '2026-10-10 13:24:58', 'RP-20261010-001 维修余料退回', 103, 1, '2026-10-10 13:24:58', 1, '2026-10-10 17:41:35', '0');
INSERT INTO `eq_spare_stock_log` VALUES (2108790872935985154, '000000', 2108783866107875329, 'SP20261010003', '同步带 550-5M-15', 'RETURN', 1.0000, 13.0000, 14.0000, 'SPARE_RETURN', 2108785370189484033, 1, 'admin', '2026-10-10 13:24:58', 'RP-20261010-001 维修余料退回', 103, 1, '2026-10-10 13:24:58', 1, '2026-10-10 17:41:35', '0');
INSERT INTO `eq_spare_stock_log` VALUES (2108790920956571650, '000000', 2108783869656256513, 'SP20261010005', '二位五通电磁阀 5V210-08', 'RETURN', 1.0000, 14.0000, 15.0000, 'SPARE_RETURN', 2108790920151265281, 1, 'admin', '2026-10-10 13:25:10', 'RP-20261010-002 维修余料退回', 103, 1, '2026-10-10 13:25:10', 1, '2026-10-10 17:41:36', '0');

-- ----------------------------
-- Table structure for lt_lot
-- ----------------------------
DROP TABLE IF EXISTS `lt_lot`;
CREATE TABLE `lt_lot`  (
  `lot_id` bigint(20) NOT NULL COMMENT '批次ID(主键)',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '000000',
  `lot_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '批次编码',
  `material_id` bigint(20) NOT NULL COMMENT '物料ID',
  `material_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '物料编码(冗余)',
  `material_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '物料名称(冗余)',
  `supplier_id` bigint(20) NULL DEFAULT NULL COMMENT '供应商ID',
  `supplier_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '供应商名称(冗余)',
  `supplier_lot` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '供应商批次号',
  `quantity` decimal(14, 4) NOT NULL COMMENT '批次数量',
  `consumed_qty` decimal(14, 4) NULL DEFAULT 0.0000 COMMENT '已消耗数量',
  `produced_date` date NULL DEFAULT NULL COMMENT '生产日期',
  `expiry_date` date NULL DEFAULT NULL COMMENT '有效期',
  `status` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT 'IN_STOCK' COMMENT '状态: IN_STOCK/IN_USE/CONSUMED/QUARANTINED/SCRAPPED',
  `qc_status` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT 'PENDING' COMMENT 'QC状态: PENDING/PASS/FAIL',
  `iqc_id` bigint(20) NULL DEFAULT NULL COMMENT 'IQC检验单ID(关联qc_iqc.iqc_id,可空;关联后IQC完成自动回写qc_status)',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '备注',
  `create_dept` bigint(20) NULL DEFAULT NULL COMMENT '创建部门',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '删除标志',
  `erp_batch_id` bigint(20) NULL DEFAULT NULL COMMENT '有明确凭据的ERP批次身份，不按同码猜测',
  `allocation_version` bigint(20) NOT NULL DEFAULT 1 COMMENT '批次分配版本',
  PRIMARY KEY (`lot_id`) USING BTREE,
  UNIQUE INDEX `uk_lot_code`(`tenant_id`, `lot_code`) USING BTREE,
  INDEX `idx_material`(`material_id`) USING BTREE,
  INDEX `idx_status`(`status`) USING BTREE,
  INDEX `idx_qc_status`(`qc_status`) USING BTREE,
  INDEX `idx_expiry`(`expiry_date`) USING BTREE,
  INDEX `idx_iqc_id`(`iqc_id`) USING BTREE,
  INDEX `idx_lot_erp_batch`(`tenant_id`, `erp_batch_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = 'MES批次主档' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for lt_lot_allocation
-- ----------------------------
DROP TABLE IF EXISTS `lt_lot_allocation`;
CREATE TABLE `lt_lot_allocation`  (
  `allocation_id` bigint(20) NOT NULL COMMENT '批次分配ID',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '租户ID，必须由认证上下文提供',
  `command_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '幂等业务命令ID',
  `line_no` bigint(20) NOT NULL COMMENT '命令内分配行号',
  `lot_id` bigint(20) NOT NULL COMMENT 'MES本地批次ID',
  `erp_batch_id` bigint(20) NULL DEFAULT NULL COMMENT '有证据的ERP批次ID，SN-only来源允许空值',
  `material_id` bigint(20) NOT NULL COMMENT '物料ID',
  `quantity` decimal(18, 4) NOT NULL COMMENT '分配基本单位数量',
  `source_type` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '分配凭据来源类型',
  `source_id` bigint(20) NOT NULL COMMENT '分配凭据ID',
  `source_line_id` bigint(20) NOT NULL DEFAULT 0 COMMENT '凭据行ID',
  `allocation_version` bigint(20) NOT NULL DEFAULT 1 COMMENT '批次分配版本',
  `evidence_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '原凭据及分配依据JSON，不能仅用同码匹配',
  `evidence_hash` char(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '冻结证据摘要',
  `created_at` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`allocation_id`) USING BTREE,
  UNIQUE INDEX `uk_lot_allocation_command_line`(`tenant_id`, `command_id`, `line_no`) USING BTREE,
  INDEX `idx_lot_allocation_mapping`(`tenant_id`, `lot_id`, `erp_batch_id`, `allocation_version`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = 'MES批次到ERP批次的带证据数量分配' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for lt_sn_binding
-- ----------------------------
DROP TABLE IF EXISTS `lt_sn_binding`;
CREATE TABLE `lt_sn_binding`  (
  `binding_id` bigint(20) NOT NULL COMMENT '绑定ID(主键)',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '000000',
  `sn_id` bigint(20) NOT NULL COMMENT 'SN ID',
  `sn_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT 'SN编码(冗余)',
  `lot_id` bigint(20) NOT NULL COMMENT '批次ID',
  `lot_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '批次编码(冗余)',
  `material_id` bigint(20) NOT NULL COMMENT '物料ID',
  `bound_time` datetime(0) NOT NULL COMMENT '绑定时间',
  `bound_by` bigint(20) NULL DEFAULT NULL COMMENT '绑定人ID',
  `create_dept` bigint(20) NULL DEFAULT NULL COMMENT '创建部门',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '删除标志',
  PRIMARY KEY (`binding_id`) USING BTREE,
  UNIQUE INDEX `uk_sn_material`(`tenant_id`, `sn_id`, `material_id`) USING BTREE,
  INDEX `idx_sn_id`(`sn_id`) USING BTREE,
  INDEX `idx_lot_id`(`lot_id`) USING BTREE,
  INDEX `idx_material_id`(`material_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = 'MES SN批次绑定关系' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for lt_sn_consumption
-- ----------------------------
DROP TABLE IF EXISTS `lt_sn_consumption`;
CREATE TABLE `lt_sn_consumption`  (
  `entry_id` bigint(20) NOT NULL COMMENT '组件消耗账分录ID',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '租户ID，必须由认证上下文提供',
  `command_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '幂等业务命令ID',
  `line_no` bigint(20) NOT NULL COMMENT '命令内稳定行号',
  `identity_id` bigint(20) NOT NULL COMMENT '成品正式实物身份',
  `local_sn_id` bigint(20) NOT NULL COMMENT 'MES本地成品SN主键',
  `component_material_id` bigint(20) NOT NULL COMMENT '组件物料ID',
  `component_lot_id` bigint(20) NOT NULL COMMENT '组件MES批次ID',
  `quantity` decimal(18, 4) NOT NULL COMMENT '正数绝对数量，方向由分录类型确定',
  `wo_consumption_id` bigint(20) NOT NULL COMMENT '原工单消耗记录lt_wo_consumption主键',
  `process_id` bigint(20) NULL DEFAULT NULL COMMENT '工序ID',
  `operation_ref` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '工位操作或离线操作凭据',
  `entry_type` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'CONSUME消耗或REVERSE冲正，不覆盖原分录',
  `original_entry_id` bigint(20) NULL DEFAULT NULL COMMENT '冲正所引用的原CONSUME分录',
  `policy_version` bigint(20) NOT NULL DEFAULT 1 COMMENT '消耗时混批策略版本',
  `created_by` bigint(20) NOT NULL COMMENT '操作人ID',
  `created_at` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`entry_id`) USING BTREE,
  UNIQUE INDEX `uk_sn_consumption_command_line`(`tenant_id`, `command_id`, `line_no`) USING BTREE,
  INDEX `idx_sn_consumption_identity`(`tenant_id`, `identity_id`, `component_material_id`) USING BTREE,
  INDEX `idx_sn_consumption_source`(`tenant_id`, `wo_consumption_id`) USING BTREE,
  INDEX `idx_sn_consumption_reverse`(`tenant_id`, `original_entry_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '实物组件消耗不可变流水账，冲正必须引用原分录' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for lt_sn_material_guard
-- ----------------------------
DROP TABLE IF EXISTS `lt_sn_material_guard`;
CREATE TABLE `lt_sn_material_guard`  (
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '租户ID，必须由认证上下文提供',
  `identity_id` bigint(20) NOT NULL COMMENT '成品正式身份',
  `component_material_id` bigint(20) NOT NULL COMMENT '组件物料ID',
  `selected_lot_id` bigint(20) NULL DEFAULT NULL COMMENT '禁止混批时首次选定批次',
  `allow_mixed_lot` tinyint(1) NOT NULL DEFAULT 1 COMMENT '冻结混批策略，默认允许',
  `policy_version` bigint(20) NOT NULL DEFAULT 1 COMMENT '策略版本',
  `version` bigint(20) NOT NULL DEFAULT 1 COMMENT '并发互斥与乐观锁版本',
  PRIMARY KEY (`tenant_id`, `identity_id`, `component_material_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '同实物同组件物料的混批并发守卫' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for lt_wo_consumption
-- ----------------------------
DROP TABLE IF EXISTS `lt_wo_consumption`;
CREATE TABLE `lt_wo_consumption`  (
  `consumption_id` bigint(20) NOT NULL COMMENT '消耗记录ID(主键)',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '000000',
  `wo_id` bigint(20) NOT NULL COMMENT '工单ID',
  `wo_no` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '工单编号(冗余)',
  `lot_id` bigint(20) NOT NULL COMMENT '批次ID',
  `lot_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '批次编码(冗余)',
  `material_id` bigint(20) NOT NULL COMMENT '物料ID',
  `material_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '物料编码(冗余)',
  `consumed_qty` decimal(14, 4) NOT NULL COMMENT '消耗数量',
  `consumed_time` datetime(0) NOT NULL COMMENT '消耗时间',
  `operator_id` bigint(20) NULL DEFAULT NULL COMMENT '操作员ID',
  `operator_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '操作员姓名(冗余)',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '备注',
  `create_dept` bigint(20) NULL DEFAULT NULL COMMENT '创建部门',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '删除标志',
  `source_allocation_id` bigint(20) NULL DEFAULT NULL COMMENT '实际消耗引用的原额度分配ID，旧记录未知保持NULL',
  PRIMARY KEY (`consumption_id`) USING BTREE,
  INDEX `idx_wo_id`(`wo_id`) USING BTREE,
  INDEX `idx_lot_id`(`lot_id`) USING BTREE,
  INDEX `idx_material_id`(`material_id`) USING BTREE,
  INDEX `idx_consumed_time`(`consumed_time`) USING BTREE,
  INDEX `idx_wo_consumption_source_allocation`(`tenant_id`, `source_allocation_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = 'MES工单批次消耗记录' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for mes_content_file
-- ----------------------------
DROP TABLE IF EXISTS `mes_content_file`;
CREATE TABLE `mes_content_file`  (
  `content_file_id` bigint(20) NOT NULL COMMENT '配置文件ID',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '000000' COMMENT '租户ID',
  `content_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '配置编码(自动编码 MES_CONFIG_CODE)',
  `content_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '配置名称',
  `content_type` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'CONFIG_FILE' COMMENT '配置类型: CONFIG_FILE(可扩展校准/证书)',
  `material_id` bigint(20) NOT NULL COMMENT '适用物料ID',
  `material_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `material_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `version` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '版本号',
  `oss_id` bigint(20) NULL DEFAULT NULL COMMENT '配置文件OSS文件ID',
  `file_md5` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '文件MD5',
  `file_size` bigint(20) NULL DEFAULT NULL COMMENT '文件大小(字节)',
  `release_note` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT '发布说明',
  `status` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'DRAFT' COMMENT 'DRAFT/IN_REVIEW/RELEASED/ARCHIVED',
  `is_default` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0' COMMENT '物料默认版本(0否/1是)',
  `published_by` bigint(20) NULL DEFAULT NULL,
  `publish_time` datetime(0) NULL DEFAULT NULL,
  `create_dept` bigint(20) NULL DEFAULT NULL,
  `create_by` bigint(20) NULL DEFAULT NULL,
  `create_time` datetime(0) NULL DEFAULT NULL,
  `update_by` bigint(20) NULL DEFAULT NULL,
  `update_time` datetime(0) NULL DEFAULT NULL,
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  PRIMARY KEY (`content_file_id`) USING BTREE,
  UNIQUE INDEX `uk_tenant_content_code`(`tenant_id`, `content_code`) USING BTREE,
  INDEX `idx_tenant_id`(`tenant_id`) USING BTREE,
  INDEX `idx_material`(`material_id`) USING BTREE,
  INDEX `idx_status`(`status`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '刷写内容档案(配置文件等, 审批发布)' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for mes_firmware
-- ----------------------------
DROP TABLE IF EXISTS `mes_firmware`;
CREATE TABLE `mes_firmware`  (
  `firmware_id` bigint(20) NOT NULL COMMENT '固件ID',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '000000' COMMENT '租户ID',
  `firmware_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '固件编码(自动编码 MES_FW_CODE)',
  `firmware_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '固件名称',
  `material_id` bigint(20) NOT NULL COMMENT '适用物料ID(产品)',
  `material_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '适用物料编码',
  `material_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '适用物料名称',
  `version` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '版本号(如 1.2.3)',
  `build_no` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '构建号',
  `oss_id` bigint(20) NULL DEFAULT NULL COMMENT '固件文件OSS文件ID(sys_oss)',
  `file_md5` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '固件文件MD5',
  `file_size` bigint(20) NULL DEFAULT NULL COMMENT '固件文件大小(字节)',
  `release_note` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT '发布说明',
  `status` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'DRAFT' COMMENT '状态: DRAFT/IN_REVIEW/RELEASED/ARCHIVED',
  `is_default` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0' COMMENT '是否物料默认版本(0否/1是, 物料内唯一)',
  `select_flow_id` bigint(20) NULL DEFAULT NULL COMMENT '审批流配置ID(wf_custom_form.id)',
  `published_by` bigint(20) NULL DEFAULT NULL COMMENT '发布人ID',
  `publish_time` datetime(0) NULL DEFAULT NULL COMMENT '发布时间',
  `create_dept` bigint(20) NULL DEFAULT NULL COMMENT '创建部门',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建人',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新人',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0' COMMENT '删除标志(0存在/2删除)',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`firmware_id`) USING BTREE,
  UNIQUE INDEX `uk_tenant_firmware_code`(`tenant_id`, `firmware_code`) USING BTREE,
  INDEX `idx_tenant_id`(`tenant_id`) USING BTREE,
  INDEX `idx_material`(`material_id`) USING BTREE,
  INDEX `idx_status`(`status`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '固件档案' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of mes_firmware
-- ----------------------------
INSERT INTO `mes_firmware` VALUES (1, '000000', 'FW20260914001', '智能路由器 WR-1200主控固件', 14, 'IF20260914014', '智能路由器 WR-1200', 'V1.0.0', 'BUILD001', NULL, 'md50000000000000000000000000001', 262144, '初始版本固件', 'RELEASED', '1', NULL, 1, '2026-09-14 15:07:27', 103, 1, '2026-09-14 15:07:27', NULL, '2026-09-14 15:07:27', '0', NULL);
INSERT INTO `mes_firmware` VALUES (2, '000000', 'FW20260914002', '变频电风扇主控固件', 15, 'IF20260914015', '变频电风扇', 'V1.0.0', 'BUILD002', NULL, 'md50000000000000000000000000002', 262144, '初始版本固件', 'RELEASED', '1', NULL, 1, '2026-09-14 15:07:27', 103, 1, '2026-09-14 15:07:27', NULL, '2026-09-14 15:07:27', '0', NULL);
INSERT INTO `mes_firmware` VALUES (3, '000000', 'FW20260914003', '开关电源模组 SMPS-60主控固件', 16, 'IF20260914016', '开关电源模组 SMPS-60', 'V1.0.0', 'BUILD003', NULL, 'md50000000000000000000000000003', 262144, '初始版本固件', 'RELEASED', '1', NULL, 1, '2026-09-14 15:07:27', 103, 1, '2026-09-14 15:07:27', NULL, '2026-09-14 15:07:27', '0', NULL);
INSERT INTO `mes_firmware` VALUES (4, '000000', 'FW20260914004', '无刷直流电机 BLDC-45主控固件', 17, 'IF20260914017', '无刷直流电机 BLDC-45', 'V1.0.0', 'BUILD004', NULL, 'md50000000000000000000000000004', 262144, '初始版本固件', 'RELEASED', '1', NULL, 1, '2026-09-14 15:07:27', 103, 1, '2026-09-14 15:07:27', NULL, '2026-09-14 15:07:27', '0', NULL);
INSERT INTO `mes_firmware` VALUES (5, '000000', 'FW20260914005', '温度传感器模组 TS-100主控固件', 18, 'IF20260914018', '温度传感器模组 TS-100', 'V1.0.0', 'BUILD005', NULL, 'md50000000000000000000000000005', 262144, '初始版本固件', 'RELEASED', '1', NULL, 1, '2026-09-14 15:07:27', 103, 1, '2026-09-14 15:07:27', NULL, '2026-09-14 15:07:27', '0', NULL);
INSERT INTO `mes_firmware` VALUES (6, '000000', 'FW20260914006', 'LED 护眼台灯主控固件', 26, 'IF20260914026', 'LED 护眼台灯', 'V1.0.0', 'BUILD006', NULL, 'md50000000000000000000000000006', 262144, '初始版本固件', 'RELEASED', '1', NULL, 1, '2026-09-14 15:07:27', 103, 1, '2026-09-14 15:07:27', NULL, '2026-09-14 15:07:27', '0', NULL);
INSERT INTO `mes_firmware` VALUES (7, '000000', 'FW20260914007', '智能网关 GW-1000主控固件', 27, 'IF20260914027', '智能网关 GW-1000', 'V1.0.0', 'BUILD007', NULL, 'md50000000000000000000000000007', 262144, '初始版本固件', 'RELEASED', '1', NULL, 1, '2026-09-14 15:07:27', 103, 1, '2026-09-14 15:07:27', NULL, '2026-09-14 15:07:27', '0', NULL);
INSERT INTO `mes_firmware` VALUES (8, '000000', 'FW20260914008', '锂电池包 48V20Ah主控固件', 30, 'IF20260914030', '锂电池包 48V20Ah', 'V1.0.0', 'BUILD008', NULL, 'md50000000000000000000000000008', 262144, '初始版本固件', 'RELEASED', '1', NULL, 1, '2026-09-14 15:07:27', 103, 1, '2026-09-14 15:07:27', NULL, '2026-09-14 15:07:27', '0', NULL);
INSERT INTO `mes_firmware` VALUES (9, '000000', 'FW20260914009', '交流充电桩 AC-7kW主控固件', 31, 'IF20260914031', '交流充电桩 AC-7kW', 'V1.0.0', 'BUILD009', NULL, 'md50000000000000000000000000009', 262144, '初始版本固件', 'RELEASED', '1', NULL, 1, '2026-09-14 15:07:27', 103, 1, '2026-09-14 15:07:27', NULL, '2026-09-14 15:07:27', '0', NULL);
INSERT INTO `mes_firmware` VALUES (10, '000000', 'FW20260914010', '六轴机械臂 RB-6主控固件', 33, 'IF20260914033', '六轴机械臂 RB-6', 'V1.0.0', 'BUILD010', NULL, 'md50000000000000000000000000010', 262144, '初始版本固件', 'RELEASED', '1', NULL, 1, '2026-09-14 15:07:27', 103, 1, '2026-09-14 15:07:27', NULL, '2026-09-14 15:07:27', '0', NULL);
INSERT INTO `mes_firmware` VALUES (11, '000000', 'FW20260914011', '智能手环 BAND-3主控固件', 34, 'IF20260914034', '智能手环 BAND-3', 'V1.0.0', 'BUILD011', NULL, 'md50000000000000000000000000011', 262144, '初始版本固件', 'RELEASED', '1', NULL, 1, '2026-09-14 15:07:27', 103, 1, '2026-09-14 15:07:27', NULL, '2026-09-14 15:07:27', '0', NULL);
INSERT INTO `mes_firmware` VALUES (12, '000000', 'FW20260914012', '手持 POS 机 POS-8主控固件', 35, 'IF20260914035', '手持 POS 机 POS-8', 'V1.0.0', 'BUILD012', NULL, 'md50000000000000000000000000012', 262144, '初始版本固件', 'RELEASED', '1', NULL, 1, '2026-09-14 15:07:27', 103, 1, '2026-09-14 15:07:27', NULL, '2026-09-14 15:07:27', '0', NULL);
INSERT INTO `mes_firmware` VALUES (13, '000000', 'FW20260914013', '网络摄像机 IPC-300主控固件', 36, 'IF20260914036', '网络摄像机 IPC-300', 'V1.0.0', 'BUILD013', NULL, 'md50000000000000000000000000013', 262144, '初始版本固件', 'RELEASED', '1', NULL, 1, '2026-09-14 15:07:27', 103, 1, '2026-09-14 15:07:27', NULL, '2026-09-14 15:07:27', '0', NULL);
INSERT INTO `mes_firmware` VALUES (14, '000000', 'FW20260914014', '无线蓝牙音箱 SPK-20主控固件', 37, 'IF20260914037', '无线蓝牙音箱 SPK-20', 'V1.0.0', 'BUILD014', NULL, 'md50000000000000000000000000014', 262144, '初始版本固件', 'RELEASED', '1', NULL, 1, '2026-09-14 15:07:27', 103, 1, '2026-09-14 15:07:27', NULL, '2026-09-14 15:07:27', '0', NULL);

-- ----------------------------
-- Table structure for mes_flash_record
-- ----------------------------
DROP TABLE IF EXISTS `mes_flash_record`;
CREATE TABLE `mes_flash_record`  (
  `flash_record_id` bigint(20) NOT NULL COMMENT '刷写记录ID',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '000000' COMMENT '租户ID',
  `flash_no` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '刷写记录号(自动编码 MES_FLASH_NO)',
  `flash_type_id` bigint(20) NULL DEFAULT NULL COMMENT '刷写类型ID(mes_flash_type)',
  `flash_type_code` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '刷写类型标识(快照: firmware_file/config_file/mac/sn)',
  `sn_id` bigint(20) NOT NULL COMMENT 'SN ID',
  `sn_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'SN编码',
  `mes_wo_id` bigint(20) NOT NULL COMMENT 'MES工单ID',
  `wo_no` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '工单号',
  `card_id` bigint(20) NULL DEFAULT NULL COMMENT '流转卡ID',
  `step_record_id` bigint(20) NULL DEFAULT NULL COMMENT '流转卡工序记录ID(pro_flow_card_step)',
  `process_id` bigint(20) NULL DEFAULT NULL COMMENT '工序ID',
  `process_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '工序编码',
  `process_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '工序名称',
  `content_ref_type` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '内容引用类型: FIRMWARE/CONFIG/MAC_POOL/SN_POOL/EXTERNAL',
  `content_ref_id` bigint(20) NULL DEFAULT NULL COMMENT '内容源记录ID(固件=mes_firmware_id; 池类=工序配置的 contentRefId, 与完工门禁比对口径一致; 工序未配置时落本次分配的资源项ID)',
  `content_version` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '内容版本(固件类=固件版本)',
  `content_payload` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT '实际写入内容快照JSON(如 {\"mac\":\"00:1A:2B:3C:4D:5E\"})',
  `content_checksum` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '内容校验值(泛化MD5/校验码)',
  `equipment_id` bigint(20) NULL DEFAULT NULL COMMENT '刷写设备ID(eq_equipment)',
  `equipment_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '刷写设备编码',
  `operator_id` bigint(20) NULL DEFAULT NULL COMMENT '操作人ID',
  `operator_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '操作人姓名',
  `flash_time` datetime(0) NULL DEFAULT NULL COMMENT '刷写时间',
  `result` varchar(8) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '结果: PASS/FAIL',
  `fail_reason` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '失败原因',
  `retry_count` int(11) NOT NULL DEFAULT 0 COMMENT '重试次数',
  `flash_mode` varchar(8) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'MANUAL' COMMENT '刷写模式: AUTO/MANUAL',
  `create_dept` bigint(20) NULL DEFAULT NULL COMMENT '创建部门',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建人',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新人',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0' COMMENT '删除标志(0存在/2删除)',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`flash_record_id`) USING BTREE,
  UNIQUE INDEX `uk_tenant_flash_no`(`tenant_id`, `flash_no`) USING BTREE,
  INDEX `idx_tenant_id`(`tenant_id`) USING BTREE,
  INDEX `idx_sn`(`sn_id`) USING BTREE,
  INDEX `idx_wo`(`mes_wo_id`) USING BTREE,
  INDEX `idx_flash_type`(`tenant_id`, `flash_type_id`) USING BTREE,
  INDEX `idx_content_ref`(`content_ref_type`, `content_ref_id`) USING BTREE,
  INDEX `idx_sn_code`(`tenant_id`, `sn_code`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '固件刷写记录(SN级)' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for mes_flash_type
-- ----------------------------
DROP TABLE IF EXISTS `mes_flash_type`;
CREATE TABLE `mes_flash_type`  (
  `flash_type_id` bigint(20) NOT NULL COMMENT '刷写类型ID',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '000000' COMMENT '租户ID',
  `type_code` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '类型标识: firmware_file/config_file/mac/sn/external_*',
  `type_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '显示名',
  `source_type` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '内容来源: FILE/POOL/EXTERNAL/INLINE',
  `source_provider` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'SPI Provider bean名(如 firmwareFileFlashProvider)',
  `source_config` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT '来源配置JSON(审批流标识/池ID/REST模板)',
  `verify_strategy` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'MD5_MATCH' COMMENT '校验策略: MD5_MATCH/RESOURCE_BOUND/CUSTOM',
  `gate_enabled` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1' COMMENT '是否参与完工门禁(0否/1是)',
  `status` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ENABLED' COMMENT 'ENABLED/DISABLED',
  `sort_order` int(11) NOT NULL DEFAULT 0 COMMENT '排序',
  `create_dept` bigint(20) NULL DEFAULT NULL COMMENT '创建部门',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建人',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新人',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0' COMMENT '删除标志(0存在/2删除)',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`flash_type_id`) USING BTREE,
  UNIQUE INDEX `uk_tenant_type_code`(`tenant_id`, `type_code`) USING BTREE,
  INDEX `idx_tenant_id`(`tenant_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '刷写类型定义(配置化目录)' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for mes_label_print_log
-- ----------------------------
DROP TABLE IF EXISTS `mes_label_print_log`;
CREATE TABLE `mes_label_print_log`  (
  `log_id` bigint(20) NOT NULL COMMENT '打印日志ID',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '000000' COMMENT '租户ID',
  `sn_id` bigint(20) NULL DEFAULT NULL COMMENT 'SN ID',
  `sn_code` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '正式SN原码，最长128位',
  `template_id` bigint(20) NULL DEFAULT NULL COMMENT '模板ID',
  `template_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '模板编码(快照)',
  `printer_host` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '打印机地址(快照)',
  `printer_port` int(11) NULL DEFAULT 9100 COMMENT '打印机端口',
  `print_time` datetime(0) NULL DEFAULT NULL COMMENT '打印时间',
  `result` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '结果: SUCCESS/FAIL',
  `fail_reason` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '失败原因',
  `retry_count` int(11) NULL DEFAULT NULL COMMENT '重打计数(同SN同模板历史打印次数, 首次0)',
  `print_source` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '来源: AUTO/REPRINT/TEST',
  `operator_id` bigint(20) NULL DEFAULT NULL COMMENT '操作人ID',
  `operator_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '操作人姓名',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '备注',
  `create_dept` bigint(20) NULL DEFAULT NULL COMMENT '创建部门',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP(0) COMMENT '更新时间',
  `template_revision` bigint(20) NULL DEFAULT NULL COMMENT '打印时模板修订号，历史未知留空',
  `original_print_log_id` bigint(20) NULL DEFAULT NULL COMMENT '补打引用的原任务ID，历史不补造',
  `template_snapshot` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT '冻结模板布局及修订JSON，历史留空',
  `field_snapshot` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT '冻结SN物料工单等字段JSON，历史留空',
  `rendered_payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT '冻结完整打印指令，补打不读取新模板',
  `content_hash` char(64) CHARACTER SET ascii COLLATE ascii_bin NULL DEFAULT NULL COMMENT '原模板快照UTF8字节SHA256，历史不补造',
  `payload_hash` char(64) CHARACTER SET ascii COLLATE ascii_bin NULL DEFAULT NULL COMMENT '实际编码发送字节SHA256，历史不补造',
  `payload_charset` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL COMMENT '实际发送字符集名称',
  `snapshot_mode` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL COMMENT '冻结或历史兼容模式，旧记录保持空值',
  `reprint_reason` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '人工补打原因，历史缺失不补造',
  PRIMARY KEY (`log_id`) USING BTREE,
  INDEX `idx_label_print_sn_tpl`(`tenant_id`, `sn_id`, `template_id`, `result`) USING BTREE,
  INDEX `idx_label_print_time`(`print_time`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '标签打印留痕' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for mes_label_print_task
-- ----------------------------
DROP TABLE IF EXISTS `mes_label_print_task`;
CREATE TABLE `mes_label_print_task`  (
  `task_id` bigint(20) NOT NULL COMMENT '打印任务ID，同时作为本次终态打印日志ID',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '租户ID，必须由认证上下文提供',
  `task_key` char(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '租户内稳定任务键，自动任务固定SN及模板版本',
  `request_fingerprint` char(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '提交业务意图摘要，命令不得更换原任务或补打原因',
  `sn_id` bigint(20) NULL DEFAULT NULL COMMENT 'MES本地SN，测试任务可空',
  `template_id` bigint(20) NOT NULL COMMENT '请求打印模板ID',
  `template_revision` bigint(20) NULL DEFAULT NULL COMMENT '冻结修订，历史未知保持空值',
  `print_source` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'AUTO、TEST或REPRINT',
  `original_print_log_id` bigint(20) NULL DEFAULT NULL COMMENT '补打引用原任务或旧日志，保留原审计',
  `reprint_reason` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '人工补打原因，不补造历史原因',
  `frozen_record` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '不可变完整打印快照JSON，包含布局字段载荷及来源',
  `record_hash` char(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '完整冻结记录UTF8字节SHA256',
  `status` varchar(24) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING' COMMENT 'PENDING、SENDING、SENT、FAIL、UNKNOWN、LEGACY_SENT',
  `attempt_count` int(11) NOT NULL DEFAULT 0 COMMENT '实际发送领取次数，只允许0转1',
  `lease_token` varchar(64) CHARACTER SET ascii COLLATE ascii_bin NULL DEFAULT NULL COMMENT '一次领取令牌，禁止发送中任务重新领取',
  `lease_until` datetime(0) NULL DEFAULT NULL COMMENT '数据库时钟计算的发送租约，过期只能转UNKNOWN',
  `sending_started_at` datetime(0) NULL DEFAULT NULL COMMENT '领取发送时刻',
  `completed_at` datetime(0) NULL DEFAULT NULL COMMENT '终态记录时刻，不代表实际出纸',
  `last_error` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '脱敏错误或待人工核验原因',
  `created_at` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP(0) COMMENT '更新时间',
  PRIMARY KEY (`task_id`) USING BTREE,
  UNIQUE INDEX `uk_label_task_key`(`tenant_id`, `task_key`) USING BTREE,
  INDEX `idx_label_task_pending`(`tenant_id`, `status`, `created_at`) USING BTREE,
  INDEX `idx_label_task_lease`(`tenant_id`, `status`, `lease_until`) USING BTREE,
  INDEX `idx_label_task_sn`(`tenant_id`, `sn_id`, `template_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = 'MES事务内冻结的持久化打印任务，发送不等于出纸确认' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for mes_label_template
-- ----------------------------
DROP TABLE IF EXISTS `mes_label_template`;
CREATE TABLE `mes_label_template`  (
  `template_id` bigint(20) NOT NULL COMMENT '模板ID',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '000000' COMMENT '租户ID',
  `template_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '模板编码',
  `template_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '模板名称',
  `label_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT 'SN' COMMENT '标签类型: SN 标签(流转卡标签后续扩展)',
  `label_lang` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'TSPL' COMMENT '打印机语言: TSPL/ZPL',
  `width_mm` int(11) NULL DEFAULT 60 COMMENT '标签宽度(mm)',
  `height_mm` int(11) NULL DEFAULT 40 COMMENT '标签高度(mm)',
  `printer_host` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '网络打印机地址(TCP RAW 9100)',
  `printer_port` int(11) NULL DEFAULT 9100 COMMENT '网络打印机端口',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '字段映射布局 JSON: {items:[{type,field,x,y,size,height}]}',
  `enabled` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT 'Y' COMMENT '是否启用(Y/N): SN 造码打印仅消费启用模板',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '备注',
  `create_dept` bigint(20) NULL DEFAULT NULL,
  `create_by` bigint(20) NULL DEFAULT NULL,
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP,
  `update_by` bigint(20) NULL DEFAULT NULL,
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP(0),
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '删除标志',
  `template_revision` bigint(20) NOT NULL DEFAULT 1 COMMENT '模板修订号，保存时递增，打印时冻结',
  PRIMARY KEY (`template_id`) USING BTREE,
  UNIQUE INDEX `uk_template_code`(`tenant_id`, `template_code`) USING BTREE,
  INDEX `idx_label_type`(`label_type`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '标签打印模板' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for mes_material_load
-- ----------------------------
DROP TABLE IF EXISTS `mes_material_load`;
CREATE TABLE `mes_material_load`  (
  `load_id` bigint(20) NOT NULL COMMENT '台账ID',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '000000' COMMENT '租户ID',
  `mes_wo_id` bigint(20) NULL DEFAULT NULL COMMENT '工单ID(pro_work_order.mes_wo_id)',
  `wo_no` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '工单编号',
  `station_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '工位编码',
  `process_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '工序编码',
  `workstation_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '工作中心编码(MBOM快照冗余)',
  `material_id` bigint(20) NOT NULL COMMENT '物料ID',
  `material_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '物料编码',
  `material_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '物料名称',
  `batch_id` bigint(20) NULL DEFAULT NULL COMMENT '批次ID(wm_batch.batch_id)',
  `batch_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '批次编码(wm_batch.batch_code)',
  `feeder_slot` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '料站号(可空, 贴片机 feeder 位号等)',
  `is_alternative` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT 'N' COMMENT '是否替代料匹配: Y=bd_bom_alternative替代料, N=BOM主料',
  `operator_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '上料人工号',
  `operator_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '上料人姓名',
  `load_time` datetime(0) NOT NULL COMMENT '上料时间',
  `status` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT 'ACTIVE' COMMENT '状态: ACTIVE=在机, REPLACED=已换料',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '备注',
  `create_dept` bigint(20) NULL DEFAULT NULL,
  `create_by` bigint(20) NULL DEFAULT NULL,
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP,
  `update_by` bigint(20) NULL DEFAULT NULL,
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP(0),
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '删除标志',
  PRIMARY KEY (`load_id`) USING BTREE,
  INDEX `idx_mes_wo_id`(`mes_wo_id`) USING BTREE,
  INDEX `idx_station_code`(`station_code`) USING BTREE,
  INDEX `idx_material`(`material_id`) USING BTREE,
  INDEX `idx_load_time`(`load_time`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '工位物料上料台账(上料防错 C19 写入, 换料置 REPLACED)' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for mes_mbom
-- ----------------------------
DROP TABLE IF EXISTS `mes_mbom`;
CREATE TABLE `mes_mbom`  (
  `mbom_id` bigint(20) NOT NULL COMMENT 'MBOM ID(主键)',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '000000' COMMENT '租户ID',
  `bom_id` bigint(20) NOT NULL COMMENT '关联ERP bd_bom.bom_id',
  `routing_id` bigint(20) NULL DEFAULT NULL COMMENT '制造工艺路线ID(可继承自bd_bom.routing_id或MES侧指定)',
  `mbom_version` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT 'MBOM版本号',
  `mbom_status` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT 'DRAFT' COMMENT 'DRAFT/ACTIVE/FROZEN',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '备注',
  `create_dept` bigint(20) NULL DEFAULT NULL COMMENT '创建部门',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT '0' COMMENT '删除标志',
  PRIMARY KEY (`mbom_id`) USING BTREE,
  UNIQUE INDEX `uk_bom_id`(`tenant_id`, `bom_id`) USING BTREE,
  INDEX `idx_routing_id`(`routing_id`) USING BTREE,
  INDEX `idx_tenant_id`(`tenant_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = 'MES制造BOM头' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of mes_mbom
-- ----------------------------
INSERT INTO `mes_mbom` VALUES (1, '000000', 1, 1, '1.0', 'ACTIVE', '高强度螺栓组套 M12制造BOM（关联ERP BOM#4）', 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom` VALUES (2, '000000', 5, 2, '1.0', 'ACTIVE', '精密齿轮箱总成制造BOM（关联ERP BOM#9）', 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom` VALUES (3, '000000', 10, 3, '1.0', 'ACTIVE', '压缩弹簧组制造BOM（关联ERP BOM#11）', 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom` VALUES (4, '000000', 12, 4, '1.0', 'ACTIVE', '设备钣金机箱制造BOM（关联ERP BOM#14）', 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom` VALUES (5, '000000', 15, 5, '1.0', 'ACTIVE', '钢结构支架总成制造BOM（关联ERP BOM#17）', 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom` VALUES (6, '000000', 18, 6, '1.0', 'ACTIVE', '注塑模具制造BOM（关联ERP BOM#21）', 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom` VALUES (7, '000000', 22, 7, '1.0', 'ACTIVE', '棘轮扳手组套制造BOM（关联ERP BOM#25）', 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom` VALUES (8, '000000', 26, 8, '1.0', 'ACTIVE', '齿轮减速机 JZQ-350制造BOM（关联ERP BOM#30）', 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom` VALUES (9, '000000', 31, 9, '1.0', 'ACTIVE', '单级离心泵制造BOM（关联ERP BOM#34）', 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom` VALUES (10, '000000', 35, 10, '1.0', 'ACTIVE', '数控铣床 XK714制造BOM（关联ERP BOM#39）', 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom` VALUES (11, '000000', 40, 11, '1.0', 'ACTIVE', '皮带输送线制造BOM（关联ERP BOM#44）', 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom` VALUES (12, '000000', 45, 12, '1.0', 'ACTIVE', '螺杆式空压机制造BOM（关联ERP BOM#48）', 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom` VALUES (13, '000000', 49, 13, '1.0', 'ACTIVE', '双层 PCB 板制造BOM（关联ERP BOM#50）', 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom` VALUES (14, '000000', 51, 14, '1.0', 'ACTIVE', '智能路由器 WR-1200制造BOM（关联ERP BOM#54）', 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom` VALUES (15, '000000', 55, 15, '1.0', 'ACTIVE', '变频电风扇制造BOM（关联ERP BOM#59）', 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom` VALUES (16, '000000', 60, 16, '1.0', 'ACTIVE', '开关电源模组 SMPS-60制造BOM（关联ERP BOM#61）', 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom` VALUES (17, '000000', 62, 17, '1.0', 'ACTIVE', '无刷直流电机 BLDC-45制造BOM（关联ERP BOM#64）', 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom` VALUES (18, '000000', 65, 18, '1.0', 'ACTIVE', '温度传感器模组 TS-100制造BOM（关联ERP BOM#67）', 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom` VALUES (19, '000000', 68, 19, '1.0', 'ACTIVE', '数字万用表 DM-800制造BOM（关联ERP BOM#70）', 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom` VALUES (20, '000000', 71, 20, '1.0', 'ACTIVE', '汽车门锁总成制造BOM（关联ERP BOM#75）', 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom` VALUES (21, '000000', 76, 21, '1.0', 'ACTIVE', '城市通勤自行车制造BOM（关联ERP BOM#79）', 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom` VALUES (22, '000000', 80, 22, '1.0', 'ACTIVE', '四轴无人机机架制造BOM（关联ERP BOM#83）', 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom` VALUES (23, '000000', 84, 23, '1.0', 'ACTIVE', '不锈钢手术剪制造BOM（关联ERP BOM#87）', 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom` VALUES (24, '000000', 88, 24, '1.0', 'ACTIVE', '手动轮椅制造BOM（关联ERP BOM#91）', 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom` VALUES (25, '000000', 92, 25, '1.0', 'ACTIVE', '简易金属工具架 RACK-001制造BOM（关联ERP BOM#95）', 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom` VALUES (26, '000000', 96, 26, '1.0', 'ACTIVE', 'LED 护眼台灯制造BOM（关联ERP BOM#100）', 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom` VALUES (27, '000000', 101, 27, '1.0', 'ACTIVE', '智能网关 GW-1000制造BOM（关联ERP BOM#103）', 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom` VALUES (28, '000000', 104, 28, '1.0', 'ACTIVE', '精密塑料外壳 PC-200制造BOM（关联ERP BOM#106）', 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom` VALUES (29, '000000', 107, 29, '1.0', 'ACTIVE', '硅胶密封圈组制造BOM（关联ERP BOM#108）', 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom` VALUES (30, '000000', 109, 30, '1.0', 'ACTIVE', '锂电池包 48V20Ah制造BOM（关联ERP BOM#111）', 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom` VALUES (31, '000000', 112, 31, '1.0', 'ACTIVE', '交流充电桩 AC-7kW制造BOM（关联ERP BOM#115）', 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom` VALUES (32, '000000', 116, 32, '1.0', 'ACTIVE', '光伏组件 450W制造BOM（关联ERP BOM#117）', 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom` VALUES (33, '000000', 118, 33, '1.0', 'ACTIVE', '六轴机械臂 RB-6制造BOM（关联ERP BOM#122）', 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom` VALUES (34, '000000', 123, 34, '1.0', 'ACTIVE', '智能手环 BAND-3制造BOM（关联ERP BOM#126）', 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom` VALUES (35, '000000', 127, 35, '1.0', 'ACTIVE', '手持 POS 机 POS-8制造BOM（关联ERP BOM#131）', 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom` VALUES (36, '000000', 132, 36, '1.0', 'ACTIVE', '网络摄像机 IPC-300制造BOM（关联ERP BOM#134）', 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom` VALUES (37, '000000', 135, 37, '1.0', 'ACTIVE', '无线蓝牙音箱 SPK-20制造BOM（关联ERP BOM#137）', 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom` VALUES (2106995184992432129, '000000', 2106762033351315457, 2106995183973216258, '1.0', 'ACTIVE', NULL, 103, 1, '2026-10-05 14:29:33', 1, '2026-10-05 14:29:33', '0');

-- ----------------------------
-- Table structure for mes_mbom_line
-- ----------------------------
DROP TABLE IF EXISTS `mes_mbom_line`;
CREATE TABLE `mes_mbom_line`  (
  `mbom_line_id` bigint(20) NOT NULL COMMENT 'MBOM明细ID(主键)',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '000000' COMMENT '租户ID',
  `mbom_id` bigint(20) NOT NULL COMMENT '关联mes_mbom.mbom_id',
  `bom_id` bigint(20) NOT NULL COMMENT '冗余ERP bom_id',
  `bom_detail_id` bigint(20) NULL DEFAULT NULL COMMENT '关联ERP bd_bom_detail.detail_id(可空,MES附加消耗料时为空)',
  `child_material_id` bigint(20) NOT NULL COMMENT '子项物料ID',
  `quantity_per_parent` decimal(18, 6) NOT NULL COMMENT '单位父项用量',
  `loss_rate` decimal(8, 4) NULL DEFAULT 0.0000 COMMENT '损耗率(%)',
  `routing_step_id` bigint(20) NULL DEFAULT NULL COMMENT 'ERP bd_routing_step.step_id(工序步骤)',
  `process_id` bigint(20) NULL DEFAULT NULL COMMENT 'ERP bd_process.process_id(工序)',
  `workstation_id` bigint(20) NULL DEFAULT NULL COMMENT 'ERP bd_workstation.workstation_id(工位)',
  `operation_content` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '作业内容',
  `backflush_flag` tinyint(1) NULL DEFAULT 0 COMMENT '是否倒冲 0否1是',
  `sort_order` int(11) NULL DEFAULT 0 COMMENT '显示排序',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '备注',
  `create_dept` bigint(20) NULL DEFAULT NULL COMMENT '创建部门',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT '0' COMMENT '删除标志',
  PRIMARY KEY (`mbom_line_id`) USING BTREE,
  INDEX `idx_mbom_id`(`mbom_id`) USING BTREE,
  INDEX `idx_bom_id`(`bom_id`) USING BTREE,
  INDEX `idx_bom_detail_id`(`bom_detail_id`) USING BTREE,
  INDEX `idx_routing_step_id`(`routing_step_id`) USING BTREE,
  INDEX `idx_child_material_id`(`child_material_id`) USING BTREE,
  INDEX `idx_tenant_id`(`tenant_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = 'MES制造BOM明细' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of mes_mbom_line
-- ----------------------------
INSERT INTO `mes_mbom_line` VALUES (1, '000000', 1, 4, NULL, 38, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 1, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (2, '000000', 1, 4, NULL, 39, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 2, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (3, '000000', 1, 4, NULL, 40, 2.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 3, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (4, '000000', 1, 4, NULL, 140, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 4, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (5, '000000', 2, 9, NULL, 41, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 1, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (6, '000000', 2, 9, NULL, 42, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 2, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (7, '000000', 2, 9, NULL, 43, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 3, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (8, '000000', 2, 9, NULL, 44, 2.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 4, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (9, '000000', 2, 9, NULL, 142, 2.500000, 0.0000, NULL, NULL, NULL, NULL, 0, 5, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (10, '000000', 2, 9, NULL, 143, 4.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 6, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (11, '000000', 3, 11, NULL, 45, 10.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 1, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (12, '000000', 3, 11, NULL, 140, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 2, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (13, '000000', 4, 14, NULL, 46, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 1, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (14, '000000', 4, 14, NULL, 47, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 2, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (15, '000000', 4, 14, NULL, 146, 0.800000, 0.0000, NULL, NULL, NULL, NULL, 0, 3, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (16, '000000', 5, 17, NULL, 48, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 1, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (17, '000000', 5, 17, NULL, 49, 2.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 2, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (18, '000000', 5, 17, NULL, 149, 1.600000, 0.0000, NULL, NULL, NULL, NULL, 0, 3, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (19, '000000', 6, 21, NULL, 50, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 1, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (20, '000000', 6, 21, NULL, 51, 2.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 2, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (21, '000000', 6, 21, NULL, 52, 2.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 3, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (22, '000000', 7, 25, NULL, 53, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 1, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (23, '000000', 7, 25, NULL, 54, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 2, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (24, '000000', 7, 25, NULL, 55, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 3, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (25, '000000', 7, 25, NULL, 154, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 4, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (26, '000000', 8, 30, NULL, 56, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 1, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (27, '000000', 8, 30, NULL, 57, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 2, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (28, '000000', 8, 30, NULL, 58, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 3, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (29, '000000', 8, 30, NULL, 59, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 4, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (30, '000000', 8, 30, NULL, 142, 6.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 5, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (31, '000000', 9, 34, NULL, 60, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 1, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (32, '000000', 9, 34, NULL, 61, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 2, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (33, '000000', 9, 34, NULL, 62, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 3, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (34, '000000', 9, 34, NULL, 158, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 4, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (35, '000000', 10, 39, NULL, 63, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 1, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (36, '000000', 10, 39, NULL, 64, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 2, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (37, '000000', 10, 39, NULL, 65, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 3, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (38, '000000', 10, 39, NULL, 66, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 4, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (39, '000000', 10, 39, NULL, 149, 6.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 5, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (40, '000000', 11, 44, NULL, 67, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 1, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (41, '000000', 11, 44, NULL, 68, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 2, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (42, '000000', 11, 44, NULL, 69, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 3, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (43, '000000', 11, 44, NULL, 70, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 4, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (44, '000000', 11, 44, NULL, 146, 2.400000, 0.0000, NULL, NULL, NULL, NULL, 0, 5, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (45, '000000', 12, 48, NULL, 71, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 1, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (46, '000000', 12, 48, NULL, 72, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 2, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (47, '000000', 12, 48, NULL, 73, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 3, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (48, '000000', 12, 48, NULL, 142, 12.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 4, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (49, '000000', 13, 50, NULL, 74, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 1, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (50, '000000', 14, 54, NULL, 75, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 1, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (51, '000000', 14, 54, NULL, 76, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 2, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (52, '000000', 14, 54, NULL, 77, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 3, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (53, '000000', 14, 54, NULL, 171, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 4, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (54, '000000', 15, 59, NULL, 78, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 1, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (55, '000000', 15, 59, NULL, 79, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 2, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (56, '000000', 15, 59, NULL, 80, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 3, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (57, '000000', 15, 59, NULL, 81, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 4, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (58, '000000', 15, 59, NULL, 173, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 5, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (59, '000000', 16, 61, NULL, 82, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 1, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (60, '000000', 17, 64, NULL, 83, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 1, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (61, '000000', 17, 64, NULL, 84, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 2, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (62, '000000', 17, 64, NULL, 179, 0.160000, 0.0000, NULL, NULL, NULL, NULL, 0, 3, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (63, '000000', 18, 67, NULL, 85, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 1, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (64, '000000', 18, 67, NULL, 86, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 2, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (65, '000000', 19, 70, NULL, 87, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 1, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (66, '000000', 19, 70, NULL, 88, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 2, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (67, '000000', 20, 75, NULL, 89, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 1, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (68, '000000', 20, 75, NULL, 90, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 2, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (69, '000000', 20, 75, NULL, 91, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 3, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (70, '000000', 20, 75, NULL, 92, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 4, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (71, '000000', 21, 79, NULL, 93, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 1, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (72, '000000', 21, 79, NULL, 94, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 2, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (73, '000000', 21, 79, NULL, 95, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 3, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (74, '000000', 21, 79, NULL, 146, 0.450000, 0.0000, NULL, NULL, NULL, NULL, 0, 4, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (75, '000000', 22, 83, NULL, 96, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 1, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (76, '000000', 22, 83, NULL, 97, 2.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 2, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (77, '000000', 22, 83, NULL, 98, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 3, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (78, '000000', 23, 87, NULL, 99, 2.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 1, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (79, '000000', 23, 87, NULL, 100, 2.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 2, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (80, '000000', 23, 87, NULL, 101, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 3, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (81, '000000', 23, 87, NULL, 198, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 4, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (82, '000000', 24, 91, NULL, 102, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 1, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (83, '000000', 24, 91, NULL, 103, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 2, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (84, '000000', 24, 91, NULL, 104, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 3, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (85, '000000', 24, 91, NULL, 146, 0.700000, 0.0000, NULL, NULL, NULL, NULL, 0, 4, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (86, '000000', 25, 95, NULL, 105, 2.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 1, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (87, '000000', 25, 95, NULL, 106, 4.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 2, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (88, '000000', 25, 95, NULL, 107, 8.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 3, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (89, '000000', 25, 95, NULL, 146, 0.420000, 0.0000, NULL, NULL, NULL, NULL, 0, 4, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (90, '000000', 25, 95, NULL, 201, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 5, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (91, '000000', 26, 100, NULL, 108, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 1, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (92, '000000', 26, 100, NULL, 109, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 2, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (93, '000000', 26, 100, NULL, 110, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 3, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (94, '000000', 26, 100, NULL, 111, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 4, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (95, '000000', 27, 103, NULL, 112, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 1, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (96, '000000', 27, 103, NULL, 113, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 2, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (97, '000000', 27, 103, NULL, 114, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 3, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (98, '000000', 27, 103, NULL, 171, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 4, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (99, '000000', 28, 106, NULL, 115, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 1, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (100, '000000', 28, 106, NULL, 116, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 2, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (101, '000000', 29, 108, NULL, 117, 20.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 1, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (102, '000000', 29, 108, NULL, 207, 0.080000, 0.0000, NULL, NULL, NULL, NULL, 0, 2, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (103, '000000', 30, 111, NULL, 118, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 1, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (104, '000000', 30, 111, NULL, 119, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 2, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (105, '000000', 31, 115, NULL, 120, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 1, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (106, '000000', 31, 115, NULL, 121, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 2, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (107, '000000', 31, 115, NULL, 122, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 3, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (108, '000000', 31, 115, NULL, 146, 0.900000, 0.0000, NULL, NULL, NULL, NULL, 0, 4, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (109, '000000', 32, 117, NULL, 123, 12.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 1, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (110, '000000', 32, 117, NULL, 216, 2.400000, 0.0000, NULL, NULL, NULL, NULL, 0, 2, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (111, '000000', 33, 122, NULL, 124, 3.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 1, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (112, '000000', 33, 122, NULL, 125, 3.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 2, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (113, '000000', 33, 122, NULL, 126, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 3, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (114, '000000', 33, 122, NULL, 127, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 4, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (115, '000000', 33, 122, NULL, 220, 2.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 5, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (116, '000000', 34, 126, NULL, 128, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 1, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (117, '000000', 34, 126, NULL, 129, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 2, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (118, '000000', 34, 126, NULL, 130, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 3, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (119, '000000', 34, 126, NULL, 223, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 4, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (120, '000000', 35, 131, NULL, 131, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 1, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (121, '000000', 35, 131, NULL, 132, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 2, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (122, '000000', 35, 131, NULL, 133, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 3, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (123, '000000', 35, 131, NULL, 134, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 4, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (124, '000000', 36, 134, NULL, 135, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 1, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (125, '000000', 36, 134, NULL, 136, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 2, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (126, '000000', 37, 137, NULL, 137, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 1, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (127, '000000', 37, 137, NULL, 138, 1.000000, 0.0000, NULL, NULL, NULL, NULL, 0, 2, NULL, 1, 103, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `mes_mbom_line` VALUES (2106995185059540994, '000000', 2106995184992432129, 2106762033351315457, 2106762033816883202, 2106760678595317762, 1.000000, 0.0000, 2106995184052908033, 44, 46, NULL, 0, 1, NULL, 103, 1, '2026-10-05 14:29:33', 1, '2026-10-05 14:29:33', '0');
INSERT INTO `mes_mbom_line` VALUES (2106995185126649857, '000000', 2106995184992432129, 2106762033351315457, 2106762034014015489, 2106760679291572226, 1.000000, 0.0000, 2106995184052908033, 44, 46, NULL, 0, 2, NULL, 103, 1, '2026-10-05 14:29:33', 1, '2026-10-05 14:29:33', '0');
INSERT INTO `mes_mbom_line` VALUES (2106995185139232770, '000000', 2106995184992432129, 2106762033351315457, 2106762034135650306, 2106760679643893762, 2.000000, 0.0000, 2106995184052908033, 44, 46, NULL, 0, 3, NULL, 103, 1, '2026-10-05 14:29:33', 1, '2026-10-05 14:29:33', '0');

-- ----------------------------
-- Table structure for mes_release_package
-- ----------------------------
DROP TABLE IF EXISTS `mes_release_package`;
CREATE TABLE `mes_release_package`  (
  `package_id` bigint(20) NOT NULL COMMENT '发布包ID',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '000000' COMMENT '租户ID',
  `package_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '发布包编码(自动编码 MES_RP_CODE)',
  `client_id` bigint(20) NOT NULL COMMENT '客户ID(bd_client.client_id)',
  `client_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '客户名称(冗余)',
  `material_id` bigint(20) NOT NULL COMMENT '成品物料ID(bd_material.material_id)',
  `material_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '物料编码(冗余)',
  `material_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '物料名称(冗余)',
  `customer_product_code` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '客户产品代号(客户对该产品的内部编号, 匹配键)',
  `customer_product_name` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '客户产品名称',
  `version` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '版本号(如 2.1)',
  `release_notes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT '发布说明',
  `status` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'DRAFT' COMMENT '状态: DRAFT/IN_REVIEW/RELEASED/ARCHIVED',
  `effective_date` datetime(0) NULL DEFAULT NULL COMMENT '生效日期(空=发布即生效)',
  `expiry_date` datetime(0) NULL DEFAULT NULL COMMENT '过期日期(空=永久有效)',
  `is_default` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0' COMMENT '是否客户+物料默认发布包(0否/1是, 客户+物料内唯一)',
  `select_flow_id` bigint(20) NULL DEFAULT NULL COMMENT '审批流配置ID(wf_custom_form.id)',
  `published_by` bigint(20) NULL DEFAULT NULL COMMENT '发布人ID',
  `publish_time` datetime(0) NULL DEFAULT NULL COMMENT '发布时间',
  `create_dept` bigint(20) NULL DEFAULT NULL COMMENT '创建部门',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建人',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新人',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0' COMMENT '删除标志(0存在/2删除)',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`package_id`) USING BTREE,
  UNIQUE INDEX `uk_tenant_package_code`(`tenant_id`, `package_code`) USING BTREE,
  INDEX `idx_client_material`(`client_id`, `material_id`) USING BTREE,
  INDEX `idx_material`(`material_id`) USING BTREE,
  INDEX `idx_status`(`status`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = 'MES客户定制化发布包主表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for mes_release_pkg_bom_item
-- ----------------------------
DROP TABLE IF EXISTS `mes_release_pkg_bom_item`;
CREATE TABLE `mes_release_pkg_bom_item`  (
  `item_id` bigint(20) NOT NULL COMMENT '主键ID',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '000000' COMMENT '租户ID',
  `package_id` bigint(20) NOT NULL COMMENT '发布包ID(mes_release_package.package_id)',
  `action_type` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '操作类型: REPLACE/ADD/REMOVE',
  `child_material_id` bigint(20) NULL DEFAULT NULL COMMENT '原物料ID(REPLACE/REMOVE 定位键, 按子件物料定位抗BOM版本变更)',
  `child_material_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '原物料编码(冗余)',
  `child_material_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '原物料名称(冗余)',
  `bom_detail_id` bigint(20) NULL DEFAULT NULL COMMENT '标准BOM明细行ID(可选精确定位, 空则按原物料定位)',
  `target_material_id` bigint(20) NULL DEFAULT NULL COMMENT '目标物料ID(REPLACE/ADD 必填)',
  `target_material_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '目标物料编码(冗余)',
  `target_material_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '目标物料名称(冗余)',
  `quantity_per_parent` decimal(18, 6) NULL DEFAULT NULL COMMENT '单位用量(空=REPLACE沿用原行/ADD必填)',
  `sort_order` int(11) NOT NULL DEFAULT 0 COMMENT '排序',
  `create_dept` bigint(20) NULL DEFAULT NULL COMMENT '创建部门',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建人',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新人',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0' COMMENT '删除标志(0存在/2删除)',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`item_id`) USING BTREE,
  INDEX `idx_package`(`package_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = 'MES发布包BOM选配表(替换/新增/移除)' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for mes_release_pkg_config
-- ----------------------------
DROP TABLE IF EXISTS `mes_release_pkg_config`;
CREATE TABLE `mes_release_pkg_config`  (
  `config_id` bigint(20) NOT NULL COMMENT '主键ID',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '000000' COMMENT '租户ID',
  `package_id` bigint(20) NOT NULL COMMENT '发布包ID(mes_release_package.package_id)',
  `config_group` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '配置分组: FLASH/TEST_PARAM/LABEL/PACKAGING/PROCESS',
  `config_key` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '配置键',
  `config_value` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '配置值',
  `config_type` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT 'STRING' COMMENT '值类型: STRING/NUMBER/BOOLEAN/JSON',
  `process_id` bigint(20) NULL DEFAULT NULL COMMENT '关联工序ID(空=全局生效)',
  `process_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '工序编码(冗余)',
  `sort_order` int(11) NOT NULL DEFAULT 0 COMMENT '排序',
  `create_dept` bigint(20) NULL DEFAULT NULL COMMENT '创建部门',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建人',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新人',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0' COMMENT '删除标志(0存在/2删除)',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`config_id`) USING BTREE,
  INDEX `idx_package`(`package_id`) USING BTREE,
  INDEX `idx_group`(`config_group`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = 'MES发布包配置项表(测试参数/标签/包装/工艺参数)' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for mes_release_pkg_firmware
-- ----------------------------
DROP TABLE IF EXISTS `mes_release_pkg_firmware`;
CREATE TABLE `mes_release_pkg_firmware`  (
  `mapping_id` bigint(20) NOT NULL COMMENT '主键ID',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '000000' COMMENT '租户ID',
  `package_id` bigint(20) NOT NULL COMMENT '发布包ID(mes_release_package.package_id)',
  `routing_step_id` bigint(20) NULL DEFAULT NULL COMMENT '工艺路线步骤ID(bd_routing_step.step_id, 精确定位)',
  `process_id` bigint(20) NULL DEFAULT NULL COMMENT '工序ID(bd_process.process_id, 宽泛定位)',
  `process_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '工序编码(冗余)',
  `process_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '工序名称(冗余)',
  `pcba_material_id` bigint(20) NULL DEFAULT NULL COMMENT 'PCBA物料ID(固件物理载体, 追溯用, 可空)',
  `pcba_material_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT 'PCBA物料编码(冗余)',
  `pcba_material_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT 'PCBA物料名称(冗余)',
  `firmware_id` bigint(20) NOT NULL COMMENT '固件ID(mes_firmware.firmware_id, 仅RELEASED)',
  `firmware_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '固件编码(冗余)',
  `firmware_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '固件名称(冗余)',
  `firmware_version` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '固件版本(冗余)',
  `sort_order` int(11) NOT NULL DEFAULT 0 COMMENT '排序',
  `create_dept` bigint(20) NULL DEFAULT NULL COMMENT '创建部门',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建人',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新人',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0' COMMENT '删除标志(0存在/2删除)',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`mapping_id`) USING BTREE,
  INDEX `idx_package`(`package_id`) USING BTREE,
  INDEX `idx_process`(`process_id`) USING BTREE,
  INDEX `idx_firmware`(`firmware_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = 'MES发布包固件映射表(工序→固件)' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for mes_resource_item
-- ----------------------------
DROP TABLE IF EXISTS `mes_resource_item`;
CREATE TABLE `mes_resource_item`  (
  `item_id` bigint(20) NOT NULL COMMENT '资源项ID',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '000000' COMMENT '租户ID',
  `pool_id` bigint(20) NOT NULL COMMENT '资源池ID',
  `resource_value` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '资源值(如MAC 00:1A:2B:3C:4D:5E)',
  `status` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'AVAILABLE' COMMENT 'AVAILABLE/ALLOCATED/USED/SCRAPPED',
  `bound_sn_id` bigint(20) NULL DEFAULT NULL COMMENT '已绑定SN ID(一SN绑一资源)',
  `bound_time` datetime(0) NULL DEFAULT NULL COMMENT '绑定时间',
  `create_dept` bigint(20) NULL DEFAULT NULL,
  `create_by` bigint(20) NULL DEFAULT NULL,
  `create_time` datetime(0) NULL DEFAULT NULL,
  `update_by` bigint(20) NULL DEFAULT NULL,
  `update_time` datetime(0) NULL DEFAULT NULL,
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  PRIMARY KEY (`item_id`) USING BTREE,
  UNIQUE INDEX `uk_tenant_pool_value`(`tenant_id`, `pool_id`, `resource_value`) USING BTREE,
  INDEX `idx_pool_status`(`pool_id`, `status`) USING BTREE,
  INDEX `idx_bound_sn`(`bound_sn_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '资源池明细' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for mes_resource_pool
-- ----------------------------
DROP TABLE IF EXISTS `mes_resource_pool`;
CREATE TABLE `mes_resource_pool`  (
  `pool_id` bigint(20) NOT NULL COMMENT '资源池ID',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '000000' COMMENT '租户ID',
  `pool_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '资源池编码(自动编码 MES_POOL_CODE)',
  `pool_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '资源池名称',
  `resource_type` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '资源类型: MAC/SN/CERT',
  `source` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'INTERNAL' COMMENT '来源: INTERNAL(内部导入)/EXTERNAL(外部REST)',
  `external_config` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT '外部REST配置JSON(baseUrl/路径/鉴权, 经SSRF校验)',
  `alloc_strategy` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'FIFO' COMMENT '分配策略: FIFO/随机',
  `total_count` int(11) NULL DEFAULT NULL COMMENT '总数量',
  `used_count` int(11) NOT NULL DEFAULT 0 COMMENT '已分配数量',
  `status` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ENABLED' COMMENT 'ENABLED/DISABLED',
  `create_dept` bigint(20) NULL DEFAULT NULL,
  `create_by` bigint(20) NULL DEFAULT NULL,
  `create_time` datetime(0) NULL DEFAULT NULL,
  `update_by` bigint(20) NULL DEFAULT NULL,
  `update_time` datetime(0) NULL DEFAULT NULL,
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  PRIMARY KEY (`pool_id`) USING BTREE,
  UNIQUE INDEX `uk_tenant_pool_code`(`tenant_id`, `pool_code`) USING BTREE,
  INDEX `idx_tenant_id`(`tenant_id`) USING BTREE,
  INDEX `idx_resource_type`(`resource_type`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '刷写资源池(MAC/SN等)' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for mes_sn_bind_log
-- ----------------------------
DROP TABLE IF EXISTS `mes_sn_bind_log`;
CREATE TABLE `mes_sn_bind_log`  (
  `log_id` bigint(20) NOT NULL COMMENT '日志ID',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT '000000',
  `action` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '操作: BIND/UNBIND/REBIND',
  `parent_sn_id` bigint(20) NULL DEFAULT NULL COMMENT '父SN ID',
  `parent_sn_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '父SN编码',
  `component_sn_id` bigint(20) NULL DEFAULT NULL COMMENT '组件SN ID',
  `component_sn_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '组件SN编码',
  `new_component_sn_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '换板新组件SN编码(REBIND)',
  `reason` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '操作原因(解绑/换板必填)',
  `operator_code` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '操作员工号',
  `create_dept` bigint(20) NULL DEFAULT NULL,
  `create_by` bigint(20) NULL DEFAULT NULL,
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP,
  `update_by` bigint(20) NULL DEFAULT NULL,
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP(0),
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT '0',
  PRIMARY KEY (`log_id`) USING BTREE,
  INDEX `idx_parent`(`parent_sn_id`) USING BTREE,
  INDEX `idx_component`(`component_sn_id`) USING BTREE,
  INDEX `idx_parent_sn_code`(`tenant_id`, `parent_sn_code`) USING BTREE,
  INDEX `idx_component_sn_code`(`tenant_id`, `component_sn_code`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '关键件绑定操作日志' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for mes_station_device
-- ----------------------------
DROP TABLE IF EXISTS `mes_station_device`;
CREATE TABLE `mes_station_device`  (
  `device_id` bigint(20) NOT NULL COMMENT '设备ID',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT '000000',
  `device_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '设备编码(工控机)',
  `station_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '绑定工位编码',
  `process_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '绑定工序编码',
  `app_version` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '终端版本',
  `operator_code` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '当前操作员工号',
  `operator_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '当前操作员姓名',
  `shutdown_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT '0' COMMENT '主动下线标记: 1=应用正常退出(即时离线判定)',
  `last_heartbeat` datetime(0) NULL DEFAULT NULL COMMENT '最后心跳时间',
  `create_dept` bigint(20) NULL DEFAULT NULL,
  `create_by` bigint(20) NULL DEFAULT NULL,
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP,
  `update_by` bigint(20) NULL DEFAULT NULL,
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP(0),
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT '0',
  PRIMARY KEY (`device_id`) USING BTREE,
  UNIQUE INDEX `uk_device_code`(`tenant_id`, `device_code`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '工位终端设备台账' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of mes_station_device
-- ----------------------------
INSERT INTO `mes_station_device` VALUES (2107083839232684034, '000000', 'GZZ0046-01', 'STN|CJ012|GZZ0046|ASM|GENERAL', 'ASM', NULL, 'SCZX20251222018', NULL, '0', '2026-10-06 12:39:39', 103, 1, '2026-10-05 20:21:50', 1, '2026-10-06 12:39:38', '0');
INSERT INTO `mes_station_device` VALUES (2107083839329153025, '000000', 'GZZ0052-01', 'STN|CJ013|GZZ0052|QC|GENERAL', 'QC', NULL, 'SCZX20251222017', NULL, '0', '2026-10-06 12:39:39', 103, 1, '2026-10-05 20:21:50', 1, '2026-10-06 12:39:38', '0');
INSERT INTO `mes_station_device` VALUES (2108958569418149889, '000000', 'UNREGISTERED', 'STN|下料车间|GZZ0001|LASER|GENERAL', 'LASER', '33.4.11', NULL, NULL, '1', '2026-10-11 16:39:19', -1, -1, '2026-10-11 00:31:20', -1, '2026-10-11 16:39:19', '0');
INSERT INTO `mes_station_device` VALUES (2109836475962998785, '000000', '一号工位机', NULL, NULL, '1.0.0', NULL, NULL, '1', '2026-10-13 10:40:19', -1, -1, '2026-10-13 10:39:49', -1, '2026-10-13 10:40:18', '0');

-- ----------------------------
-- Table structure for mes_station_report
-- ----------------------------
DROP TABLE IF EXISTS `mes_station_report`;
CREATE TABLE `mes_station_report`  (
  `report_id` bigint(20) NOT NULL COMMENT '报工记录ID',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT '000000',
  `report_type` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '报工类型: SINGLE(单件过站)/BATCH(批量计数)',
  `sn_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT 'SN编码(SINGLE)',
  `station_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '工位编码',
  `card_id` bigint(20) NULL DEFAULT NULL COMMENT '流转卡ID',
  `step_record_id` bigint(20) NULL DEFAULT NULL COMMENT '流转卡工序记录ID',
  `mes_wo_id` bigint(20) NULL DEFAULT NULL COMMENT 'MES工单ID',
  `wo_no` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '工单编号(冗余)',
  `operator_id` bigint(20) NULL DEFAULT NULL COMMENT '操作员用户ID',
  `operator_code` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '操作员工号',
  `operator_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '操作员姓名',
  `result` varchar(8) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '结果: PASS/FAIL(SINGLE)',
  `defect_codes` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '不良代码(逗号分隔)',
  `good_qty` decimal(18, 4) NULL DEFAULT 0.0000 COMMENT '良品数量',
  `defect_qty` decimal(18, 4) NULL DEFAULT 0.0000 COMMENT '不良数量',
  `client_ts` bigint(20) NOT NULL COMMENT '客户端时间戳(毫秒)',
  `client_key` varchar(160) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '幂等键: SINGLE|sn|station|ts 或 BATCH|station|ts',
  `create_dept` bigint(20) NULL DEFAULT NULL,
  `create_by` bigint(20) NULL DEFAULT NULL,
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP,
  `update_by` bigint(20) NULL DEFAULT NULL,
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP(0),
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT '0',
  `request_fingerprint` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '单件规范化原始请求SHA256指纹;旧记录不得猜测回填',
  PRIMARY KEY (`report_id`) USING BTREE,
  UNIQUE INDEX `uk_tenant_client_key`(`tenant_id`, `client_key`) USING BTREE,
  INDEX `idx_sn_code`(`sn_code`) USING BTREE,
  INDEX `idx_station_code`(`station_code`) USING BTREE,
  INDEX `idx_step_record`(`step_record_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '工位终端报工记录(设备通道)' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of mes_station_report
-- ----------------------------
INSERT INTO `mes_station_report` VALUES (2107085565406883841, '000000', 'SINGLE', 'SN-FC-SCGD202610050001-9899-0001', 'STN|CJ012|GZZ0046|ASM|GENERAL', 2107083840268677122, 2107083840331591682, 2106995561900978178, 'SCGD202610050001', NULL, NULL, NULL, 'PASS', NULL, 1.0000, 0.0000, 1791203036950, 'SINGLE|SN-FC-SCGD202610050001-9899-0001|STN|CJ012|GZZ0046|ASM|GENERAL|1791203036950', 103, 1, '2026-10-05 20:28:41', 1, '2026-10-05 20:28:41', '0', 'e49f915315256fbf304dd480007c7848778089db299df275819505f0a917f15f');
INSERT INTO `mes_station_report` VALUES (2107085565645959170, '000000', 'SINGLE', 'SN-FC-SCGD202610050001-9899-0002', 'STN|CJ012|GZZ0046|ASM|GENERAL', 2107083840268677122, 2107083840331591682, 2106995561900978178, 'SCGD202610050001', NULL, NULL, NULL, 'PASS', NULL, 1.0000, 0.0000, 1791203036951, 'SINGLE|SN-FC-SCGD202610050001-9899-0002|STN|CJ012|GZZ0046|ASM|GENERAL|1791203036951', 103, 1, '2026-10-05 20:28:41', 1, '2026-10-05 20:28:41', '0', 'c4ad3356b39652c2196f6d8b666d5224a323ce577fc2086ebc627c2a449da7f5');
INSERT INTO `mes_station_report` VALUES (2107085565864062977, '000000', 'SINGLE', 'SN-FC-SCGD202610050001-9899-0003', 'STN|CJ012|GZZ0046|ASM|GENERAL', 2107083840268677122, 2107083840331591682, 2106995561900978178, 'SCGD202610050001', NULL, NULL, NULL, 'PASS', NULL, 1.0000, 0.0000, 1791203036952, 'SINGLE|SN-FC-SCGD202610050001-9899-0003|STN|CJ012|GZZ0046|ASM|GENERAL|1791203036952', 103, 1, '2026-10-05 20:28:41', 1, '2026-10-05 20:28:41', '0', '92cb0f40b9f6103385868abfd9fa6736afb77b167a9fec45fb25cb961dd22953');
INSERT INTO `mes_station_report` VALUES (2107085566015057922, '000000', 'SINGLE', 'SN-FC-SCGD202610050001-9899-0004', 'STN|CJ012|GZZ0046|ASM|GENERAL', 2107083840268677122, 2107083840331591682, 2106995561900978178, 'SCGD202610050001', NULL, NULL, NULL, 'PASS', NULL, 1.0000, 0.0000, 1791203036953, 'SINGLE|SN-FC-SCGD202610050001-9899-0004|STN|CJ012|GZZ0046|ASM|GENERAL|1791203036953', 103, 1, '2026-10-05 20:28:41', 1, '2026-10-05 20:28:41', '0', 'c2b6b67a79aef398ae64ec2cfc682ff6cea413a15dfc88780d79c00e965569ab');
INSERT INTO `mes_station_report` VALUES (2107085566258327553, '000000', 'SINGLE', 'SN-FC-SCGD202610050001-9899-0005', 'STN|CJ012|GZZ0046|ASM|GENERAL', 2107083840268677122, 2107083840331591682, 2106995561900978178, 'SCGD202610050001', NULL, NULL, NULL, 'PASS', NULL, 1.0000, 0.0000, 1791203036954, 'SINGLE|SN-FC-SCGD202610050001-9899-0005|STN|CJ012|GZZ0046|ASM|GENERAL|1791203036954', 103, 1, '2026-10-05 20:28:41', 1, '2026-10-05 20:28:41', '0', '480e88f297f7f469b1b1e0018db399074512aa6445c78509df75458a8e1a0610');
INSERT INTO `mes_station_report` VALUES (2107085566384156674, '000000', 'SINGLE', 'SN-FC-SCGD202610050001-9899-0006', 'STN|CJ012|GZZ0046|ASM|GENERAL', 2107083840268677122, 2107083840331591682, 2106995561900978178, 'SCGD202610050001', NULL, NULL, NULL, 'PASS', NULL, 1.0000, 0.0000, 1791203036955, 'SINGLE|SN-FC-SCGD202610050001-9899-0006|STN|CJ012|GZZ0046|ASM|GENERAL|1791203036955', 103, 1, '2026-10-05 20:28:41', 1, '2026-10-05 20:28:41', '0', 'f95736bcfd111359b371d17c8e542cd53a3f3f68dffdd77692225ea3aaba1f27');
INSERT INTO `mes_station_report` VALUES (2107085566514180097, '000000', 'SINGLE', 'SN-FC-SCGD202610050001-9899-0007', 'STN|CJ012|GZZ0046|ASM|GENERAL', 2107083840268677122, 2107083840331591682, 2106995561900978178, 'SCGD202610050001', NULL, NULL, NULL, 'PASS', NULL, 1.0000, 0.0000, 1791203036956, 'SINGLE|SN-FC-SCGD202610050001-9899-0007|STN|CJ012|GZZ0046|ASM|GENERAL|1791203036956', 103, 1, '2026-10-05 20:28:41', 1, '2026-10-05 20:28:41', '0', 'b0e909c03076c40ed8de0a118cb29bb9205382e4363e2f3a22de74bd7976b59c');
INSERT INTO `mes_station_report` VALUES (2107085566711312385, '000000', 'SINGLE', 'SN-FC-SCGD202610050001-9899-0008', 'STN|CJ012|GZZ0046|ASM|GENERAL', 2107083840268677122, 2107083840331591682, 2106995561900978178, 'SCGD202610050001', NULL, NULL, NULL, 'PASS', NULL, 1.0000, 0.0000, 1791203036957, 'SINGLE|SN-FC-SCGD202610050001-9899-0008|STN|CJ012|GZZ0046|ASM|GENERAL|1791203036957', 103, 1, '2026-10-05 20:28:42', 1, '2026-10-05 20:28:42', '0', 'b2a88e1195364a1857acdf30f605fb528dd9f457173488299bc5952b5d82f520');
INSERT INTO `mes_station_report` VALUES (2107085566862307330, '000000', 'SINGLE', 'SN-FC-SCGD202610050001-9899-0009', 'STN|CJ012|GZZ0046|ASM|GENERAL', 2107083840268677122, 2107083840331591682, 2106995561900978178, 'SCGD202610050001', NULL, NULL, NULL, 'PASS', NULL, 1.0000, 0.0000, 1791203036958, 'SINGLE|SN-FC-SCGD202610050001-9899-0009|STN|CJ012|GZZ0046|ASM|GENERAL|1791203036958', 103, 1, '2026-10-05 20:28:42', 1, '2026-10-05 20:28:42', '0', 'ba19d008e822d127f99b0158e433cffcdf2581cd719100a1c1cce3b4f9d32a52');
INSERT INTO `mes_station_report` VALUES (2107085567009107970, '000000', 'SINGLE', 'SN-FC-SCGD202610050001-9899-0010', 'STN|CJ012|GZZ0046|ASM|GENERAL', 2107083840268677122, 2107083840331591682, 2106995561900978178, 'SCGD202610050001', NULL, NULL, NULL, 'PASS', NULL, 1.0000, 0.0000, 1791203036959, 'SINGLE|SN-FC-SCGD202610050001-9899-0010|STN|CJ012|GZZ0046|ASM|GENERAL|1791203036959', 103, 1, '2026-10-05 20:28:42', 1, '2026-10-05 20:28:42', '0', '11d1125382d2d09528c5cfe43489fecd65d3dd6f21e4ffc9f86e9b64309af4ff');
INSERT INTO `mes_station_report` VALUES (2107085567260766209, '000000', 'SINGLE', 'SN-FC-SCGD202610050001-9899-0001', 'STN|CJ013|GZZ0052|QC|GENERAL', 2107083840268677122, 2107083840394506242, 2106995561900978178, 'SCGD202610050001', NULL, NULL, NULL, 'PASS', NULL, 1.0000, 0.0000, 1791203037050, 'SINGLE|SN-FC-SCGD202610050001-9899-0001|STN|CJ013|GZZ0052|QC|GENERAL|1791203037050', 103, 1, '2026-10-05 20:28:42', 1, '2026-10-05 20:28:42', '0', 'f3abaac52c420052b80ee488daf5a115468abfc432fbd60fe68751c931686342');
INSERT INTO `mes_station_report` VALUES (2107085567571144706, '000000', 'SINGLE', 'SN-FC-SCGD202610050001-9899-0002', 'STN|CJ013|GZZ0052|QC|GENERAL', 2107083840268677122, 2107083840394506242, 2106995561900978178, 'SCGD202610050001', NULL, NULL, NULL, 'PASS', NULL, 1.0000, 0.0000, 1791203037051, 'SINGLE|SN-FC-SCGD202610050001-9899-0002|STN|CJ013|GZZ0052|QC|GENERAL|1791203037051', 103, 1, '2026-10-05 20:28:42', 1, '2026-10-05 20:28:42', '0', 'e380b29e20af3b3247139e3819ff1bd54bafbd6da4fce31f1efa8d35c94f9767');
INSERT INTO `mes_station_report` VALUES (2107085567734722562, '000000', 'SINGLE', 'SN-FC-SCGD202610050001-9899-0003', 'STN|CJ013|GZZ0052|QC|GENERAL', 2107083840268677122, 2107083840394506242, 2106995561900978178, 'SCGD202610050001', NULL, NULL, NULL, 'PASS', NULL, 1.0000, 0.0000, 1791203037052, 'SINGLE|SN-FC-SCGD202610050001-9899-0003|STN|CJ013|GZZ0052|QC|GENERAL|1791203037052', 103, 1, '2026-10-05 20:28:42', 1, '2026-10-05 20:28:42', '0', '7f52079d69490486a17debe2802a7b8db899b95722069b653a7520590968e0ee');
INSERT INTO `mes_station_report` VALUES (2107085567873134593, '000000', 'SINGLE', 'SN-FC-SCGD202610050001-9899-0004', 'STN|CJ013|GZZ0052|QC|GENERAL', 2107083840268677122, 2107083840394506242, 2106995561900978178, 'SCGD202610050001', NULL, NULL, NULL, 'PASS', NULL, 1.0000, 0.0000, 1791203037053, 'SINGLE|SN-FC-SCGD202610050001-9899-0004|STN|CJ013|GZZ0052|QC|GENERAL|1791203037053', 103, 1, '2026-10-05 20:28:42', 1, '2026-10-05 20:28:42', '0', '66973ac1c6553fab8033b67b7de674f65c10409ea6474309bbd9bbd56fb77960');
INSERT INTO `mes_station_report` VALUES (2107085568066072578, '000000', 'SINGLE', 'SN-FC-SCGD202610050001-9899-0005', 'STN|CJ013|GZZ0052|QC|GENERAL', 2107083840268677122, 2107083840394506242, 2106995561900978178, 'SCGD202610050001', NULL, NULL, NULL, 'PASS', NULL, 1.0000, 0.0000, 1791203037054, 'SINGLE|SN-FC-SCGD202610050001-9899-0005|STN|CJ013|GZZ0052|QC|GENERAL|1791203037054', 103, 1, '2026-10-05 20:28:42', 1, '2026-10-05 20:28:42', '0', 'a7d9468bc16d36db8d03b93503d5d3945120151b6b550b9810326e64aa42bf7a');
INSERT INTO `mes_station_report` VALUES (2107085568217067522, '000000', 'SINGLE', 'SN-FC-SCGD202610050001-9899-0006', 'STN|CJ013|GZZ0052|QC|GENERAL', 2107083840268677122, 2107083840394506242, 2106995561900978178, 'SCGD202610050001', NULL, NULL, NULL, 'PASS', NULL, 1.0000, 0.0000, 1791203037055, 'SINGLE|SN-FC-SCGD202610050001-9899-0006|STN|CJ013|GZZ0052|QC|GENERAL|1791203037055', 103, 1, '2026-10-05 20:28:42', 1, '2026-10-05 20:28:42', '0', '7bc7f923552eb4dcba3d1b125571a57575e191fe6495302c44c524f8aca0a47a');
INSERT INTO `mes_station_report` VALUES (2107085568447754242, '000000', 'SINGLE', 'SN-FC-SCGD202610050001-9899-0007', 'STN|CJ013|GZZ0052|QC|GENERAL', 2107083840268677122, 2107083840394506242, 2106995561900978178, 'SCGD202610050001', NULL, NULL, NULL, 'PASS', NULL, 1.0000, 0.0000, 1791203037056, 'SINGLE|SN-FC-SCGD202610050001-9899-0007|STN|CJ013|GZZ0052|QC|GENERAL|1791203037056', 103, 1, '2026-10-05 20:28:42', 1, '2026-10-05 20:28:42', '0', '8afab436b1f7801d0774a88287bf2094abc4ed0ccba0de80c5a866bd3f55b1b2');
INSERT INTO `mes_station_report` VALUES (2107085568586166274, '000000', 'SINGLE', 'SN-FC-SCGD202610050001-9899-0008', 'STN|CJ013|GZZ0052|QC|GENERAL', 2107083840268677122, 2107083840394506242, 2106995561900978178, 'SCGD202610050001', NULL, NULL, NULL, 'PASS', NULL, 1.0000, 0.0000, 1791203037057, 'SINGLE|SN-FC-SCGD202610050001-9899-0008|STN|CJ013|GZZ0052|QC|GENERAL|1791203037057', 103, 1, '2026-10-05 20:28:42', 1, '2026-10-05 20:28:42', '0', '511c56a2ddca2c1dadeea0e8f3747cf5735b60e28d99100a6efd005497fadf60');
INSERT INTO `mes_station_report` VALUES (2107085568728772609, '000000', 'SINGLE', 'SN-FC-SCGD202610050001-9899-0009', 'STN|CJ013|GZZ0052|QC|GENERAL', 2107083840268677122, 2107083840394506242, 2106995561900978178, 'SCGD202610050001', NULL, NULL, NULL, 'PASS', NULL, 1.0000, 0.0000, 1791203037058, 'SINGLE|SN-FC-SCGD202610050001-9899-0009|STN|CJ013|GZZ0052|QC|GENERAL|1791203037058', 103, 1, '2026-10-05 20:28:42', 1, '2026-10-05 20:28:42', '0', '6fb9eaf344886679caa2077b36345d60ba5654e26f1d11d6830c4ab90dce5229');
INSERT INTO `mes_station_report` VALUES (2107108405774561282, '000000', 'SINGLE', 'SN-FC-SCGD202610050001-9899-0010', 'STN|CJ013|GZZ0052|QC|GENERAL', 2107083840268677122, 2107083840394506242, 2106995561900978178, 'SCGD202610050001', NULL, NULL, NULL, 'PASS', NULL, 1.0000, 0.0000, 1791203037059, 'SINGLE|SN-FC-SCGD202610050001-9899-0010|STN|CJ013|GZZ0052|QC|GENERAL|1791203037059', 103, 1, '2026-10-05 21:59:27', 1, '2026-10-05 21:59:27', '0', 'f50ad401ba81ead2bf6a82bb9a3097d640fd88e427d0ff2fce6fcaddf2c2b347');
INSERT INTO `mes_station_report` VALUES (2107330082697588737, '000000', 'SINGLE', 'SN-FC-SCGD202610060001-8774-0001', 'STN|CJ012|GZZ0046|ASM|GENERAL', 2107328405412196354, 2107328405445750785, 2107323241485774850, 'SCGD202610060001', 106, 'SCZX20251222018', '李芳华', 'PASS', NULL, 1.0000, 0.0000, 1791261618578, 'SINGLE|SN-FC-SCGD202610060001-8774-0001|STN|CJ012|GZZ0046|ASM|GENERAL|1791261618578', 103, 1, '2026-10-06 12:40:19', 1, '2026-10-06 12:40:19', '0', '2f48898427b50d31cb979b78ff52ed30ad410859bd2a5ac1de15255b74a4ba8d');
INSERT INTO `mes_station_report` VALUES (2107330083096047618, '000000', 'SINGLE', 'SN-FC-SCGD202610060001-8774-0002', 'STN|CJ012|GZZ0046|ASM|GENERAL', 2107328405412196354, 2107328405445750785, 2107323241485774850, 'SCGD202610060001', 106, 'SCZX20251222018', '李芳华', 'PASS', NULL, 1.0000, 0.0000, 1791261618725, 'SINGLE|SN-FC-SCGD202610060001-8774-0002|STN|CJ012|GZZ0046|ASM|GENERAL|1791261618725', 103, 1, '2026-10-06 12:40:19', 1, '2026-10-06 12:40:19', '0', '19f56fb26c81f5f3b1f2c033f99389b317e228b3a3971096617a58d5ed5acf85');
INSERT INTO `mes_station_report` VALUES (2107330083410620417, '000000', 'SINGLE', 'SN-FC-SCGD202610060001-8774-0003', 'STN|CJ012|GZZ0046|ASM|GENERAL', 2107328405412196354, 2107328405445750785, 2107323241485774850, 'SCGD202610060001', 106, 'SCZX20251222018', '李芳华', 'PASS', NULL, 1.0000, 0.0000, 1791261618789, 'SINGLE|SN-FC-SCGD202610060001-8774-0003|STN|CJ012|GZZ0046|ASM|GENERAL|1791261618789', 103, 1, '2026-10-06 12:40:19', 1, '2026-10-06 12:40:19', '0', '40953f1ec8a1873a70bdb08b8c1787b421a9c9dbc903797554bf0a765e68967e');
INSERT INTO `mes_station_report` VALUES (2107330083729387521, '000000', 'SINGLE', 'SN-FC-SCGD202610060001-8774-0004', 'STN|CJ012|GZZ0046|ASM|GENERAL', 2107328405412196354, 2107328405445750785, 2107323241485774850, 'SCGD202610060001', 106, 'SCZX20251222018', '李芳华', 'PASS', NULL, 1.0000, 0.0000, 1791261618860, 'SINGLE|SN-FC-SCGD202610060001-8774-0004|STN|CJ012|GZZ0046|ASM|GENERAL|1791261618860', 103, 1, '2026-10-06 12:40:19', 1, '2026-10-06 12:40:19', '0', 'e49d33115d7e49497916dac49d0baee1bfc5ee6911a12877a0ddf042795fdc7d');
INSERT INTO `mes_station_report` VALUES (2107330084274647041, '000000', 'SINGLE', 'SN-FC-SCGD202610060001-8774-0005', 'STN|CJ012|GZZ0046|ASM|GENERAL', 2107328405412196354, 2107328405445750785, 2107323241485774850, 'SCGD202610060001', 106, 'SCZX20251222018', '李芳华', 'PASS', NULL, 1.0000, 0.0000, 1791261618936, 'SINGLE|SN-FC-SCGD202610060001-8774-0005|STN|CJ012|GZZ0046|ASM|GENERAL|1791261618936', 103, 1, '2026-10-06 12:40:19', 1, '2026-10-06 12:40:19', '0', 'deff17be9376d8941bb9aa4262f69c9ac2bf6f69d2eb0df2aa27cf8c3360a201');
INSERT INTO `mes_station_report` VALUES (2107330084664717313, '000000', 'SINGLE', 'SN-FC-SCGD202610060001-8774-0006', 'STN|CJ012|GZZ0046|ASM|GENERAL', 2107328405412196354, 2107328405445750785, 2107323241485774850, 'SCGD202610060001', 106, 'SCZX20251222018', '李芳华', 'PASS', NULL, 1.0000, 0.0000, 1791261619083, 'SINGLE|SN-FC-SCGD202610060001-8774-0006|STN|CJ012|GZZ0046|ASM|GENERAL|1791261619083', 103, 1, '2026-10-06 12:40:19', 1, '2026-10-06 12:40:19', '0', '76b3f16c5b9443b40cf0c5e49f5eb722ae33c7f8d9251f0aac6ff40250d06688');
INSERT INTO `mes_station_report` VALUES (2107330658810408962, '000000', 'SINGLE', 'SN-FC-SCGD202610060001-8774-0001', 'STN|CJ013|GZZ0052|QC|GENERAL', 2107328405412196354, 2107328405466722305, 2107323241485774850, 'SCGD202610060001', 105, 'SCZX20251222017', '张明', 'PASS', NULL, 1.0000, 0.0000, 1791261755970, 'SINGLE|SN-FC-SCGD202610060001-8774-0001|STN|CJ013|GZZ0052|QC|GENERAL|1791261755970', 103, 1, '2026-10-06 12:42:36', 1, '2026-10-06 12:42:36', '0', '5d2d75497c69a6d86c4ea0f76613fc25bbd48495a38a72d1853d5109533306f2');
INSERT INTO `mes_station_report` VALUES (2107330659150147586, '000000', 'SINGLE', 'SN-FC-SCGD202610060001-8774-0002', 'STN|CJ013|GZZ0052|QC|GENERAL', 2107328405412196354, 2107328405466722305, 2107323241485774850, 'SCGD202610060001', 105, 'SCZX20251222017', '张明', 'PASS', NULL, 1.0000, 0.0000, 1791261756069, 'SINGLE|SN-FC-SCGD202610060001-8774-0002|STN|CJ013|GZZ0052|QC|GENERAL|1791261756069', 103, 1, '2026-10-06 12:42:36', 1, '2026-10-06 12:42:36', '0', '0fdda47eb9e22b2793cc2a711a7fe5c34e2afa9d8375a33baf41d262f827b56d');
INSERT INTO `mes_station_report` VALUES (2107330659573772290, '000000', 'SINGLE', 'SN-FC-SCGD202610060001-8774-0003', 'STN|CJ013|GZZ0052|QC|GENERAL', 2107328405412196354, 2107328405466722305, 2107323241485774850, 'SCGD202610060001', 105, 'SCZX20251222017', '张明', 'PASS', NULL, 1.0000, 0.0000, 1791261756127, 'SINGLE|SN-FC-SCGD202610060001-8774-0003|STN|CJ013|GZZ0052|QC|GENERAL|1791261756127', 103, 1, '2026-10-06 12:42:36', 1, '2026-10-06 12:42:36', '0', 'd6674356136fd5d5db7ce1b41344536cdff1f29044d6eb47464a829f326bd407');
INSERT INTO `mes_station_report` VALUES (2107330659963842561, '000000', 'SINGLE', 'SN-FC-SCGD202610060001-8774-0004', 'STN|CJ013|GZZ0052|QC|GENERAL', 2107328405412196354, 2107328405466722305, 2107323241485774850, 'SCGD202610060001', 105, 'SCZX20251222017', '张明', 'PASS', NULL, 1.0000, 0.0000, 1791261756228, 'SINGLE|SN-FC-SCGD202610060001-8774-0004|STN|CJ013|GZZ0052|QC|GENERAL|1791261756228', 103, 1, '2026-10-06 12:42:36', 1, '2026-10-06 12:42:36', '0', 'a6e06ff739e7dc5a7c56bfb6e8504b3c709ea96538117d8f02332d309518b4bb');
INSERT INTO `mes_station_report` VALUES (2107330660261638146, '000000', 'SINGLE', 'SN-FC-SCGD202610060001-8774-0005', 'STN|CJ013|GZZ0052|QC|GENERAL', 2107328405412196354, 2107328405466722305, 2107323241485774850, 'SCGD202610060001', 105, 'SCZX20251222017', '张明', 'PASS', NULL, 1.0000, 0.0000, 1791261756321, 'SINGLE|SN-FC-SCGD202610060001-8774-0005|STN|CJ013|GZZ0052|QC|GENERAL|1791261756321', 103, 1, '2026-10-06 12:42:36', 1, '2026-10-06 12:42:36', '0', 'ce53acc6b223c6d194dba5e2ef5f202fe1261fe6cea9d6bf54fe0d22804eb557');
INSERT INTO `mes_station_report` VALUES (2107332442668871682, '000000', 'SINGLE', 'SN-FC-SCGD202610060001-8774-0006', 'STN|CJ013|GZZ0052|QC|GENERAL', 2107328405412196354, 2107328405466722305, 2107323241485774850, 'SCGD202610060001', 105, 'SCZX20251222017', '张明', 'PASS', NULL, 1.0000, 0.0000, 1791261756391, 'SINGLE|SN-FC-SCGD202610060001-8774-0006|STN|CJ013|GZZ0052|QC|GENERAL|1791261756391', 103, 1, '2026-10-06 12:49:41', 1, '2026-10-06 12:49:41', '0', '6700b003916f0232777db7ceb68ed905d61e790f0a6eb5edb12a0a3881f5dc0d');
INSERT INTO `mes_station_report` VALUES (2107525803774279682, '000000', 'SINGLE', 'SN-FC-SCGD202610060002-5604-0001', 'STN|CJ012|GZZ0046|ASM|GENERAL', 2107524224165838850, 2107524224207781889, 2107352232221392898, 'SCGD202610060002', 106, 'SCZX20251222018', '李芳华', 'PASS', NULL, 1.0000, 0.0000, 1791308282052, 'SINGLE|SN-FC-SCGD202610060002-5604-0001|STN|CJ012|GZZ0046|ASM|GENERAL|1791308282052', 103, 1, '2026-10-07 01:38:02', 1, '2026-10-07 01:38:02', '0', '990bac02008395258192c16357db67c4d9d5feb7c483ad2df9f17ed076095c41');
INSERT INTO `mes_station_report` VALUES (2107525804365676545, '000000', 'SINGLE', 'SN-FC-SCGD202610060002-5604-0002', 'STN|CJ012|GZZ0046|ASM|GENERAL', 2107524224165838850, 2107524224207781889, 2107352232221392898, 'SCGD202610060002', 106, 'SCZX20251222018', '李芳华', 'PASS', NULL, 1.0000, 0.0000, 1791308282053, 'SINGLE|SN-FC-SCGD202610060002-5604-0002|STN|CJ012|GZZ0046|ASM|GENERAL|1791308282053', 103, 1, '2026-10-07 01:38:02', 1, '2026-10-07 01:38:02', '0', 'aee0ac16be6166174b8944feb86b7cc989f785f7f6243f537035f7ec43970157');
INSERT INTO `mes_station_report` VALUES (2107525804529254401, '000000', 'SINGLE', 'SN-FC-SCGD202610060002-5604-0003', 'STN|CJ012|GZZ0046|ASM|GENERAL', 2107524224165838850, 2107524224207781889, 2107352232221392898, 'SCGD202610060002', 106, 'SCZX20251222018', '李芳华', 'PASS', NULL, 1.0000, 0.0000, 1791308282054, 'SINGLE|SN-FC-SCGD202610060002-5604-0003|STN|CJ012|GZZ0046|ASM|GENERAL|1791308282054', 103, 1, '2026-10-07 01:38:02', 1, '2026-10-07 01:38:02', '0', '17f3cc2bfe0e85f7c376ff2e01e2e1e4c2c7c7ac4d0831edc4887458efe83dc4');
INSERT INTO `mes_station_report` VALUES (2107525804743163905, '000000', 'SINGLE', 'SN-FC-SCGD202610060002-5604-0004', 'STN|CJ012|GZZ0046|ASM|GENERAL', 2107524224165838850, 2107524224207781889, 2107352232221392898, 'SCGD202610060002', 106, 'SCZX20251222018', '李芳华', 'PASS', NULL, 1.0000, 0.0000, 1791308282055, 'SINGLE|SN-FC-SCGD202610060002-5604-0004|STN|CJ012|GZZ0046|ASM|GENERAL|1791308282055', 103, 1, '2026-10-07 01:38:02', 1, '2026-10-07 01:38:02', '0', 'c6087de105c3515c8956e91e683374c82a060fd4ba484d4671a76c33547fd211');
INSERT INTO `mes_station_report` VALUES (2107525804936101889, '000000', 'SINGLE', 'SN-FC-SCGD202610060002-5604-0005', 'STN|CJ012|GZZ0046|ASM|GENERAL', 2107524224165838850, 2107524224207781889, 2107352232221392898, 'SCGD202610060002', 106, 'SCZX20251222018', '李芳华', 'PASS', NULL, 1.0000, 0.0000, 1791308282056, 'SINGLE|SN-FC-SCGD202610060002-5604-0005|STN|CJ012|GZZ0046|ASM|GENERAL|1791308282056', 103, 1, '2026-10-07 01:38:02', 1, '2026-10-07 01:38:02', '0', '71778743cd2fed10fdb2f52e2432310a9189bd82316ed6e9e4c22c50b008db35');
INSERT INTO `mes_station_report` VALUES (2107525805196148737, '000000', 'SINGLE', 'SN-FC-SCGD202610060002-5604-0006', 'STN|CJ012|GZZ0046|ASM|GENERAL', 2107524224165838850, 2107524224207781889, 2107352232221392898, 'SCGD202610060002', 106, 'SCZX20251222018', '李芳华', 'PASS', NULL, 1.0000, 0.0000, 1791308282057, 'SINGLE|SN-FC-SCGD202610060002-5604-0006|STN|CJ012|GZZ0046|ASM|GENERAL|1791308282057', 103, 1, '2026-10-07 01:38:03', 1, '2026-10-07 01:38:03', '0', '26238b34c2e1ebfe9d0f98106c2e9329b1d82e3d83c8522842cdc07a73fe33e8');
INSERT INTO `mes_station_report` VALUES (2107525805418446850, '000000', 'SINGLE', 'SN-FC-SCGD202610060002-5604-0001', 'STN|CJ013|GZZ0052|QC|GENERAL', 2107524224165838850, 2107524224237142018, 2107352232221392898, 'SCGD202610060002', 105, 'SCZX20251222017', '张明', 'PASS', NULL, 1.0000, 0.0000, 1791308282152, 'SINGLE|SN-FC-SCGD202610060002-5604-0001|STN|CJ013|GZZ0052|QC|GENERAL|1791308282152', 103, 1, '2026-10-07 01:38:03', 1, '2026-10-07 01:38:03', '0', '4a26a259a54cb106ff2e9e6d2625f8bbbd9f0fae962d6971b459768ccd617230');
INSERT INTO `mes_station_report` VALUES (2107525805657522177, '000000', 'SINGLE', 'SN-FC-SCGD202610060002-5604-0002', 'STN|CJ013|GZZ0052|QC|GENERAL', 2107524224165838850, 2107524224237142018, 2107352232221392898, 'SCGD202610060002', 105, 'SCZX20251222017', '张明', 'PASS', NULL, 1.0000, 0.0000, 1791308282153, 'SINGLE|SN-FC-SCGD202610060002-5604-0002|STN|CJ013|GZZ0052|QC|GENERAL|1791308282153', 103, 1, '2026-10-07 01:38:03', 1, '2026-10-07 01:38:03', '0', 'a4d76c3c640fb22f07ad6a58d5d65117aa7947b6f79397dd58efd5233580d54d');
INSERT INTO `mes_station_report` VALUES (2107525805921763330, '000000', 'SINGLE', 'SN-FC-SCGD202610060002-5604-0003', 'STN|CJ013|GZZ0052|QC|GENERAL', 2107524224165838850, 2107524224237142018, 2107352232221392898, 'SCGD202610060002', 105, 'SCZX20251222017', '张明', 'PASS', NULL, 1.0000, 0.0000, 1791308282154, 'SINGLE|SN-FC-SCGD202610060002-5604-0003|STN|CJ013|GZZ0052|QC|GENERAL|1791308282154', 103, 1, '2026-10-07 01:38:03', 1, '2026-10-07 01:38:03', '0', '7121a01f8fc2be9a5d52decc13d09b04d3a49281a8748fe77709ef26d9f7d441');
INSERT INTO `mes_station_report` VALUES (2107525806093729794, '000000', 'SINGLE', 'SN-FC-SCGD202610060002-5604-0004', 'STN|CJ013|GZZ0052|QC|GENERAL', 2107524224165838850, 2107524224237142018, 2107352232221392898, 'SCGD202610060002', 105, 'SCZX20251222017', '张明', 'PASS', NULL, 1.0000, 0.0000, 1791308282155, 'SINGLE|SN-FC-SCGD202610060002-5604-0004|STN|CJ013|GZZ0052|QC|GENERAL|1791308282155', 103, 1, '2026-10-07 01:38:03', 1, '2026-10-07 01:38:03', '0', 'cca2c380951a06663ca4e1c57c350dd34e52bda3691786a5bf3f45a5020bffec');
INSERT INTO `mes_station_report` VALUES (2107525806248919042, '000000', 'SINGLE', 'SN-FC-SCGD202610060002-5604-0005', 'STN|CJ013|GZZ0052|QC|GENERAL', 2107524224165838850, 2107524224237142018, 2107352232221392898, 'SCGD202610060002', 105, 'SCZX20251222017', '张明', 'PASS', NULL, 1.0000, 0.0000, 1791308282156, 'SINGLE|SN-FC-SCGD202610060002-5604-0005|STN|CJ013|GZZ0052|QC|GENERAL|1791308282156', 103, 1, '2026-10-07 01:38:03', 1, '2026-10-07 01:38:03', '0', '592fa140c840acf4abe9a03ae006c4e6a0e7fcd04d091eb727c4198c2c0209b6');
INSERT INTO `mes_station_report` VALUES (2107526721894842369, '000000', 'SINGLE', 'SN-FC-SCGD202610060002-5604-0006', 'STN|CJ013|GZZ0052|QC|GENERAL', 2107524224165838850, 2107524224237142018, 2107352232221392898, 'SCGD202610060002', 105, 'SCZX20251222017', '张明', 'PASS', NULL, 1.0000, 0.0000, 1791308282157, 'SINGLE|SN-FC-SCGD202610060002-5604-0006|STN|CJ013|GZZ0052|QC|GENERAL|1791308282157', 103, 1, '2026-10-07 01:41:41', 1, '2026-10-07 01:41:41', '0', '876e185d243293ae68b6ae359199a29fbdff02117ca5ee4f168bc268e5e8cfe6');

-- ----------------------------
-- Table structure for mes_test_item
-- ----------------------------
DROP TABLE IF EXISTS `mes_test_item`;
CREATE TABLE `mes_test_item`  (
  `test_item_id` bigint(20) NOT NULL COMMENT '测试项ID',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '000000' COMMENT '租户ID',
  `item_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '测试项编码(如 RF-TXPWR)',
  `item_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '测试项名称',
  `material_id` bigint(20) NOT NULL COMMENT '适用物料ID',
  `content_ref_id` bigint(20) NOT NULL DEFAULT 0 COMMENT '内容源ID(0=该物料所有版本通用, 固件类=mes_firmware_id)',
  `data_type` varchar(8) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NUMERIC' COMMENT '数据类型: NUMERIC/TEXT/ENUM',
  `unit` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '单位',
  `upper_limit` decimal(18, 4) NULL DEFAULT NULL COMMENT '上限',
  `lower_limit` decimal(18, 4) NULL DEFAULT NULL COMMENT '下限',
  `target_value` decimal(18, 4) NULL DEFAULT NULL COMMENT '目标值',
  `pass_enum` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT 'ENUM合格值(JSON数组)',
  `is_required` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1' COMMENT '是否必测(0否/1是)',
  `sort_order` int(11) NOT NULL DEFAULT 0 COMMENT '排序',
  `create_dept` bigint(20) NULL DEFAULT NULL COMMENT '创建部门',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建人',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新人',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0' COMMENT '删除标志(0存在/2删除)',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`test_item_id`) USING BTREE,
  UNIQUE INDEX `uk_tenant_material_item`(`tenant_id`, `material_id`, `content_ref_id`, `item_code`) USING BTREE,
  INDEX `idx_tenant_id`(`tenant_id`) USING BTREE,
  INDEX `idx_material`(`material_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '测试项标准主数据' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of mes_test_item
-- ----------------------------
INSERT INTO `mes_test_item` VALUES (1, '000000', 'TI20260914001', '双层 PCB 板出厂测试项', 13, 0, 'NUMBER', NULL, NULL, NULL, NULL, NULL, '1', 1, 103, 1, '2026-09-14 15:07:27', NULL, '2026-09-14 15:07:27', '0', NULL);
INSERT INTO `mes_test_item` VALUES (2, '000000', 'TI20260914002', '智能路由器 WR-1200出厂测试项', 14, 0, 'NUMBER', NULL, NULL, NULL, NULL, NULL, '1', 2, 103, 1, '2026-09-14 15:07:27', NULL, '2026-09-14 15:07:27', '0', NULL);
INSERT INTO `mes_test_item` VALUES (3, '000000', 'TI20260914003', '变频电风扇出厂测试项', 15, 0, 'NUMBER', NULL, NULL, NULL, NULL, NULL, '1', 3, 103, 1, '2026-09-14 15:07:27', NULL, '2026-09-14 15:07:27', '0', NULL);
INSERT INTO `mes_test_item` VALUES (4, '000000', 'TI20260914004', '开关电源模组 SMPS-60出厂测试项', 16, 0, 'NUMBER', NULL, NULL, NULL, NULL, NULL, '1', 4, 103, 1, '2026-09-14 15:07:27', NULL, '2026-09-14 15:07:27', '0', NULL);
INSERT INTO `mes_test_item` VALUES (5, '000000', 'TI20260914005', '无刷直流电机 BLDC-45出厂测试项', 17, 0, 'NUMBER', NULL, NULL, NULL, NULL, NULL, '1', 5, 103, 1, '2026-09-14 15:07:27', NULL, '2026-09-14 15:07:27', '0', NULL);
INSERT INTO `mes_test_item` VALUES (6, '000000', 'TI20260914006', '温度传感器模组 TS-100出厂测试项', 18, 0, 'NUMBER', NULL, NULL, NULL, NULL, NULL, '1', 6, 103, 1, '2026-09-14 15:07:27', NULL, '2026-09-14 15:07:27', '0', NULL);
INSERT INTO `mes_test_item` VALUES (7, '000000', 'TI20260914007', '数字万用表 DM-800出厂测试项', 19, 0, 'NUMBER', NULL, NULL, NULL, NULL, NULL, '1', 7, 103, 1, '2026-09-14 15:07:27', NULL, '2026-09-14 15:07:27', '0', NULL);
INSERT INTO `mes_test_item` VALUES (8, '000000', 'TI20260914008', 'LED 护眼台灯出厂测试项', 26, 0, 'NUMBER', NULL, NULL, NULL, NULL, NULL, '1', 8, 103, 1, '2026-09-14 15:07:27', NULL, '2026-09-14 15:07:27', '0', NULL);
INSERT INTO `mes_test_item` VALUES (9, '000000', 'TI20260914009', '智能网关 GW-1000出厂测试项', 27, 0, 'NUMBER', NULL, NULL, NULL, NULL, NULL, '1', 9, 103, 1, '2026-09-14 15:07:27', NULL, '2026-09-14 15:07:27', '0', NULL);
INSERT INTO `mes_test_item` VALUES (10, '000000', 'TI20260914010', '锂电池包 48V20Ah出厂测试项', 30, 0, 'NUMBER', NULL, NULL, NULL, NULL, NULL, '1', 10, 103, 1, '2026-09-14 15:07:27', NULL, '2026-09-14 15:07:27', '0', NULL);
INSERT INTO `mes_test_item` VALUES (11, '000000', 'TI20260914011', '交流充电桩 AC-7kW出厂测试项', 31, 0, 'NUMBER', NULL, NULL, NULL, NULL, NULL, '1', 11, 103, 1, '2026-09-14 15:07:27', NULL, '2026-09-14 15:07:27', '0', NULL);
INSERT INTO `mes_test_item` VALUES (12, '000000', 'TI20260914012', '光伏组件 450W出厂测试项', 32, 0, 'NUMBER', NULL, NULL, NULL, NULL, NULL, '1', 12, 103, 1, '2026-09-14 15:07:27', NULL, '2026-09-14 15:07:27', '0', NULL);
INSERT INTO `mes_test_item` VALUES (13, '000000', 'TI20260914013', '六轴机械臂 RB-6出厂测试项', 33, 0, 'NUMBER', NULL, NULL, NULL, NULL, NULL, '1', 13, 103, 1, '2026-09-14 15:07:27', NULL, '2026-09-14 15:07:27', '0', NULL);
INSERT INTO `mes_test_item` VALUES (14, '000000', 'TI20260914014', '智能手环 BAND-3出厂测试项', 34, 0, 'NUMBER', NULL, NULL, NULL, NULL, NULL, '1', 14, 103, 1, '2026-09-14 15:07:27', NULL, '2026-09-14 15:07:27', '0', NULL);
INSERT INTO `mes_test_item` VALUES (15, '000000', 'TI20260914015', '手持 POS 机 POS-8出厂测试项', 35, 0, 'NUMBER', NULL, NULL, NULL, NULL, NULL, '1', 15, 103, 1, '2026-09-14 15:07:27', NULL, '2026-09-14 15:07:27', '0', NULL);
INSERT INTO `mes_test_item` VALUES (16, '000000', 'TI20260914016', '网络摄像机 IPC-300出厂测试项', 36, 0, 'NUMBER', NULL, NULL, NULL, NULL, NULL, '1', 16, 103, 1, '2026-09-14 15:07:27', NULL, '2026-09-14 15:07:27', '0', NULL);
INSERT INTO `mes_test_item` VALUES (17, '000000', 'TI20260914017', '无线蓝牙音箱 SPK-20出厂测试项', 37, 0, 'NUMBER', NULL, NULL, NULL, NULL, NULL, '1', 17, 103, 1, '2026-09-14 15:07:27', NULL, '2026-09-14 15:07:27', '0', NULL);

-- ----------------------------
-- Table structure for mes_test_record
-- ----------------------------
DROP TABLE IF EXISTS `mes_test_record`;
CREATE TABLE `mes_test_record`  (
  `test_record_id` bigint(20) NOT NULL COMMENT '测试记录ID',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '000000' COMMENT '租户ID',
  `test_no` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '测试单号(一次SN测试一条单号, 共享多行)',
  `sn_id` bigint(20) NOT NULL COMMENT 'SN ID',
  `sn_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'SN编码',
  `mes_wo_id` bigint(20) NOT NULL COMMENT 'MES工单ID',
  `wo_no` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '工单号',
  `card_id` bigint(20) NULL DEFAULT NULL COMMENT '流转卡ID',
  `step_record_id` bigint(20) NULL DEFAULT NULL COMMENT '流转卡工序记录ID(测试工序)',
  `process_id` bigint(20) NULL DEFAULT NULL COMMENT '工序ID',
  `process_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '工序编码',
  `process_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '工序名称',
  `content_ref_id` bigint(20) NULL DEFAULT NULL COMMENT '测试时内容源ID(固件类=mes_firmware_id)',
  `content_version` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '测试时内容版本',
  `test_item_id` bigint(20) NOT NULL COMMENT '测试项ID',
  `item_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '测试项编码(快照)',
  `item_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '测试项名称(快照)',
  `data_type` varchar(8) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '数据类型(快照)',
  `unit` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '单位',
  `numeric_value` decimal(18, 4) NULL DEFAULT NULL COMMENT '实测数值',
  `text_value` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '实测文本',
  `upper_limit` decimal(18, 4) NULL DEFAULT NULL COMMENT '上限(快照)',
  `lower_limit` decimal(18, 4) NULL DEFAULT NULL COMMENT '下限(快照)',
  `target_value` decimal(18, 4) NULL DEFAULT NULL COMMENT '目标值(快照)',
  `pass_enum` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT 'ENUM合格值(快照)',
  `result` varchar(8) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '结果: PASS/FAIL(空=未测)',
  `tester_id` bigint(20) NULL DEFAULT NULL COMMENT '测试人ID',
  `tester_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '测试人姓名',
  `equipment_id` bigint(20) NULL DEFAULT NULL COMMENT '测试设备ID',
  `equipment_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '测试设备编码',
  `test_time` datetime(0) NULL DEFAULT NULL COMMENT '测试时间',
  `test_mode` varchar(8) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'MANUAL' COMMENT '测试模式: AUTO/MANUAL',
  `create_dept` bigint(20) NULL DEFAULT NULL COMMENT '创建部门',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建人',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新人',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0' COMMENT '删除标志(0存在/2删除)',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`test_record_id`) USING BTREE,
  UNIQUE INDEX `uk_tenant_test_no_item`(`tenant_id`, `test_no`, `test_item_id`) USING BTREE,
  INDEX `idx_tenant_id`(`tenant_id`) USING BTREE,
  INDEX `idx_sn`(`sn_id`) USING BTREE,
  INDEX `idx_wo`(`mes_wo_id`) USING BTREE,
  INDEX `idx_content_ref`(`content_ref_id`) USING BTREE,
  INDEX `idx_sn_code`(`tenant_id`, `sn_code`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '测试记录(SN级全检)' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for mes_trace_inbox
-- ----------------------------
DROP TABLE IF EXISTS `mes_trace_inbox`;
CREATE TABLE `mes_trace_inbox`  (
  `event_id` varchar(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '跨库稳定事件ID',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '租户ID，必须由认证上下文提供',
  `source_module` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '事件源模块',
  `aggregate_type` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '来源业务聚合类型',
  `aggregate_id` bigint(20) NOT NULL COMMENT '来源业务聚合ID',
  `aggregate_version` bigint(20) NOT NULL COMMENT '同来源聚合单调版本',
  `event_type` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '事件类型',
  `schema_version` int(11) NOT NULL DEFAULT 1 COMMENT '消息契约版本',
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '原始冻结载荷JSON，禁止重试时重新计算',
  `content_hash` char(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '原始载荷UTF8字节SHA256',
  `status` varchar(24) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NEW' COMMENT 'NEW、WAITING、BROKER_SENT、APPLIED或CONFLICT状态',
  `attempts` int(11) NOT NULL DEFAULT 0 COMMENT '已尝试次数',
  `next_attempt_at` datetime(0) NULL DEFAULT NULL COMMENT '下次可重试时间，ACK重新激活时允许空值',
  `lease_owner` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL COMMENT '当前租约持有者',
  `lease_until` datetime(0) NULL DEFAULT NULL COMMENT '租约截止时间',
  `last_error` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT '脱敏后的最近错误',
  `result_payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT '幂等消费结果JSON',
  `created_at` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP(0) COMMENT '更新时间',
  `applied_at` datetime(0) NULL DEFAULT NULL COMMENT '成功应用时间',
  PRIMARY KEY (`event_id`) USING BTREE,
  UNIQUE INDEX `uk_trace_event_stream_version`(`tenant_id`, `source_module`, `aggregate_type`, `aggregate_id`, `aggregate_version`) USING BTREE,
  INDEX `idx_trace_event_retry`(`status`, `next_attempt_at`, `lease_until`) USING BTREE,
  INDEX `idx_trace_event_tenant`(`tenant_id`, `created_at`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '本数据源事务内冻结的追溯幂等收件箱' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for mes_trace_outbox
-- ----------------------------
DROP TABLE IF EXISTS `mes_trace_outbox`;
CREATE TABLE `mes_trace_outbox`  (
  `event_id` varchar(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '跨库稳定事件ID',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '租户ID，必须由认证上下文提供',
  `source_module` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '事件源模块',
  `aggregate_type` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '来源业务聚合类型',
  `aggregate_id` bigint(20) NOT NULL COMMENT '来源业务聚合ID',
  `aggregate_version` bigint(20) NOT NULL COMMENT '同来源聚合单调版本',
  `event_type` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '事件类型',
  `schema_version` int(11) NOT NULL DEFAULT 1 COMMENT '消息契约版本',
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '原始冻结载荷JSON，禁止重试时重新计算',
  `content_hash` char(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '原始载荷UTF8字节SHA256',
  `status` varchar(24) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NEW' COMMENT 'NEW、WAITING、BROKER_SENT、APPLIED或CONFLICT状态',
  `attempts` int(11) NOT NULL DEFAULT 0 COMMENT '已尝试次数',
  `next_attempt_at` datetime(0) NULL DEFAULT NULL COMMENT '下次可重试时间，ACK重新激活时允许空值',
  `lease_owner` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL COMMENT '当前租约持有者',
  `lease_until` datetime(0) NULL DEFAULT NULL COMMENT '租约截止时间',
  `last_error` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT '脱敏后的最近错误',
  `result_payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT '幂等消费结果JSON',
  `created_at` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP(0) COMMENT '更新时间',
  `applied_at` datetime(0) NULL DEFAULT NULL COMMENT '成功应用时间',
  PRIMARY KEY (`event_id`) USING BTREE,
  UNIQUE INDEX `uk_trace_event_stream_version`(`tenant_id`, `source_module`, `aggregate_type`, `aggregate_id`, `aggregate_version`) USING BTREE,
  INDEX `idx_trace_event_retry`(`status`, `next_attempt_at`, `lease_until`) USING BTREE,
  INDEX `idx_trace_event_tenant`(`tenant_id`, `created_at`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '本数据源事务内冻结的追溯发件箱' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for mes_trace_repair_item
-- ----------------------------
DROP TABLE IF EXISTS `mes_trace_repair_item`;
CREATE TABLE `mes_trace_repair_item`  (
  `run_id` varchar(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '修复运行ID',
  `item_id` varchar(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '计划内修复项ID',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '租户ID，必须由认证上下文提供',
  `target_table` varchar(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '白名单目标表',
  `target_key` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '包含租户的完整主键JSON',
  `before_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '修复前完整行JSON',
  `after_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '修复后完整行JSON',
  `evidence_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '冻结来源凭据及审核依据JSON',
  `before_hash` char(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '修复前规范行摘要，CAS比较依据',
  `after_hash` char(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '修复后规范行摘要',
  `evidence_hash` char(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '证据摘要',
  `status` varchar(24) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PLANNED' COMMENT '修复项状态',
  `version` bigint(20) NOT NULL DEFAULT 1 COMMENT '修复项CAS版本',
  `created_at` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP(0) COMMENT '更新时间',
  PRIMARY KEY (`run_id`, `item_id`) USING BTREE,
  INDEX `idx_trace_repair_target`(`tenant_id`, `target_table`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '历史修复前后镜像与证据，不覆盖原业务凭据' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for mes_trace_repair_run
-- ----------------------------
DROP TABLE IF EXISTS `mes_trace_repair_run`;
CREATE TABLE `mes_trace_repair_run`  (
  `run_id` varchar(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '修复运行ID',
  `target_database` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '显式核实的目标业务库',
  `target_environment` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '环境标识，不保存口令或连接串',
  `backup_reference` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '已核实的离线备份引用',
  `plan_hash` char(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '批准计划摘要',
  `before_snapshot_hash` char(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '完整修复前导出摘要',
  `after_snapshot_hash` char(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '离线预演结果摘要',
  `journal_hash` char(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '批准运行日志摘要',
  `status` varchar(24) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PLANNED' COMMENT 'PLANNED、APPLIED、REVERTED或待补偿',
  `version` bigint(20) NOT NULL DEFAULT 1 COMMENT '运行状态CAS版本',
  `created_at` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP(0) COMMENT '更新时间',
  PRIMARY KEY (`run_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '本数据源历史修复运行日志，跨库不伪装原子事务' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for ncr_8d_report
-- ----------------------------
DROP TABLE IF EXISTS `ncr_8d_report`;
CREATE TABLE `ncr_8d_report`  (
  `report_id` bigint(20) NOT NULL COMMENT '报告ID(主键)',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '000000' COMMENT '租户ID',
  `ncr_id` bigint(20) NOT NULL COMMENT '关联NCR ID',
  `d1_team` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT 'D1团队',
  `d2_problem` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT 'D2问题描述',
  `d3_interim` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT 'D3临时措施',
  `d4_root_cause` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT 'D4根因分析',
  `d5_permanent` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT 'D5永久措施',
  `d6_implement` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT 'D6措施实施与验证',
  `d7_prevent` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT 'D7预防措施',
  `d8_recognize` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT 'D8团队认可',
  `status` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT 'DRAFT' COMMENT 'DRAFT/IN_PROGRESS/COMPLETED',
  `completed_by` bigint(20) NULL DEFAULT NULL COMMENT '完成人',
  `completed_time` datetime(0) NULL DEFAULT NULL COMMENT '完成时间',
  `create_dept` bigint(20) NULL DEFAULT NULL COMMENT '创建部门',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT '0' COMMENT '删除标志(0正常 1删除)',
  PRIMARY KEY (`report_id`) USING BTREE,
  INDEX `idx_ncr_id`(`ncr_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '8D报告' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of ncr_8d_report
-- ----------------------------
INSERT INTO `ncr_8d_report` VALUES (2100406122517053441, '000000', 2100064131300126721, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DRAFT', NULL, NULL, 103, 1, '2026-09-17 10:06:58', 1, '2026-09-17 10:06:58', '0');
INSERT INTO `ncr_8d_report` VALUES (2100479900102098945, '000000', 2100479770728792065, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DRAFT', NULL, NULL, 103, 1, '2026-09-17 15:00:08', 1, '2026-09-17 15:00:08', '0');
INSERT INTO `ncr_8d_report` VALUES (2100495654260199425, '000000', 2100495565311594498, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DRAFT', NULL, NULL, 103, 1, '2026-09-17 16:02:44', 1, '2026-09-17 16:02:44', '0');

-- ----------------------------
-- Table structure for ncr_defect
-- ----------------------------
DROP TABLE IF EXISTS `ncr_defect`;
CREATE TABLE `ncr_defect`  (
  `defect_id` bigint(20) NOT NULL COMMENT '缺陷明细ID(主键)',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '000000' COMMENT '租户ID',
  `ncr_id` bigint(20) NOT NULL COMMENT 'NCR ID',
  `defect_code_id` bigint(20) NULL DEFAULT NULL COMMENT '缺陷代码ID(可空-自动建单时仅记defectCode字符串,REVIEW时关联正式代码库)',
  `defect_code` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '缺陷代码(冗余)',
  `defect_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '缺陷名称(冗余)',
  `defect_qty` decimal(14, 4) NOT NULL COMMENT '缺陷数量',
  `defect_cause` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '缺陷原因(MAN/MACHINE/MATERIAL/METHOD/ENVIRONMENT/MEASUREMENT)',
  `root_cause_desc` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '根因描述',
  `create_dept` bigint(20) NULL DEFAULT NULL COMMENT '创建部门',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT '0' COMMENT '删除标志(0正常 1删除)',
  PRIMARY KEY (`defect_id`) USING BTREE,
  INDEX `idx_ncr_id`(`ncr_id`) USING BTREE,
  INDEX `idx_defect_code_id`(`defect_code_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = 'NCR缺陷明细' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for ncr_defect_code
-- ----------------------------
DROP TABLE IF EXISTS `ncr_defect_code`;
CREATE TABLE `ncr_defect_code`  (
  `code_id` bigint(20) NOT NULL COMMENT '代码ID(主键)',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '000000' COMMENT '租户ID',
  `parent_id` bigint(20) NULL DEFAULT 0 COMMENT '父代码ID(层级,0=根)',
  `code` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '缺陷代码',
  `name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '缺陷名称',
  `level` int(4) NULL DEFAULT 1 COMMENT '层级(1类别/2子类/3代码)',
  `enabled` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT '1' COMMENT '是否启用(1/0)',
  `sort_order` int(4) NULL DEFAULT 0 COMMENT '排序',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '备注',
  `create_dept` bigint(20) NULL DEFAULT NULL COMMENT '创建部门',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT '0' COMMENT '删除标志(0正常 1删除)',
  PRIMARY KEY (`code_id`) USING BTREE,
  UNIQUE INDEX `uk_code`(`tenant_id`, `code`) USING BTREE,
  INDEX `idx_parent_id`(`parent_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '缺陷代码库' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of ncr_defect_code
-- ----------------------------
INSERT INTO `ncr_defect_code` VALUES (1, '000000', 0, 'DC01', '尺寸超差', 1, 'Y', 1, NULL, 103, 1, '2026-09-14 15:07:27', 1, '2026-09-22 11:09:27', '0');
INSERT INTO `ncr_defect_code` VALUES (2, '000000', 1, 'DC0101', '外径超上差', 2, '1', 101, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `ncr_defect_code` VALUES (3, '000000', 1, 'DC0102', '外径超下差', 2, '1', 102, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `ncr_defect_code` VALUES (4, '000000', 1, 'DC0103', '长度超差', 2, '1', 103, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `ncr_defect_code` VALUES (5, '000000', 1, 'DC0104', '同轴度超差', 2, '1', 104, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `ncr_defect_code` VALUES (6, '000000', 1, 'DC0105', '平面度超差', 2, '1', 105, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `ncr_defect_code` VALUES (7, '000000', 1, 'DC0106', '孔位偏移', 2, '1', 106, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `ncr_defect_code` VALUES (8, '000000', 0, 'DC02', '外观缺陷', 1, '1', 2, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `ncr_defect_code` VALUES (9, '000000', 8, 'DC0201', '划痕', 2, '1', 201, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `ncr_defect_code` VALUES (10, '000000', 8, 'DC0202', '碰伤', 2, '1', 202, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `ncr_defect_code` VALUES (11, '000000', 8, 'DC0203', '凹坑', 2, '1', 203, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `ncr_defect_code` VALUES (12, '000000', 8, 'DC0204', '毛刺未清', 2, '1', 204, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `ncr_defect_code` VALUES (13, '000000', 8, 'DC0205', '锈蚀', 2, '1', 205, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `ncr_defect_code` VALUES (14, '000000', 8, 'DC0206', '色差', 2, '1', 206, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `ncr_defect_code` VALUES (15, '000000', 8, 'DC0207', '流痕', 2, '1', 207, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `ncr_defect_code` VALUES (16, '000000', 8, 'DC0208', '缩水', 2, '1', 208, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `ncr_defect_code` VALUES (17, '000000', 0, 'DC03', '材料缺陷', 1, '1', 3, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `ncr_defect_code` VALUES (18, '000000', 17, 'DC0301', '材质不符', 2, '1', 301, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `ncr_defect_code` VALUES (19, '000000', 17, 'DC0302', '硬度不足', 2, '1', 302, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `ncr_defect_code` VALUES (20, '000000', 17, 'DC0303', '夹杂', 2, '1', 303, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `ncr_defect_code` VALUES (21, '000000', 17, 'DC0304', '气孔', 2, '1', 304, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `ncr_defect_code` VALUES (22, '000000', 17, 'DC0305', '裂纹', 2, '1', 305, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `ncr_defect_code` VALUES (23, '000000', 0, 'DC04', '焊接缺陷', 1, '1', 4, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `ncr_defect_code` VALUES (24, '000000', 23, 'DC0401', '未焊透', 2, '1', 401, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `ncr_defect_code` VALUES (25, '000000', 23, 'DC0402', '咬边', 2, '1', 402, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `ncr_defect_code` VALUES (26, '000000', 23, 'DC0403', '气孔', 2, '1', 403, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `ncr_defect_code` VALUES (27, '000000', 23, 'DC0404', '焊瘤', 2, '1', 404, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `ncr_defect_code` VALUES (28, '000000', 23, 'DC0405', '焊缝偏移', 2, '1', 405, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `ncr_defect_code` VALUES (29, '000000', 0, 'DC05', '电镀涂装缺陷', 1, '1', 5, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `ncr_defect_code` VALUES (30, '000000', 29, 'DC0501', '镀层起泡', 2, '1', 501, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `ncr_defect_code` VALUES (31, '000000', 29, 'DC0502', '镀层脱落', 2, '1', 502, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `ncr_defect_code` VALUES (32, '000000', 29, 'DC0503', '镀层厚度不足', 2, '1', 503, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `ncr_defect_code` VALUES (33, '000000', 29, 'DC0504', '喷涂流挂', 2, '1', 504, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `ncr_defect_code` VALUES (34, '000000', 29, 'DC0505', '喷涂漏底', 2, '1', 505, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `ncr_defect_code` VALUES (35, '000000', 29, 'DC0506', '附着力不足', 2, '1', 506, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `ncr_defect_code` VALUES (36, '000000', 0, 'DC06', '注塑缺陷', 1, '1', 6, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `ncr_defect_code` VALUES (37, '000000', 36, 'DC0601', '欠注', 2, '1', 601, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `ncr_defect_code` VALUES (38, '000000', 36, 'DC0602', '飞边', 2, '1', 602, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `ncr_defect_code` VALUES (39, '000000', 36, 'DC0603', '熔接痕', 2, '1', 603, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `ncr_defect_code` VALUES (40, '000000', 36, 'DC0604', '银纹', 2, '1', 604, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `ncr_defect_code` VALUES (41, '000000', 36, 'DC0605', '变形', 2, '1', 605, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `ncr_defect_code` VALUES (42, '000000', 0, 'DC07', '电子功能缺陷', 1, '1', 7, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `ncr_defect_code` VALUES (43, '000000', 42, 'DC0701', '不开机', 2, '1', 701, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `ncr_defect_code` VALUES (44, '000000', 42, 'DC0702', '功能失效', 2, '1', 702, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `ncr_defect_code` VALUES (45, '000000', 42, 'DC0703', '通信异常', 2, '1', 703, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `ncr_defect_code` VALUES (46, '000000', 42, 'DC0704', '参数漂移', 2, '1', 704, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `ncr_defect_code` VALUES (47, '000000', 42, 'DC0705', '短路', 2, '1', 705, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `ncr_defect_code` VALUES (48, '000000', 42, 'DC0706', '虚焊', 2, '1', 706, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `ncr_defect_code` VALUES (49, '000000', 42, 'DC0707', '固件版本错误', 2, '1', 707, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `ncr_defect_code` VALUES (50, '000000', 0, 'DC08', '装配缺陷', 1, '1', 8, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `ncr_defect_code` VALUES (51, '000000', 50, 'DC0801', '漏装', 2, '1', 801, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `ncr_defect_code` VALUES (52, '000000', 50, 'DC0802', '错装', 2, '1', 802, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `ncr_defect_code` VALUES (53, '000000', 50, 'DC0803', '装配不到位', 2, '1', 803, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `ncr_defect_code` VALUES (54, '000000', 50, 'DC0804', '扭矩不足', 2, '1', 804, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `ncr_defect_code` VALUES (55, '000000', 50, 'DC0805', '间隙超差', 2, '1', 805, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `ncr_defect_code` VALUES (56, '000000', 0, 'DC09', '包装标识缺陷', 1, '1', 9, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `ncr_defect_code` VALUES (57, '000000', 56, 'DC0901', '标签错误', 2, '1', 901, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `ncr_defect_code` VALUES (58, '000000', 56, 'DC0902', '包装破损', 2, '1', 902, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `ncr_defect_code` VALUES (59, '000000', 56, 'DC0903', '缺少附件', 2, '1', 903, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `ncr_defect_code` VALUES (60, '000000', 56, 'DC0904', '说明书缺失', 2, '1', 904, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `ncr_defect_code` VALUES (61, '000000', 56, 'DC0905', '条码无法识别', 2, '1', 905, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');

-- ----------------------------
-- Table structure for ncr_order
-- ----------------------------
DROP TABLE IF EXISTS `ncr_order`;
CREATE TABLE `ncr_order`  (
  `ncr_id` bigint(20) NOT NULL COMMENT 'NCR ID(主键)',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '000000' COMMENT '租户ID',
  `ncr_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'NCR编号',
  `source_type` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '来源类型(IQC/IPQC/OQC/PROCESS/CUSTOMER)',
  `source_id` bigint(20) NULL DEFAULT NULL COMMENT '来源单据ID(iqc_id/ipqc_id/oqc_id/step_record_id)',
  `wo_id` bigint(20) NULL DEFAULT NULL COMMENT '关联工单ID',
  `wo_no` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '工单编号(冗余)',
  `card_id` bigint(20) NULL DEFAULT NULL COMMENT '流转卡ID(PROCESS来源)',
  `step_record_id` bigint(20) NULL DEFAULT NULL COMMENT '工序记录ID(PROCESS来源)',
  `process_id` bigint(20) NULL DEFAULT NULL COMMENT '工序ID(IPQC/PROCESS来源)',
  `process_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '工序名称(冗余)',
  `material_id` bigint(20) NULL DEFAULT NULL COMMENT '物料ID',
  `material_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '物料编码(冗余)',
  `material_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '物料名称(冗余)',
  `lot_id` bigint(20) NULL DEFAULT NULL COMMENT '关联批次ID(隔离用)',
  `lot_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '批次编码(冗余)',
  `defect_qty` decimal(14, 4) NOT NULL COMMENT '不良数量',
  `disposition` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '处置(REWORK/SCRAP/ACCEPT_AS_IS/RETURN)',
  `status` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT 'OPEN' COMMENT 'OPEN/REVIEW/DISPOSITION/IN_REWORK/CLOSED',
  `review_by` bigint(20) NULL DEFAULT NULL COMMENT '评审人',
  `review_time` datetime(0) NULL DEFAULT NULL COMMENT '评审时间',
  `disposition_by` bigint(20) NULL DEFAULT NULL COMMENT '处置人',
  `disposition_time` datetime(0) NULL DEFAULT NULL COMMENT '处置时间',
  `disposition_signature_id` bigint(20) NULL DEFAULT NULL COMMENT '处置签名ID(P0-6预留)',
  `created_time` datetime(0) NOT NULL COMMENT '创建时间',
  `closed_time` datetime(0) NULL DEFAULT NULL COMMENT '关闭时间',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '备注',
  `create_dept` bigint(20) NULL DEFAULT NULL COMMENT '创建部门',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT '0' COMMENT '删除标志(0正常 1删除)',
  PRIMARY KEY (`ncr_id`) USING BTREE,
  UNIQUE INDEX `uk_ncr_code`(`tenant_id`, `ncr_code`) USING BTREE,
  UNIQUE INDEX `uk_source`(`tenant_id`, `source_type`, `source_id`) USING BTREE,
  INDEX `idx_wo_id`(`wo_id`) USING BTREE,
  INDEX `idx_status`(`status`) USING BTREE,
  INDEX `idx_lot_id`(`lot_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = 'NCR不合格品单' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of ncr_order
-- ----------------------------
INSERT INTO `ncr_order` VALUES (2100064131300126721, '000000', 'NCR20260916001', 'CUSTOMER', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'E2E-SIGN-001', 'E2E签署验证物料1', NULL, NULL, 5.0000, 'SCRAP', 'CLOSED', NULL, NULL, 1, '2026-09-16 11:31:41', 2100065055972237313, '2026-09-16 11:28:01', '2026-09-16 11:31:41', '签署控制 E2E', 103, 1, '2026-09-16 11:28:01', 1, '2026-09-16 11:28:01', '0');
INSERT INTO `ncr_order` VALUES (2100064131790860290, '000000', 'NCR20260916002', 'CUSTOMER', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'E2E-SIGN-002', 'E2E签署验证物料2', NULL, NULL, 5.0000, 'RETURN', 'CLOSED', NULL, NULL, 1, '2026-09-16 11:31:59', NULL, '2026-09-16 11:28:01', '2026-09-16 11:31:59', '未签署路径回归', 103, 1, '2026-09-16 11:28:01', 1, '2026-09-16 11:28:01', '0');
INSERT INTO `ncr_order` VALUES (2100479770728792065, '000000', 'NCR20260917001', 'CUSTOMER', NULL, NULL, '', NULL, NULL, NULL, NULL, 2, 'IF20260914002', '精密齿轮箱总成', NULL, NULL, 1.0000, 'SCRAP', 'CLOSED', 1, '2026-09-17 14:59:48', 1, '2026-09-17 15:00:04', NULL, '2026-09-17 14:59:37', '2026-09-17 15:00:04', '测试', 103, 1, '2026-09-17 14:59:37', 1, '2026-09-17 14:59:37', '0');
INSERT INTO `ncr_order` VALUES (2100495565311594498, '000000', 'NCR20260917002', 'CUSTOMER', NULL, NULL, '', NULL, NULL, NULL, NULL, 4, 'IF20260914004', '设备钣金机箱', NULL, NULL, 1.0000, 'SCRAP', 'CLOSED', 1, '2026-09-17 16:02:32', 1, '2026-09-17 16:03:13', 2100495775400087553, '2026-09-17 16:02:23', '2026-09-17 16:03:13', '测试', 103, 1, '2026-09-17 16:02:23', 1, '2026-09-17 16:02:23', '0');

-- ----------------------------
-- Table structure for ncr_rework_order
-- ----------------------------
DROP TABLE IF EXISTS `ncr_rework_order`;
CREATE TABLE `ncr_rework_order`  (
  `rework_id` bigint(20) NOT NULL COMMENT '返工记录ID(主键)',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '000000' COMMENT '租户ID',
  `rework_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '返工工单编号',
  `ncr_id` bigint(20) NOT NULL COMMENT '关联NCR ID',
  `original_wo_id` bigint(20) NOT NULL COMMENT '原工单ID',
  `original_wo_no` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '原工单编号(冗余)',
  `rework_wo_id` bigint(20) NOT NULL COMMENT '生成的返工工单ID(pro_work_order.mes_wo_id)',
  `rework_wo_no` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '返工工单编号(冗余)',
  `rework_qty` decimal(14, 4) NOT NULL COMMENT '返工数量',
  `rework_reason` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '返工原因',
  `status` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT 'OPEN' COMMENT 'OPEN/IN_PROGRESS/COMPLETED',
  `create_dept` bigint(20) NULL DEFAULT NULL COMMENT '创建部门',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT '0' COMMENT '删除标志(0正常 1删除)',
  PRIMARY KEY (`rework_id`) USING BTREE,
  UNIQUE INDEX `uk_rework_code`(`tenant_id`, `rework_code`) USING BTREE,
  INDEX `idx_ncr_id`(`ncr_id`) USING BTREE,
  INDEX `idx_rework_wo_id`(`rework_wo_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = 'NCR返工工单' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for pro_andon
-- ----------------------------
DROP TABLE IF EXISTS `pro_andon`;
CREATE TABLE `pro_andon`  (
  `andon_id` bigint(20) NOT NULL COMMENT '安灯ID(主键)',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '000000',
  `andon_no` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '安灯编号',
  `mes_wo_id` bigint(20) NULL DEFAULT NULL COMMENT '关联MES工单ID',
  `wo_no` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '工单编号(冗余)',
  `card_id` bigint(20) NULL DEFAULT NULL COMMENT '关联流转卡ID',
  `card_no` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '流转卡编号(冗余)',
  `step_record_id` bigint(20) NULL DEFAULT NULL COMMENT '关联流转卡工序记录ID',
  `station_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '工位编码(设备通道呼叫)',
  `call_type` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '呼叫类型: QUALITY/MATERIAL/EQUIPMENT/OTHER',
  `call_reason` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '呼叫原因',
  `andon_status` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT 'CALLED' COMMENT 'CALLED/RESPONDED/RESOLVED/CANCELLED',
  `caller_id` bigint(20) NULL DEFAULT NULL COMMENT '呼叫人ID',
  `caller_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '呼叫人姓名',
  `responder_id` bigint(20) NULL DEFAULT NULL COMMENT '响应人ID',
  `responder_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '响应人姓名',
  `call_time` datetime(0) NULL DEFAULT NULL COMMENT '呼叫时间',
  `respond_time` datetime(0) NULL DEFAULT NULL COMMENT '响应时间',
  `resolve_time` datetime(0) NULL DEFAULT NULL COMMENT '解决时间',
  `duration_minutes` int(11) NULL DEFAULT NULL COMMENT '持续时长(分钟, 解决时计算)',
  `source` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT 'MANUAL' COMMENT 'MANUAL/IoT(来源)',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `notify_user_ids` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '呼叫通知被通知人ID(逗号分隔)',
  `notify_time` datetime(0) NULL DEFAULT NULL COMMENT '呼叫通知落库时间(非空=呼叫通知已发出,幂等依据)',
  `create_dept` bigint(20) NULL DEFAULT NULL,
  `create_by` bigint(20) NULL DEFAULT NULL,
  `create_time` datetime(0) NULL DEFAULT NULL,
  `update_by` bigint(20) NULL DEFAULT NULL,
  `update_time` datetime(0) NULL DEFAULT NULL,
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT '0',
  PRIMARY KEY (`andon_id`) USING BTREE,
  UNIQUE INDEX `uk_andon_no`(`tenant_id`, `andon_no`) USING BTREE,
  INDEX `idx_andon_status`(`andon_status`) USING BTREE,
  INDEX `idx_call_type`(`call_type`) USING BTREE,
  INDEX `idx_mes_wo_id`(`mes_wo_id`) USING BTREE,
  INDEX `idx_card_id`(`card_id`) USING BTREE,
  INDEX `idx_station_code`(`station_code`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = 'MES安灯呼叫' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of pro_andon
-- ----------------------------
INSERT INTO `pro_andon` VALUES (2104774462089936897, '000000', 'AND-20260929-1236', NULL, NULL, NULL, NULL, NULL, NULL, 'EQUIPMENT', 'IoT设备告警[TEMPERATURE]: 设备 DEV0025 属性 temperature 越限：当前 187.2 > 阈值 80.0000（规则：温度超上限(全局默认)） (值=187.2, 阈值=80.0000)', 'RESOLVED', NULL, NULL, 1, 'admin', '2026-09-29 11:25:11', '2026-09-29 13:23:39', '2026-09-29 13:23:39', 118, 'MANUAL', '复核DEV0025已入库温度187.3℃及产品规则8701（220℃）；规则7001错误低优先级匹配造成误报，现按人工关闭留痕；187.3℃高于80℃，不作为规则7001自动恢复证据。', '1', '2026-09-29 11:25:11', -1, -1, '2026-09-29 11:25:11', -1, '2026-09-29 11:25:11', '0');
INSERT INTO `pro_andon` VALUES (2104804656011997186, '000000', 'AND-20260929-0028', NULL, NULL, NULL, NULL, NULL, NULL, 'EQUIPMENT', 'IoT设备告警[TEMPERATURE]: 设备 DEV0025 属性 temperature 越限：当前 224.8 > 阈值 220.0000（规则：注塑机料筒温度超上限） (值=224.8, 阈值=220.0000)', 'RESOLVED', NULL, NULL, 1, 'admin', '2026-09-29 13:25:10', '2026-09-29 13:28:17', '2026-09-29 13:28:17', 3, 'MANUAL', '设备DEV0025产品规则8701超温告警已自动恢复，入库恢复温度187.24℃；确认阈值220℃，按联动通知记录复核后关闭安灯。现有来源显示MANUAL为已记录待修复缺陷，不改写历史来源。', '1', '2026-09-29 13:25:10', -1, -1, '2026-09-29 13:25:10', -1, '2026-09-29 13:25:10', '0');
INSERT INTO `pro_andon` VALUES (2104823418433994754, '000000', 'AND-20260929-3338', NULL, NULL, NULL, NULL, NULL, NULL, 'EQUIPMENT', 'IoT设备告警[TEMPERATURE] (deviceCode=DEV0025, deviceId=2104512194450214913): 设备 DEV0025 属性 temperature 越限：当前 224.8 > 阈值 220.0000（规则：注塑机料筒温度超上限） (值=224.8, 阈值=220.0000)', 'RESOLVED', NULL, NULL, 1, 'admin', '2026-09-29 14:39:43', '2026-09-29 14:41:58', '2026-09-29 14:41:58', 2, 'IoT', '设备DEV0025产品规则8701超温已由入库恢复值187.23℃自动恢复；经同源通知记录确认IoT安灯，复核关闭。', '1', '2026-09-29 14:39:43', -1, -1, '2026-09-29 14:39:43', -1, '2026-09-29 14:39:43', '0');
INSERT INTO `pro_andon` VALUES (2105517750573047810, '000000', 'AND-20261001-5021', NULL, NULL, NULL, NULL, NULL, NULL, 'EQUIPMENT', 'IoT设备告警[TEMPERATURE] (deviceCode=DEV0025, deviceId=2104512194450214913, mesEquipmentId=1): 设备 DEV0025 属性 temperature 越限：当前 224.8 > 阈值 220.0000（规则：注塑机料筒温度超上限） (值=224.8, 阈值=220.0000)', 'RESOLVED', NULL, NULL, 1, 'admin', '2026-10-01 12:38:45', '2026-10-01 12:40:20', '2026-10-01 12:40:20', 1, 'IoT', '设备温度恢复正常，已核对同源IoT告警与通知记录后关闭安灯。', '1', '2026-10-01 12:38:45', -1, -1, '2026-10-01 12:38:45', -1, '2026-10-01 12:38:45', '0');

-- ----------------------------
-- Table structure for pro_completion_manifest
-- ----------------------------
DROP TABLE IF EXISTS `pro_completion_manifest`;
CREATE TABLE `pro_completion_manifest`  (
  `manifest_id` bigint(20) NOT NULL COMMENT '最终交付清单ID',
  `revision` int(11) NOT NULL DEFAULT 1 COMMENT '冻结修订号',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '租户ID，必须由认证上下文提供',
  `mes_wo_id` bigint(20) NOT NULL COMMENT 'MES工单ID',
  `erp_wo_id` bigint(20) NULL DEFAULT NULL COMMENT 'ERP工单ID',
  `material_id` bigint(20) NOT NULL COMMENT '成品物料ID',
  `line_count` bigint(20) NOT NULL COMMENT '冻结清单行数',
  `good_qty` decimal(18, 4) NOT NULL COMMENT '合格基本单位数量',
  `scrap_qty` decimal(18, 4) NOT NULL DEFAULT 0.0000 COMMENT '报废基本单位数量',
  `content_hash` char(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '冻结清单规范内容SHA256',
  `material_line_count` bigint(20) NULL DEFAULT NULL COMMENT '实际用料分配行数，旧清单未知保持NULL',
  `material_hash` char(64) CHARACTER SET ascii COLLATE ascii_bin NULL DEFAULT NULL COMMENT '实际用料分配规范内容SHA256，旧清单不回填',
  `status` varchar(24) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'FROZEN' COMMENT '冻结交付状态',
  `created_at` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`manifest_id`) USING BTREE,
  UNIQUE INDEX `uk_completion_manifest_revision`(`tenant_id`, `mes_wo_id`, `revision`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '最终工单一次交付的不可变修订清单' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for pro_completion_manifest_line
-- ----------------------------
DROP TABLE IF EXISTS `pro_completion_manifest_line`;
CREATE TABLE `pro_completion_manifest_line`  (
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '租户ID，必须由认证上下文提供',
  `manifest_id` bigint(20) NOT NULL COMMENT '冻结清单ID',
  `revision` int(11) NOT NULL COMMENT '冻结修订号',
  `line_no` bigint(20) NOT NULL COMMENT '稳定清单行号',
  `identity_id` bigint(20) NULL DEFAULT NULL COMMENT 'ERP正式实物身份，非SN行可空',
  `local_sn_id` bigint(20) NULL DEFAULT NULL COMMENT 'MES本地SN主键',
  `sn_code` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '冻结正式SN原码',
  `batch_id` bigint(20) NULL DEFAULT NULL COMMENT 'ERP批次ID',
  `local_lot_id` bigint(20) NULL DEFAULT NULL COMMENT 'MES本地批次ID',
  `material_id` bigint(20) NOT NULL COMMENT '物料ID',
  `quantity` decimal(18, 4) NOT NULL COMMENT '基本单位数量，SN行一件',
  `result` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '质量结果GOOD或SCRAP',
  `source_version` bigint(20) NOT NULL COMMENT '冻结时来源身份或批次版本',
  PRIMARY KEY (`tenant_id`, `manifest_id`, `revision`, `line_no`) USING BTREE,
  UNIQUE INDEX `uk_manifest_identity`(`tenant_id`, `manifest_id`, `revision`, `identity_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '公共CompletionManifestLine逐字段映射' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for pro_completion_material_allocation
-- ----------------------------
DROP TABLE IF EXISTS `pro_completion_material_allocation`;
CREATE TABLE `pro_completion_material_allocation`  (
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '租户ID，必须由认证上下文提供',
  `manifest_id` bigint(20) NOT NULL COMMENT '冻结完工清单ID',
  `revision` int(11) NOT NULL COMMENT '冻结清单修订',
  `allocation_id` bigint(20) NOT NULL COMMENT '原实际消耗lt_wo_consumption.consumption_id，不是额度分配ID',
  `material_id` bigint(20) NOT NULL COMMENT '实际组件物料ID',
  `reservation_id` bigint(20) NULL DEFAULT NULL COMMENT 'ERP实际库存预留头',
  `reservation_line_id` bigint(20) NULL DEFAULT NULL COMMENT 'ERP实际库存预留行',
  `posting_group_id` bigint(20) NULL DEFAULT NULL COMMENT '已发料ERP原过账证明组',
  `identity_id` bigint(20) NULL DEFAULT NULL COMMENT 'ERP正式组件身份',
  `source_stock_id` bigint(20) NULL DEFAULT NULL COMMENT 'ERP实际来源库存ID',
  `erp_batch_id` bigint(20) NULL DEFAULT NULL COMMENT 'ERP批次ID，SN-only来源允许空值',
  `quantity` decimal(18, 4) NOT NULL COMMENT '实际消耗基本单位数量',
  `source_version` bigint(20) NOT NULL COMMENT '冻结时实际分配来源版本',
  `evidence_hash` char(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '实际来源证据SHA256',
  `source_event_id` varchar(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT 'ERP原授权或过账事件ID',
  PRIMARY KEY (`tenant_id`, `manifest_id`, `revision`, `allocation_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '最终完工清单的实际用料不可变快照' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for pro_dispatch
-- ----------------------------
DROP TABLE IF EXISTS `pro_dispatch`;
CREATE TABLE `pro_dispatch`  (
  `dispatch_id` bigint(20) NOT NULL COMMENT '派工单ID(主键)',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '000000',
  `dispatch_no` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '派工单编号',
  `mes_wo_id` bigint(20) NOT NULL COMMENT '关联MES工单ID',
  `wo_no` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '工单编号(冗余)',
  `card_id` bigint(20) NULL DEFAULT NULL COMMENT '关联流转卡ID',
  `card_no` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '流转卡编号(冗余)',
  `step_record_id` bigint(20) NULL DEFAULT NULL COMMENT '关联流转卡工序记录ID',
  `sequence_num` int(11) NULL DEFAULT NULL COMMENT '工序序号(冗余)',
  `process_id` bigint(20) NOT NULL COMMENT '工序ID',
  `process_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `process_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `workcenter_id` bigint(20) NULL DEFAULT NULL,
  `workcenter_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `operator_id` bigint(20) NULL DEFAULT NULL COMMENT '操作员ID(SchWorker.workerId)',
  `operator_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '操作员姓名',
  `planned_qty` decimal(18, 4) NULL DEFAULT 0.0000 COMMENT '派工数量',
  `completed_qty` decimal(18, 4) NULL DEFAULT 0.0000 COMMENT '已完成数量',
  `good_qty` decimal(18, 4) NULL DEFAULT 0.0000 COMMENT '良品数量',
  `defect_qty` decimal(18, 4) NULL DEFAULT 0.0000 COMMENT '不良品数量',
  `scrap_qty` decimal(18, 4) NULL DEFAULT 0.0000 COMMENT '报废数量',
  `dispatch_status` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT 'PENDING' COMMENT 'PENDING/IN_PROGRESS/COMPLETED/CANCELLED',
  `plan_start_time` datetime(0) NULL DEFAULT NULL,
  `plan_end_time` datetime(0) NULL DEFAULT NULL,
  `actual_start_time` datetime(0) NULL DEFAULT NULL,
  `actual_end_time` datetime(0) NULL DEFAULT NULL,
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `create_dept` bigint(20) NULL DEFAULT NULL,
  `create_by` bigint(20) NULL DEFAULT NULL,
  `create_time` datetime(0) NULL DEFAULT NULL,
  `update_by` bigint(20) NULL DEFAULT NULL,
  `update_time` datetime(0) NULL DEFAULT NULL,
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT '0',
  PRIMARY KEY (`dispatch_id`) USING BTREE,
  UNIQUE INDEX `uk_dispatch_no`(`tenant_id`, `dispatch_no`) USING BTREE,
  INDEX `idx_mes_wo_id`(`mes_wo_id`) USING BTREE,
  INDEX `idx_card_id`(`card_id`) USING BTREE,
  INDEX `idx_step_record_id`(`step_record_id`) USING BTREE,
  INDEX `idx_operator_id`(`operator_id`) USING BTREE,
  INDEX `idx_dispatch_status`(`dispatch_status`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = 'MES派工单' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of pro_dispatch
-- ----------------------------
INSERT INTO `pro_dispatch` VALUES (2104806277991297026, '000000', 'DIS-FC-SCGD202609280001-1173-6737', 2104803729263751169, 'SCGD202609280001', 2104804115554955266, 'FC-SCGD202609280001-1173', 2104804115622064130, 10, 9, 'FORGE', '锻造', 16, 'GZZ0016', 1, '系统管理员', 10.0000, 10.0000, 10.0000, 0.0000, 0.0000, 'COMPLETED', NULL, NULL, '2026-10-01 12:16:08', '2026-10-01 12:16:27', NULL, 103, 1, '2026-09-29 13:31:37', 1, '2026-09-29 13:31:37', '0');
INSERT INTO `pro_dispatch` VALUES (2105513104131465218, '000000', 'DIS-FC-SCGD202609280001-1173-7220', 2104803729263751169, 'SCGD202609280001', 2104804115554955266, 'FC-SCGD202609280001-1173', 2104804115701755905, 20, 10, 'TURN', '车削', 5, 'GZZ0005', 1, '系统管理员', 10.0000, 10.0000, 10.0000, 0.0000, 0.0000, 'COMPLETED', NULL, NULL, '2026-10-01 12:20:55', '2026-10-01 12:20:55', NULL, 103, 1, '2026-10-01 12:20:17', 1, '2026-10-01 12:20:17', '0');
INSERT INTO `pro_dispatch` VALUES (2105514757559656450, '000000', 'DIS-FC-SCGD202609280001-1173-1431', 2104803729263751169, 'SCGD202609280001', 2104804115554955266, 'FC-SCGD202609280001-1173', 2104804115705950210, 30, 27, 'QUENCH', '淬火', 31, 'GZZ0031', 1, '系统管理员', 10.0000, 10.0000, 10.0000, 0.0000, 0.0000, 'COMPLETED', NULL, NULL, '2026-10-01 12:26:52', '2026-10-01 12:26:53', NULL, 103, 1, '2026-10-01 12:26:51', 1, '2026-10-01 12:26:51', '0');
INSERT INTO `pro_dispatch` VALUES (2105514989731160065, '000000', 'DIS-FC-SCGD202609280001-1173-6784', 2104803729263751169, 'SCGD202609280001', 2104804115554955266, 'FC-SCGD202609280001-1173', 2104804115718533121, 40, 28, 'TEMPER', '回火', 32, 'GZZ0032', 1, '系统管理员', 10.0000, 10.0000, 10.0000, 0.0000, 0.0000, 'COMPLETED', NULL, NULL, '2026-10-01 12:27:47', '2026-10-01 12:27:48', NULL, 103, 1, '2026-10-01 12:27:47', 1, '2026-10-01 12:27:47', '0');
INSERT INTO `pro_dispatch` VALUES (2105515159306870786, '000000', 'DIS-FC-SCGD202609280001-1173-7214', 2104803729263751169, 'SCGD202609280001', 2104804115554955266, 'FC-SCGD202609280001-1173', 2104804115735310338, 50, 31, 'PLATE', '电镀', 34, 'GZZ0034', 1, '系统管理员', 10.0000, 10.0000, 10.0000, 0.0000, 0.0000, 'COMPLETED', NULL, NULL, '2026-10-01 12:28:28', '2026-10-01 12:28:29', NULL, 103, 1, '2026-10-01 12:28:27', 1, '2026-10-01 12:28:27', '0');
INSERT INTO `pro_dispatch` VALUES (2105515367818305538, '000000', 'DIS-FC-SCGD202609280001-1173-6928', 2104803729263751169, 'SCGD202609280001', 2104804115554955266, 'FC-SCGD202609280001-1173', 2104804115747893249, 60, 54, 'QC', '质检', 52, 'GZZ0052', 1, '系统管理员', 10.0000, 10.0000, 10.0000, 0.0000, 0.0000, 'COMPLETED', NULL, NULL, '2026-10-01 12:29:18', '2026-10-01 12:29:18', NULL, 103, 1, '2026-10-01 12:29:17', 1, '2026-10-01 12:29:17', '0');
INSERT INTO `pro_dispatch` VALUES (2105515549632995329, '000000', 'DIS-FC-SCGD202609280001-1173-0276', 2104803729263751169, 'SCGD202609280001', 2104804115554955266, 'FC-SCGD202609280001-1173', 2104804115760476162, 70, 55, 'PKG', '包装', 53, 'GZZ0053', 1, '系统管理员', 10.0000, 10.0000, 10.0000, 0.0000, 0.0000, 'COMPLETED', NULL, NULL, '2026-10-01 12:30:01', '2026-10-01 12:30:02', NULL, 103, 1, '2026-10-01 12:30:00', 1, '2026-10-01 12:30:00', '0');
INSERT INTO `pro_dispatch` VALUES (2108665142730227714, '000000', 'DIS-FC-SCGD202610080013-8257-1786', 2108617060583989249, 'SCGD202610080013', 2108660178645614593, 'FC-SCGD202610080013-8257', 2108660178666586114, 10, 44, 'ASM', '装配', 46, 'GZZ0046', 1, '系统管理员', 22.0000, 22.0000, 22.0000, 0.0000, 0.0000, 'COMPLETED', NULL, NULL, '2026-10-10 05:47:55', '2026-10-10 05:47:55', NULL, 103, 1, '2026-10-10 05:05:22', 1, '2026-10-10 05:05:22', '0');
INSERT INTO `pro_dispatch` VALUES (2108665143296458754, '000000', 'DIS-FC-SCGD202610080013-8257-1922', 2108617060583989249, 'SCGD202610080013', 2108660178645614593, 'FC-SCGD202610080013-8257', 2108660178674974722, 20, 54, 'QC', '质检', 52, 'GZZ0052', 1, '系统管理员', 22.0000, 22.0000, 22.0000, 0.0000, 0.0000, 'COMPLETED', NULL, NULL, '2026-10-10 05:47:55', '2026-10-10 05:47:56', NULL, 103, 1, '2026-10-10 05:05:22', 1, '2026-10-10 05:05:22', '0');
INSERT INTO `pro_dispatch` VALUES (2108665143862689793, '000000', 'DIS-FC-SCGD202610080017-8501-2057', 2108617069803069441, 'SCGD202610080017', 2108660179664830465, 'FC-SCGD202610080017-8501', 2108660179694190594, 10, 44, 'ASM', '装配', 46, 'GZZ0046', 1, '系统管理员', 22.0000, 22.0000, 22.0000, 0.0000, 0.0000, 'COMPLETED', NULL, NULL, '2026-10-10 05:53:32', '2026-10-10 05:53:32', NULL, 103, 1, '2026-10-10 05:05:22', 1, '2026-10-10 05:05:22', '0');
INSERT INTO `pro_dispatch` VALUES (2108665144357617666, '000000', 'DIS-FC-SCGD202610080017-8501-2175', 2108617069803069441, 'SCGD202610080017', 2108660179664830465, 'FC-SCGD202610080017-8501', 2108660179698384897, 20, 54, 'QC', '质检', 52, 'GZZ0052', 1, '系统管理员', 22.0000, 22.0000, 22.0000, 0.0000, 0.0000, 'COMPLETED', NULL, NULL, '2026-10-10 05:53:32', '2026-10-10 05:53:33', NULL, 103, 1, '2026-10-10 05:05:22', 1, '2026-10-10 05:05:22', '0');
INSERT INTO `pro_dispatch` VALUES (2108738612675698690, '000000', 'DIS-FC-SCGD202610080009-7951-8384', 2108617051121639426, 'SCGD202610080009', 2108660177370546178, 'FC-SCGD202610080009-7951', 2108660177408294913, 10, 44, 'ASM', '装配', 46, 'GZZ0046', 1, '系统管理员', 22.0000, 22.0000, 22.0000, 0.0000, 0.0000, 'COMPLETED', NULL, NULL, '2026-10-10 09:57:25', '2026-10-10 09:57:25', NULL, 103, 1, '2026-10-10 09:57:18', 1, '2026-10-10 09:57:18', '0');
INSERT INTO `pro_dispatch` VALUES (2108738613682331649, '000000', 'DIS-FC-SCGD202610080009-7951-8627', 2108617051121639426, 'SCGD202610080009', 2108660177370546178, 'FC-SCGD202610080009-7951', 2108660177437655041, 20, 54, 'QC', '质检', 52, 'GZZ0052', 1, '系统管理员', 22.0000, 22.0000, 22.0000, 0.0000, 0.0000, 'COMPLETED', NULL, NULL, '2026-10-10 09:57:26', '2026-10-10 09:57:26', NULL, 103, 1, '2026-10-10 09:57:19', 1, '2026-10-10 09:57:19', '0');

-- ----------------------------
-- Table structure for pro_flow_card
-- ----------------------------
DROP TABLE IF EXISTS `pro_flow_card`;
CREATE TABLE `pro_flow_card`  (
  `card_id` bigint(20) NOT NULL COMMENT '流转卡ID(主键)',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '000000' COMMENT '租户ID',
  `card_no` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '流转卡编号',
  `mes_wo_id` bigint(20) NOT NULL COMMENT '关联MES工单ID',
  `wo_no` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '工单编号(冗余)',
  `material_id` bigint(20) NULL DEFAULT NULL COMMENT '物料ID',
  `material_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '物料编码(冗余)',
  `material_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '物料名称(冗余)',
  `planned_qty` decimal(18, 4) NULL DEFAULT 0.0000 COMMENT '计划数量',
  `completed_qty` decimal(18, 4) NULL DEFAULT 0.0000 COMMENT '已完成数量',
  `scrap_qty` decimal(18, 4) NULL DEFAULT 0.0000 COMMENT '报废数量',
  `aggregated_flag` tinyint(4) NOT NULL DEFAULT 0 COMMENT '完工数量是否已一次性入账到工单(0=未入账 1=已入账)',
  `current_step_id` bigint(20) NULL DEFAULT NULL COMMENT '当前工序步骤记录ID',
  `current_step_seq` int(4) NULL DEFAULT NULL COMMENT '当前工序序号',
  `card_status` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT 'CREATED' COMMENT '流转卡状态: CREATED/RELEASED/IN_PROGRESS/COMPLETED/CLOSED',
  `barcode` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '流转卡条码',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '备注',
  `create_dept` bigint(20) NULL DEFAULT NULL COMMENT '创建部门',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建人',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新人',
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP(0) COMMENT '更新时间',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT '0' COMMENT '删除标志(0正常 1删除)',
  PRIMARY KEY (`card_id`) USING BTREE,
  UNIQUE INDEX `uk_card_no`(`tenant_id`, `card_no`) USING BTREE,
  UNIQUE INDEX `uk_barcode`(`tenant_id`, `barcode`) USING BTREE,
  INDEX `idx_mes_wo_id`(`mes_wo_id`) USING BTREE,
  INDEX `idx_card_status`(`card_status`) USING BTREE,
  INDEX `idx_tenant_id`(`tenant_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = 'MES流转卡表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of pro_flow_card
-- ----------------------------
INSERT INTO `pro_flow_card` VALUES (2104804115554955266, '000000', 'FC-SCGD202609280001-1173', 2104803729263751169, 'SCGD202609280001', 1, 'IF20260914001', '高强度螺栓组套 M12', 10.0000, 10.0000, 0.0000, 1, 2104804115622064130, NULL, 'COMPLETED', 'FC2104804115554955266', NULL, 103, 1, '2026-09-29 13:23:01', 1, '2026-10-01 12:30:01', '0');
INSERT INTO `pro_flow_card` VALUES (2107083840268677122, '000000', 'FC-SCGD202610050001-9899', 2106995561900978178, 'SCGD202610050001', 2106761349704929281, 'IF20261004006', 'M12高强度镀锌螺栓连接组件', 10.0000, 10.0000, 0.0000, 1, 2107083840331591682, NULL, 'COMPLETED', 'FC2107083840268677122', NULL, 103, 1, '2026-10-05 20:21:50', 1, '2026-10-05 21:59:26', '0');
INSERT INTO `pro_flow_card` VALUES (2107328405412196354, '000000', 'FC-SCGD202610060001-8774', 2107323241485774850, 'SCGD202610060001', 2106761349704929281, 'IF20261004006', 'M12高强度镀锌螺栓连接组件', 6.0000, 6.0000, 0.0000, 1, 2107328405445750785, NULL, 'COMPLETED', 'FC2107328405412196354', NULL, 103, 1, '2026-10-06 12:33:39', 1, '2026-10-06 12:49:41', '0');
INSERT INTO `pro_flow_card` VALUES (2107524224165838850, '000000', 'FC-SCGD202610060002-5604', 2107352232221392898, 'SCGD202610060002', 2106761349704929281, 'IF20261004006', 'M12高强度镀锌螺栓连接组件', 6.0000, 6.0000, 0.0000, 1, 2107524224207781889, NULL, 'COMPLETED', 'FC2107524224165838850', NULL, 103, 1, '2026-10-07 01:31:46', 1, '2026-10-07 01:41:41', '0');
INSERT INTO `pro_flow_card` VALUES (2108660177370546178, '000000', 'FC-SCGD202610080009-7951', 2108617051121639426, 'SCGD202610080009', 2106761349704929281, 'IF20261004006', 'M12高强度镀锌螺栓连接组件', 22.0000, 22.0000, 0.0000, 1, 2108660177408294913, NULL, 'COMPLETED', 'FC2108660177370546178', NULL, 103, 1, '2026-10-10 04:45:38', 1, '2026-10-10 09:57:26', '0');
INSERT INTO `pro_flow_card` VALUES (2108660178645614593, '000000', 'FC-SCGD202610080013-8257', 2108617060583989249, 'SCGD202610080013', 2106761349704929281, 'IF20261004006', 'M12高强度镀锌螺栓连接组件', 22.0000, 22.0000, 0.0000, 1, 2108660178666586114, NULL, 'COMPLETED', 'FC2108660178645614593', NULL, 103, 1, '2026-10-10 04:45:38', 1, '2026-10-10 05:47:55', '0');
INSERT INTO `pro_flow_card` VALUES (2108660179664830465, '000000', 'FC-SCGD202610080017-8501', 2108617069803069441, 'SCGD202610080017', 2106761349704929281, 'IF20261004006', 'M12高强度镀锌螺栓连接组件', 22.0000, 22.0000, 0.0000, 1, 2108660179694190594, NULL, 'COMPLETED', 'FC2108660179664830465', NULL, 103, 1, '2026-10-10 04:45:39', 1, '2026-10-10 05:53:32', '0');

-- ----------------------------
-- Table structure for pro_flow_card_step
-- ----------------------------
DROP TABLE IF EXISTS `pro_flow_card_step`;
CREATE TABLE `pro_flow_card_step`  (
  `step_record_id` bigint(20) NOT NULL COMMENT '工序记录ID(主键)',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '000000' COMMENT '租户ID',
  `card_id` bigint(20) NOT NULL COMMENT '关联流转卡ID',
  `card_no` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '流转卡编号(冗余)',
  `mes_wo_id` bigint(20) NOT NULL COMMENT '关联MES工单ID(冗余便于查询)',
  `wo_step_id` bigint(20) NULL DEFAULT NULL COMMENT '关联工单工序步骤ID(pro_work_order_step.step_id)',
  `sequence_num` int(4) NOT NULL DEFAULT 0 COMMENT '工序序号(从1开始)',
  `process_id` bigint(20) NULL DEFAULT NULL COMMENT '工序ID(来自ERP bd_routing_step)',
  `process_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '工序编码(冗余)',
  `process_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '工序名称(冗余)',
  `workcenter_id` bigint(20) NULL DEFAULT NULL COMMENT '工作中心ID',
  `workcenter_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '工作中心编码(冗余)',
  `is_key_process` tinyint(1) NULL DEFAULT 0 COMMENT '是否关键工序(0否 1是)',
  `step_status` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT 'PENDING' COMMENT '工序状态: PENDING/IN_PROGRESS/COMPLETED/SKIPPED',
  `operator_id` bigint(20) NULL DEFAULT NULL COMMENT '操作员ID',
  `operator_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '操作员姓名(冗余)',
  `planned_qty` decimal(18, 4) NULL DEFAULT 0.0000 COMMENT '计划数量',
  `good_qty` decimal(18, 4) NULL DEFAULT 0.0000 COMMENT '良品数量',
  `defect_qty` decimal(18, 4) NULL DEFAULT 0.0000 COMMENT '不良品数量',
  `scrap_qty` decimal(18, 4) NULL DEFAULT 0.0000 COMMENT '报废数量',
  `actual_start_time` datetime(0) NULL DEFAULT NULL COMMENT '实际开始时间',
  `actual_end_time` datetime(0) NULL DEFAULT NULL COMMENT '实际结束时间',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '备注',
  `entry_check_result` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '进站校验结果(PASS/FAIL)',
  `entry_check_remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '进站校验备注(失败原因)',
  `exit_check_result` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '出站校验结果(PASS/FAIL)',
  `exit_check_remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '出站校验备注(失败原因)',
  `skip_reason` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '跳站原因',
  `create_dept` bigint(20) NULL DEFAULT NULL COMMENT '创建部门',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建人',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新人',
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP(0) COMMENT '更新时间',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT '0' COMMENT '删除标志(0正常 1删除)',
  PRIMARY KEY (`step_record_id`) USING BTREE,
  INDEX `idx_card_id`(`card_id`) USING BTREE,
  INDEX `idx_mes_wo_id`(`mes_wo_id`) USING BTREE,
  INDEX `idx_step_status`(`step_status`) USING BTREE,
  INDEX `idx_tenant_id`(`tenant_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = 'MES流转卡工序记录表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of pro_flow_card_step
-- ----------------------------
INSERT INTO `pro_flow_card_step` VALUES (2104804115622064130, '000000', 2104804115554955266, 'FC-SCGD202609280001-1173', 2104803729263751169, 2104803729293111298, 10, 9, 'FORGE', '锻造', 16, 'GZZ0016', 0, 'COMPLETED', 1, '系统管理员', 10.0000, 10.0000, 0.0000, 0.0000, '2026-10-01 12:16:08', '2026-10-01 12:16:27', NULL, NULL, NULL, NULL, NULL, NULL, 103, 1, '2026-09-29 13:23:01', 1, '2026-10-01 12:16:26', '0');
INSERT INTO `pro_flow_card_step` VALUES (2104804115701755905, '000000', 2104804115554955266, 'FC-SCGD202609280001-1173', 2104803729263751169, 2104803729360220162, 20, 10, 'TURN', '车削', 5, 'GZZ0005', 0, 'COMPLETED', 1, '系统管理员', 10.0000, 10.0000, 0.0000, 0.0000, '2026-10-01 12:20:55', '2026-10-01 12:20:55', NULL, NULL, NULL, NULL, NULL, NULL, 103, 1, '2026-09-29 13:23:01', 1, '2026-10-01 12:20:55', '0');
INSERT INTO `pro_flow_card_step` VALUES (2104804115705950210, '000000', 2104804115554955266, 'FC-SCGD202609280001-1173', 2104803729263751169, 2104803729376997377, 30, 27, 'QUENCH', '淬火', 31, 'GZZ0031', 0, 'COMPLETED', 1, '系统管理员', 10.0000, 10.0000, 0.0000, 0.0000, '2026-10-01 12:26:52', '2026-10-01 12:26:53', NULL, NULL, NULL, NULL, NULL, NULL, 103, 1, '2026-09-29 13:23:01', 1, '2026-10-01 12:26:52', '0');
INSERT INTO `pro_flow_card_step` VALUES (2104804115718533121, '000000', 2104804115554955266, 'FC-SCGD202609280001-1173', 2104803729263751169, 2104803729389580290, 40, 28, 'TEMPER', '回火', 32, 'GZZ0032', 0, 'COMPLETED', 1, '系统管理员', 10.0000, 10.0000, 0.0000, 0.0000, '2026-10-01 12:27:47', '2026-10-01 12:27:48', NULL, NULL, NULL, NULL, NULL, NULL, 103, 1, '2026-09-29 13:23:01', 1, '2026-10-01 12:27:48', '0');
INSERT INTO `pro_flow_card_step` VALUES (2104804115735310338, '000000', 2104804115554955266, 'FC-SCGD202609280001-1173', 2104803729263751169, 2104803729402163202, 50, 31, 'PLATE', '电镀', 34, 'GZZ0034', 0, 'COMPLETED', 1, '系统管理员', 10.0000, 10.0000, 0.0000, 0.0000, '2026-10-01 12:28:28', '2026-10-01 12:28:29', NULL, NULL, NULL, NULL, NULL, NULL, 103, 1, '2026-09-29 13:23:01', 1, '2026-10-01 12:28:28', '0');
INSERT INTO `pro_flow_card_step` VALUES (2104804115747893249, '000000', 2104804115554955266, 'FC-SCGD202609280001-1173', 2104803729263751169, 2104803729423134722, 60, 54, 'QC', '质检', 52, 'GZZ0052', 0, 'COMPLETED', 1, '系统管理员', 10.0000, 10.0000, 0.0000, 0.0000, '2026-10-01 12:29:18', '2026-10-01 12:29:18', NULL, NULL, NULL, NULL, NULL, NULL, 103, 1, '2026-09-29 13:23:01', 1, '2026-10-01 12:29:18', '0');
INSERT INTO `pro_flow_card_step` VALUES (2104804115760476162, '000000', 2104804115554955266, 'FC-SCGD202609280001-1173', 2104803729263751169, 2104803729439911938, 70, 55, 'PKG', '包装', 53, 'GZZ0053', 0, 'COMPLETED', 1, '系统管理员', 10.0000, 10.0000, 0.0000, 0.0000, '2026-10-01 12:30:01', '2026-10-01 12:30:02', NULL, NULL, NULL, NULL, NULL, NULL, 103, 1, '2026-09-29 13:23:01', 1, '2026-10-01 12:30:01', '0');
INSERT INTO `pro_flow_card_step` VALUES (2107083840331591682, '000000', 2107083840268677122, 'FC-SCGD202610050001-9899', 2106995561900978178, 2106995561926144002, 10, 44, 'ASM', '装配', 46, 'GZZ0046', 0, 'COMPLETED', NULL, NULL, 10.0000, 10.0000, 0.0000, 0.0000, '2026-10-05 20:28:41', '2026-10-05 20:28:42', NULL, NULL, NULL, NULL, NULL, NULL, 103, 1, '2026-10-05 20:21:50', 1, '2026-10-05 20:28:41', '0');
INSERT INTO `pro_flow_card_step` VALUES (2107083840394506242, '000000', 2107083840268677122, 'FC-SCGD202610050001-9899', 2106995561900978178, 2106995561989058562, 20, 54, 'QC', '质检', 52, 'GZZ0052', 1, 'COMPLETED', NULL, NULL, 10.0000, 10.0000, 0.0000, 0.0000, '2026-10-05 20:28:42', '2026-10-05 21:59:27', NULL, NULL, NULL, NULL, NULL, NULL, 103, 1, '2026-10-05 20:21:50', 1, '2026-10-05 21:59:26', '0');
INSERT INTO `pro_flow_card_step` VALUES (2107328405445750785, '000000', 2107328405412196354, 'FC-SCGD202610060001-8774', 2107323241485774850, 2107323241506746370, 10, 44, 'ASM', '装配', 46, 'GZZ0046', 0, 'COMPLETED', 106, NULL, 6.0000, 6.0000, 0.0000, 0.0000, '2026-10-06 12:40:19', '2026-10-06 12:40:19', NULL, NULL, NULL, NULL, NULL, NULL, 103, 1, '2026-10-06 12:33:39', 1, '2026-10-06 12:40:19', '0');
INSERT INTO `pro_flow_card_step` VALUES (2107328405466722305, '000000', 2107328405412196354, 'FC-SCGD202610060001-8774', 2107323241485774850, 2107323241519329281, 20, 54, 'QC', '质检', 52, 'GZZ0052', 1, 'COMPLETED', 105, NULL, 6.0000, 6.0000, 0.0000, 0.0000, '2026-10-06 12:42:36', '2026-10-06 12:49:41', NULL, NULL, NULL, NULL, NULL, NULL, 103, 1, '2026-10-06 12:33:39', 1, '2026-10-06 12:49:41', '0');
INSERT INTO `pro_flow_card_step` VALUES (2107524224207781889, '000000', 2107524224165838850, 'FC-SCGD202610060002-5604', 2107352232221392898, 2107352232246558721, 10, 44, 'ASM', '装配', 46, 'GZZ0046', 0, 'COMPLETED', 106, NULL, 6.0000, 6.0000, 0.0000, 0.0000, '2026-10-07 01:38:02', '2026-10-07 01:38:03', NULL, NULL, NULL, NULL, NULL, NULL, 103, 1, '2026-10-07 01:31:46', 1, '2026-10-07 01:38:02', '0');
INSERT INTO `pro_flow_card_step` VALUES (2107524224237142018, '000000', 2107524224165838850, 'FC-SCGD202610060002-5604', 2107352232221392898, 2107352232280113154, 20, 54, 'QC', '质检', 52, 'GZZ0052', 1, 'COMPLETED', 105, NULL, 6.0000, 6.0000, 0.0000, 0.0000, '2026-10-07 01:38:03', '2026-10-07 01:41:41', NULL, NULL, NULL, NULL, NULL, NULL, 103, 1, '2026-10-07 01:31:46', 1, '2026-10-07 01:41:41', '0');
INSERT INTO `pro_flow_card_step` VALUES (2108660177408294913, '000000', 2108660177370546178, 'FC-SCGD202610080009-7951', 2108617051121639426, 2108617051146805249, 10, 44, 'ASM', '装配', 46, 'GZZ0046', 0, 'COMPLETED', 1, '系统管理员', 22.0000, 22.0000, 0.0000, 0.0000, '2026-10-10 09:57:25', '2026-10-10 09:57:25', NULL, 'PASS', NULL, NULL, NULL, NULL, 103, 1, '2026-10-10 04:45:38', 1, '2026-10-10 09:57:25', '0');
INSERT INTO `pro_flow_card_step` VALUES (2108660177437655041, '000000', 2108660177370546178, 'FC-SCGD202610080009-7951', 2108617051121639426, 2108617051167776769, 20, 54, 'QC', '质检', 52, 'GZZ0052', 1, 'COMPLETED', 1, '系统管理员', 22.0000, 22.0000, 0.0000, 0.0000, '2026-10-10 09:57:26', '2026-10-10 09:57:26', NULL, 'PASS', NULL, NULL, NULL, NULL, 103, 1, '2026-10-10 04:45:38', 1, '2026-10-10 09:57:26', '0');
INSERT INTO `pro_flow_card_step` VALUES (2108660178666586114, '000000', 2108660178645614593, 'FC-SCGD202610080013-8257', 2108617060583989249, 2108617060596572162, 10, 44, 'ASM', '装配', 46, 'GZZ0046', 0, 'COMPLETED', 1, '系统管理员', 22.0000, 22.0000, 0.0000, 0.0000, '2026-10-10 05:47:55', '2026-10-10 05:47:55', NULL, 'PASS', NULL, NULL, NULL, NULL, 103, 1, '2026-10-10 04:45:38', 1, '2026-10-10 05:47:54', '0');
INSERT INTO `pro_flow_card_step` VALUES (2108660178674974722, '000000', 2108660178645614593, 'FC-SCGD202610080013-8257', 2108617060583989249, 2108617060596572163, 20, 54, 'QC', '质检', 52, 'GZZ0052', 1, 'COMPLETED', 1, '系统管理员', 22.0000, 22.0000, 0.0000, 0.0000, '2026-10-10 05:47:55', '2026-10-10 05:47:56', NULL, 'PASS', NULL, NULL, NULL, NULL, 103, 1, '2026-10-10 04:45:38', 1, '2026-10-10 05:47:55', '0');
INSERT INTO `pro_flow_card_step` VALUES (2108660179694190594, '000000', 2108660179664830465, 'FC-SCGD202610080017-8501', 2108617069803069441, 2108617069815652353, 10, 44, 'ASM', '装配', 46, 'GZZ0046', 0, 'COMPLETED', 1, '系统管理员', 22.0000, 22.0000, 0.0000, 0.0000, '2026-10-10 05:53:32', '2026-10-10 05:53:32', NULL, 'PASS', NULL, NULL, NULL, NULL, 103, 1, '2026-10-10 04:45:39', 1, '2026-10-10 05:53:32', '0');
INSERT INTO `pro_flow_card_step` VALUES (2108660179698384897, '000000', 2108660179664830465, 'FC-SCGD202610080017-8501', 2108617069803069441, 2108617069815652354, 20, 54, 'QC', '质检', 52, 'GZZ0052', 1, 'COMPLETED', 1, '系统管理员', 22.0000, 22.0000, 0.0000, 0.0000, '2026-10-10 05:53:32', '2026-10-10 05:53:33', NULL, 'PASS', NULL, NULL, NULL, NULL, 103, 1, '2026-10-10 04:45:39', 1, '2026-10-10 05:53:32', '0');

-- ----------------------------
-- Table structure for pro_product_lot_output
-- ----------------------------
DROP TABLE IF EXISTS `pro_product_lot_output`;
CREATE TABLE `pro_product_lot_output`  (
  `output_id` bigint(20) NOT NULL COMMENT '实际产品批次产出ID',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '租户ID，必须由认证上下文提供',
  `command_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '幂等业务命令ID',
  `line_no` bigint(20) NOT NULL COMMENT '原命令内实际产出行号',
  `mes_wo_id` bigint(20) NOT NULL COMMENT '真实MES生产工单',
  `card_id` bigint(20) NOT NULL COMMENT '实际生产流转卡',
  `step_record_id` bigint(20) NOT NULL COMMENT '实际报工工序记录',
  `lot_id` bigint(20) NOT NULL COMMENT '实际MES产品批次',
  `source_allocation_id` bigint(20) NOT NULL COMMENT '原PRODUCTION_OUTPUT额度分配ID，ERP批次由该原凭据取得',
  `material_id` bigint(20) NOT NULL COMMENT '实际产品物料',
  `quantity` decimal(18, 4) NOT NULL COMMENT '实际基本单位产出数量',
  `result` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '实际GOOD或SCRAP，不以授权额度推定合格产出',
  `source_version` bigint(20) NOT NULL DEFAULT 1 COMMENT '实际产出冻结版本',
  `created_by` bigint(20) NOT NULL COMMENT '认证上下文中的实际报工人',
  `created_at` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`output_id`) USING BTREE,
  UNIQUE INDEX `uk_product_output_command`(`tenant_id`, `command_id`, `line_no`) USING BTREE,
  UNIQUE INDEX `uk_product_output_lot`(`tenant_id`, `lot_id`) USING BTREE,
  INDEX `idx_product_output_work_order`(`tenant_id`, `mes_wo_id`, `card_id`, `step_record_id`, `lot_id`, `output_id`) USING BTREE,
  INDEX `idx_product_output_step`(`tenant_id`, `step_record_id`) USING BTREE,
  INDEX `idx_product_output_source`(`tenant_id`, `source_allocation_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '真实批次型产品产出，来源额度不是质量证明，不补造历史产出' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for pro_sn
-- ----------------------------
DROP TABLE IF EXISTS `pro_sn`;
CREATE TABLE `pro_sn`  (
  `sn_id` bigint(20) NOT NULL COMMENT 'SN ID(主键)',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '000000',
  `sn_code` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'SN序列号编码',
  `mes_wo_id` bigint(20) NULL DEFAULT NULL COMMENT '工单ID，仅已核实SUBCONTRACT来源可空',
  `wo_no` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '工单编号(冗余)',
  `card_id` bigint(20) NULL DEFAULT NULL COMMENT '关联流转卡ID',
  `card_no` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '流转卡编号(冗余)',
  `material_id` bigint(20) NOT NULL COMMENT '物料ID',
  `material_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '物料编码(冗余)',
  `material_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '物料名称(冗余)',
  `current_step_seq` int(11) NULL DEFAULT NULL COMMENT '当前工序序号',
  `sn_status` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT 'IN_PRODUCTION' COMMENT 'IN_PRODUCTION/COMPLETED/SCRAPPED/SHIPPED',
  `parent_sn_id` bigint(20) NULL DEFAULT NULL COMMENT '父SN ID(组装追溯, 组件SN指向成品SN)',
  `parent_sn_code` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '父SN编码(冗余)',
  `source` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT 'MANUAL' COMMENT 'MANUAL/BATCH(来源: 手动/批量生成)',
  `production_date` date NULL DEFAULT NULL COMMENT '生产日期',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `create_dept` bigint(20) NULL DEFAULT NULL,
  `create_by` bigint(20) NULL DEFAULT NULL,
  `create_time` datetime(0) NULL DEFAULT NULL,
  `update_by` bigint(20) NULL DEFAULT NULL,
  `update_time` datetime(0) NULL DEFAULT NULL,
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT '0',
  `source_id` bigint(20) NULL DEFAULT NULL COMMENT '来源单据ID(委外=subcontract_id)',
  `subcontract_no` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '委外单号(冗余,SN直达追溯委外订单)',
  `identity_id` bigint(20) NULL DEFAULT NULL COMMENT 'ERP正式身份wm_sn.sn_id，本地sn_id语义不变',
  `product_lot_id` bigint(20) NULL DEFAULT NULL COMMENT 'MES成品批次lt_lot.lot_id',
  `identity_version` bigint(20) NOT NULL DEFAULT 1 COMMENT '身份映射版本',
  `handoff_status` varchar(24) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NONE' COMMENT '交付状态，历史默认NONE',
  PRIMARY KEY (`sn_id`) USING BTREE,
  UNIQUE INDEX `uk_sn_code`(`tenant_id`, `sn_code`) USING BTREE,
  UNIQUE INDEX `uk_pro_sn_identity`(`tenant_id`, `identity_id`) USING BTREE,
  INDEX `idx_sn_status`(`sn_status`) USING BTREE,
  INDEX `idx_mes_wo_id`(`mes_wo_id`) USING BTREE,
  INDEX `idx_card_id`(`card_id`) USING BTREE,
  INDEX `idx_material_id`(`material_id`) USING BTREE,
  INDEX `idx_parent_sn_id`(`parent_sn_id`) USING BTREE,
  INDEX `idx_subcontract_no`(`tenant_id`, `subcontract_no`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = 'MES SN序列号追溯' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of pro_sn
-- ----------------------------
INSERT INTO `pro_sn` VALUES (2104806275306942466, '000000', 'SN-FC-SCGD202609280001-1173-0001', 2104803729263751169, 'SCGD202609280001', 2104804115554955266, 'FC-SCGD202609280001-1173', 1, 'IF20260914001', '高强度螺栓组套 M12', NULL, 'COMPLETED', NULL, NULL, 'BATCH', '2026-09-29', NULL, 103, 1, '2026-09-29 13:31:36', 1, '2026-09-29 13:31:36', '0', NULL, NULL, NULL, NULL, 1, 'NONE');
INSERT INTO `pro_sn` VALUES (2104806275319525377, '000000', 'SN-FC-SCGD202609280001-1173-0002', 2104803729263751169, 'SCGD202609280001', 2104804115554955266, 'FC-SCGD202609280001-1173', 1, 'IF20260914001', '高强度螺栓组套 M12', NULL, 'COMPLETED', NULL, NULL, 'BATCH', '2026-09-29', NULL, 103, 1, '2026-09-29 13:31:36', 1, '2026-09-29 13:31:36', '0', NULL, NULL, NULL, NULL, 1, 'NONE');
INSERT INTO `pro_sn` VALUES (2104806275332108290, '000000', 'SN-FC-SCGD202609280001-1173-0003', 2104803729263751169, 'SCGD202609280001', 2104804115554955266, 'FC-SCGD202609280001-1173', 1, 'IF20260914001', '高强度螺栓组套 M12', NULL, 'COMPLETED', NULL, NULL, 'BATCH', '2026-09-29', NULL, 103, 1, '2026-09-29 13:31:36', 1, '2026-09-29 13:31:36', '0', NULL, NULL, NULL, NULL, 1, 'NONE');
INSERT INTO `pro_sn` VALUES (2104806275336302594, '000000', 'SN-FC-SCGD202609280001-1173-0004', 2104803729263751169, 'SCGD202609280001', 2104804115554955266, 'FC-SCGD202609280001-1173', 1, 'IF20260914001', '高强度螺栓组套 M12', NULL, 'COMPLETED', NULL, NULL, 'BATCH', '2026-09-29', NULL, 103, 1, '2026-09-29 13:31:36', 1, '2026-09-29 13:31:36', '0', NULL, NULL, NULL, NULL, 1, 'NONE');
INSERT INTO `pro_sn` VALUES (2104806275348885506, '000000', 'SN-FC-SCGD202609280001-1173-0005', 2104803729263751169, 'SCGD202609280001', 2104804115554955266, 'FC-SCGD202609280001-1173', 1, 'IF20260914001', '高强度螺栓组套 M12', NULL, 'COMPLETED', NULL, NULL, 'BATCH', '2026-09-29', NULL, 103, 1, '2026-09-29 13:31:36', 1, '2026-09-29 13:31:36', '0', NULL, NULL, NULL, NULL, 1, 'NONE');
INSERT INTO `pro_sn` VALUES (2104806275357274114, '000000', 'SN-FC-SCGD202609280001-1173-0006', 2104803729263751169, 'SCGD202609280001', 2104804115554955266, 'FC-SCGD202609280001-1173', 1, 'IF20260914001', '高强度螺栓组套 M12', NULL, 'COMPLETED', NULL, NULL, 'BATCH', '2026-09-29', NULL, 103, 1, '2026-09-29 13:31:36', 1, '2026-09-29 13:31:36', '0', NULL, NULL, NULL, NULL, 1, 'NONE');
INSERT INTO `pro_sn` VALUES (2104806275365662722, '000000', 'SN-FC-SCGD202609280001-1173-0007', 2104803729263751169, 'SCGD202609280001', 2104804115554955266, 'FC-SCGD202609280001-1173', 1, 'IF20260914001', '高强度螺栓组套 M12', NULL, 'COMPLETED', NULL, NULL, 'BATCH', '2026-09-29', NULL, 103, 1, '2026-09-29 13:31:36', 1, '2026-09-29 13:31:36', '0', NULL, NULL, NULL, NULL, 1, 'NONE');
INSERT INTO `pro_sn` VALUES (2104806275378245634, '000000', 'SN-FC-SCGD202609280001-1173-0008', 2104803729263751169, 'SCGD202609280001', 2104804115554955266, 'FC-SCGD202609280001-1173', 1, 'IF20260914001', '高强度螺栓组套 M12', NULL, 'COMPLETED', NULL, NULL, 'BATCH', '2026-09-29', NULL, 103, 1, '2026-09-29 13:31:36', 1, '2026-09-29 13:31:36', '0', NULL, NULL, NULL, NULL, 1, 'NONE');
INSERT INTO `pro_sn` VALUES (2104806275382439938, '000000', 'SN-FC-SCGD202609280001-1173-0009', 2104803729263751169, 'SCGD202609280001', 2104804115554955266, 'FC-SCGD202609280001-1173', 1, 'IF20260914001', '高强度螺栓组套 M12', NULL, 'COMPLETED', NULL, NULL, 'BATCH', '2026-09-29', NULL, 103, 1, '2026-09-29 13:31:36', 1, '2026-09-29 13:31:36', '0', NULL, NULL, NULL, NULL, 1, 'NONE');
INSERT INTO `pro_sn` VALUES (2104806275390828546, '000000', 'SN-FC-SCGD202609280001-1173-0010', 2104803729263751169, 'SCGD202609280001', 2104804115554955266, 'FC-SCGD202609280001-1173', 1, 'IF20260914001', '高强度螺栓组套 M12', NULL, 'COMPLETED', NULL, NULL, 'BATCH', '2026-09-29', NULL, 103, 1, '2026-09-29 13:31:36', 1, '2026-09-29 13:31:36', '0', NULL, NULL, NULL, NULL, 1, 'NONE');
INSERT INTO `pro_sn` VALUES (2107083840956542977, '000000', 'SN-FC-SCGD202610050001-9899-0001', 2106995561900978178, 'SCGD202610050001', 2107083840268677122, 'FC-SCGD202610050001-9899', 2106761349704929281, 'IF20261004006', 'M12高强度镀锌螺栓连接组件', 20, 'COMPLETED', NULL, NULL, 'BATCH', '2026-10-05', NULL, 103, 1, '2026-10-05 20:21:50', 1, '2026-10-05 20:21:50', '0', NULL, NULL, NULL, NULL, 1, 'NONE');
INSERT INTO `pro_sn` VALUES (2107083840973320193, '000000', 'SN-FC-SCGD202610050001-9899-0002', 2106995561900978178, 'SCGD202610050001', 2107083840268677122, 'FC-SCGD202610050001-9899', 2106761349704929281, 'IF20261004006', 'M12高强度镀锌螺栓连接组件', 20, 'COMPLETED', NULL, NULL, 'BATCH', '2026-10-05', NULL, 103, 1, '2026-10-05 20:21:50', 1, '2026-10-05 20:21:50', '0', NULL, NULL, NULL, NULL, 1, 'NONE');
INSERT INTO `pro_sn` VALUES (2107083840985903106, '000000', 'SN-FC-SCGD202610050001-9899-0003', 2106995561900978178, 'SCGD202610050001', 2107083840268677122, 'FC-SCGD202610050001-9899', 2106761349704929281, 'IF20261004006', 'M12高强度镀锌螺栓连接组件', 20, 'COMPLETED', NULL, NULL, 'BATCH', '2026-10-05', NULL, 103, 1, '2026-10-05 20:21:50', 1, '2026-10-05 20:21:50', '0', NULL, NULL, NULL, NULL, 1, 'NONE');
INSERT INTO `pro_sn` VALUES (2107083841053011970, '000000', 'SN-FC-SCGD202610050001-9899-0004', 2106995561900978178, 'SCGD202610050001', 2107083840268677122, 'FC-SCGD202610050001-9899', 2106761349704929281, 'IF20261004006', 'M12高强度镀锌螺栓连接组件', 20, 'COMPLETED', NULL, NULL, 'BATCH', '2026-10-05', NULL, 103, 1, '2026-10-05 20:21:50', 1, '2026-10-05 20:21:50', '0', NULL, NULL, NULL, NULL, 1, 'NONE');
INSERT INTO `pro_sn` VALUES (2107083841069789185, '000000', 'SN-FC-SCGD202610050001-9899-0005', 2106995561900978178, 'SCGD202610050001', 2107083840268677122, 'FC-SCGD202610050001-9899', 2106761349704929281, 'IF20261004006', 'M12高强度镀锌螺栓连接组件', 20, 'COMPLETED', NULL, NULL, 'BATCH', '2026-10-05', NULL, 103, 1, '2026-10-05 20:21:50', 1, '2026-10-05 20:21:50', '0', NULL, NULL, NULL, NULL, 1, 'NONE');
INSERT INTO `pro_sn` VALUES (2107083841082372097, '000000', 'SN-FC-SCGD202610050001-9899-0006', 2106995561900978178, 'SCGD202610050001', 2107083840268677122, 'FC-SCGD202610050001-9899', 2106761349704929281, 'IF20261004006', 'M12高强度镀锌螺栓连接组件', 20, 'COMPLETED', NULL, NULL, 'BATCH', '2026-10-05', NULL, 103, 1, '2026-10-05 20:21:50', 1, '2026-10-05 20:21:50', '0', NULL, NULL, NULL, NULL, 1, 'NONE');
INSERT INTO `pro_sn` VALUES (2107083841099149313, '000000', 'SN-FC-SCGD202610050001-9899-0007', 2106995561900978178, 'SCGD202610050001', 2107083840268677122, 'FC-SCGD202610050001-9899', 2106761349704929281, 'IF20261004006', 'M12高强度镀锌螺栓连接组件', 20, 'COMPLETED', NULL, NULL, 'BATCH', '2026-10-05', NULL, 103, 1, '2026-10-05 20:21:50', 1, '2026-10-05 20:21:50', '0', NULL, NULL, NULL, NULL, 1, 'NONE');
INSERT INTO `pro_sn` VALUES (2107083841103343617, '000000', 'SN-FC-SCGD202610050001-9899-0008', 2106995561900978178, 'SCGD202610050001', 2107083840268677122, 'FC-SCGD202610050001-9899', 2106761349704929281, 'IF20261004006', 'M12高强度镀锌螺栓连接组件', 20, 'COMPLETED', NULL, NULL, 'BATCH', '2026-10-05', NULL, 103, 1, '2026-10-05 20:21:50', 1, '2026-10-05 20:21:50', '0', NULL, NULL, NULL, NULL, 1, 'NONE');
INSERT INTO `pro_sn` VALUES (2107083841120120834, '000000', 'SN-FC-SCGD202610050001-9899-0009', 2106995561900978178, 'SCGD202610050001', 2107083840268677122, 'FC-SCGD202610050001-9899', 2106761349704929281, 'IF20261004006', 'M12高强度镀锌螺栓连接组件', 20, 'COMPLETED', NULL, NULL, 'BATCH', '2026-10-05', NULL, 103, 1, '2026-10-05 20:21:50', 1, '2026-10-05 20:21:50', '0', NULL, NULL, NULL, NULL, 1, 'NONE');
INSERT INTO `pro_sn` VALUES (2107083841128509441, '000000', 'SN-FC-SCGD202610050001-9899-0010', 2106995561900978178, 'SCGD202610050001', 2107083840268677122, 'FC-SCGD202610050001-9899', 2106761349704929281, 'IF20261004006', 'M12高强度镀锌螺栓连接组件', 20, 'COMPLETED', NULL, NULL, 'BATCH', '2026-10-05', NULL, 103, 1, '2026-10-05 20:21:50', 1, '2026-10-05 20:21:50', '0', NULL, NULL, NULL, NULL, 1, 'NONE');
INSERT INTO `pro_sn` VALUES (2107328406297194497, '000000', 'SN-FC-SCGD202610060001-8774-0001', 2107323241485774850, 'SCGD202610060001', 2107328405412196354, 'FC-SCGD202610060001-8774', 2106761349704929281, 'IF20261004006', 'M12高强度镀锌螺栓连接组件', 20, 'SHIPPED', NULL, NULL, 'BATCH', '2026-10-06', NULL, 103, 1, '2026-10-06 12:33:39', 1, '2026-10-06 12:33:39', '0', NULL, NULL, NULL, NULL, 1, 'NONE');
INSERT INTO `pro_sn` VALUES (2107328406305583105, '000000', 'SN-FC-SCGD202610060001-8774-0002', 2107323241485774850, 'SCGD202610060001', 2107328405412196354, 'FC-SCGD202610060001-8774', 2106761349704929281, 'IF20261004006', 'M12高强度镀锌螺栓连接组件', 20, 'SHIPPED', NULL, NULL, 'BATCH', '2026-10-06', NULL, 103, 1, '2026-10-06 12:33:39', 1, '2026-10-06 12:33:39', '0', NULL, NULL, NULL, NULL, 1, 'NONE');
INSERT INTO `pro_sn` VALUES (2107328406313971714, '000000', 'SN-FC-SCGD202610060001-8774-0003', 2107323241485774850, 'SCGD202610060001', 2107328405412196354, 'FC-SCGD202610060001-8774', 2106761349704929281, 'IF20261004006', 'M12高强度镀锌螺栓连接组件', 20, 'SHIPPED', NULL, NULL, 'BATCH', '2026-10-06', NULL, 103, 1, '2026-10-06 12:33:39', 1, '2026-10-06 12:33:39', '0', NULL, NULL, NULL, NULL, 1, 'NONE');
INSERT INTO `pro_sn` VALUES (2107328406313971715, '000000', 'SN-FC-SCGD202610060001-8774-0004', 2107323241485774850, 'SCGD202610060001', 2107328405412196354, 'FC-SCGD202610060001-8774', 2106761349704929281, 'IF20261004006', 'M12高强度镀锌螺栓连接组件', 20, 'SHIPPED', NULL, NULL, 'BATCH', '2026-10-06', NULL, 103, 1, '2026-10-06 12:33:39', 1, '2026-10-06 12:33:39', '0', NULL, NULL, NULL, NULL, 1, 'NONE');
INSERT INTO `pro_sn` VALUES (2107328406326554626, '000000', 'SN-FC-SCGD202610060001-8774-0005', 2107323241485774850, 'SCGD202610060001', 2107328405412196354, 'FC-SCGD202610060001-8774', 2106761349704929281, 'IF20261004006', 'M12高强度镀锌螺栓连接组件', 20, 'SHIPPED', NULL, NULL, 'BATCH', '2026-10-06', NULL, 103, 1, '2026-10-06 12:33:39', 1, '2026-10-06 12:33:39', '0', NULL, NULL, NULL, NULL, 1, 'NONE');
INSERT INTO `pro_sn` VALUES (2107328406330748930, '000000', 'SN-FC-SCGD202610060001-8774-0006', 2107323241485774850, 'SCGD202610060001', 2107328405412196354, 'FC-SCGD202610060001-8774', 2106761349704929281, 'IF20261004006', 'M12高强度镀锌螺栓连接组件', 20, 'SHIPPED', NULL, NULL, 'BATCH', '2026-10-06', NULL, 103, 1, '2026-10-06 12:33:39', 1, '2026-10-06 12:33:39', '0', NULL, NULL, NULL, NULL, 1, 'NONE');
INSERT INTO `pro_sn` VALUES (2107524224652378114, '000000', 'SN-FC-SCGD202610060002-5604-0001', 2107352232221392898, 'SCGD202610060002', 2107524224165838850, 'FC-SCGD202610060002-5604', 2106761349704929281, 'IF20261004006', 'M12高强度镀锌螺栓连接组件', 20, 'SHIPPED', NULL, NULL, 'BATCH', '2026-10-07', NULL, 103, 1, '2026-10-07 01:31:46', 1, '2026-10-07 01:31:46', '0', NULL, NULL, NULL, NULL, 1, 'NONE');
INSERT INTO `pro_sn` VALUES (2107524224664961025, '000000', 'SN-FC-SCGD202610060002-5604-0002', 2107352232221392898, 'SCGD202610060002', 2107524224165838850, 'FC-SCGD202610060002-5604', 2106761349704929281, 'IF20261004006', 'M12高强度镀锌螺栓连接组件', 20, 'SHIPPED', NULL, NULL, 'BATCH', '2026-10-07', NULL, 103, 1, '2026-10-07 01:31:46', 1, '2026-10-07 01:31:46', '0', NULL, NULL, NULL, NULL, 1, 'NONE');
INSERT INTO `pro_sn` VALUES (2107524224669155330, '000000', 'SN-FC-SCGD202610060002-5604-0003', 2107352232221392898, 'SCGD202610060002', 2107524224165838850, 'FC-SCGD202610060002-5604', 2106761349704929281, 'IF20261004006', 'M12高强度镀锌螺栓连接组件', 20, 'SHIPPED', NULL, NULL, 'BATCH', '2026-10-07', NULL, 103, 1, '2026-10-07 01:31:46', 1, '2026-10-07 01:31:46', '0', NULL, NULL, NULL, NULL, 1, 'NONE');
INSERT INTO `pro_sn` VALUES (2107524224673349633, '000000', 'SN-FC-SCGD202610060002-5604-0004', 2107352232221392898, 'SCGD202610060002', 2107524224165838850, 'FC-SCGD202610060002-5604', 2106761349704929281, 'IF20261004006', 'M12高强度镀锌螺栓连接组件', 20, 'SHIPPED', NULL, NULL, 'BATCH', '2026-10-07', NULL, 103, 1, '2026-10-07 01:31:46', 1, '2026-10-07 01:31:46', '0', NULL, NULL, NULL, NULL, 1, 'NONE');
INSERT INTO `pro_sn` VALUES (2107524224681738242, '000000', 'SN-FC-SCGD202610060002-5604-0005', 2107352232221392898, 'SCGD202610060002', 2107524224165838850, 'FC-SCGD202610060002-5604', 2106761349704929281, 'IF20261004006', 'M12高强度镀锌螺栓连接组件', 20, 'SHIPPED', NULL, NULL, 'BATCH', '2026-10-07', NULL, 103, 1, '2026-10-07 01:31:46', 1, '2026-10-07 01:31:46', '0', NULL, NULL, NULL, NULL, 1, 'NONE');
INSERT INTO `pro_sn` VALUES (2107524224690126850, '000000', 'SN-FC-SCGD202610060002-5604-0006', 2107352232221392898, 'SCGD202610060002', 2107524224165838850, 'FC-SCGD202610060002-5604', 2106761349704929281, 'IF20261004006', 'M12高强度镀锌螺栓连接组件', 20, 'SHIPPED', NULL, NULL, 'BATCH', '2026-10-07', NULL, 103, 1, '2026-10-07 01:31:46', 1, '2026-10-07 01:31:46', '0', NULL, NULL, NULL, NULL, 1, 'NONE');

-- ----------------------------
-- Table structure for pro_step_check_rule
-- ----------------------------
DROP TABLE IF EXISTS `pro_step_check_rule`;
CREATE TABLE `pro_step_check_rule`  (
  `rule_id` bigint(20) NOT NULL COMMENT '规则ID(主键)',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '000000' COMMENT '租户ID',
  `process_id` bigint(20) NOT NULL COMMENT '工序ID',
  `check_type` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '校验类型',
  `check_stage` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '校验阶段: ENTRY/EXIT',
  `enabled` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '1' COMMENT '是否启用(0停用 1启用)',
  `error_msg` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '校验失败提示',
  `sort_order` int(4) NULL DEFAULT 0 COMMENT '排序',
  `create_dept` bigint(20) NULL DEFAULT NULL,
  `create_by` bigint(20) NULL DEFAULT NULL,
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP,
  `update_by` bigint(20) NULL DEFAULT NULL,
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP(0),
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '删除标志',
  PRIMARY KEY (`rule_id`) USING BTREE,
  INDEX `idx_process_id`(`process_id`) USING BTREE,
  INDEX `idx_check_stage`(`check_stage`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = 'MES工序校验规则配置' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for pro_step_guide
-- ----------------------------
DROP TABLE IF EXISTS `pro_step_guide`;
CREATE TABLE `pro_step_guide`  (
  `guide_id` bigint(20) NOT NULL COMMENT '指引ID(主键)',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '000000' COMMENT '租户ID',
  `process_id` bigint(20) NOT NULL COMMENT '工序ID(ERP bd_process.process_id)',
  `guide_type` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '指引类型: TEXT/SOP_LINK',
  `guide_title` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '指引标题',
  `guide_content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '文本内容(TEXT类型用)',
  `sop_id` bigint(20) NULL DEFAULT NULL COMMENT '关联SOP文档(SOP_LINK类型用)',
  `sort_order` int(4) NULL DEFAULT 0 COMMENT '排序',
  `enabled` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '1' COMMENT '是否启用(0停用 1启用)',
  `create_dept` bigint(20) NULL DEFAULT NULL,
  `create_by` bigint(20) NULL DEFAULT NULL,
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP,
  `update_by` bigint(20) NULL DEFAULT NULL,
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP(0),
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '删除标志',
  PRIMARY KEY (`guide_id`) USING BTREE,
  INDEX `idx_process_id`(`process_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = 'MES工序流程指引配置' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for pro_work_order
-- ----------------------------
DROP TABLE IF EXISTS `pro_work_order`;
CREATE TABLE `pro_work_order`  (
  `mes_wo_id` bigint(20) NOT NULL COMMENT 'MES工单ID(主键)',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '000000' COMMENT '租户ID',
  `erp_wo_id` bigint(20) NULL DEFAULT NULL COMMENT '关联ERP工单ID',
  `wo_no` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'MES工单编号(继承或派生)',
  `material_id` bigint(20) NULL DEFAULT NULL COMMENT '产品物料ID',
  `material_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '产品编码(冗余)',
  `material_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '产品名称(冗余)',
  `planned_qty` decimal(18, 4) NULL DEFAULT 0.0000 COMMENT '计划数量',
  `completed_qty` decimal(18, 4) NULL DEFAULT 0.0000 COMMENT '已完成数量',
  `scrap_qty` decimal(18, 4) NULL DEFAULT 0.0000 COMMENT '报废数量',
  `unit_id` bigint(20) NULL DEFAULT NULL COMMENT '单位ID',
  `unit_name` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '单位名称',
  `plan_start_date` datetime(0) NULL DEFAULT NULL COMMENT '计划开工日期',
  `plan_end_date` datetime(0) NULL DEFAULT NULL COMMENT '计划完工日期',
  `actual_start_date` datetime(0) NULL DEFAULT NULL COMMENT '实际开工时间',
  `actual_end_date` datetime(0) NULL DEFAULT NULL COMMENT '实际完工时间',
  `workshop_id` bigint(20) NULL DEFAULT NULL COMMENT '车间ID',
  `workshop_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '车间名称(冗余)',
  `bom_id` bigint(20) NULL DEFAULT NULL COMMENT 'BOM ID',
  `equipment_id` bigint(20) NULL DEFAULT NULL COMMENT '关联设备ID',
  `routing_id` bigint(20) NULL DEFAULT NULL COMMENT '工艺路线ID(MES侧维护)',
  `wo_status` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT 'CREATED' COMMENT '工单状态: CREATED/RELEASED/IN_PROGRESS/COMPLETED/CANCELLED',
  `priority` int(4) NULL DEFAULT 5 COMMENT '优先级(1最高,9最低)',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '备注',
  `select_flow_id` bigint(20) NULL DEFAULT NULL COMMENT '已选审批流程模板ID',
  `create_dept` bigint(20) NULL DEFAULT NULL COMMENT '创建部门',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建人',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新人',
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP(0) COMMENT '更新时间',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT '0' COMMENT '删除标志(0正常 1删除)',
  `source_type` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT 'ERP' COMMENT '工单来源(ERP/REWORK/MANUAL)',
  `release_package_id` bigint(20) NULL DEFAULT NULL COMMENT '发布包ID(mes_release_package, 工单按此包生成)',
  `release_package_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '发布包编码(冗余)',
  `release_package_ver` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '发布包版本(冗余快照)',
  `release_config` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT '发布包配置项快照(JSON数组, 供工位/报表消费)',
  PRIMARY KEY (`mes_wo_id`) USING BTREE,
  UNIQUE INDEX `uk_wo_no`(`tenant_id`, `wo_no`) USING BTREE,
  UNIQUE INDEX `uk_tenant_erp_wo`(`tenant_id`, `erp_wo_id`) USING BTREE,
  INDEX `idx_erp_wo_id`(`erp_wo_id`) USING BTREE,
  INDEX `idx_material_id`(`material_id`) USING BTREE,
  INDEX `idx_wo_status`(`wo_status`) USING BTREE,
  INDEX `idx_tenant_id`(`tenant_id`) USING BTREE,
  INDEX `idx_equipment_id`(`equipment_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = 'MES工单表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of pro_work_order
-- ----------------------------
INSERT INTO `pro_work_order` VALUES (2104803729263751169, '000000', 2104510684576272385, 'SCGD202609280001', 1, 'IF20260914001', '高强度螺栓组套 M12', 10.0000, 10.0000, 0.0000, 27, '套', '2026-09-29 00:00:00', '2026-10-09 00:00:00', '2026-10-01 12:16:08', '2026-10-01 12:30:02', 3, '冲压车间', 1, NULL, 1, 'COMPLETED', 5, NULL, NULL, -1, -1, '2026-09-29 13:21:29', -1, '2026-10-01 12:30:01', '0', 'ERP', NULL, NULL, NULL, NULL);
INSERT INTO `pro_work_order` VALUES (2106995561900978178, '000000', 2106995346720600065, 'SCGD202610050001', 2106761349704929281, 'IF20261004006', 'M12高强度镀锌螺栓连接组件', 10.0000, 10.0000, 0.0000, 26, '件', '2026-10-05 14:30:11', NULL, '2026-10-05 20:28:41', '2026-10-05 21:59:27', 12, '装配车间', 2106762033351315457, NULL, 2106995183973216258, 'COMPLETED', 5, NULL, NULL, -1, -1, '2026-10-05 14:31:03', -1, '2026-10-05 21:59:26', '0', 'ERP', NULL, NULL, NULL, NULL);
INSERT INTO `pro_work_order` VALUES (2107323241485774850, '000000', 2107322465837330433, 'SCGD202610060001', 2106761349704929281, 'IF20261004006', 'M12高强度镀锌螺栓连接组件', 6.0000, 6.0000, 0.0000, 26, '件', '2026-10-06 12:10:03', '2026-10-10 00:00:00', '2026-10-06 12:40:19', '2026-10-06 12:49:41', 12, '装配车间', 2106762033351315457, NULL, 2106995183973216258, 'COMPLETED', 5, NULL, NULL, -1, -1, '2026-10-06 12:13:08', -1, '2026-10-06 12:49:41', '0', 'ERP', NULL, NULL, NULL, NULL);
INSERT INTO `pro_work_order` VALUES (2107352232221392898, '000000', 2107352226521333762, 'SCGD202610060002', 2106761349704929281, 'IF20261004006', 'M12高强度镀锌螺栓连接组件', 6.0000, 6.0000, 0.0000, 26, '件', '2026-10-06 14:08:18', NULL, '2026-10-07 01:38:02', '2026-10-07 01:41:41', 12, '装配车间', 2106762033351315457, NULL, 2106995183973216258, 'COMPLETED', 5, NULL, NULL, -1, -1, '2026-10-06 14:08:20', -1, '2026-10-07 01:41:41', '0', 'ERP', NULL, NULL, NULL, NULL);
INSERT INTO `pro_work_order` VALUES (2108013109962543106, '000000', 2107969309344985089, 'SCGD202610080001', 2106761349704929281, 'IF20261004006', 'M12高强度镀锌螺栓连接组件', 4.0000, 0.0000, 0.0000, 26, '件', '2026-10-08 07:00:22', NULL, NULL, NULL, NULL, NULL, 2106762033351315457, NULL, 2106995183973216258, 'CREATED', 5, NULL, NULL, -1, -1, '2026-10-08 09:54:25', -1, '2026-10-08 09:54:25', '0', 'ERP', NULL, NULL, NULL, NULL);
INSERT INTO `pro_work_order` VALUES (2108617051121639426, '000000', 2108082632988254209, 'SCGD202610080009', 2106761349704929281, 'IF20261004006', 'M12高强度镀锌螺栓连接组件', 22.0000, 22.0000, 0.0000, 26, '件', '2026-10-22 00:00:00', '2026-10-26 23:59:59', '2026-10-10 09:57:25', '2026-10-10 09:57:27', 13, '测试车间', 2106762033351315457, NULL, 2106995183973216258, 'COMPLETED', 5, NULL, NULL, -1, -1, '2026-10-10 01:54:16', -1, '2026-10-10 09:57:26', '0', 'ERP', NULL, NULL, NULL, NULL);
INSERT INTO `pro_work_order` VALUES (2108617060583989249, '000000', 2108082643172024321, 'SCGD202610080013', 2106761349704929281, 'IF20261004006', 'M12高强度镀锌螺栓连接组件', 22.0000, 22.0000, 0.0000, 26, '件', '2026-10-26 00:00:00', '2026-10-27 23:59:59', '2026-10-10 05:47:55', '2026-10-10 05:47:56', 13, '测试车间', 2106762033351315457, NULL, 2106995183973216258, 'COMPLETED', 5, NULL, NULL, -1, -1, '2026-10-10 01:54:18', -1, '2026-10-10 05:47:55', '0', 'ERP', NULL, NULL, NULL, NULL);
INSERT INTO `pro_work_order` VALUES (2108617069803069441, '000000', 2108082653523566594, 'SCGD202610080017', 2106761349704929281, 'IF20261004006', 'M12高强度镀锌螺栓连接组件', 22.0000, 22.0000, 0.0000, 26, '件', '2026-10-27 00:00:00', '2026-10-29 23:59:59', '2026-10-10 05:53:32', '2026-10-10 05:53:33', 13, '测试车间', 2106762033351315457, NULL, 2106995183973216258, 'COMPLETED', 5, NULL, NULL, -1, -1, '2026-10-10 01:54:20', -1, '2026-10-10 05:53:32', '0', 'ERP', NULL, NULL, NULL, NULL);

-- ----------------------------
-- Table structure for pro_work_order_bom_line
-- ----------------------------
DROP TABLE IF EXISTS `pro_work_order_bom_line`;
CREATE TABLE `pro_work_order_bom_line`  (
  `wo_bom_line_id` bigint(20) NOT NULL COMMENT '快照明细ID(主键)',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '000000' COMMENT '租户ID',
  `mes_wo_id` bigint(20) NOT NULL COMMENT '关联MES工单ID',
  `mbom_line_id` bigint(20) NULL DEFAULT NULL COMMENT '源mes_mbom_line.mbom_line_id(可空,无MBOM时)',
  `bom_id` bigint(20) NULL DEFAULT NULL COMMENT 'ERP BOM ID',
  `bom_detail_id` bigint(20) NULL DEFAULT NULL COMMENT 'ERP明细ID(溯源)',
  `child_material_id` bigint(20) NOT NULL COMMENT '子项物料ID',
  `child_material_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '物料编码(冗余)',
  `child_material_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '物料名称(冗余)',
  `quantity_per_parent` decimal(18, 6) NOT NULL COMMENT '单位父项用量',
  `loss_rate` decimal(8, 4) NULL DEFAULT 0.0000 COMMENT '损耗率(%)',
  `total_quantity` decimal(18, 6) NULL DEFAULT NULL COMMENT '含损耗用量 = qty × (1 + loss/100)',
  `routing_step_id` bigint(20) NULL DEFAULT NULL COMMENT '工序步骤ID',
  `sequence_num` int(11) NULL DEFAULT NULL COMMENT '工序序号(冗余)',
  `process_id` bigint(20) NULL DEFAULT NULL COMMENT '工序ID',
  `process_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '工序编码(冗余)',
  `process_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '工序名称(冗余)',
  `workstation_id` bigint(20) NULL DEFAULT NULL COMMENT '工位ID',
  `workstation_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '工位编码(冗余)',
  `workstation_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '工位名称(冗余)',
  `operation_content` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '作业内容',
  `backflush_flag` tinyint(1) NULL DEFAULT 0 COMMENT '是否倒冲 0否1是',
  `sort_order` int(11) NULL DEFAULT 0 COMMENT '显示排序',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '备注',
  `create_dept` bigint(20) NULL DEFAULT NULL COMMENT '创建部门',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT '0' COMMENT '删除标志',
  PRIMARY KEY (`wo_bom_line_id`) USING BTREE,
  INDEX `idx_mes_wo_id`(`mes_wo_id`) USING BTREE,
  INDEX `idx_child_material_id`(`child_material_id`) USING BTREE,
  INDEX `idx_tenant_id`(`tenant_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = 'MES工单BOM明细快照' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of pro_work_order_bom_line
-- ----------------------------
INSERT INTO `pro_work_order_bom_line` VALUES (2104803729465077762, '000000', 2104803729263751169, 1, 1, NULL, 38, 'IF20260914038', '冷镦坯 M12', 1.000000, 0.0000, 1.000000, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, NULL, -1, -1, '2026-09-29 13:21:29', -1, '2026-09-29 13:21:29', '0');
INSERT INTO `pro_work_order_bom_line` VALUES (2104803729527992321, '000000', 2104803729263751169, 2, 1, NULL, 39, 'IF20260914039', '螺母 M12 8级', 1.000000, 0.0000, 1.000000, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 2, NULL, -1, -1, '2026-09-29 13:21:29', -1, '2026-09-29 13:21:29', '0');
INSERT INTO `pro_work_order_bom_line` VALUES (2104803729540575234, '000000', 2104803729263751169, 3, 1, NULL, 40, 'IF20260914040', '平垫 M12', 2.000000, 0.0000, 2.000000, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 3, NULL, -1, -1, '2026-09-29 13:21:29', -1, '2026-09-29 13:21:29', '0');
INSERT INTO `pro_work_order_bom_line` VALUES (2104803729557352450, '000000', 2104803729263751169, 4, 1, NULL, 140, 'IF20260914140', '包装纸盒 小号', 1.000000, 0.0000, 1.000000, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 4, NULL, -1, -1, '2026-09-29 13:21:29', -1, '2026-09-29 13:21:29', '0');
INSERT INTO `pro_work_order_bom_line` VALUES (2106995562014224385, '000000', 2106995561900978178, 2106995185059540994, 2106762033351315457, 2106762033816883202, 2106760678595317762, 'IF20261004003', '六角头螺栓 M12×50 8.8级 镀锌', 1.000000, 0.0000, 1.000000, 2106995184052908033, 10, 44, 'ASM', '装配', 46, 'GZZ0046', '装配线A', NULL, 0, 1, NULL, -1, -1, '2026-10-05 14:31:03', -1, '2026-10-05 14:31:03', '0');
INSERT INTO `pro_work_order_bom_line` VALUES (2106995562081333249, '000000', 2106995561900978178, 2106995185126649857, 2106762033351315457, 2106762034014015489, 2106760679291572226, 'IF20261004004', '六角螺母 M12 8级 镀锌', 1.000000, 0.0000, 1.000000, 2106995184052908033, 10, 44, 'ASM', '装配', 46, 'GZZ0046', '装配线A', NULL, 0, 2, NULL, -1, -1, '2026-10-05 14:31:03', -1, '2026-10-05 14:31:03', '0');
INSERT INTO `pro_work_order_bom_line` VALUES (2106995562093916162, '000000', 2106995561900978178, 2106995185139232770, 2106762033351315457, 2106762034135650306, 2106760679643893762, 'IF20261004005', '平垫圈 12 A级 镀锌', 2.000000, 0.0000, 2.000000, 2106995184052908033, 10, 44, 'ASM', '装配', 46, 'GZZ0046', '装配线A', NULL, 0, 3, NULL, -1, -1, '2026-10-05 14:31:03', -1, '2026-10-05 14:31:03', '0');
INSERT INTO `pro_work_order_bom_line` VALUES (2107323241531912194, '000000', 2107323241485774850, 2106995185059540994, 2106762033351315457, 2106762033816883202, 2106760678595317762, 'IF20261004003', '六角头螺栓 M12×50 8.8级 镀锌', 1.000000, 0.0000, 1.000000, 2106995184052908033, 10, 44, 'ASM', '装配', 46, 'GZZ0046', '装配线A', NULL, 0, 1, NULL, -1, -1, '2026-10-06 12:13:08', -1, '2026-10-06 12:13:08', '0');
INSERT INTO `pro_work_order_bom_line` VALUES (2107323241565466625, '000000', 2107323241485774850, 2106995185126649857, 2106762033351315457, 2106762034014015489, 2106760679291572226, 'IF20261004004', '六角螺母 M12 8级 镀锌', 1.000000, 0.0000, 1.000000, 2106995184052908033, 10, 44, 'ASM', '装配', 46, 'GZZ0046', '装配线A', NULL, 0, 2, NULL, -1, -1, '2026-10-06 12:13:08', -1, '2026-10-06 12:13:08', '0');
INSERT INTO `pro_work_order_bom_line` VALUES (2107323241573855234, '000000', 2107323241485774850, 2106995185139232770, 2106762033351315457, 2106762034135650306, 2106760679643893762, 'IF20261004005', '平垫圈 12 A级 镀锌', 2.000000, 0.0000, 2.000000, 2106995184052908033, 10, 44, 'ASM', '装配', 46, 'GZZ0046', '装配线A', NULL, 0, 3, NULL, -1, -1, '2026-10-06 12:13:08', -1, '2026-10-06 12:13:08', '0');
INSERT INTO `pro_work_order_bom_line` VALUES (2107352232309473282, '000000', 2107352232221392898, 2106995185059540994, 2106762033351315457, 2106762033816883202, 2106760678595317762, 'IF20261004003', '六角头螺栓 M12×50 8.8级 镀锌', 1.000000, 0.0000, 1.000000, 2106995184052908033, 10, 44, 'ASM', '装配', 46, 'GZZ0046', '装配线A', NULL, 0, 1, NULL, -1, -1, '2026-10-06 14:08:20', -1, '2026-10-06 14:08:20', '0');
INSERT INTO `pro_work_order_bom_line` VALUES (2107352232334639106, '000000', 2107352232221392898, 2106995185126649857, 2106762033351315457, 2106762034014015489, 2106760679291572226, 'IF20261004004', '六角螺母 M12 8级 镀锌', 1.000000, 0.0000, 1.000000, 2106995184052908033, 10, 44, 'ASM', '装配', 46, 'GZZ0046', '装配线A', NULL, 0, 2, NULL, -1, -1, '2026-10-06 14:08:20', -1, '2026-10-06 14:08:20', '0');
INSERT INTO `pro_work_order_bom_line` VALUES (2107352232338833409, '000000', 2107352232221392898, 2106995185139232770, 2106762033351315457, 2106762034135650306, 2106760679643893762, 'IF20261004005', '平垫圈 12 A级 镀锌', 2.000000, 0.0000, 2.000000, 2106995184052908033, 10, 44, 'ASM', '装配', 46, 'GZZ0046', '装配线A', NULL, 0, 3, NULL, -1, -1, '2026-10-06 14:08:20', -1, '2026-10-06 14:08:20', '0');
INSERT INTO `pro_work_order_bom_line` VALUES (2108013110075789314, '000000', 2108013109962543106, 2106995185059540994, 2106762033351315457, 2106762033816883202, 2106760678595317762, 'IF20261004003', '六角头螺栓 M12×50 8.8级 镀锌', 1.000000, 0.0000, 1.000000, 2106995184052908033, 10, 44, 'ASM', '装配', 46, 'GZZ0046', '装配线A', NULL, 0, 1, NULL, -1, -1, '2026-10-08 09:54:25', -1, '2026-10-08 09:54:25', '0');
INSERT INTO `pro_work_order_bom_line` VALUES (2108013110130315265, '000000', 2108013109962543106, 2106995185126649857, 2106762033351315457, 2106762034014015489, 2106760679291572226, 'IF20261004004', '六角螺母 M12 8级 镀锌', 1.000000, 0.0000, 1.000000, 2106995184052908033, 10, 44, 'ASM', '装配', 46, 'GZZ0046', '装配线A', NULL, 0, 2, NULL, -1, -1, '2026-10-08 09:54:25', -1, '2026-10-08 09:54:25', '0');
INSERT INTO `pro_work_order_bom_line` VALUES (2108013110138703874, '000000', 2108013109962543106, 2106995185139232770, 2106762033351315457, 2106762034135650306, 2106760679643893762, 'IF20261004005', '平垫圈 12 A级 镀锌', 2.000000, 0.0000, 2.000000, 2106995184052908033, 10, 44, 'ASM', '装配', 46, 'GZZ0046', '装配线A', NULL, 0, 3, NULL, -1, -1, '2026-10-08 09:54:25', -1, '2026-10-08 09:54:25', '0');
INSERT INTO `pro_work_order_bom_line` VALUES (2108617051180359681, '000000', 2108617051121639426, 2106995185059540994, 2106762033351315457, 2106762033816883202, 2106760678595317762, 'IF20261004003', '六角头螺栓 M12×50 8.8级 镀锌', 1.000000, 0.0000, 1.000000, 2106995184052908033, 10, 44, 'ASM', '装配', 46, 'GZZ0046', '装配线A', NULL, 0, 1, NULL, -1, -1, '2026-10-10 01:54:16', -1, '2026-10-10 01:54:16', '0');
INSERT INTO `pro_work_order_bom_line` VALUES (2108617051205525506, '000000', 2108617051121639426, 2106995185126649857, 2106762033351315457, 2106762034014015489, 2106760679291572226, 'IF20261004004', '六角螺母 M12 8级 镀锌', 1.000000, 0.0000, 1.000000, 2106995184052908033, 10, 44, 'ASM', '装配', 46, 'GZZ0046', '装配线A', NULL, 0, 2, NULL, -1, -1, '2026-10-10 01:54:16', -1, '2026-10-10 01:54:16', '0');
INSERT INTO `pro_work_order_bom_line` VALUES (2108617051213914114, '000000', 2108617051121639426, 2106995185139232770, 2106762033351315457, 2106762034135650306, 2106760679643893762, 'IF20261004005', '平垫圈 12 A级 镀锌', 2.000000, 0.0000, 2.000000, 2106995184052908033, 10, 44, 'ASM', '装配', 46, 'GZZ0046', '装配线A', NULL, 0, 3, NULL, -1, -1, '2026-10-10 01:54:16', -1, '2026-10-10 01:54:16', '0');
INSERT INTO `pro_work_order_bom_line` VALUES (2108617060604960770, '000000', 2108617060583989249, 2106995185059540994, 2106762033351315457, 2106762033816883202, 2106760678595317762, 'IF20261004003', '六角头螺栓 M12×50 8.8级 镀锌', 1.000000, 0.0000, 1.000000, 2106995184052908033, 10, 44, 'ASM', '装配', 46, 'GZZ0046', '装配线A', NULL, 0, 1, NULL, -1, -1, '2026-10-10 01:54:18', -1, '2026-10-10 01:54:18', '0');
INSERT INTO `pro_work_order_bom_line` VALUES (2108617060613349377, '000000', 2108617060583989249, 2106995185126649857, 2106762033351315457, 2106762034014015489, 2106760679291572226, 'IF20261004004', '六角螺母 M12 8级 镀锌', 1.000000, 0.0000, 1.000000, 2106995184052908033, 10, 44, 'ASM', '装配', 46, 'GZZ0046', '装配线A', NULL, 0, 2, NULL, -1, -1, '2026-10-10 01:54:18', -1, '2026-10-10 01:54:18', '0');
INSERT INTO `pro_work_order_bom_line` VALUES (2108617060621737986, '000000', 2108617060583989249, 2106995185139232770, 2106762033351315457, 2106762034135650306, 2106760679643893762, 'IF20261004005', '平垫圈 12 A级 镀锌', 2.000000, 0.0000, 2.000000, 2106995184052908033, 10, 44, 'ASM', '装配', 46, 'GZZ0046', '装配线A', NULL, 0, 3, NULL, -1, -1, '2026-10-10 01:54:18', -1, '2026-10-10 01:54:18', '0');
INSERT INTO `pro_work_order_bom_line` VALUES (2108617069824040961, '000000', 2108617069803069441, 2106995185059540994, 2106762033351315457, 2106762033816883202, 2106760678595317762, 'IF20261004003', '六角头螺栓 M12×50 8.8级 镀锌', 1.000000, 0.0000, 1.000000, 2106995184052908033, 10, 44, 'ASM', '装配', 46, 'GZZ0046', '装配线A', NULL, 0, 1, NULL, -1, -1, '2026-10-10 01:54:20', -1, '2026-10-10 01:54:20', '0');
INSERT INTO `pro_work_order_bom_line` VALUES (2108617069832429569, '000000', 2108617069803069441, 2106995185126649857, 2106762033351315457, 2106762034014015489, 2106760679291572226, 'IF20261004004', '六角螺母 M12 8级 镀锌', 1.000000, 0.0000, 1.000000, 2106995184052908033, 10, 44, 'ASM', '装配', 46, 'GZZ0046', '装配线A', NULL, 0, 2, NULL, -1, -1, '2026-10-10 01:54:20', -1, '2026-10-10 01:54:20', '0');
INSERT INTO `pro_work_order_bom_line` VALUES (2108617069832429570, '000000', 2108617069803069441, 2106995185139232770, 2106762033351315457, 2106762034135650306, 2106760679643893762, 'IF20261004005', '平垫圈 12 A级 镀锌', 2.000000, 0.0000, 2.000000, 2106995184052908033, 10, 44, 'ASM', '装配', 46, 'GZZ0046', '装配线A', NULL, 0, 3, NULL, -1, -1, '2026-10-10 01:54:20', -1, '2026-10-10 01:54:20', '0');

-- ----------------------------
-- Table structure for pro_work_order_step
-- ----------------------------
DROP TABLE IF EXISTS `pro_work_order_step`;
CREATE TABLE `pro_work_order_step`  (
  `step_id` bigint(20) NOT NULL COMMENT '工序步骤ID(主键)',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '000000' COMMENT '租户ID',
  `mes_wo_id` bigint(20) NOT NULL COMMENT '所属MES工单ID',
  `sequence_num` int(4) NOT NULL DEFAULT 0 COMMENT '工序序号(从1开始)',
  `step_type` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'GENERAL' COMMENT '工序类型: GENERAL/FLASH/TEST',
  `content_ref_type` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '内容引用类型(单类型快捷绑定: FIRMWARE/CONFIG/MAC_POOL...)',
  `content_ref_id` bigint(20) NULL DEFAULT NULL COMMENT '内容源记录ID(固件类=mes_firmware_id)',
  `step_flash_config` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT '多类型绑定JSON: [{\"flashTypeCode\":\"firmware_file\",\"contentRefId\":123},{\"flashTypeCode\":\"mac\"}]',
  `process_id` bigint(20) NULL DEFAULT NULL COMMENT 'ERP工序ID(bd_routing_step.routing_step_id)',
  `process_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '工序编码(冗余)',
  `process_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '工序名称(冗余)',
  `workcenter_id` bigint(20) NULL DEFAULT NULL COMMENT '工作中心ID',
  `workcenter_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '工作中心编码(冗余)',
  `planned_qty` decimal(18, 4) NULL DEFAULT 0.0000 COMMENT '计划数量',
  `completed_qty` decimal(18, 4) NULL DEFAULT 0.0000 COMMENT '完成数量',
  `scrap_qty` decimal(18, 4) NULL DEFAULT 0.0000 COMMENT '报废数量',
  `step_status` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT 'PENDING' COMMENT '工序状态: PENDING/READY/IN_PROGRESS/COMPLETED/SKIPPED',
  `is_key_process` tinyint(1) NULL DEFAULT 0 COMMENT '是否关键工序(0否 1是)',
  `start_time` datetime(0) NULL DEFAULT NULL COMMENT '开始时间',
  `end_time` datetime(0) NULL DEFAULT NULL COMMENT '结束时间',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '备注',
  `create_dept` bigint(20) NULL DEFAULT NULL COMMENT '创建部门',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建人',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新人',
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP(0) COMMENT '更新时间',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT '0' COMMENT '删除标志(0正常 1删除)',
  `firmware_source` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '固件来源: PACKAGE/ROUTING/MATERIAL_DEFAULT/MANUAL',
  PRIMARY KEY (`step_id`) USING BTREE,
  INDEX `idx_mes_wo_id`(`mes_wo_id`) USING BTREE,
  INDEX `idx_step_status`(`step_status`) USING BTREE,
  INDEX `idx_tenant_id`(`tenant_id`) USING BTREE,
  INDEX `idx_step_type`(`tenant_id`, `step_type`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = 'MES工单工序步骤表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of pro_work_order_step
-- ----------------------------
INSERT INTO `pro_work_order_step` VALUES (2104803729293111298, '000000', 2104803729263751169, 10, 'GENERAL', NULL, NULL, NULL, 9, 'FORGE', '锻造', 16, 'GZZ0016', 10.0000, 0.0000, 0.0000, 'PENDING', 0, NULL, NULL, NULL, -1, -1, '2026-09-29 13:21:29', -1, '2026-09-29 13:21:29', '0', NULL);
INSERT INTO `pro_work_order_step` VALUES (2104803729360220162, '000000', 2104803729263751169, 20, 'GENERAL', NULL, NULL, NULL, 10, 'TURN', '车削', 5, 'GZZ0005', 10.0000, 0.0000, 0.0000, 'PENDING', 0, NULL, NULL, NULL, -1, -1, '2026-09-29 13:21:29', -1, '2026-09-29 13:21:29', '0', NULL);
INSERT INTO `pro_work_order_step` VALUES (2104803729376997377, '000000', 2104803729263751169, 30, 'GENERAL', NULL, NULL, NULL, 27, 'QUENCH', '淬火', 31, 'GZZ0031', 10.0000, 0.0000, 0.0000, 'PENDING', 0, NULL, NULL, NULL, -1, -1, '2026-09-29 13:21:29', -1, '2026-09-29 13:21:29', '0', NULL);
INSERT INTO `pro_work_order_step` VALUES (2104803729389580290, '000000', 2104803729263751169, 40, 'GENERAL', NULL, NULL, NULL, 28, 'TEMPER', '回火', 32, 'GZZ0032', 10.0000, 0.0000, 0.0000, 'PENDING', 0, NULL, NULL, NULL, -1, -1, '2026-09-29 13:21:29', -1, '2026-09-29 13:21:29', '0', NULL);
INSERT INTO `pro_work_order_step` VALUES (2104803729402163202, '000000', 2104803729263751169, 50, 'GENERAL', NULL, NULL, NULL, 31, 'PLATE', '电镀', 34, 'GZZ0034', 10.0000, 0.0000, 0.0000, 'PENDING', 0, NULL, NULL, NULL, -1, -1, '2026-09-29 13:21:29', -1, '2026-09-29 13:21:29', '0', NULL);
INSERT INTO `pro_work_order_step` VALUES (2104803729423134722, '000000', 2104803729263751169, 60, 'GENERAL', NULL, NULL, NULL, 54, 'QC', '质检', 52, 'GZZ0052', 10.0000, 0.0000, 0.0000, 'PENDING', 0, NULL, NULL, NULL, -1, -1, '2026-09-29 13:21:29', -1, '2026-09-29 13:21:29', '0', NULL);
INSERT INTO `pro_work_order_step` VALUES (2104803729439911938, '000000', 2104803729263751169, 70, 'GENERAL', NULL, NULL, NULL, 55, 'PKG', '包装', 53, 'GZZ0053', 10.0000, 0.0000, 0.0000, 'PENDING', 0, NULL, NULL, NULL, -1, -1, '2026-09-29 13:21:29', -1, '2026-09-29 13:21:29', '0', NULL);
INSERT INTO `pro_work_order_step` VALUES (2106995561926144002, '000000', 2106995561900978178, 10, 'GENERAL', NULL, NULL, NULL, 44, 'ASM', '装配', 46, 'GZZ0046', 10.0000, 10.0000, 0.0000, 'COMPLETED', 0, '2026-10-05 20:28:41', '2026-10-05 20:28:42', NULL, -1, -1, '2026-10-05 14:31:03', -1, '2026-10-06 09:22:36', '0', NULL);
INSERT INTO `pro_work_order_step` VALUES (2106995561989058562, '000000', 2106995561900978178, 20, 'GENERAL', NULL, NULL, NULL, 54, 'QC', '质检', 52, 'GZZ0052', 10.0000, 10.0000, 0.0000, 'COMPLETED', 1, '2026-10-05 20:28:42', '2026-10-05 21:59:27', NULL, -1, -1, '2026-10-05 14:31:03', -1, '2026-10-06 09:22:36', '0', NULL);
INSERT INTO `pro_work_order_step` VALUES (2107323241506746370, '000000', 2107323241485774850, 10, 'GENERAL', NULL, NULL, NULL, 44, 'ASM', '装配', 46, 'GZZ0046', 6.0000, 6.0000, 0.0000, 'COMPLETED', 0, '2026-10-06 12:40:19', '2026-10-06 12:40:19', NULL, -1, -1, '2026-10-06 12:13:08', -1, '2026-10-06 12:40:19', '0', NULL);
INSERT INTO `pro_work_order_step` VALUES (2107323241519329281, '000000', 2107323241485774850, 20, 'GENERAL', NULL, NULL, NULL, 54, 'QC', '质检', 52, 'GZZ0052', 6.0000, 6.0000, 0.0000, 'COMPLETED', 1, '2026-10-06 12:42:36', '2026-10-06 12:49:41', NULL, -1, -1, '2026-10-06 12:13:08', -1, '2026-10-06 12:49:41', '0', NULL);
INSERT INTO `pro_work_order_step` VALUES (2107352232246558721, '000000', 2107352232221392898, 10, 'GENERAL', NULL, NULL, NULL, 44, 'ASM', '装配', 46, 'GZZ0046', 6.0000, 6.0000, 0.0000, 'COMPLETED', 0, '2026-10-07 01:38:02', '2026-10-07 01:38:03', NULL, -1, -1, '2026-10-06 14:08:20', -1, '2026-10-07 01:38:02', '0', NULL);
INSERT INTO `pro_work_order_step` VALUES (2107352232280113154, '000000', 2107352232221392898, 20, 'GENERAL', NULL, NULL, NULL, 54, 'QC', '质检', 52, 'GZZ0052', 6.0000, 6.0000, 0.0000, 'COMPLETED', 1, '2026-10-07 01:38:03', '2026-10-07 01:41:41', NULL, -1, -1, '2026-10-06 14:08:20', -1, '2026-10-07 01:41:41', '0', NULL);
INSERT INTO `pro_work_order_step` VALUES (2108013109987708929, '000000', 2108013109962543106, 10, 'GENERAL', NULL, NULL, NULL, 44, 'ASM', '装配', 46, 'GZZ0046', 4.0000, 0.0000, 0.0000, 'PENDING', 0, NULL, NULL, NULL, -1, -1, '2026-10-08 09:54:25', -1, '2026-10-08 09:54:25', '0', NULL);
INSERT INTO `pro_work_order_step` VALUES (2108013110054817793, '000000', 2108013109962543106, 20, 'GENERAL', NULL, NULL, NULL, 54, 'QC', '质检', 52, 'GZZ0052', 4.0000, 0.0000, 0.0000, 'PENDING', 1, NULL, NULL, NULL, -1, -1, '2026-10-08 09:54:25', -1, '2026-10-08 09:54:25', '0', NULL);
INSERT INTO `pro_work_order_step` VALUES (2108617051146805249, '000000', 2108617051121639426, 10, 'GENERAL', NULL, NULL, NULL, 44, 'ASM', '装配', 46, 'GZZ0046', 22.0000, 22.0000, 0.0000, 'COMPLETED', 0, '2026-10-10 09:57:25', '2026-10-10 09:57:25', NULL, -1, -1, '2026-10-10 01:54:16', -1, '2026-10-10 09:57:25', '0', NULL);
INSERT INTO `pro_work_order_step` VALUES (2108617051167776769, '000000', 2108617051121639426, 20, 'GENERAL', NULL, NULL, NULL, 54, 'QC', '质检', 52, 'GZZ0052', 22.0000, 22.0000, 0.0000, 'COMPLETED', 1, '2026-10-10 09:57:26', '2026-10-10 09:57:26', NULL, -1, -1, '2026-10-10 01:54:16', -1, '2026-10-10 09:57:26', '0', NULL);
INSERT INTO `pro_work_order_step` VALUES (2108617060596572162, '000000', 2108617060583989249, 10, 'GENERAL', NULL, NULL, NULL, 44, 'ASM', '装配', 46, 'GZZ0046', 22.0000, 22.0000, 0.0000, 'COMPLETED', 0, '2026-10-10 05:47:55', '2026-10-10 05:47:55', NULL, -1, -1, '2026-10-10 01:54:18', -1, '2026-10-10 05:47:54', '0', NULL);
INSERT INTO `pro_work_order_step` VALUES (2108617060596572163, '000000', 2108617060583989249, 20, 'GENERAL', NULL, NULL, NULL, 54, 'QC', '质检', 52, 'GZZ0052', 22.0000, 22.0000, 0.0000, 'COMPLETED', 1, '2026-10-10 05:47:55', '2026-10-10 05:47:56', NULL, -1, -1, '2026-10-10 01:54:18', -1, '2026-10-10 05:47:55', '0', NULL);
INSERT INTO `pro_work_order_step` VALUES (2108617069815652353, '000000', 2108617069803069441, 10, 'GENERAL', NULL, NULL, NULL, 44, 'ASM', '装配', 46, 'GZZ0046', 22.0000, 22.0000, 0.0000, 'COMPLETED', 0, '2026-10-10 05:53:32', '2026-10-10 05:53:32', NULL, -1, -1, '2026-10-10 01:54:20', -1, '2026-10-10 05:53:32', '0', NULL);
INSERT INTO `pro_work_order_step` VALUES (2108617069815652354, '000000', 2108617069803069441, 20, 'GENERAL', NULL, NULL, NULL, 54, 'QC', '质检', 52, 'GZZ0052', 22.0000, 22.0000, 0.0000, 'COMPLETED', 1, '2026-10-10 05:53:32', '2026-10-10 05:53:33', NULL, -1, -1, '2026-10-10 01:54:20', -1, '2026-10-10 05:53:32', '0', NULL);

-- ----------------------------
-- Table structure for qc_inspect_detail
-- ----------------------------
DROP TABLE IF EXISTS `qc_inspect_detail`;
CREATE TABLE `qc_inspect_detail`  (
  `detail_id` bigint(20) NOT NULL COMMENT '检验明细ID(主键)',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '000000' COMMENT '租户ID',
  `check_id` bigint(20) NOT NULL COMMENT '检验单ID(qc_iqc.iqc_id/qc_ipqc.ipqc_id/qc_oqc.oqc_id)',
  `check_type` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '检验类别: IQC/IPQC/OQC',
  `template_id` bigint(20) NULL DEFAULT NULL COMMENT '来源模板ID(快照溯源)',
  `item_id` bigint(20) NULL DEFAULT NULL COMMENT '来源检验项目ID',
  `item_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '项目编码(快照)',
  `item_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '项目名称(快照)',
  `data_type` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT 'QUANTITATIVE' COMMENT '数据类型(快照): QUANTITATIVE/QUALITATIVE',
  `standard_type` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '标准类型(快照): NOMINAL/LSL_ONLY/USL_ONLY/LSL_USL',
  `standard_desc` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '标准快照描述(如10±0.05mm)',
  `unit` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '单位(快照)',
  `criticality` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT 'MAJOR' COMMENT '关键度(快照): CRITICAL/MAJOR/MINOR',
  `sample_qty` decimal(14, 4) NULL DEFAULT NULL COMMENT '样本量',
  `measured_value` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '实测值(定量:数值/多值; 定性:OK/NG等)',
  `nominal_value` decimal(18, 6) NULL DEFAULT NULL COMMENT '名义值(快照, 判定用)',
  `lsl_value` decimal(18, 6) NULL DEFAULT NULL COMMENT '下限(快照, 判定用)',
  `usl_value` decimal(18, 6) NULL DEFAULT NULL COMMENT '上限(快照, 判定用)',
  `tol_upper` decimal(18, 6) NULL DEFAULT NULL COMMENT '上公差(快照, 判定用)',
  `tol_lower` decimal(18, 6) NULL DEFAULT NULL COMMENT '下公差(快照, 判定用)',
  `judge_result` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT 'PENDING' COMMENT '判定结果: PASS/FAIL/PENDING',
  `seq_num` int(11) NULL DEFAULT 1 COMMENT '序号',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '备注',
  `create_dept` bigint(20) NULL DEFAULT NULL COMMENT '创建部门',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT '0' COMMENT '删除标志',
  PRIMARY KEY (`detail_id`) USING BTREE,
  INDEX `idx_check`(`check_type`, `check_id`) USING BTREE,
  INDEX `idx_check_id`(`check_id`) USING BTREE,
  INDEX `idx_tenant_id`(`tenant_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = 'QC检验单明细' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of qc_inspect_detail
-- ----------------------------
INSERT INTO `qc_inspect_detail` VALUES (2107086753934225409, '000000', 2107086753833562114, 'IPQC', 2107083839501119490, 2107083839576616961, 'M12_BOLT_COUNT', '螺栓装配数量', 'QUANTITATIVE', 'NOMINAL', '1 ± 0 件/套', '件/套', 'MAJOR', 10.0000, '1,1,1,1,1,1,1,1,1,1', 1.000000, NULL, NULL, 0.000000, 0.000000, 'PASS', 1, '十套软件输入样本；每个数表示每套装配件数量，标准源自原BOM。', 103, 1, '2026-10-05 20:33:25', 1, '2026-10-05 20:33:25', '0');
INSERT INTO `qc_inspect_detail` VALUES (2107086753946808321, '000000', 2107086753833562114, 'IPQC', 2107083839501119490, 2107083839647920129, 'M12_NUT_COUNT', '螺母装配数量', 'QUANTITATIVE', 'NOMINAL', '1 ± 0 件/套', '件/套', 'MAJOR', 10.0000, '1,1,1,1,1,1,1,1,1,1', 1.000000, NULL, NULL, 0.000000, 0.000000, 'PASS', 2, '十套软件输入样本；每个数表示每套装配件数量，标准源自原BOM。', 103, 1, '2026-10-05 20:33:25', 1, '2026-10-05 20:33:25', '0');
INSERT INTO `qc_inspect_detail` VALUES (2107086753946808322, '000000', 2107086753833562114, 'IPQC', 2107083839501119490, 2107083839660503042, 'M12_WASHER_COUNT', '平垫圈装配数量', 'QUANTITATIVE', 'NOMINAL', '2 ± 0 件/套', '件/套', 'MAJOR', 10.0000, '2,2,2,2,2,2,2,2,2,2', 2.000000, NULL, NULL, 0.000000, 0.000000, 'PASS', 3, '十套软件输入样本；每个数表示每套装配件数量，标准源自原BOM。', 103, 1, '2026-10-05 20:33:25', 1, '2026-10-05 20:33:25', '0');
INSERT INTO `qc_inspect_detail` VALUES (2107125050769321985, '000000', 2107125050639298561, 'OQC', 2107114370913710081, 2107114370985013250, 'M12_OQC_BOLT_COUNT', '螺栓配套数量', 'QUANTITATIVE', 'NOMINAL', '1 ± 0 件/套', '件/套', 'MAJOR', 10.0000, '1,1,1,1,1,1,1,1,1,1', 1.000000, NULL, NULL, 0.000000, 0.000000, 'PASS', 1, '每项十套软件样本；标准来源原BOM1/1/2件单耗。', 103, 1, '2026-10-05 23:05:35', 1, '2026-10-05 23:05:35', '0');
INSERT INTO `qc_inspect_detail` VALUES (2107125050786099202, '000000', 2107125050639298561, 'OQC', 2107114370913710081, 2107114371014373377, 'M12_OQC_NUT_COUNT', '螺母配套数量', 'QUANTITATIVE', 'NOMINAL', '1 ± 0 件/套', '件/套', 'MAJOR', 10.0000, '1,1,1,1,1,1,1,1,1,1', 1.000000, NULL, NULL, 0.000000, 0.000000, 'PASS', 2, '每项十套软件样本；标准来源原BOM1/1/2件单耗。', 103, 1, '2026-10-05 23:05:35', 1, '2026-10-05 23:05:35', '0');
INSERT INTO `qc_inspect_detail` VALUES (2107125050794487809, '000000', 2107125050639298561, 'OQC', 2107114370913710081, 2107114371022761985, 'M12_OQC_WASHER_COUNT', '平垫圈配套数量', 'QUANTITATIVE', 'NOMINAL', '2 ± 0 件/套', '件/套', 'MAJOR', 10.0000, '2,2,2,2,2,2,2,2,2,2', 2.000000, NULL, NULL, 0.000000, 0.000000, 'PASS', 3, '每项十套软件样本；标准来源原BOM1/1/2件单耗。', 103, 1, '2026-10-05 23:05:35', 1, '2026-10-05 23:05:35', '0');
INSERT INTO `qc_inspect_detail` VALUES (2107310554823471105, '000000', 2107310554534064128, 'IQC', 2107180758202277889, 2107180758260998145, 'MARK_SPEC', '物料标识与采购规格一致性', 'QUALITATIVE', NULL, 'OK/NG', NULL, 'MAJOR', 2.0000, 'OK', NULL, NULL, NULL, NULL, NULL, 'PASS', 1, '本地软件检验记录；用于明细判定链路，不代表实物抽检或测量', -1, -1, '2026-10-06 11:22:43', 1, '2026-10-06 11:24:08', '0');
INSERT INTO `qc_inspect_detail` VALUES (2107310554836054018, '000000', 2107310554534064128, 'IQC', 2107180758202277889, 2107180758286163970, 'QTY_LIST', '到货数量与随货清单一致性', 'QUALITATIVE', NULL, 'OK/NG', NULL, 'MAJOR', 2.0000, 'OK', NULL, NULL, NULL, NULL, NULL, 'PASS', 2, '本地软件检验记录；用于明细判定链路，不代表实物抽检或测量', -1, -1, '2026-10-06 11:22:43', 1, '2026-10-06 11:24:08', '0');
INSERT INTO `qc_inspect_detail` VALUES (2107310554840248321, '000000', 2107310554534064128, 'IQC', 2107180758202277889, 2107180758294552578, 'APPEARANCE', '表面及包装完整性', 'QUALITATIVE', NULL, 'OK/NG', NULL, 'MAJOR', 2.0000, 'OK', NULL, NULL, NULL, NULL, NULL, 'PASS', 3, '本地软件检验记录；用于明细判定链路，不代表实物抽检或测量', -1, -1, '2026-10-06 11:22:43', 1, '2026-10-06 11:24:08', '0');
INSERT INTO `qc_inspect_detail` VALUES (2107310616349716482, '000000', 2107310616316162048, 'IQC', 2107180758873366530, 2107180758885949441, 'MARK_SPEC', '物料标识与采购规格一致性', 'QUALITATIVE', NULL, 'OK/NG', NULL, 'MAJOR', 2.0000, 'OK', NULL, NULL, NULL, NULL, NULL, 'PASS', 1, '本地软件检验记录；用于明细判定链路，不代表实物抽检或测量', -1, -1, '2026-10-06 11:22:58', 1, '2026-10-06 11:24:19', '0');
INSERT INTO `qc_inspect_detail` VALUES (2107310616358105089, '000000', 2107310616316162048, 'IQC', 2107180758873366530, 2107180758890143746, 'QTY_LIST', '到货数量与随货清单一致性', 'QUALITATIVE', NULL, 'OK/NG', NULL, 'MAJOR', 2.0000, 'OK', NULL, NULL, NULL, NULL, NULL, 'PASS', 2, '本地软件检验记录；用于明细判定链路，不代表实物抽检或测量', -1, -1, '2026-10-06 11:22:58', 1, '2026-10-06 11:24:19', '0');
INSERT INTO `qc_inspect_detail` VALUES (2107310616366493697, '000000', 2107310616316162048, 'IQC', 2107180758873366530, 2107180758898532353, 'APPEARANCE', '表面及包装完整性', 'QUALITATIVE', NULL, 'OK/NG', NULL, 'MAJOR', 2.0000, 'OK', NULL, NULL, NULL, NULL, NULL, 'PASS', 3, '本地软件检验记录；用于明细判定链路，不代表实物抽检或测量', -1, -1, '2026-10-06 11:22:58', 1, '2026-10-06 11:24:19', '0');
INSERT INTO `qc_inspect_detail` VALUES (2107310677792075777, '000000', 2107310677737549824, 'IQC', 2107180759166967810, 2107180759183745025, 'MARK_SPEC', '物料标识与采购规格一致性', 'QUALITATIVE', NULL, 'OK/NG', NULL, 'MAJOR', 4.0000, 'OK', NULL, NULL, NULL, NULL, NULL, 'PASS', 1, '本地软件检验记录；用于明细判定链路，不代表实物抽检或测量', -1, -1, '2026-10-06 11:23:12', 1, '2026-10-06 11:24:41', '0');
INSERT INTO `qc_inspect_detail` VALUES (2107310677792075778, '000000', 2107310677737549824, 'IQC', 2107180759166967810, 2107180759187939329, 'QTY_LIST', '到货数量与随货清单一致性', 'QUALITATIVE', NULL, 'OK/NG', NULL, 'MAJOR', 4.0000, 'OK', NULL, NULL, NULL, NULL, NULL, 'PASS', 2, '本地软件检验记录；用于明细判定链路，不代表实物抽检或测量', -1, -1, '2026-10-06 11:23:12', 1, '2026-10-06 11:24:41', '0');
INSERT INTO `qc_inspect_detail` VALUES (2107310677804658690, '000000', 2107310677737549824, 'IQC', 2107180759166967810, 2107180759196327937, 'APPEARANCE', '表面及包装完整性', 'QUALITATIVE', NULL, 'OK/NG', NULL, 'MAJOR', 4.0000, 'OK', NULL, NULL, NULL, NULL, NULL, 'PASS', 3, '本地软件检验记录；用于明细判定链路，不代表实物抽检或测量', -1, -1, '2026-10-06 11:23:12', 1, '2026-10-06 11:24:41', '0');
INSERT INTO `qc_inspect_detail` VALUES (2107312390359953410, '000000', 2107312390305427456, 'IQC', 2107180758202277889, 2107180758260998145, 'MARK_SPEC', '物料标识与采购规格一致性', 'QUALITATIVE', NULL, 'OK/NG', NULL, 'MAJOR', 4.0000, 'OK', NULL, NULL, NULL, NULL, NULL, 'PASS', 1, '本地软件检验记录；用于明细判定链路，不代表实物抽检或测量', -1, -1, '2026-10-06 11:30:00', 1, '2026-10-06 11:30:05', '0');
INSERT INTO `qc_inspect_detail` VALUES (2107312390364147714, '000000', 2107312390305427456, 'IQC', 2107180758202277889, 2107180758286163970, 'QTY_LIST', '到货数量与随货清单一致性', 'QUALITATIVE', NULL, 'OK/NG', NULL, 'MAJOR', 4.0000, 'OK', NULL, NULL, NULL, NULL, NULL, 'PASS', 2, '本地软件检验记录；用于明细判定链路，不代表实物抽检或测量', -1, -1, '2026-10-06 11:30:00', 1, '2026-10-06 11:30:05', '0');
INSERT INTO `qc_inspect_detail` VALUES (2107312390372536322, '000000', 2107312390305427456, 'IQC', 2107180758202277889, 2107180758294552578, 'APPEARANCE', '表面及包装完整性', 'QUALITATIVE', NULL, 'OK/NG', NULL, 'MAJOR', 4.0000, 'OK', NULL, NULL, NULL, NULL, NULL, 'PASS', 3, '本地软件检验记录；用于明细判定链路，不代表实物抽检或测量', -1, -1, '2026-10-06 11:30:00', 1, '2026-10-06 11:30:05', '0');
INSERT INTO `qc_inspect_detail` VALUES (2107312454226620417, '000000', 2107312454167900160, 'IQC', 2107180758873366530, 2107180758885949441, 'MARK_SPEC', '物料标识与采购规格一致性', 'QUALITATIVE', NULL, 'OK/NG', NULL, 'MAJOR', 4.0000, 'OK', NULL, NULL, NULL, NULL, NULL, 'PASS', 1, '本地软件检验记录；用于明细判定链路，不代表实物抽检或测量', -1, -1, '2026-10-06 11:30:16', 1, '2026-10-06 11:30:26', '0');
INSERT INTO `qc_inspect_detail` VALUES (2107312454235009025, '000000', 2107312454167900160, 'IQC', 2107180758873366530, 2107180758890143746, 'QTY_LIST', '到货数量与随货清单一致性', 'QUALITATIVE', NULL, 'OK/NG', NULL, 'MAJOR', 4.0000, 'OK', NULL, NULL, NULL, NULL, NULL, 'PASS', 2, '本地软件检验记录；用于明细判定链路，不代表实物抽检或测量', -1, -1, '2026-10-06 11:30:16', 1, '2026-10-06 11:30:26', '0');
INSERT INTO `qc_inspect_detail` VALUES (2107312454235009026, '000000', 2107312454167900160, 'IQC', 2107180758873366530, 2107180758898532353, 'APPEARANCE', '表面及包装完整性', 'QUALITATIVE', NULL, 'OK/NG', NULL, 'MAJOR', 4.0000, 'OK', NULL, NULL, NULL, NULL, NULL, 'PASS', 3, '本地软件检验记录；用于明细判定链路，不代表实物抽检或测量', -1, -1, '2026-10-06 11:30:16', 1, '2026-10-06 11:30:26', '0');
INSERT INTO `qc_inspect_detail` VALUES (2107312531309539330, '000000', 2107312531259207680, 'IQC', 2107180759166967810, 2107180759183745025, 'MARK_SPEC', '物料标识与采购规格一致性', 'QUALITATIVE', NULL, 'OK/NG', NULL, 'MAJOR', 8.0000, 'OK', NULL, NULL, NULL, NULL, NULL, 'PASS', 1, '本地软件检验记录；用于明细判定链路，不代表实物抽检或测量', -1, -1, '2026-10-06 11:30:34', 1, '2026-10-06 11:30:42', '0');
INSERT INTO `qc_inspect_detail` VALUES (2107312531317927938, '000000', 2107312531259207680, 'IQC', 2107180759166967810, 2107180759187939329, 'QTY_LIST', '到货数量与随货清单一致性', 'QUALITATIVE', NULL, 'OK/NG', NULL, 'MAJOR', 8.0000, 'OK', NULL, NULL, NULL, NULL, NULL, 'PASS', 2, '本地软件检验记录；用于明细判定链路，不代表实物抽检或测量', -1, -1, '2026-10-06 11:30:34', 1, '2026-10-06 11:30:42', '0');
INSERT INTO `qc_inspect_detail` VALUES (2107312531326316545, '000000', 2107312531259207680, 'IQC', 2107180759166967810, 2107180759196327937, 'APPEARANCE', '表面及包装完整性', 'QUALITATIVE', NULL, 'OK/NG', NULL, 'MAJOR', 8.0000, 'OK', NULL, NULL, NULL, NULL, NULL, 'PASS', 3, '本地软件检验记录；用于明细判定链路，不代表实物抽检或测量', -1, -1, '2026-10-06 11:30:34', 1, '2026-10-06 11:30:42', '0');
INSERT INTO `qc_inspect_detail` VALUES (2107331726562766849, '000000', 2107331726478880769, 'IPQC', 2107083839501119490, 2107083839576616961, 'M12_BOLT_COUNT', '螺栓装配数量', 'QUANTITATIVE', 'NOMINAL', '1 ± 0 件/套', '件/套', 'MAJOR', 6.0000, '1,1,1,1,1,1', 1.000000, NULL, NULL, 0.000000, 0.000000, 'PASS', 1, '六套软件装配数量输入，标准由BOM生成；非现场量具或扭矩测量', 103, 1, '2026-10-06 12:46:51', 1, '2026-10-06 12:46:51', '0');
INSERT INTO `qc_inspect_detail` VALUES (2107331726571155458, '000000', 2107331726478880769, 'IPQC', 2107083839501119490, 2107083839647920129, 'M12_NUT_COUNT', '螺母装配数量', 'QUANTITATIVE', 'NOMINAL', '1 ± 0 件/套', '件/套', 'MAJOR', 6.0000, '1,1,1,1,1,1', 1.000000, NULL, NULL, 0.000000, 0.000000, 'PASS', 2, '六套软件装配数量输入，标准由BOM生成；非现场量具或扭矩测量', 103, 1, '2026-10-06 12:46:51', 1, '2026-10-06 12:46:51', '0');
INSERT INTO `qc_inspect_detail` VALUES (2107331726575349762, '000000', 2107331726478880769, 'IPQC', 2107083839501119490, 2107083839660503042, 'M12_WASHER_COUNT', '平垫圈装配数量', 'QUANTITATIVE', 'NOMINAL', '2 ± 0 件/套', '件/套', 'MAJOR', 6.0000, '2,2,2,2,2,2', 2.000000, NULL, NULL, 0.000000, 0.000000, 'PASS', 3, '六套软件装配数量输入，标准由BOM生成；非现场量具或扭矩测量', 103, 1, '2026-10-06 12:46:51', 1, '2026-10-06 12:46:51', '0');
INSERT INTO `qc_inspect_detail` VALUES (2107337265589989378, '000000', 2107337265527074817, 'OQC', 2107114370913710081, 2107114370985013250, 'M12_OQC_BOLT_COUNT', '螺栓配套数量', 'QUANTITATIVE', 'NOMINAL', '1 ± 0 件/套', '件/套', 'MAJOR', 6.0000, '1,1,1,1,1,1', 1.000000, NULL, NULL, 0.000000, 0.000000, 'PASS', 1, '本批六组软件数量输入；按原BOM规范自动判定，不作为物理检测结果。', 103, 1, '2026-10-06 13:08:51', 1, '2026-10-06 13:08:51', '0');
INSERT INTO `qc_inspect_detail` VALUES (2107337265594183681, '000000', 2107337265527074817, 'OQC', 2107114370913710081, 2107114371014373377, 'M12_OQC_NUT_COUNT', '螺母配套数量', 'QUANTITATIVE', 'NOMINAL', '1 ± 0 件/套', '件/套', 'MAJOR', 6.0000, '1,1,1,1,1,1', 1.000000, NULL, NULL, 0.000000, 0.000000, 'PASS', 2, '本批六组软件数量输入；按原BOM规范自动判定，不作为物理检测结果。', 103, 1, '2026-10-06 13:08:51', 1, '2026-10-06 13:08:51', '0');
INSERT INTO `qc_inspect_detail` VALUES (2107337265602572289, '000000', 2107337265527074817, 'OQC', 2107114370913710081, 2107114371022761985, 'M12_OQC_WASHER_COUNT', '平垫圈配套数量', 'QUANTITATIVE', 'NOMINAL', '2 ± 0 件/套', '件/套', 'MAJOR', 6.0000, '2,2,2,2,2,2', 2.000000, NULL, NULL, 0.000000, 0.000000, 'PASS', 3, '本批六组软件数量输入；按原BOM规范自动判定，不作为物理检测结果。', 103, 1, '2026-10-06 13:08:51', 1, '2026-10-06 13:08:51', '0');
INSERT INTO `qc_inspect_detail` VALUES (2107516476711731202, '000000', 2107516476623650816, 'IQC', 2107180758202277889, 2107180758260998145, 'MARK_SPEC', '物料标识与采购规格一致性', 'QUALITATIVE', NULL, 'OK/NG', NULL, 'MAJOR', 2.0000, 'OK', NULL, NULL, NULL, NULL, NULL, 'PASS', 1, '本地软件检验记录；用于明细判定链路，不代表实物抽检或测量', -1, -1, '2026-10-07 01:00:58', 1, '2026-10-07 01:01:03', '0');
INSERT INTO `qc_inspect_detail` VALUES (2107516476728508418, '000000', 2107516476623650816, 'IQC', 2107180758202277889, 2107180758286163970, 'QTY_LIST', '到货数量与随货清单一致性', 'QUALITATIVE', NULL, 'OK/NG', NULL, 'MAJOR', 2.0000, 'OK', NULL, NULL, NULL, NULL, NULL, 'PASS', 2, '本地软件检验记录；用于明细判定链路，不代表实物抽检或测量', -1, -1, '2026-10-07 01:00:58', 1, '2026-10-07 01:01:03', '0');
INSERT INTO `qc_inspect_detail` VALUES (2107516476728508419, '000000', 2107516476623650816, 'IQC', 2107180758202277889, 2107180758294552578, 'APPEARANCE', '表面及包装完整性', 'QUALITATIVE', NULL, 'OK/NG', NULL, 'MAJOR', 2.0000, 'OK', NULL, NULL, NULL, NULL, NULL, 'PASS', 3, '本地软件检验记录；用于明细判定链路，不代表实物抽检或测量', -1, -1, '2026-10-07 01:00:58', 1, '2026-10-07 01:01:03', '0');
INSERT INTO `qc_inspect_detail` VALUES (2107516539672428546, '000000', 2107516539609513984, 'IQC', 2107180758873366530, 2107180758885949441, 'MARK_SPEC', '物料标识与采购规格一致性', 'QUALITATIVE', NULL, 'OK/NG', NULL, 'MAJOR', 2.0000, 'OK', NULL, NULL, NULL, NULL, NULL, 'PASS', 1, '本地软件检验记录；用于明细判定链路，不代表实物抽检或测量', -1, -1, '2026-10-07 01:01:13', 1, '2026-10-07 01:01:21', '0');
INSERT INTO `qc_inspect_detail` VALUES (2107516539676622849, '000000', 2107516539609513984, 'IQC', 2107180758873366530, 2107180758890143746, 'QTY_LIST', '到货数量与随货清单一致性', 'QUALITATIVE', NULL, 'OK/NG', NULL, 'MAJOR', 2.0000, 'OK', NULL, NULL, NULL, NULL, NULL, 'PASS', 2, '本地软件检验记录；用于明细判定链路，不代表实物抽检或测量', -1, -1, '2026-10-07 01:01:13', 1, '2026-10-07 01:01:21', '0');
INSERT INTO `qc_inspect_detail` VALUES (2107516539685011458, '000000', 2107516539609513984, 'IQC', 2107180758873366530, 2107180758898532353, 'APPEARANCE', '表面及包装完整性', 'QUALITATIVE', NULL, 'OK/NG', NULL, 'MAJOR', 2.0000, 'OK', NULL, NULL, NULL, NULL, NULL, 'PASS', 3, '本地软件检验记录；用于明细判定链路，不代表实物抽检或测量', -1, -1, '2026-10-07 01:01:13', 1, '2026-10-07 01:01:21', '0');
INSERT INTO `qc_inspect_detail` VALUES (2107516606038900738, '000000', 2107516605988569088, 'IQC', 2107180759166967810, 2107180759183745025, 'MARK_SPEC', '物料标识与采购规格一致性', 'QUALITATIVE', NULL, 'OK/NG', NULL, 'MAJOR', 4.0000, 'OK', NULL, NULL, NULL, NULL, NULL, 'PASS', 1, '本地软件检验记录；用于明细判定链路，不代表实物抽检或测量', -1, -1, '2026-10-07 01:01:29', 1, '2026-10-07 01:01:37', '0');
INSERT INTO `qc_inspect_detail` VALUES (2107516606047289345, '000000', 2107516605988569088, 'IQC', 2107180759166967810, 2107180759187939329, 'QTY_LIST', '到货数量与随货清单一致性', 'QUALITATIVE', NULL, 'OK/NG', NULL, 'MAJOR', 4.0000, 'OK', NULL, NULL, NULL, NULL, NULL, 'PASS', 2, '本地软件检验记录；用于明细判定链路，不代表实物抽检或测量', -1, -1, '2026-10-07 01:01:29', 1, '2026-10-07 01:01:37', '0');
INSERT INTO `qc_inspect_detail` VALUES (2107516606059872258, '000000', 2107516605988569088, 'IQC', 2107180759166967810, 2107180759196327937, 'APPEARANCE', '表面及包装完整性', 'QUALITATIVE', NULL, 'OK/NG', NULL, 'MAJOR', 4.0000, 'OK', NULL, NULL, NULL, NULL, NULL, 'PASS', 3, '本地软件检验记录；用于明细判定链路，不代表实物抽检或测量', -1, -1, '2026-10-07 01:01:29', 1, '2026-10-07 01:01:37', '0');
INSERT INTO `qc_inspect_detail` VALUES (2107518638049165314, '000000', 2107518637990445056, 'IQC', 2107180758202277889, 2107180758260998145, 'MARK_SPEC', '物料标识与采购规格一致性', 'QUALITATIVE', NULL, 'OK/NG', NULL, 'MAJOR', 4.0000, 'OK', NULL, NULL, NULL, NULL, NULL, 'PASS', 1, '本地软件检验记录；用于明细判定链路，不代表实物抽检或测量', -1, -1, '2026-10-07 01:09:34', 1, '2026-10-07 01:09:38', '0');
INSERT INTO `qc_inspect_detail` VALUES (2107518638057553922, '000000', 2107518637990445056, 'IQC', 2107180758202277889, 2107180758286163970, 'QTY_LIST', '到货数量与随货清单一致性', 'QUALITATIVE', NULL, 'OK/NG', NULL, 'MAJOR', 4.0000, 'OK', NULL, NULL, NULL, NULL, NULL, 'PASS', 2, '本地软件检验记录；用于明细判定链路，不代表实物抽检或测量', -1, -1, '2026-10-07 01:09:34', 1, '2026-10-07 01:09:38', '0');
INSERT INTO `qc_inspect_detail` VALUES (2107518638065942529, '000000', 2107518637990445056, 'IQC', 2107180758202277889, 2107180758294552578, 'APPEARANCE', '表面及包装完整性', 'QUALITATIVE', NULL, 'OK/NG', NULL, 'MAJOR', 4.0000, 'OK', NULL, NULL, NULL, NULL, NULL, 'PASS', 3, '本地软件检验记录；用于明细判定链路，不代表实物抽检或测量', -1, -1, '2026-10-07 01:09:34', 1, '2026-10-07 01:09:38', '0');
INSERT INTO `qc_inspect_detail` VALUES (2107518702112964609, '000000', 2107518702058438656, 'IQC', 2107180758873366530, 2107180758885949441, 'MARK_SPEC', '物料标识与采购规格一致性', 'QUALITATIVE', NULL, 'OK/NG', NULL, 'MAJOR', 4.0000, 'OK', NULL, NULL, NULL, NULL, NULL, 'PASS', 1, '本地软件检验记录；用于明细判定链路，不代表实物抽检或测量', -1, -1, '2026-10-07 01:09:49', 1, '2026-10-07 01:09:59', '0');
INSERT INTO `qc_inspect_detail` VALUES (2107518702117158914, '000000', 2107518702058438656, 'IQC', 2107180758873366530, 2107180758890143746, 'QTY_LIST', '到货数量与随货清单一致性', 'QUALITATIVE', NULL, 'OK/NG', NULL, 'MAJOR', 4.0000, 'OK', NULL, NULL, NULL, NULL, NULL, 'PASS', 2, '本地软件检验记录；用于明细判定链路，不代表实物抽检或测量', -1, -1, '2026-10-07 01:09:49', 1, '2026-10-07 01:09:59', '0');
INSERT INTO `qc_inspect_detail` VALUES (2107518702125547522, '000000', 2107518702058438656, 'IQC', 2107180758873366530, 2107180758898532353, 'APPEARANCE', '表面及包装完整性', 'QUALITATIVE', NULL, 'OK/NG', NULL, 'MAJOR', 4.0000, 'OK', NULL, NULL, NULL, NULL, NULL, 'PASS', 3, '本地软件检验记录；用于明细判定链路，不代表实物抽检或测量', -1, -1, '2026-10-07 01:09:49', 1, '2026-10-07 01:09:59', '0');
INSERT INTO `qc_inspect_detail` VALUES (2107518778684178433, '000000', 2107518778629652480, 'IQC', 2107180759166967810, 2107180759183745025, 'MARK_SPEC', '物料标识与采购规格一致性', 'QUALITATIVE', NULL, 'OK/NG', NULL, 'MAJOR', 8.0000, 'OK', NULL, NULL, NULL, NULL, NULL, 'PASS', 1, '本地软件检验记录；用于明细判定链路，不代表实物抽检或测量', -1, -1, '2026-10-07 01:10:07', 1, '2026-10-07 01:10:15', '0');
INSERT INTO `qc_inspect_detail` VALUES (2107518778696761346, '000000', 2107518778629652480, 'IQC', 2107180759166967810, 2107180759187939329, 'QTY_LIST', '到货数量与随货清单一致性', 'QUALITATIVE', NULL, 'OK/NG', NULL, 'MAJOR', 8.0000, 'OK', NULL, NULL, NULL, NULL, NULL, 'PASS', 2, '本地软件检验记录；用于明细判定链路，不代表实物抽检或测量', -1, -1, '2026-10-07 01:10:07', 1, '2026-10-07 01:10:15', '0');
INSERT INTO `qc_inspect_detail` VALUES (2107518778705149954, '000000', 2107518778629652480, 'IQC', 2107180759166967810, 2107180759196327937, 'APPEARANCE', '表面及包装完整性', 'QUALITATIVE', NULL, 'OK/NG', NULL, 'MAJOR', 8.0000, 'OK', NULL, NULL, NULL, NULL, NULL, 'PASS', 3, '本地软件检验记录；用于明细判定链路，不代表实物抽检或测量', -1, -1, '2026-10-07 01:10:07', 1, '2026-10-07 01:10:15', '0');
INSERT INTO `qc_inspect_detail` VALUES (2107526720942735361, '000000', 2107526720884015106, 'IPQC', 2107083839501119490, 2107083839576616961, 'M12_BOLT_COUNT', '螺栓装配数量', 'QUANTITATIVE', 'NOMINAL', '1 ± 0 件/套', '件/套', 'MAJOR', 6.0000, '1,1,1,1,1,1', 1.000000, NULL, NULL, 0.000000, 0.000000, 'PASS', 1, '每个数表示一件组件的装配数量；六个软件输入值来源于本工单原BOM，不代表物理测量。', 103, 1, '2026-10-07 01:41:41', 1, '2026-10-07 01:41:41', '0');
INSERT INTO `qc_inspect_detail` VALUES (2107526720951123970, '000000', 2107526720884015106, 'IPQC', 2107083839501119490, 2107083839647920129, 'M12_NUT_COUNT', '螺母装配数量', 'QUANTITATIVE', 'NOMINAL', '1 ± 0 件/套', '件/套', 'MAJOR', 6.0000, '1,1,1,1,1,1', 1.000000, NULL, NULL, 0.000000, 0.000000, 'PASS', 2, '每个数表示一件组件的装配数量；六个软件输入值来源于本工单原BOM，不代表物理测量。', 103, 1, '2026-10-07 01:41:41', 1, '2026-10-07 01:41:41', '0');
INSERT INTO `qc_inspect_detail` VALUES (2107526720963706882, '000000', 2107526720884015106, 'IPQC', 2107083839501119490, 2107083839660503042, 'M12_WASHER_COUNT', '平垫圈装配数量', 'QUANTITATIVE', 'NOMINAL', '2 ± 0 件/套', '件/套', 'MAJOR', 6.0000, '2,2,2,2,2,2', 2.000000, NULL, NULL, 0.000000, 0.000000, 'PASS', 3, '每个数表示一件组件的装配数量；六个软件输入值来源于本工单原BOM，不代表物理测量。', 103, 1, '2026-10-07 01:41:41', 1, '2026-10-07 01:41:41', '0');
INSERT INTO `qc_inspect_detail` VALUES (2107530536148762625, '000000', 2107530536031322113, 'OQC', 2107114370913710081, 2107114370985013250, 'M12_OQC_BOLT_COUNT', '螺栓配套数量', 'QUANTITATIVE', 'NOMINAL', '1 ± 0 件/套', '件/套', 'MAJOR', 6.0000, '1,1,1,1,1,1', 1.000000, NULL, NULL, 0.000000, 0.000000, 'PASS', 1, '本批六组软件数量输入；按原BOM规范自动判定，不作为物理检测结果。', 103, 1, '2026-10-07 01:56:50', 1, '2026-10-07 01:56:51', '0');
INSERT INTO `qc_inspect_detail` VALUES (2107530536157151234, '000000', 2107530536031322113, 'OQC', 2107114370913710081, 2107114371014373377, 'M12_OQC_NUT_COUNT', '螺母配套数量', 'QUANTITATIVE', 'NOMINAL', '1 ± 0 件/套', '件/套', 'MAJOR', 6.0000, '1,1,1,1,1,1', 1.000000, NULL, NULL, 0.000000, 0.000000, 'PASS', 2, '本批六组软件数量输入；按原BOM规范自动判定，不作为物理检测结果。', 103, 1, '2026-10-07 01:56:51', 1, '2026-10-07 01:56:51', '0');
INSERT INTO `qc_inspect_detail` VALUES (2107530536169734145, '000000', 2107530536031322113, 'OQC', 2107114370913710081, 2107114371022761985, 'M12_OQC_WASHER_COUNT', '平垫圈配套数量', 'QUANTITATIVE', 'NOMINAL', '2 ± 0 件/套', '件/套', 'MAJOR', 6.0000, '2,2,2,2,2,2', 2.000000, NULL, NULL, 0.000000, 0.000000, 'PASS', 3, '本批六组软件数量输入；按原BOM规范自动判定，不作为物理检测结果。', 103, 1, '2026-10-07 01:56:51', 1, '2026-10-07 01:56:51', '0');
INSERT INTO `qc_inspect_detail` VALUES (2108007599464976386, '000000', 2108007599179763712, 'IQC', 2107180759166967810, 2107180759183745025, 'MARK_SPEC', '物料标识与采购规格一致性', 'QUALITATIVE', NULL, 'OK/NG', NULL, 'MAJOR', 2.0000, 'OK', NULL, NULL, NULL, NULL, NULL, 'PASS', 1, '本地业务检验资料；三项为软件流程定性输入，不代表实物抽检、尺寸测量或供应商签章。', -1, -1, '2026-10-08 09:32:31', 1, '2026-10-08 09:35:55', '0');
INSERT INTO `qc_inspect_detail` VALUES (2108007599485947906, '000000', 2108007599179763712, 'IQC', 2107180759166967810, 2107180759187939329, 'QTY_LIST', '到货数量与随货清单一致性', 'QUALITATIVE', NULL, 'OK/NG', NULL, 'MAJOR', 2.0000, 'OK', NULL, NULL, NULL, NULL, NULL, 'PASS', 2, '本地业务检验资料；三项为软件流程定性输入，不代表实物抽检、尺寸测量或供应商签章。', -1, -1, '2026-10-08 09:32:31', 1, '2026-10-08 09:35:55', '0');
INSERT INTO `qc_inspect_detail` VALUES (2108007599490142210, '000000', 2108007599179763712, 'IQC', 2107180759166967810, 2107180759196327937, 'APPEARANCE', '表面及包装完整性', 'QUALITATIVE', NULL, 'OK/NG', NULL, 'MAJOR', 2.0000, 'OK', NULL, NULL, NULL, NULL, NULL, 'PASS', 3, '本地业务检验资料；三项为软件流程定性输入，不代表实物抽检、尺寸测量或供应商签章。', -1, -1, '2026-10-08 09:32:31', 1, '2026-10-08 09:35:55', '0');
INSERT INTO `qc_inspect_detail` VALUES (2108593288690786305, '000000', 2108593288606900224, 'IQC', 2107180758873366530, 2107180758885949441, 'MARK_SPEC', '物料标识与采购规格一致性', 'QUALITATIVE', NULL, 'OK/NG', NULL, 'MAJOR', 5.0000, 'OK', NULL, NULL, NULL, NULL, NULL, 'PASS', 1, '标识与原采购规格一致', -1, -1, '2026-10-10 00:19:50', 1, '2026-10-10 00:35:14', '0');
INSERT INTO `qc_inspect_detail` VALUES (2108593288699174913, '000000', 2108593288606900224, 'IQC', 2107180758873366530, 2107180758890143746, 'QTY_LIST', '到货数量与随货清单一致性', 'QUALITATIVE', NULL, 'OK/NG', NULL, 'MAJOR', 5.0000, 'OK', NULL, NULL, NULL, NULL, NULL, 'PASS', 2, '本批数量与供货清单一致', -1, -1, '2026-10-10 00:19:50', 1, '2026-10-10 00:35:14', '0');
INSERT INTO `qc_inspect_detail` VALUES (2108593288707563521, '000000', 2108593288606900224, 'IQC', 2107180758873366530, 2107180758898532353, 'APPEARANCE', '表面及包装完整性', 'QUALITATIVE', NULL, 'OK/NG', NULL, 'MAJOR', 5.0000, 'OK', NULL, NULL, NULL, NULL, NULL, 'PASS', 3, '表面与包装完整', -1, -1, '2026-10-10 00:19:50', 1, '2026-10-10 00:35:14', '0');
INSERT INTO `qc_inspect_detail` VALUES (2108593346295357442, '000000', 2108593346253414400, 'IQC', 2107180759166967810, 2107180759183745025, 'MARK_SPEC', '物料标识与采购规格一致性', 'QUALITATIVE', NULL, 'OK/NG', NULL, 'MAJOR', 8.0000, 'OK', NULL, NULL, NULL, NULL, NULL, 'PASS', 1, '标识与原采购规格一致', -1, -1, '2026-10-10 00:20:04', 1, '2026-10-10 00:35:25', '0');
INSERT INTO `qc_inspect_detail` VALUES (2108593346295357443, '000000', 2108593346253414400, 'IQC', 2107180759166967810, 2107180759187939329, 'QTY_LIST', '到货数量与随货清单一致性', 'QUALITATIVE', NULL, 'OK/NG', NULL, 'MAJOR', 8.0000, 'OK', NULL, NULL, NULL, NULL, NULL, 'PASS', 2, '本批数量与供货清单一致', -1, -1, '2026-10-10 00:20:04', 1, '2026-10-10 00:35:25', '0');
INSERT INTO `qc_inspect_detail` VALUES (2108593346303746050, '000000', 2108593346253414400, 'IQC', 2107180759166967810, 2107180759196327937, 'APPEARANCE', '表面及包装完整性', 'QUALITATIVE', NULL, 'OK/NG', NULL, 'MAJOR', 8.0000, 'OK', NULL, NULL, NULL, NULL, NULL, 'PASS', 3, '表面与包装完整', -1, -1, '2026-10-10 00:20:04', 1, '2026-10-10 00:35:25', '0');
INSERT INTO `qc_inspect_detail` VALUES (2108654961824825345, '000000', 2108654961719967744, 'IQC', 2107180758202277889, 2107180758260998145, 'MARK_SPEC', '物料标识与采购规格一致性', 'QUALITATIVE', NULL, 'OK/NG', NULL, 'MAJOR', 5.0000, 'OK', NULL, NULL, NULL, NULL, NULL, 'PASS', 1, '按本批检验资料核对该项目符合要求', -1, -1, '2026-10-10 04:24:54', 1, '2026-10-10 04:25:07', '0');
INSERT INTO `qc_inspect_detail` VALUES (2108654961841602561, '000000', 2108654961719967744, 'IQC', 2107180758202277889, 2107180758286163970, 'QTY_LIST', '到货数量与随货清单一致性', 'QUALITATIVE', NULL, 'OK/NG', NULL, 'MAJOR', 5.0000, 'OK', NULL, NULL, NULL, NULL, NULL, 'PASS', 2, '按本批检验资料核对该项目符合要求', -1, -1, '2026-10-10 04:24:54', 1, '2026-10-10 04:25:07', '0');
INSERT INTO `qc_inspect_detail` VALUES (2108654961845796866, '000000', 2108654961719967744, 'IQC', 2107180758202277889, 2107180758294552578, 'APPEARANCE', '表面及包装完整性', 'QUALITATIVE', NULL, 'OK/NG', NULL, 'MAJOR', 5.0000, 'OK', NULL, NULL, NULL, NULL, NULL, 'PASS', 3, '按本批检验资料核对该项目符合要求', -1, -1, '2026-10-10 04:24:54', 1, '2026-10-10 04:25:07', '0');
INSERT INTO `qc_inspect_detail` VALUES (2108659592235778049, '000000', 2108659592160280576, 'IQC', 2107180759166967810, 2107180759183745025, 'MARK_SPEC', '物料标识与采购规格一致性', 'QUALITATIVE', NULL, 'OK/NG', NULL, 'MAJOR', 8.0000, 'OK', NULL, NULL, NULL, NULL, NULL, 'PASS', 1, '按本批检验资料核对该项目符合要求', -1, -1, '2026-10-10 04:43:18', 1, '2026-10-10 04:43:22', '0');
INSERT INTO `qc_inspect_detail` VALUES (2108659592244166657, '000000', 2108659592160280576, 'IQC', 2107180759166967810, 2107180759187939329, 'QTY_LIST', '到货数量与随货清单一致性', 'QUALITATIVE', NULL, 'OK/NG', NULL, 'MAJOR', 8.0000, 'OK', NULL, NULL, NULL, NULL, NULL, 'PASS', 2, '按本批检验资料核对该项目符合要求', -1, -1, '2026-10-10 04:43:18', 1, '2026-10-10 04:43:22', '0');
INSERT INTO `qc_inspect_detail` VALUES (2108659592248360961, '000000', 2108659592160280576, 'IQC', 2107180759166967810, 2107180759196327937, 'APPEARANCE', '表面及包装完整性', 'QUALITATIVE', NULL, 'OK/NG', NULL, 'MAJOR', 8.0000, 'OK', NULL, NULL, NULL, NULL, NULL, 'PASS', 3, '按本批检验资料核对该项目符合要求', -1, -1, '2026-10-10 04:43:18', 1, '2026-10-10 04:43:22', '0');
INSERT INTO `qc_inspect_detail` VALUES (2108660683698536450, '000000', 2108660683627233280, 'IQC', 2107180758873366530, 2107180758885949441, 'MARK_SPEC', '物料标识与采购规格一致性', 'QUALITATIVE', NULL, 'OK/NG', NULL, 'MAJOR', 5.0000, 'OK', NULL, NULL, NULL, NULL, NULL, 'PASS', 1, '按本批检验资料核对该项目符合要求', -1, -1, '2026-10-10 04:47:39', 1, '2026-10-10 04:47:43', '0');
INSERT INTO `qc_inspect_detail` VALUES (2108660683711119362, '000000', 2108660683627233280, 'IQC', 2107180758873366530, 2107180758890143746, 'QTY_LIST', '到货数量与随货清单一致性', 'QUALITATIVE', NULL, 'OK/NG', NULL, 'MAJOR', 5.0000, 'OK', NULL, NULL, NULL, NULL, NULL, 'PASS', 2, '按本批检验资料核对该项目符合要求', -1, -1, '2026-10-10 04:47:39', 1, '2026-10-10 04:47:43', '0');
INSERT INTO `qc_inspect_detail` VALUES (2108660683719507970, '000000', 2108660683627233280, 'IQC', 2107180758873366530, 2107180758898532353, 'APPEARANCE', '表面及包装完整性', 'QUALITATIVE', NULL, 'OK/NG', NULL, 'MAJOR', 5.0000, 'OK', NULL, NULL, NULL, NULL, NULL, 'PASS', 3, '按本批检验资料核对该项目符合要求', -1, -1, '2026-10-10 04:47:39', 1, '2026-10-10 04:47:43', '0');
INSERT INTO `qc_inspect_detail` VALUES (2108666698141728770, '000000', 2108666698074619904, 'IQC', 2107180758202277889, 2107180758260998145, 'MARK_SPEC', '物料标识与采购规格一致性', 'QUALITATIVE', NULL, 'OK/NG', NULL, 'MAJOR', 5.0000, 'OK', NULL, NULL, NULL, NULL, NULL, 'PASS', 1, '按本批检验资料核对该项目符合要求', -1, -1, '2026-10-10 05:11:33', 1, '2026-10-10 05:11:37', '0');
INSERT INTO `qc_inspect_detail` VALUES (2108666698150117377, '000000', 2108666698074619904, 'IQC', 2107180758202277889, 2107180758286163970, 'QTY_LIST', '到货数量与随货清单一致性', 'QUALITATIVE', NULL, 'OK/NG', NULL, 'MAJOR', 5.0000, 'OK', NULL, NULL, NULL, NULL, NULL, 'PASS', 2, '按本批检验资料核对该项目符合要求', -1, -1, '2026-10-10 05:11:33', 1, '2026-10-10 05:11:37', '0');
INSERT INTO `qc_inspect_detail` VALUES (2108666698154311682, '000000', 2108666698074619904, 'IQC', 2107180758202277889, 2107180758294552578, 'APPEARANCE', '表面及包装完整性', 'QUALITATIVE', NULL, 'OK/NG', NULL, 'MAJOR', 5.0000, 'OK', NULL, NULL, NULL, NULL, NULL, 'PASS', 3, '按本批检验资料核对该项目符合要求', -1, -1, '2026-10-10 05:11:33', 1, '2026-10-10 05:11:37', '0');
INSERT INTO `qc_inspect_detail` VALUES (2108667412419117058, '000000', 2108667412372979712, 'IQC', 2107180759166967810, 2107180759183745025, 'MARK_SPEC', '物料标识与采购规格一致性', 'QUALITATIVE', NULL, 'OK/NG', NULL, 'MAJOR', 8.0000, 'OK', NULL, NULL, NULL, NULL, NULL, 'PASS', 1, '按本批检验资料核对该项目符合要求', -1, -1, '2026-10-10 05:14:23', 1, '2026-10-10 05:14:27', '0');
INSERT INTO `qc_inspect_detail` VALUES (2108667412427505665, '000000', 2108667412372979712, 'IQC', 2107180759166967810, 2107180759187939329, 'QTY_LIST', '到货数量与随货清单一致性', 'QUALITATIVE', NULL, 'OK/NG', NULL, 'MAJOR', 8.0000, 'OK', NULL, NULL, NULL, NULL, NULL, 'PASS', 2, '按本批检验资料核对该项目符合要求', -1, -1, '2026-10-10 05:14:23', 1, '2026-10-10 05:14:27', '0');
INSERT INTO `qc_inspect_detail` VALUES (2108667412427505666, '000000', 2108667412372979712, 'IQC', 2107180759166967810, 2107180759196327937, 'APPEARANCE', '表面及包装完整性', 'QUALITATIVE', NULL, 'OK/NG', NULL, 'MAJOR', 8.0000, 'OK', NULL, NULL, NULL, NULL, NULL, 'PASS', 3, '按本批检验资料核对该项目符合要求', -1, -1, '2026-10-10 05:14:23', 1, '2026-10-10 05:14:27', '0');
INSERT INTO `qc_inspect_detail` VALUES (2108668074578083842, '000000', 2108668074506780672, 'IQC', 2107180758202277889, 2107180758260998145, 'MARK_SPEC', '物料标识与采购规格一致性', 'QUALITATIVE', NULL, 'OK/NG', NULL, 'MAJOR', 5.0000, 'OK', NULL, NULL, NULL, NULL, NULL, 'PASS', 1, '按本批检验资料核对该项目符合要求', -1, -1, '2026-10-10 05:17:01', 1, '2026-10-10 05:17:05', '0');
INSERT INTO `qc_inspect_detail` VALUES (2108668074586472449, '000000', 2108668074506780672, 'IQC', 2107180758202277889, 2107180758286163970, 'QTY_LIST', '到货数量与随货清单一致性', 'QUALITATIVE', NULL, 'OK/NG', NULL, 'MAJOR', 5.0000, 'OK', NULL, NULL, NULL, NULL, NULL, 'PASS', 2, '按本批检验资料核对该项目符合要求', -1, -1, '2026-10-10 05:17:01', 1, '2026-10-10 05:17:05', '0');
INSERT INTO `qc_inspect_detail` VALUES (2108668074586472450, '000000', 2108668074506780672, 'IQC', 2107180758202277889, 2107180758294552578, 'APPEARANCE', '表面及包装完整性', 'QUALITATIVE', NULL, 'OK/NG', NULL, 'MAJOR', 5.0000, 'OK', NULL, NULL, NULL, NULL, NULL, 'PASS', 3, '按本批检验资料核对该项目符合要求', -1, -1, '2026-10-10 05:17:01', 1, '2026-10-10 05:17:05', '0');
INSERT INTO `qc_inspect_detail` VALUES (2108675852977766401, '000000', 2108675852910657537, 'IPQC', 2107083839501119490, 2107083839576616961, 'M12_BOLT_COUNT', '螺栓装配数量', 'QUANTITATIVE', 'NOMINAL', '1 ± 0 件/套', '件/套', 'MAJOR', 2.0000, '1', 1.000000, NULL, NULL, 0.000000, 0.000000, 'PASS', 1, '按本批装配记录核对各组件数量', 103, 1, '2026-10-10 05:47:55', 1, '2026-10-10 05:47:55', '0');
INSERT INTO `qc_inspect_detail` VALUES (2108675852990349314, '000000', 2108675852910657537, 'IPQC', 2107083839501119490, 2107083839647920129, 'M12_NUT_COUNT', '螺母装配数量', 'QUANTITATIVE', 'NOMINAL', '1 ± 0 件/套', '件/套', 'MAJOR', 2.0000, '1', 1.000000, NULL, NULL, 0.000000, 0.000000, 'PASS', 2, '按本批装配记录核对各组件数量', 103, 1, '2026-10-10 05:47:55', 1, '2026-10-10 05:47:55', '0');
INSERT INTO `qc_inspect_detail` VALUES (2108675852998737921, '000000', 2108675852910657537, 'IPQC', 2107083839501119490, 2107083839660503042, 'M12_WASHER_COUNT', '平垫圈装配数量', 'QUANTITATIVE', 'NOMINAL', '2 ± 0 件/套', '件/套', 'MAJOR', 2.0000, '2', 2.000000, NULL, NULL, 0.000000, 0.000000, 'PASS', 3, '按本批装配记录核对各组件数量', 103, 1, '2026-10-10 05:47:55', 1, '2026-10-10 05:47:55', '0');
INSERT INTO `qc_inspect_detail` VALUES (2108677267020251138, '000000', 2108677266978308097, 'IPQC', 2107083839501119490, 2107083839576616961, 'M12_BOLT_COUNT', '螺栓装配数量', 'QUANTITATIVE', 'NOMINAL', '1 ± 0 件/套', '件/套', 'MAJOR', 2.0000, '1', 1.000000, NULL, NULL, 0.000000, 0.000000, 'PASS', 1, '按本批装配记录核对各组件数量', 103, 1, '2026-10-10 05:53:32', 1, '2026-10-10 05:53:33', '0');
INSERT INTO `qc_inspect_detail` VALUES (2108677267024445442, '000000', 2108677266978308097, 'IPQC', 2107083839501119490, 2107083839647920129, 'M12_NUT_COUNT', '螺母装配数量', 'QUANTITATIVE', 'NOMINAL', '1 ± 0 件/套', '件/套', 'MAJOR', 2.0000, '1', 1.000000, NULL, NULL, 0.000000, 0.000000, 'PASS', 2, '按本批装配记录核对各组件数量', 103, 1, '2026-10-10 05:53:32', 1, '2026-10-10 05:53:33', '0');
INSERT INTO `qc_inspect_detail` VALUES (2108677267032834049, '000000', 2108677266978308097, 'IPQC', 2107083839501119490, 2107083839660503042, 'M12_WASHER_COUNT', '平垫圈装配数量', 'QUANTITATIVE', 'NOMINAL', '2 ± 0 件/套', '件/套', 'MAJOR', 2.0000, '2', 2.000000, NULL, NULL, 0.000000, 0.000000, 'PASS', 3, '按本批装配记录核对各组件数量', 103, 1, '2026-10-10 05:53:32', 1, '2026-10-10 05:53:33', '0');
INSERT INTO `qc_inspect_detail` VALUES (2108683311356248066, '000000', 2108683311272361986, 'OQC', 2107114370913710081, 2107114370985013250, 'M12_OQC_BOLT_COUNT', '螺栓配套数量', 'QUANTITATIVE', 'NOMINAL', '1 ± 0 件/套', '件/套', 'MAJOR', 5.0000, '1', 1.000000, NULL, NULL, 0.000000, 0.000000, 'PASS', 1, NULL, 103, 1, '2026-10-10 06:17:34', 1, '2026-10-10 06:19:08', '0');
INSERT INTO `qc_inspect_detail` VALUES (2108683311364636673, '000000', 2108683311272361986, 'OQC', 2107114370913710081, 2107114371014373377, 'M12_OQC_NUT_COUNT', '螺母配套数量', 'QUANTITATIVE', 'NOMINAL', '1 ± 0 件/套', '件/套', 'MAJOR', 5.0000, '1', 1.000000, NULL, NULL, 0.000000, 0.000000, 'PASS', 2, NULL, 103, 1, '2026-10-10 06:17:34', 1, '2026-10-10 06:19:08', '0');
INSERT INTO `qc_inspect_detail` VALUES (2108683311368830978, '000000', 2108683311272361986, 'OQC', 2107114370913710081, 2107114371022761985, 'M12_OQC_WASHER_COUNT', '平垫圈配套数量', 'QUANTITATIVE', 'NOMINAL', '2 ± 0 件/套', '件/套', 'MAJOR', 5.0000, '2', 2.000000, NULL, NULL, 0.000000, 0.000000, 'PASS', 3, NULL, 103, 1, '2026-10-10 06:17:34', 1, '2026-10-10 06:19:08', '0');
INSERT INTO `qc_inspect_detail` VALUES (2108684286443847682, '000000', 2108684286364155906, 'OQC', 2107114370913710081, 2107114370985013250, 'M12_OQC_BOLT_COUNT', '螺栓配套数量', 'QUANTITATIVE', 'NOMINAL', '1 ± 0 件/套', '件/套', 'MAJOR', 5.0000, '1', 1.000000, NULL, NULL, 0.000000, 0.000000, 'PASS', 1, NULL, 103, 1, '2026-10-10 06:21:26', 1, '2026-10-10 06:21:47', '0');
INSERT INTO `qc_inspect_detail` VALUES (2108684286452236289, '000000', 2108684286364155906, 'OQC', 2107114370913710081, 2107114371014373377, 'M12_OQC_NUT_COUNT', '螺母配套数量', 'QUANTITATIVE', 'NOMINAL', '1 ± 0 件/套', '件/套', 'MAJOR', 5.0000, '1', 1.000000, NULL, NULL, 0.000000, 0.000000, 'PASS', 2, NULL, 103, 1, '2026-10-10 06:21:26', 1, '2026-10-10 06:21:47', '0');
INSERT INTO `qc_inspect_detail` VALUES (2108684286460624897, '000000', 2108684286364155906, 'OQC', 2107114370913710081, 2107114371022761985, 'M12_OQC_WASHER_COUNT', '平垫圈配套数量', 'QUANTITATIVE', 'NOMINAL', '2 ± 0 件/套', '件/套', 'MAJOR', 5.0000, '2', 2.000000, NULL, NULL, 0.000000, 0.000000, 'PASS', 3, NULL, 103, 1, '2026-10-10 06:21:26', 1, '2026-10-10 06:21:47', '0');
INSERT INTO `qc_inspect_detail` VALUES (2108734173101383681, '000000', 2108734172883279872, 'IQC', 2107180758873366530, 2107180758885949441, 'MARK_SPEC', '物料标识与采购规格一致性', 'QUALITATIVE', NULL, 'OK/NG', NULL, 'MAJOR', 5.0000, 'OK', NULL, NULL, NULL, NULL, NULL, 'PASS', 1, '按本批检验资料核对该项目符合要求', -1, -1, '2026-10-10 09:39:40', 1, '2026-10-10 09:39:46', '0');
INSERT INTO `qc_inspect_detail` VALUES (2108734173105577985, '000000', 2108734172883279872, 'IQC', 2107180758873366530, 2107180758890143746, 'QTY_LIST', '到货数量与随货清单一致性', 'QUALITATIVE', NULL, 'OK/NG', NULL, 'MAJOR', 5.0000, 'OK', NULL, NULL, NULL, NULL, NULL, 'PASS', 2, '按本批检验资料核对该项目符合要求', -1, -1, '2026-10-10 09:39:40', 1, '2026-10-10 09:39:46', '0');
INSERT INTO `qc_inspect_detail` VALUES (2108734173113966594, '000000', 2108734172883279872, 'IQC', 2107180758873366530, 2107180758898532353, 'APPEARANCE', '表面及包装完整性', 'QUALITATIVE', NULL, 'OK/NG', NULL, 'MAJOR', 5.0000, 'OK', NULL, NULL, NULL, NULL, NULL, 'PASS', 3, '按本批检验资料核对该项目符合要求', -1, -1, '2026-10-10 09:39:40', 1, '2026-10-10 09:39:46', '0');
INSERT INTO `qc_inspect_detail` VALUES (2108738644883759106, '000000', 2108738644816650242, 'IPQC', 2107083839501119490, 2107083839576616961, 'M12_BOLT_COUNT', '螺栓装配数量', 'QUANTITATIVE', 'NOMINAL', '1 ± 0 件/套', '件/套', 'MAJOR', 2.0000, '1', 1.000000, NULL, NULL, 0.000000, 0.000000, 'PASS', 1, '按本批装配记录核对各组件数量', 103, 1, '2026-10-10 09:57:26', 1, '2026-10-10 09:57:26', '0');
INSERT INTO `qc_inspect_detail` VALUES (2108738644892147714, '000000', 2108738644816650242, 'IPQC', 2107083839501119490, 2107083839647920129, 'M12_NUT_COUNT', '螺母装配数量', 'QUANTITATIVE', 'NOMINAL', '1 ± 0 件/套', '件/套', 'MAJOR', 2.0000, '1', 1.000000, NULL, NULL, 0.000000, 0.000000, 'PASS', 2, '按本批装配记录核对各组件数量', 103, 1, '2026-10-10 09:57:26', 1, '2026-10-10 09:57:26', '0');
INSERT INTO `qc_inspect_detail` VALUES (2108738644896342018, '000000', 2108738644816650242, 'IPQC', 2107083839501119490, 2107083839660503042, 'M12_WASHER_COUNT', '平垫圈装配数量', 'QUANTITATIVE', 'NOMINAL', '2 ± 0 件/套', '件/套', 'MAJOR', 2.0000, '2', 2.000000, NULL, NULL, 0.000000, 0.000000, 'PASS', 3, '按本批装配记录核对各组件数量', 103, 1, '2026-10-10 09:57:26', 1, '2026-10-10 09:57:26', '0');
INSERT INTO `qc_inspect_detail` VALUES (2108747451827449858, '000000', 2108747451672260609, 'OQC', 2107114370913710081, 2107114370985013250, 'M12_OQC_BOLT_COUNT', '螺栓配套数量', 'QUANTITATIVE', 'NOMINAL', '1 ± 0 件/套', '件/套', 'MAJOR', 5.0000, '1', 1.000000, NULL, NULL, 0.000000, 0.000000, 'PASS', 1, NULL, 103, 1, '2026-10-10 10:32:26', 1, '2026-10-10 10:32:52', '0');
INSERT INTO `qc_inspect_detail` VALUES (2108747451848421378, '000000', 2108747451672260609, 'OQC', 2107114370913710081, 2107114371014373377, 'M12_OQC_NUT_COUNT', '螺母配套数量', 'QUANTITATIVE', 'NOMINAL', '1 ± 0 件/套', '件/套', 'MAJOR', 5.0000, '1', 1.000000, NULL, NULL, 0.000000, 0.000000, 'PASS', 2, NULL, 103, 1, '2026-10-10 10:32:26', 1, '2026-10-10 10:32:52', '0');
INSERT INTO `qc_inspect_detail` VALUES (2108747451865198594, '000000', 2108747451672260609, 'OQC', 2107114370913710081, 2107114371022761985, 'M12_OQC_WASHER_COUNT', '平垫圈配套数量', 'QUANTITATIVE', 'NOMINAL', '2 ± 0 件/套', '件/套', 'MAJOR', 5.0000, '2', 2.000000, NULL, NULL, 0.000000, 0.000000, 'PASS', 3, NULL, 103, 1, '2026-10-10 10:32:26', 1, '2026-10-10 10:32:52', '0');

-- ----------------------------
-- Table structure for qc_inspect_item
-- ----------------------------
DROP TABLE IF EXISTS `qc_inspect_item`;
CREATE TABLE `qc_inspect_item`  (
  `item_id` bigint(20) NOT NULL COMMENT '检验项目ID(主键)',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '000000' COMMENT '租户ID',
  `template_id` bigint(20) NOT NULL COMMENT '关联qc_inspect_template.template_id',
  `item_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '项目编码',
  `item_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '项目名称',
  `data_type` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'QUANTITATIVE' COMMENT '数据类型: QUANTITATIVE定量/QUALITATIVE定性',
  `unit` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '计量单位',
  `standard_type` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '标准类型: NOMINAL名义值/LSL_ONLY/USL_ONLY/LSL_USL',
  `nominal_value` decimal(18, 6) NULL DEFAULT NULL COMMENT '名义值(NOMINAL用)',
  `lsl_value` decimal(18, 6) NULL DEFAULT NULL COMMENT '下规格限LSL',
  `usl_value` decimal(18, 6) NULL DEFAULT NULL COMMENT '上规格限USL',
  `tol_upper` decimal(18, 6) NULL DEFAULT NULL COMMENT '上公差(NOMINAL用, 名义+tolUpper)',
  `tol_lower` decimal(18, 6) NULL DEFAULT NULL COMMENT '下公差(NOMINAL用, 名义-tolLower)',
  `aql_level` varchar(8) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '检验水平(如II)',
  `sample_plan_code` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '抽样方案(如AQL1.0)',
  `criticality` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT 'MAJOR' COMMENT '关键度: CRITICAL关键(一票否决)/MAJOR/MINOR',
  `seq_num` int(11) NULL DEFAULT 1 COMMENT '序号',
  `enabled` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT '1' COMMENT '是否启用 1是0否',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '备注',
  `create_dept` bigint(20) NULL DEFAULT NULL COMMENT '创建部门',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT '0' COMMENT '删除标志',
  PRIMARY KEY (`item_id`) USING BTREE,
  INDEX `idx_template_id`(`template_id`) USING BTREE,
  INDEX `idx_item_code`(`item_code`) USING BTREE,
  INDEX `idx_tenant_id`(`tenant_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = 'QC检验项目' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of qc_inspect_item
-- ----------------------------
INSERT INTO `qc_inspect_item` VALUES (1, '000000', 1, 'IT0001', '外观', 'VISUAL', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MINOR', 1, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (2, '000000', 1, 'IT0002', '尺寸', 'DIMENSION', 'mm', 'RANGE', NULL, -0.020000, 0.020000, NULL, NULL, NULL, NULL, 'MAJOR', 2, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (3, '000000', 1, 'IT0003', '硬度', 'NUMBER', 'HRC', 'RANGE', NULL, 55.000000, 62.000000, NULL, NULL, NULL, NULL, 'MINOR', 3, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (4, '000000', 1, 'IT0004', '功能', 'BOOLEAN', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MAJOR', 4, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (5, '000000', 1, 'IT0005', '绝缘电阻', 'NUMBER', 'MΩ', 'BOOLEAN', NULL, 100.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 5, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (6, '000000', 1, 'IT0006', '耐压', 'NUMBER', 'V', 'BOOLEAN', NULL, 1500.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 6, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (7, '000000', 2, 'IT0007', '外观', 'VISUAL', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MINOR', 1, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (8, '000000', 2, 'IT0008', '尺寸', 'DIMENSION', 'mm', 'RANGE', NULL, -0.020000, 0.020000, NULL, NULL, NULL, NULL, 'MAJOR', 2, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (9, '000000', 2, 'IT0009', '硬度', 'NUMBER', 'HRC', 'RANGE', NULL, 55.000000, 62.000000, NULL, NULL, NULL, NULL, 'MINOR', 3, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (10, '000000', 2, 'IT0010', '功能', 'BOOLEAN', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MAJOR', 4, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (11, '000000', 2, 'IT0011', '绝缘电阻', 'NUMBER', 'MΩ', 'BOOLEAN', NULL, 100.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 5, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (12, '000000', 2, 'IT0012', '耐压', 'NUMBER', 'V', 'BOOLEAN', NULL, 1500.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 6, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (13, '000000', 3, 'IT0013', '外观', 'VISUAL', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MINOR', 1, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (14, '000000', 3, 'IT0014', '尺寸', 'DIMENSION', 'mm', 'RANGE', NULL, -0.020000, 0.020000, NULL, NULL, NULL, NULL, 'MAJOR', 2, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (15, '000000', 3, 'IT0015', '硬度', 'NUMBER', 'HRC', 'RANGE', NULL, 55.000000, 62.000000, NULL, NULL, NULL, NULL, 'MINOR', 3, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (16, '000000', 3, 'IT0016', '功能', 'BOOLEAN', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MAJOR', 4, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (17, '000000', 3, 'IT0017', '绝缘电阻', 'NUMBER', 'MΩ', 'BOOLEAN', NULL, 100.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 5, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (18, '000000', 3, 'IT0018', '耐压', 'NUMBER', 'V', 'BOOLEAN', NULL, 1500.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 6, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (19, '000000', 4, 'IT0019', '外观', 'VISUAL', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MINOR', 1, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (20, '000000', 4, 'IT0020', '尺寸', 'DIMENSION', 'mm', 'RANGE', NULL, -0.020000, 0.020000, NULL, NULL, NULL, NULL, 'MAJOR', 2, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (21, '000000', 4, 'IT0021', '硬度', 'NUMBER', 'HRC', 'RANGE', NULL, 55.000000, 62.000000, NULL, NULL, NULL, NULL, 'MINOR', 3, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (22, '000000', 4, 'IT0022', '功能', 'BOOLEAN', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MAJOR', 4, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (23, '000000', 4, 'IT0023', '绝缘电阻', 'NUMBER', 'MΩ', 'BOOLEAN', NULL, 100.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 5, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (24, '000000', 4, 'IT0024', '耐压', 'NUMBER', 'V', 'BOOLEAN', NULL, 1500.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 6, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (25, '000000', 5, 'IT0025', '外观', 'VISUAL', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MINOR', 1, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (26, '000000', 5, 'IT0026', '尺寸', 'DIMENSION', 'mm', 'RANGE', NULL, -0.020000, 0.020000, NULL, NULL, NULL, NULL, 'MAJOR', 2, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (27, '000000', 5, 'IT0027', '硬度', 'NUMBER', 'HRC', 'RANGE', NULL, 55.000000, 62.000000, NULL, NULL, NULL, NULL, 'MINOR', 3, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (28, '000000', 5, 'IT0028', '功能', 'BOOLEAN', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MAJOR', 4, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (29, '000000', 5, 'IT0029', '绝缘电阻', 'NUMBER', 'MΩ', 'BOOLEAN', NULL, 100.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 5, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (30, '000000', 5, 'IT0030', '耐压', 'NUMBER', 'V', 'BOOLEAN', NULL, 1500.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 6, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (31, '000000', 6, 'IT0031', '外观', 'VISUAL', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MINOR', 1, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (32, '000000', 6, 'IT0032', '尺寸', 'DIMENSION', 'mm', 'RANGE', NULL, -0.020000, 0.020000, NULL, NULL, NULL, NULL, 'MAJOR', 2, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (33, '000000', 6, 'IT0033', '硬度', 'NUMBER', 'HRC', 'RANGE', NULL, 55.000000, 62.000000, NULL, NULL, NULL, NULL, 'MINOR', 3, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (34, '000000', 6, 'IT0034', '功能', 'BOOLEAN', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MAJOR', 4, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (35, '000000', 6, 'IT0035', '绝缘电阻', 'NUMBER', 'MΩ', 'BOOLEAN', NULL, 100.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 5, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (36, '000000', 6, 'IT0036', '耐压', 'NUMBER', 'V', 'BOOLEAN', NULL, 1500.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 6, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (37, '000000', 7, 'IT0037', '外观', 'VISUAL', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MINOR', 1, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (38, '000000', 7, 'IT0038', '尺寸', 'DIMENSION', 'mm', 'RANGE', NULL, -0.020000, 0.020000, NULL, NULL, NULL, NULL, 'MAJOR', 2, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (39, '000000', 7, 'IT0039', '硬度', 'NUMBER', 'HRC', 'RANGE', NULL, 55.000000, 62.000000, NULL, NULL, NULL, NULL, 'MINOR', 3, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (40, '000000', 7, 'IT0040', '功能', 'BOOLEAN', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MAJOR', 4, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (41, '000000', 7, 'IT0041', '绝缘电阻', 'NUMBER', 'MΩ', 'BOOLEAN', NULL, 100.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 5, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (42, '000000', 7, 'IT0042', '耐压', 'NUMBER', 'V', 'BOOLEAN', NULL, 1500.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 6, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (43, '000000', 8, 'IT0043', '外观', 'VISUAL', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MINOR', 1, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (44, '000000', 8, 'IT0044', '尺寸', 'DIMENSION', 'mm', 'RANGE', NULL, -0.020000, 0.020000, NULL, NULL, NULL, NULL, 'MAJOR', 2, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (45, '000000', 8, 'IT0045', '硬度', 'NUMBER', 'HRC', 'RANGE', NULL, 55.000000, 62.000000, NULL, NULL, NULL, NULL, 'MINOR', 3, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (46, '000000', 8, 'IT0046', '功能', 'BOOLEAN', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MAJOR', 4, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (47, '000000', 8, 'IT0047', '绝缘电阻', 'NUMBER', 'MΩ', 'BOOLEAN', NULL, 100.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 5, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (48, '000000', 8, 'IT0048', '耐压', 'NUMBER', 'V', 'BOOLEAN', NULL, 1500.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 6, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (49, '000000', 9, 'IT0049', '外观', 'VISUAL', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MINOR', 1, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (50, '000000', 9, 'IT0050', '尺寸', 'DIMENSION', 'mm', 'RANGE', NULL, -0.020000, 0.020000, NULL, NULL, NULL, NULL, 'MAJOR', 2, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (51, '000000', 9, 'IT0051', '硬度', 'NUMBER', 'HRC', 'RANGE', NULL, 55.000000, 62.000000, NULL, NULL, NULL, NULL, 'MINOR', 3, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (52, '000000', 9, 'IT0052', '功能', 'BOOLEAN', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MAJOR', 4, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (53, '000000', 9, 'IT0053', '绝缘电阻', 'NUMBER', 'MΩ', 'BOOLEAN', NULL, 100.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 5, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (54, '000000', 9, 'IT0054', '耐压', 'NUMBER', 'V', 'BOOLEAN', NULL, 1500.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 6, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (55, '000000', 10, 'IT0055', '外观', 'VISUAL', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MINOR', 1, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (56, '000000', 10, 'IT0056', '尺寸', 'DIMENSION', 'mm', 'RANGE', NULL, -0.020000, 0.020000, NULL, NULL, NULL, NULL, 'MAJOR', 2, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (57, '000000', 10, 'IT0057', '硬度', 'NUMBER', 'HRC', 'RANGE', NULL, 55.000000, 62.000000, NULL, NULL, NULL, NULL, 'MINOR', 3, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (58, '000000', 10, 'IT0058', '功能', 'BOOLEAN', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MAJOR', 4, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (59, '000000', 10, 'IT0059', '绝缘电阻', 'NUMBER', 'MΩ', 'BOOLEAN', NULL, 100.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 5, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (60, '000000', 10, 'IT0060', '耐压', 'NUMBER', 'V', 'BOOLEAN', NULL, 1500.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 6, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (61, '000000', 11, 'IT0061', '外观', 'VISUAL', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MINOR', 1, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (62, '000000', 11, 'IT0062', '尺寸', 'DIMENSION', 'mm', 'RANGE', NULL, -0.020000, 0.020000, NULL, NULL, NULL, NULL, 'MAJOR', 2, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (63, '000000', 11, 'IT0063', '硬度', 'NUMBER', 'HRC', 'RANGE', NULL, 55.000000, 62.000000, NULL, NULL, NULL, NULL, 'MINOR', 3, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (64, '000000', 11, 'IT0064', '功能', 'BOOLEAN', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MAJOR', 4, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (65, '000000', 11, 'IT0065', '绝缘电阻', 'NUMBER', 'MΩ', 'BOOLEAN', NULL, 100.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 5, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (66, '000000', 11, 'IT0066', '耐压', 'NUMBER', 'V', 'BOOLEAN', NULL, 1500.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 6, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (67, '000000', 12, 'IT0067', '外观', 'VISUAL', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MINOR', 1, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (68, '000000', 12, 'IT0068', '尺寸', 'DIMENSION', 'mm', 'RANGE', NULL, -0.020000, 0.020000, NULL, NULL, NULL, NULL, 'MAJOR', 2, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (69, '000000', 12, 'IT0069', '硬度', 'NUMBER', 'HRC', 'RANGE', NULL, 55.000000, 62.000000, NULL, NULL, NULL, NULL, 'MINOR', 3, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (70, '000000', 12, 'IT0070', '功能', 'BOOLEAN', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MAJOR', 4, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (71, '000000', 12, 'IT0071', '绝缘电阻', 'NUMBER', 'MΩ', 'BOOLEAN', NULL, 100.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 5, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (72, '000000', 12, 'IT0072', '耐压', 'NUMBER', 'V', 'BOOLEAN', NULL, 1500.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 6, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (73, '000000', 13, 'IT0073', '外观', 'VISUAL', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MINOR', 1, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (74, '000000', 13, 'IT0074', '尺寸', 'DIMENSION', 'mm', 'RANGE', NULL, -0.020000, 0.020000, NULL, NULL, NULL, NULL, 'MAJOR', 2, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (75, '000000', 13, 'IT0075', '硬度', 'NUMBER', 'HRC', 'RANGE', NULL, 55.000000, 62.000000, NULL, NULL, NULL, NULL, 'MINOR', 3, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (76, '000000', 13, 'IT0076', '功能', 'BOOLEAN', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MAJOR', 4, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (77, '000000', 13, 'IT0077', '绝缘电阻', 'NUMBER', 'MΩ', 'BOOLEAN', NULL, 100.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 5, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (78, '000000', 13, 'IT0078', '耐压', 'NUMBER', 'V', 'BOOLEAN', NULL, 1500.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 6, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (79, '000000', 14, 'IT0079', '外观', 'VISUAL', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MINOR', 1, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (80, '000000', 14, 'IT0080', '尺寸', 'DIMENSION', 'mm', 'RANGE', NULL, -0.020000, 0.020000, NULL, NULL, NULL, NULL, 'MAJOR', 2, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (81, '000000', 14, 'IT0081', '硬度', 'NUMBER', 'HRC', 'RANGE', NULL, 55.000000, 62.000000, NULL, NULL, NULL, NULL, 'MINOR', 3, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (82, '000000', 14, 'IT0082', '功能', 'BOOLEAN', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MAJOR', 4, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (83, '000000', 14, 'IT0083', '绝缘电阻', 'NUMBER', 'MΩ', 'BOOLEAN', NULL, 100.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 5, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (84, '000000', 14, 'IT0084', '耐压', 'NUMBER', 'V', 'BOOLEAN', NULL, 1500.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 6, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (85, '000000', 15, 'IT0085', '外观', 'VISUAL', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MINOR', 1, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (86, '000000', 15, 'IT0086', '尺寸', 'DIMENSION', 'mm', 'RANGE', NULL, -0.020000, 0.020000, NULL, NULL, NULL, NULL, 'MAJOR', 2, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (87, '000000', 15, 'IT0087', '硬度', 'NUMBER', 'HRC', 'RANGE', NULL, 55.000000, 62.000000, NULL, NULL, NULL, NULL, 'MINOR', 3, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (88, '000000', 15, 'IT0088', '功能', 'BOOLEAN', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MAJOR', 4, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (89, '000000', 15, 'IT0089', '绝缘电阻', 'NUMBER', 'MΩ', 'BOOLEAN', NULL, 100.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 5, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (90, '000000', 15, 'IT0090', '耐压', 'NUMBER', 'V', 'BOOLEAN', NULL, 1500.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 6, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (91, '000000', 16, 'IT0091', '外观', 'VISUAL', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MINOR', 1, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (92, '000000', 16, 'IT0092', '尺寸', 'DIMENSION', 'mm', 'RANGE', NULL, -0.020000, 0.020000, NULL, NULL, NULL, NULL, 'MAJOR', 2, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (93, '000000', 16, 'IT0093', '硬度', 'NUMBER', 'HRC', 'RANGE', NULL, 55.000000, 62.000000, NULL, NULL, NULL, NULL, 'MINOR', 3, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (94, '000000', 16, 'IT0094', '功能', 'BOOLEAN', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MAJOR', 4, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (95, '000000', 16, 'IT0095', '绝缘电阻', 'NUMBER', 'MΩ', 'BOOLEAN', NULL, 100.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 5, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (96, '000000', 16, 'IT0096', '耐压', 'NUMBER', 'V', 'BOOLEAN', NULL, 1500.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 6, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (97, '000000', 17, 'IT0097', '外观', 'VISUAL', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MINOR', 1, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (98, '000000', 17, 'IT0098', '尺寸', 'DIMENSION', 'mm', 'RANGE', NULL, -0.020000, 0.020000, NULL, NULL, NULL, NULL, 'MAJOR', 2, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (99, '000000', 17, 'IT0099', '硬度', 'NUMBER', 'HRC', 'RANGE', NULL, 55.000000, 62.000000, NULL, NULL, NULL, NULL, 'MINOR', 3, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (100, '000000', 17, 'IT0100', '功能', 'BOOLEAN', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MAJOR', 4, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (101, '000000', 17, 'IT0101', '绝缘电阻', 'NUMBER', 'MΩ', 'BOOLEAN', NULL, 100.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 5, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (102, '000000', 17, 'IT0102', '耐压', 'NUMBER', 'V', 'BOOLEAN', NULL, 1500.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 6, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (103, '000000', 18, 'IT0103', '外观', 'VISUAL', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MINOR', 1, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (104, '000000', 18, 'IT0104', '尺寸', 'DIMENSION', 'mm', 'RANGE', NULL, -0.020000, 0.020000, NULL, NULL, NULL, NULL, 'MAJOR', 2, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (105, '000000', 18, 'IT0105', '硬度', 'NUMBER', 'HRC', 'RANGE', NULL, 55.000000, 62.000000, NULL, NULL, NULL, NULL, 'MINOR', 3, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (106, '000000', 18, 'IT0106', '功能', 'BOOLEAN', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MAJOR', 4, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (107, '000000', 18, 'IT0107', '绝缘电阻', 'NUMBER', 'MΩ', 'BOOLEAN', NULL, 100.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 5, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (108, '000000', 18, 'IT0108', '耐压', 'NUMBER', 'V', 'BOOLEAN', NULL, 1500.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 6, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (109, '000000', 19, 'IT0109', '外观', 'VISUAL', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MINOR', 1, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (110, '000000', 19, 'IT0110', '尺寸', 'DIMENSION', 'mm', 'RANGE', NULL, -0.020000, 0.020000, NULL, NULL, NULL, NULL, 'MAJOR', 2, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (111, '000000', 19, 'IT0111', '硬度', 'NUMBER', 'HRC', 'RANGE', NULL, 55.000000, 62.000000, NULL, NULL, NULL, NULL, 'MINOR', 3, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (112, '000000', 19, 'IT0112', '功能', 'BOOLEAN', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MAJOR', 4, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (113, '000000', 19, 'IT0113', '绝缘电阻', 'NUMBER', 'MΩ', 'BOOLEAN', NULL, 100.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 5, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (114, '000000', 19, 'IT0114', '耐压', 'NUMBER', 'V', 'BOOLEAN', NULL, 1500.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 6, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (115, '000000', 20, 'IT0115', '外观', 'VISUAL', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MINOR', 1, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (116, '000000', 20, 'IT0116', '尺寸', 'DIMENSION', 'mm', 'RANGE', NULL, -0.020000, 0.020000, NULL, NULL, NULL, NULL, 'MAJOR', 2, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (117, '000000', 20, 'IT0117', '硬度', 'NUMBER', 'HRC', 'RANGE', NULL, 55.000000, 62.000000, NULL, NULL, NULL, NULL, 'MINOR', 3, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (118, '000000', 20, 'IT0118', '功能', 'BOOLEAN', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MAJOR', 4, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (119, '000000', 20, 'IT0119', '绝缘电阻', 'NUMBER', 'MΩ', 'BOOLEAN', NULL, 100.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 5, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (120, '000000', 20, 'IT0120', '耐压', 'NUMBER', 'V', 'BOOLEAN', NULL, 1500.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 6, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (121, '000000', 21, 'IT0121', '外观', 'VISUAL', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MINOR', 1, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (122, '000000', 21, 'IT0122', '尺寸', 'DIMENSION', 'mm', 'RANGE', NULL, -0.020000, 0.020000, NULL, NULL, NULL, NULL, 'MAJOR', 2, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (123, '000000', 21, 'IT0123', '硬度', 'NUMBER', 'HRC', 'RANGE', NULL, 55.000000, 62.000000, NULL, NULL, NULL, NULL, 'MINOR', 3, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (124, '000000', 21, 'IT0124', '功能', 'BOOLEAN', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MAJOR', 4, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (125, '000000', 21, 'IT0125', '绝缘电阻', 'NUMBER', 'MΩ', 'BOOLEAN', NULL, 100.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 5, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (126, '000000', 21, 'IT0126', '耐压', 'NUMBER', 'V', 'BOOLEAN', NULL, 1500.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 6, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (127, '000000', 22, 'IT0127', '外观', 'VISUAL', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MINOR', 1, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (128, '000000', 22, 'IT0128', '尺寸', 'DIMENSION', 'mm', 'RANGE', NULL, -0.020000, 0.020000, NULL, NULL, NULL, NULL, 'MAJOR', 2, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (129, '000000', 22, 'IT0129', '硬度', 'NUMBER', 'HRC', 'RANGE', NULL, 55.000000, 62.000000, NULL, NULL, NULL, NULL, 'MINOR', 3, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (130, '000000', 22, 'IT0130', '功能', 'BOOLEAN', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MAJOR', 4, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (131, '000000', 22, 'IT0131', '绝缘电阻', 'NUMBER', 'MΩ', 'BOOLEAN', NULL, 100.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 5, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (132, '000000', 22, 'IT0132', '耐压', 'NUMBER', 'V', 'BOOLEAN', NULL, 1500.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 6, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (133, '000000', 23, 'IT0133', '外观', 'VISUAL', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MINOR', 1, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (134, '000000', 23, 'IT0134', '尺寸', 'DIMENSION', 'mm', 'RANGE', NULL, -0.020000, 0.020000, NULL, NULL, NULL, NULL, 'MAJOR', 2, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (135, '000000', 23, 'IT0135', '硬度', 'NUMBER', 'HRC', 'RANGE', NULL, 55.000000, 62.000000, NULL, NULL, NULL, NULL, 'MINOR', 3, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (136, '000000', 23, 'IT0136', '功能', 'BOOLEAN', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MAJOR', 4, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (137, '000000', 23, 'IT0137', '绝缘电阻', 'NUMBER', 'MΩ', 'BOOLEAN', NULL, 100.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 5, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (138, '000000', 23, 'IT0138', '耐压', 'NUMBER', 'V', 'BOOLEAN', NULL, 1500.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 6, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (139, '000000', 24, 'IT0139', '外观', 'VISUAL', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MINOR', 1, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (140, '000000', 24, 'IT0140', '尺寸', 'DIMENSION', 'mm', 'RANGE', NULL, -0.020000, 0.020000, NULL, NULL, NULL, NULL, 'MAJOR', 2, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (141, '000000', 24, 'IT0141', '硬度', 'NUMBER', 'HRC', 'RANGE', NULL, 55.000000, 62.000000, NULL, NULL, NULL, NULL, 'MINOR', 3, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (142, '000000', 24, 'IT0142', '功能', 'BOOLEAN', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MAJOR', 4, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (143, '000000', 24, 'IT0143', '绝缘电阻', 'NUMBER', 'MΩ', 'BOOLEAN', NULL, 100.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 5, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (144, '000000', 24, 'IT0144', '耐压', 'NUMBER', 'V', 'BOOLEAN', NULL, 1500.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 6, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (145, '000000', 25, 'IT0145', '外观', 'VISUAL', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MINOR', 1, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (146, '000000', 25, 'IT0146', '尺寸', 'DIMENSION', 'mm', 'RANGE', NULL, -0.020000, 0.020000, NULL, NULL, NULL, NULL, 'MAJOR', 2, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (147, '000000', 25, 'IT0147', '硬度', 'NUMBER', 'HRC', 'RANGE', NULL, 55.000000, 62.000000, NULL, NULL, NULL, NULL, 'MINOR', 3, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (148, '000000', 25, 'IT0148', '功能', 'BOOLEAN', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MAJOR', 4, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (149, '000000', 25, 'IT0149', '绝缘电阻', 'NUMBER', 'MΩ', 'BOOLEAN', NULL, 100.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 5, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (150, '000000', 25, 'IT0150', '耐压', 'NUMBER', 'V', 'BOOLEAN', NULL, 1500.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 6, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (151, '000000', 26, 'IT0151', '外观', 'VISUAL', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MINOR', 1, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (152, '000000', 26, 'IT0152', '尺寸', 'DIMENSION', 'mm', 'RANGE', NULL, -0.020000, 0.020000, NULL, NULL, NULL, NULL, 'MAJOR', 2, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (153, '000000', 26, 'IT0153', '硬度', 'NUMBER', 'HRC', 'RANGE', NULL, 55.000000, 62.000000, NULL, NULL, NULL, NULL, 'MINOR', 3, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (154, '000000', 26, 'IT0154', '功能', 'BOOLEAN', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MAJOR', 4, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (155, '000000', 26, 'IT0155', '绝缘电阻', 'NUMBER', 'MΩ', 'BOOLEAN', NULL, 100.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 5, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (156, '000000', 26, 'IT0156', '耐压', 'NUMBER', 'V', 'BOOLEAN', NULL, 1500.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 6, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (157, '000000', 27, 'IT0157', '外观', 'VISUAL', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MINOR', 1, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (158, '000000', 27, 'IT0158', '尺寸', 'DIMENSION', 'mm', 'RANGE', NULL, -0.020000, 0.020000, NULL, NULL, NULL, NULL, 'MAJOR', 2, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (159, '000000', 27, 'IT0159', '硬度', 'NUMBER', 'HRC', 'RANGE', NULL, 55.000000, 62.000000, NULL, NULL, NULL, NULL, 'MINOR', 3, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (160, '000000', 27, 'IT0160', '功能', 'BOOLEAN', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MAJOR', 4, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (161, '000000', 27, 'IT0161', '绝缘电阻', 'NUMBER', 'MΩ', 'BOOLEAN', NULL, 100.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 5, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (162, '000000', 27, 'IT0162', '耐压', 'NUMBER', 'V', 'BOOLEAN', NULL, 1500.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 6, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (163, '000000', 28, 'IT0163', '外观', 'VISUAL', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MINOR', 1, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (164, '000000', 28, 'IT0164', '尺寸', 'DIMENSION', 'mm', 'RANGE', NULL, -0.020000, 0.020000, NULL, NULL, NULL, NULL, 'MAJOR', 2, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (165, '000000', 28, 'IT0165', '硬度', 'NUMBER', 'HRC', 'RANGE', NULL, 55.000000, 62.000000, NULL, NULL, NULL, NULL, 'MINOR', 3, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (166, '000000', 28, 'IT0166', '功能', 'BOOLEAN', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MAJOR', 4, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (167, '000000', 28, 'IT0167', '绝缘电阻', 'NUMBER', 'MΩ', 'BOOLEAN', NULL, 100.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 5, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (168, '000000', 28, 'IT0168', '耐压', 'NUMBER', 'V', 'BOOLEAN', NULL, 1500.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 6, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (169, '000000', 29, 'IT0169', '外观', 'VISUAL', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MINOR', 1, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (170, '000000', 29, 'IT0170', '尺寸', 'DIMENSION', 'mm', 'RANGE', NULL, -0.020000, 0.020000, NULL, NULL, NULL, NULL, 'MAJOR', 2, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (171, '000000', 29, 'IT0171', '硬度', 'NUMBER', 'HRC', 'RANGE', NULL, 55.000000, 62.000000, NULL, NULL, NULL, NULL, 'MINOR', 3, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (172, '000000', 29, 'IT0172', '功能', 'BOOLEAN', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MAJOR', 4, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (173, '000000', 29, 'IT0173', '绝缘电阻', 'NUMBER', 'MΩ', 'BOOLEAN', NULL, 100.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 5, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (174, '000000', 29, 'IT0174', '耐压', 'NUMBER', 'V', 'BOOLEAN', NULL, 1500.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 6, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (175, '000000', 30, 'IT0175', '外观', 'VISUAL', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MINOR', 1, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (176, '000000', 30, 'IT0176', '尺寸', 'DIMENSION', 'mm', 'RANGE', NULL, -0.020000, 0.020000, NULL, NULL, NULL, NULL, 'MAJOR', 2, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (177, '000000', 30, 'IT0177', '硬度', 'NUMBER', 'HRC', 'RANGE', NULL, 55.000000, 62.000000, NULL, NULL, NULL, NULL, 'MINOR', 3, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (178, '000000', 30, 'IT0178', '功能', 'BOOLEAN', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MAJOR', 4, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (179, '000000', 30, 'IT0179', '绝缘电阻', 'NUMBER', 'MΩ', 'BOOLEAN', NULL, 100.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 5, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (180, '000000', 30, 'IT0180', '耐压', 'NUMBER', 'V', 'BOOLEAN', NULL, 1500.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 6, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (181, '000000', 31, 'IT0181', '外观', 'VISUAL', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MINOR', 1, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (182, '000000', 31, 'IT0182', '尺寸', 'DIMENSION', 'mm', 'RANGE', NULL, -0.020000, 0.020000, NULL, NULL, NULL, NULL, 'MAJOR', 2, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (183, '000000', 31, 'IT0183', '硬度', 'NUMBER', 'HRC', 'RANGE', NULL, 55.000000, 62.000000, NULL, NULL, NULL, NULL, 'MINOR', 3, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (184, '000000', 31, 'IT0184', '功能', 'BOOLEAN', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MAJOR', 4, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (185, '000000', 31, 'IT0185', '绝缘电阻', 'NUMBER', 'MΩ', 'BOOLEAN', NULL, 100.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 5, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (186, '000000', 31, 'IT0186', '耐压', 'NUMBER', 'V', 'BOOLEAN', NULL, 1500.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 6, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (187, '000000', 32, 'IT0187', '外观', 'VISUAL', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MINOR', 1, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (188, '000000', 32, 'IT0188', '尺寸', 'DIMENSION', 'mm', 'RANGE', NULL, -0.020000, 0.020000, NULL, NULL, NULL, NULL, 'MAJOR', 2, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (189, '000000', 32, 'IT0189', '硬度', 'NUMBER', 'HRC', 'RANGE', NULL, 55.000000, 62.000000, NULL, NULL, NULL, NULL, 'MINOR', 3, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (190, '000000', 32, 'IT0190', '功能', 'BOOLEAN', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MAJOR', 4, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (191, '000000', 32, 'IT0191', '绝缘电阻', 'NUMBER', 'MΩ', 'BOOLEAN', NULL, 100.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 5, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (192, '000000', 32, 'IT0192', '耐压', 'NUMBER', 'V', 'BOOLEAN', NULL, 1500.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 6, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (193, '000000', 33, 'IT0193', '外观', 'VISUAL', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MINOR', 1, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (194, '000000', 33, 'IT0194', '尺寸', 'DIMENSION', 'mm', 'RANGE', NULL, -0.020000, 0.020000, NULL, NULL, NULL, NULL, 'MAJOR', 2, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (195, '000000', 33, 'IT0195', '硬度', 'NUMBER', 'HRC', 'RANGE', NULL, 55.000000, 62.000000, NULL, NULL, NULL, NULL, 'MINOR', 3, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (196, '000000', 33, 'IT0196', '功能', 'BOOLEAN', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MAJOR', 4, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (197, '000000', 33, 'IT0197', '绝缘电阻', 'NUMBER', 'MΩ', 'BOOLEAN', NULL, 100.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 5, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (198, '000000', 33, 'IT0198', '耐压', 'NUMBER', 'V', 'BOOLEAN', NULL, 1500.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 6, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (199, '000000', 34, 'IT0199', '外观', 'VISUAL', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MINOR', 1, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (200, '000000', 34, 'IT0200', '尺寸', 'DIMENSION', 'mm', 'RANGE', NULL, -0.020000, 0.020000, NULL, NULL, NULL, NULL, 'MAJOR', 2, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (201, '000000', 34, 'IT0201', '硬度', 'NUMBER', 'HRC', 'RANGE', NULL, 55.000000, 62.000000, NULL, NULL, NULL, NULL, 'MINOR', 3, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (202, '000000', 34, 'IT0202', '功能', 'BOOLEAN', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MAJOR', 4, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (203, '000000', 34, 'IT0203', '绝缘电阻', 'NUMBER', 'MΩ', 'BOOLEAN', NULL, 100.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 5, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (204, '000000', 34, 'IT0204', '耐压', 'NUMBER', 'V', 'BOOLEAN', NULL, 1500.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 6, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (205, '000000', 35, 'IT0205', '外观', 'VISUAL', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MINOR', 1, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (206, '000000', 35, 'IT0206', '尺寸', 'DIMENSION', 'mm', 'RANGE', NULL, -0.020000, 0.020000, NULL, NULL, NULL, NULL, 'MAJOR', 2, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (207, '000000', 35, 'IT0207', '硬度', 'NUMBER', 'HRC', 'RANGE', NULL, 55.000000, 62.000000, NULL, NULL, NULL, NULL, 'MINOR', 3, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (208, '000000', 35, 'IT0208', '功能', 'BOOLEAN', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MAJOR', 4, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (209, '000000', 35, 'IT0209', '绝缘电阻', 'NUMBER', 'MΩ', 'BOOLEAN', NULL, 100.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 5, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (210, '000000', 35, 'IT0210', '耐压', 'NUMBER', 'V', 'BOOLEAN', NULL, 1500.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 6, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (211, '000000', 36, 'IT0211', '外观', 'VISUAL', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MINOR', 1, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (212, '000000', 36, 'IT0212', '尺寸', 'DIMENSION', 'mm', 'RANGE', NULL, -0.020000, 0.020000, NULL, NULL, NULL, NULL, 'MAJOR', 2, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (213, '000000', 36, 'IT0213', '硬度', 'NUMBER', 'HRC', 'RANGE', NULL, 55.000000, 62.000000, NULL, NULL, NULL, NULL, 'MINOR', 3, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (214, '000000', 36, 'IT0214', '功能', 'BOOLEAN', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MAJOR', 4, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (215, '000000', 36, 'IT0215', '绝缘电阻', 'NUMBER', 'MΩ', 'BOOLEAN', NULL, 100.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 5, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (216, '000000', 36, 'IT0216', '耐压', 'NUMBER', 'V', 'BOOLEAN', NULL, 1500.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 6, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (217, '000000', 37, 'IT0217', '外观', 'VISUAL', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MINOR', 1, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (218, '000000', 37, 'IT0218', '尺寸', 'DIMENSION', 'mm', 'RANGE', NULL, -0.020000, 0.020000, NULL, NULL, NULL, NULL, 'MAJOR', 2, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (219, '000000', 37, 'IT0219', '硬度', 'NUMBER', 'HRC', 'RANGE', NULL, 55.000000, 62.000000, NULL, NULL, NULL, NULL, 'MINOR', 3, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (220, '000000', 37, 'IT0220', '功能', 'BOOLEAN', NULL, 'BOOLEAN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MAJOR', 4, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (221, '000000', 37, 'IT0221', '绝缘电阻', 'NUMBER', 'MΩ', 'BOOLEAN', NULL, 100.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 5, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (222, '000000', 37, 'IT0222', '耐压', 'NUMBER', 'V', 'BOOLEAN', NULL, 1500.000000, NULL, NULL, NULL, NULL, NULL, 'MINOR', 6, '1', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_item` VALUES (2107083839576616961, '000000', 2107083839501119490, 'M12_BOLT_COUNT', '螺栓装配数量', 'QUANTITATIVE', '件/套', 'NOMINAL', 1.000000, NULL, NULL, 0.000000, 0.000000, NULL, NULL, 'MAJOR', 1, '1', '每套用量对应原BOM明细，不引入未经确认的尺寸或扭矩公差。', 103, 1, '2026-10-05 20:21:50', 1, '2026-10-05 20:21:50', '0');
INSERT INTO `qc_inspect_item` VALUES (2107083839647920129, '000000', 2107083839501119490, 'M12_NUT_COUNT', '螺母装配数量', 'QUANTITATIVE', '件/套', 'NOMINAL', 1.000000, NULL, NULL, 0.000000, 0.000000, NULL, NULL, 'MAJOR', 2, '1', '每套用量对应原BOM明细，不引入未经确认的尺寸或扭矩公差。', 103, 1, '2026-10-05 20:21:50', 1, '2026-10-05 20:21:50', '0');
INSERT INTO `qc_inspect_item` VALUES (2107083839660503042, '000000', 2107083839501119490, 'M12_WASHER_COUNT', '平垫圈装配数量', 'QUANTITATIVE', '件/套', 'NOMINAL', 2.000000, NULL, NULL, 0.000000, 0.000000, NULL, NULL, 'MAJOR', 3, '1', '每套用量对应原BOM明细，不引入未经确认的尺寸或扭矩公差。', 103, 1, '2026-10-05 20:21:50', 1, '2026-10-05 20:21:50', '0');
INSERT INTO `qc_inspect_item` VALUES (2107114370985013250, '000000', 2107114370913710081, 'M12_OQC_BOLT_COUNT', '螺栓配套数量', 'QUANTITATIVE', '件/套', 'NOMINAL', 1.000000, NULL, NULL, 0.000000, 0.000000, NULL, NULL, 'MAJOR', 1, '1', '每套实际用量来源原BOM；不新增未经确认的尺寸或扭矩标准。', 103, 1, '2026-10-05 22:23:09', 1, '2026-10-05 22:23:09', '0');
INSERT INTO `qc_inspect_item` VALUES (2107114371014373377, '000000', 2107114370913710081, 'M12_OQC_NUT_COUNT', '螺母配套数量', 'QUANTITATIVE', '件/套', 'NOMINAL', 1.000000, NULL, NULL, 0.000000, 0.000000, NULL, NULL, 'MAJOR', 2, '1', '每套实际用量来源原BOM；不新增未经确认的尺寸或扭矩标准。', 103, 1, '2026-10-05 22:23:09', 1, '2026-10-05 22:23:09', '0');
INSERT INTO `qc_inspect_item` VALUES (2107114371022761985, '000000', 2107114370913710081, 'M12_OQC_WASHER_COUNT', '平垫圈配套数量', 'QUANTITATIVE', '件/套', 'NOMINAL', 2.000000, NULL, NULL, 0.000000, 0.000000, NULL, NULL, 'MAJOR', 3, '1', '每套实际用量来源原BOM；不新增未经确认的尺寸或扭矩标准。', 103, 1, '2026-10-05 22:23:09', 1, '2026-10-05 22:23:09', '0');
INSERT INTO `qc_inspect_item` VALUES (2107180758260998145, '000000', 2107180758202277889, 'MARK_SPEC', '物料标识与采购规格一致性', 'QUALITATIVE', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MAJOR', 1, '1', '按随货信息与采购规格核对；未来本地软件输入样本不替代实物检验。', 103, 1, '2026-10-06 02:46:57', 1, '2026-10-06 02:46:57', '0');
INSERT INTO `qc_inspect_item` VALUES (2107180758286163970, '000000', 2107180758202277889, 'QTY_LIST', '到货数量与随货清单一致性', 'QUALITATIVE', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MAJOR', 2, '1', '按随货信息与采购规格核对；未来本地软件输入样本不替代实物检验。', 103, 1, '2026-10-06 02:46:57', 1, '2026-10-06 02:46:57', '0');
INSERT INTO `qc_inspect_item` VALUES (2107180758294552578, '000000', 2107180758202277889, 'APPEARANCE', '表面及包装完整性', 'QUALITATIVE', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MAJOR', 3, '1', '按随货信息与采购规格核对；未来本地软件输入样本不替代实物检验。', 103, 1, '2026-10-06 02:46:57', 1, '2026-10-06 02:46:57', '0');
INSERT INTO `qc_inspect_item` VALUES (2107180758885949441, '000000', 2107180758873366530, 'MARK_SPEC', '物料标识与采购规格一致性', 'QUALITATIVE', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MAJOR', 1, '1', '按随货信息与采购规格核对；未来本地软件输入样本不替代实物检验。', 103, 1, '2026-10-06 02:46:57', 1, '2026-10-06 02:46:57', '0');
INSERT INTO `qc_inspect_item` VALUES (2107180758890143746, '000000', 2107180758873366530, 'QTY_LIST', '到货数量与随货清单一致性', 'QUALITATIVE', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MAJOR', 2, '1', '按随货信息与采购规格核对；未来本地软件输入样本不替代实物检验。', 103, 1, '2026-10-06 02:46:57', 1, '2026-10-06 02:46:57', '0');
INSERT INTO `qc_inspect_item` VALUES (2107180758898532353, '000000', 2107180758873366530, 'APPEARANCE', '表面及包装完整性', 'QUALITATIVE', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MAJOR', 3, '1', '按随货信息与采购规格核对；未来本地软件输入样本不替代实物检验。', 103, 1, '2026-10-06 02:46:57', 1, '2026-10-06 02:46:57', '0');
INSERT INTO `qc_inspect_item` VALUES (2107180759183745025, '000000', 2107180759166967810, 'MARK_SPEC', '物料标识与采购规格一致性', 'QUALITATIVE', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MAJOR', 1, '1', '按随货信息与采购规格核对；未来本地软件输入样本不替代实物检验。', 103, 1, '2026-10-06 02:46:57', 1, '2026-10-06 02:46:57', '0');
INSERT INTO `qc_inspect_item` VALUES (2107180759187939329, '000000', 2107180759166967810, 'QTY_LIST', '到货数量与随货清单一致性', 'QUALITATIVE', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MAJOR', 2, '1', '按随货信息与采购规格核对；未来本地软件输入样本不替代实物检验。', 103, 1, '2026-10-06 02:46:57', 1, '2026-10-06 02:46:57', '0');
INSERT INTO `qc_inspect_item` VALUES (2107180759196327937, '000000', 2107180759166967810, 'APPEARANCE', '表面及包装完整性', 'QUALITATIVE', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MAJOR', 3, '1', '按随货信息与采购规格核对；未来本地软件输入样本不替代实物检验。', 103, 1, '2026-10-06 02:46:57', 1, '2026-10-06 02:46:57', '0');

-- ----------------------------
-- Table structure for qc_inspect_template
-- ----------------------------
DROP TABLE IF EXISTS `qc_inspect_template`;
CREATE TABLE `qc_inspect_template`  (
  `template_id` bigint(20) NOT NULL COMMENT '检验模板ID(主键)',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '000000' COMMENT '租户ID',
  `template_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '模板编码(唯一)',
  `template_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '模板名称',
  `template_type` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '模板类型: IQC/IPQC/OQC',
  `material_id` bigint(20) NULL DEFAULT NULL COMMENT '物料ID(空=通用模板)',
  `material_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '物料编码(冗余)',
  `material_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '物料名称(冗余)',
  `process_id` bigint(20) NULL DEFAULT NULL COMMENT '工序ID(IPQC维度,空=不限工序)',
  `customer_id` bigint(20) NULL DEFAULT NULL COMMENT '客户ID(客户专属模板维度,空=不限客户)',
  `version_no` int(11) NOT NULL DEFAULT 1 COMMENT '版本号',
  `status` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT 'DRAFT' COMMENT '状态: DRAFT/ACTIVE',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '备注',
  `create_dept` bigint(20) NULL DEFAULT NULL COMMENT '创建部门',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT '0' COMMENT '删除标志',
  PRIMARY KEY (`template_id`) USING BTREE,
  UNIQUE INDEX `uk_template_code`(`tenant_id`, `template_code`) USING BTREE,
  INDEX `idx_template_type`(`template_type`) USING BTREE,
  INDEX `idx_material_id`(`material_id`) USING BTREE,
  INDEX `idx_status`(`status`) USING BTREE,
  INDEX `idx_tenant_id`(`tenant_id`) USING BTREE,
  INDEX `idx_qc_tpl_match`(`template_type`, `status`, `material_id`, `process_id`, `customer_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = 'QC检验模板' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of qc_inspect_template
-- ----------------------------
INSERT INTO `qc_inspect_template` VALUES (1, '000000', 'QC20260914001', '高强度螺栓组套 M12成品检验规范', 'OQC', 1, 'IF20260914001', '高强度螺栓组套 M12', NULL, NULL, 1, 'DRAFT', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_template` VALUES (2, '000000', 'QC20260914002', '精密齿轮箱总成成品检验规范', 'OQC', 2, 'IF20260914002', '精密齿轮箱总成', NULL, NULL, 1, 'DRAFT', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', 1, '2026-09-22 11:21:08', '0');
INSERT INTO `qc_inspect_template` VALUES (3, '000000', 'QC20260914003', '压缩弹簧组成品检验规范', 'OQC', 3, 'IF20260914003', '压缩弹簧组', NULL, NULL, 1, 'DRAFT', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_template` VALUES (4, '000000', 'QC20260914004', '设备钣金机箱成品检验规范', 'OQC', 4, 'IF20260914004', '设备钣金机箱', NULL, NULL, 1, 'DRAFT', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_template` VALUES (5, '000000', 'QC20260914005', '钢结构支架总成成品检验规范', 'OQC', 5, 'IF20260914005', '钢结构支架总成', NULL, NULL, 1, 'DRAFT', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_template` VALUES (6, '000000', 'QC20260914006', '注塑模具成品检验规范', 'OQC', 6, 'IF20260914006', '注塑模具', NULL, NULL, 1, 'DRAFT', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_template` VALUES (7, '000000', 'QC20260914007', '棘轮扳手组套成品检验规范', 'OQC', 7, 'IF20260914007', '棘轮扳手组套', NULL, NULL, 1, 'DRAFT', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_template` VALUES (8, '000000', 'QC20260914008', '齿轮减速机 JZQ-350成品检验规范', 'OQC', 8, 'IF20260914008', '齿轮减速机 JZQ-350', NULL, NULL, 1, 'DRAFT', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_template` VALUES (9, '000000', 'QC20260914009', '单级离心泵成品检验规范', 'OQC', 9, 'IF20260914009', '单级离心泵', NULL, NULL, 1, 'DRAFT', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_template` VALUES (10, '000000', 'QC20260914010', '数控铣床 XK714成品检验规范', 'OQC', 10, 'IF20260914010', '数控铣床 XK714', NULL, NULL, 1, 'DRAFT', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_template` VALUES (11, '000000', 'QC20260914011', '皮带输送线成品检验规范', 'OQC', 11, 'IF20260914011', '皮带输送线', NULL, NULL, 1, 'DRAFT', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_template` VALUES (12, '000000', 'QC20260914012', '螺杆式空压机成品检验规范', 'OQC', 12, 'IF20260914012', '螺杆式空压机', NULL, NULL, 1, 'DRAFT', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_template` VALUES (13, '000000', 'QC20260914013', '双层 PCB 板成品检验规范', 'OQC', 13, 'IF20260914013', '双层 PCB 板', NULL, NULL, 1, 'DRAFT', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_template` VALUES (14, '000000', 'QC20260914014', '智能路由器 WR-1200成品检验规范', 'OQC', 14, 'IF20260914014', '智能路由器 WR-1200', NULL, NULL, 1, 'DRAFT', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_template` VALUES (15, '000000', 'QC20260914015', '变频电风扇成品检验规范', 'OQC', 15, 'IF20260914015', '变频电风扇', NULL, NULL, 1, 'DRAFT', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_template` VALUES (16, '000000', 'QC20260914016', '开关电源模组 SMPS-60成品检验规范', 'OQC', 16, 'IF20260914016', '开关电源模组 SMPS-60', NULL, NULL, 1, 'DRAFT', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_template` VALUES (17, '000000', 'QC20260914017', '无刷直流电机 BLDC-45成品检验规范', 'OQC', 17, 'IF20260914017', '无刷直流电机 BLDC-45', NULL, NULL, 1, 'DRAFT', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_template` VALUES (18, '000000', 'QC20260914018', '温度传感器模组 TS-100成品检验规范', 'OQC', 18, 'IF20260914018', '温度传感器模组 TS-100', NULL, NULL, 1, 'DRAFT', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_template` VALUES (19, '000000', 'QC20260914019', '数字万用表 DM-800成品检验规范', 'OQC', 19, 'IF20260914019', '数字万用表 DM-800', NULL, NULL, 1, 'DRAFT', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_template` VALUES (20, '000000', 'QC20260914020', '汽车门锁总成成品检验规范', 'OQC', 20, 'IF20260914020', '汽车门锁总成', NULL, NULL, 1, 'DRAFT', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_template` VALUES (21, '000000', 'QC20260914021', '城市通勤自行车成品检验规范', 'OQC', 21, 'IF20260914021', '城市通勤自行车', NULL, NULL, 1, 'DRAFT', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_template` VALUES (22, '000000', 'QC20260914022', '四轴无人机机架成品检验规范', 'OQC', 22, 'IF20260914022', '四轴无人机机架', NULL, NULL, 1, 'DRAFT', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_template` VALUES (23, '000000', 'QC20260914023', '不锈钢手术剪成品检验规范', 'OQC', 23, 'IF20260914023', '不锈钢手术剪', NULL, NULL, 1, 'DRAFT', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_template` VALUES (24, '000000', 'QC20260914024', '手动轮椅成品检验规范', 'OQC', 24, 'IF20260914024', '手动轮椅', NULL, NULL, 1, 'DRAFT', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_template` VALUES (25, '000000', 'QC20260914025', '简易金属工具架 RACK-001成品检验规范', 'OQC', 25, 'IF20260914025', '简易金属工具架 RACK-001', NULL, NULL, 1, 'DRAFT', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_template` VALUES (26, '000000', 'QC20260914026', 'LED 护眼台灯成品检验规范', 'OQC', 26, 'IF20260914026', 'LED 护眼台灯', NULL, NULL, 1, 'DRAFT', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_template` VALUES (27, '000000', 'QC20260914027', '智能网关 GW-1000成品检验规范', 'OQC', 27, 'IF20260914027', '智能网关 GW-1000', NULL, NULL, 1, 'DRAFT', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_template` VALUES (28, '000000', 'QC20260914028', '精密塑料外壳 PC-200成品检验规范', 'OQC', 28, 'IF20260914028', '精密塑料外壳 PC-200', NULL, NULL, 1, 'DRAFT', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_template` VALUES (29, '000000', 'QC20260914029', '硅胶密封圈组成品检验规范', 'OQC', 29, 'IF20260914029', '硅胶密封圈组', NULL, NULL, 1, 'DRAFT', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_template` VALUES (30, '000000', 'QC20260914030', '锂电池包 48V20Ah成品检验规范', 'OQC', 30, 'IF20260914030', '锂电池包 48V20Ah', NULL, NULL, 1, 'DRAFT', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_template` VALUES (31, '000000', 'QC20260914031', '交流充电桩 AC-7kW成品检验规范', 'OQC', 31, 'IF20260914031', '交流充电桩 AC-7kW', NULL, NULL, 1, 'DRAFT', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_template` VALUES (32, '000000', 'QC20260914032', '光伏组件 450W成品检验规范', 'OQC', 32, 'IF20260914032', '光伏组件 450W', NULL, NULL, 1, 'DRAFT', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_template` VALUES (33, '000000', 'QC20260914033', '六轴机械臂 RB-6成品检验规范', 'OQC', 33, 'IF20260914033', '六轴机械臂 RB-6', NULL, NULL, 1, 'DRAFT', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_template` VALUES (34, '000000', 'QC20260914034', '智能手环 BAND-3成品检验规范', 'OQC', 34, 'IF20260914034', '智能手环 BAND-3', NULL, NULL, 1, 'DRAFT', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_template` VALUES (35, '000000', 'QC20260914035', '手持 POS 机 POS-8成品检验规范', 'OQC', 35, 'IF20260914035', '手持 POS 机 POS-8', NULL, NULL, 1, 'DRAFT', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_template` VALUES (36, '000000', 'QC20260914036', '网络摄像机 IPC-300成品检验规范', 'OQC', 36, 'IF20260914036', '网络摄像机 IPC-300', NULL, NULL, 1, 'DRAFT', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_template` VALUES (37, '000000', 'QC20260914037', '无线蓝牙音箱 SPK-20成品检验规范', 'OQC', 37, 'IF20260914037', '无线蓝牙音箱 SPK-20', NULL, NULL, 1, 'DRAFT', '按产品族通用检验要求生成', 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `qc_inspect_template` VALUES (2107083839501119490, '000000', 'QC20261005001', 'M12镀锌连接组件装配检验规范', 'IPQC', 2106761349704929281, 'IF20261004006', 'M12高强度镀锌螺栓连接组件', 54, NULL, 1, 'ACTIVE', '标准来源为当前BOM每套螺栓1、螺母1、平垫圈2；本地接口验收值为软件录入，不是实物测量。', 103, 1, '2026-10-05 20:21:50', 1, '2026-10-05 20:21:50', '0');
INSERT INTO `qc_inspect_template` VALUES (2107114370913710081, '000000', 'QC20261005002', 'M12镀锌连接组件出货检验规范', 'OQC', 2106761349704929281, 'IF20261004006', 'M12高强度镀锌螺栓连接组件', NULL, NULL, 1, 'ACTIVE', '装配件完整性按原BOM每套1枚螺栓、1枚螺母、2枚平垫圈核对；软件验收输入不得冒充实物测量。', 103, 1, '2026-10-05 22:23:09', 1, '2026-10-05 22:23:09', '0');
INSERT INTO `qc_inspect_template` VALUES (2107180758202277889, '000000', 'QC20261006001', '六角头螺栓M12×50来料验收规范', 'IQC', 2106760678595317762, 'IF20261004003', '六角头螺栓 M12×50 8.8级 镀锌', NULL, NULL, 1, 'ACTIVE', '用于新到货业务的标识、数量清单与外观一致性项目。此处仅建立规范，不预置检验结果。', 103, 1, '2026-10-06 02:46:57', 1, '2026-10-06 02:46:57', '0');
INSERT INTO `qc_inspect_template` VALUES (2107180758873366530, '000000', 'QC20261006002', '六角螺母M12来料验收规范', 'IQC', 2106760679291572226, 'IF20261004004', '六角螺母 M12 8级 镀锌', NULL, NULL, 1, 'ACTIVE', '用于新到货业务的标识、数量清单与外观一致性项目。此处仅建立规范，不预置检验结果。', 103, 1, '2026-10-06 02:46:57', 1, '2026-10-06 02:46:57', '0');
INSERT INTO `qc_inspect_template` VALUES (2107180759166967810, '000000', 'QC20261006003', '平垫圈12来料验收规范', 'IQC', 2106760679643893762, 'IF20261004005', '平垫圈 12 A级 镀锌', NULL, NULL, 1, 'ACTIVE', '用于新到货业务的标识、数量清单与外观一致性项目。此处仅建立规范，不预置检验结果。', 103, 1, '2026-10-06 02:46:57', 1, '2026-10-06 02:46:57', '0');

-- ----------------------------
-- Table structure for qc_ipqc
-- ----------------------------
DROP TABLE IF EXISTS `qc_ipqc`;
CREATE TABLE `qc_ipqc`  (
  `ipqc_id` bigint(20) NOT NULL COMMENT 'IPQC ID(主键)',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '000000',
  `ipqc_no` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'IPQC编号',
  `mes_wo_id` bigint(20) NOT NULL COMMENT 'MES工单ID',
  `wo_no` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '工单编号(冗余)',
  `card_id` bigint(20) NULL DEFAULT NULL COMMENT '流转卡ID',
  `step_record_id` bigint(20) NULL DEFAULT NULL COMMENT '流转卡工序记录ID',
  `process_id` bigint(20) NULL DEFAULT NULL COMMENT '工序ID',
  `process_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '工序编码',
  `process_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '工序名称',
  `material_id` bigint(20) NOT NULL COMMENT '物料ID',
  `material_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '物料编码(冗余)',
  `material_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '物料名称(冗余)',
  `sample_qty` decimal(14, 4) NULL DEFAULT NULL COMMENT '抽样数量',
  `defect_qty` decimal(14, 4) NULL DEFAULT 0.0000 COMMENT '不良数量',
  `defect_rate` decimal(5, 2) NULL DEFAULT NULL COMMENT '不良率(%)',
  `inspect_result` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT 'PENDING' COMMENT '检验结果: QUALIFIED/UNQUALIFIED/PENDING',
  `defect_info` json NULL COMMENT '不良品信息(类型/数量/描述)',
  `inspector_id` bigint(20) NULL DEFAULT NULL COMMENT '检验员ID',
  `inspector_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '检验员姓名',
  `inspect_time` datetime(0) NULL DEFAULT NULL COMMENT '检验时间',
  `status` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT 'PENDING' COMMENT '状态: PENDING/INSPECTING/COMPLETED',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '备注',
  `create_dept` bigint(20) NULL DEFAULT NULL COMMENT '创建部门',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT '0' COMMENT '删除标志',
  `photo_oss_ids` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '检验照片附件ossId串(逗号分隔)',
  PRIMARY KEY (`ipqc_id`) USING BTREE,
  UNIQUE INDEX `uk_ipqc_no`(`tenant_id`, `ipqc_no`) USING BTREE,
  UNIQUE INDEX `uk_ipqc_wo_process`(`tenant_id`, `mes_wo_id`, `process_id`) USING BTREE,
  INDEX `idx_mes_wo_id`(`mes_wo_id`) USING BTREE,
  INDEX `idx_status`(`status`) USING BTREE,
  INDEX `idx_card_id`(`card_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = 'MES过程检验' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of qc_ipqc
-- ----------------------------
INSERT INTO `qc_ipqc` VALUES (2107086753833562114, '000000', 'IPQC-20261005-2107086753825173504', 2106995561900978178, 'SCGD202610050001', 2107083840268677122, 2107083840394506242, 54, 'QC', '质检', 2106761349704929281, 'IF20261004006', 'M12高强度镀锌螺栓连接组件', 10.0000, 0.0000, NULL, 'QUALIFIED', NULL, 1, 'admin', '2026-10-05 20:33:25', 'COMPLETED', '依据原BOM的1/1/2件单耗完成数量项目自动判定；非现场实物检验。', 103, 1, '2026-10-05 20:33:25', 1, '2026-10-05 20:33:25', '0', NULL);
INSERT INTO `qc_ipqc` VALUES (2107331726478880769, '000000', 'IPQC-20261006-2107331726474686464', 2107323241485774850, 'SCGD202610060001', 2107328405412196354, 2107328405466722305, 54, 'QC', '质检', 2106761349704929281, 'IF20261004006', NULL, 6.0000, 0.0000, NULL, 'QUALIFIED', NULL, 1, 'admin', '2026-10-06 12:46:50', 'COMPLETED', '六套连接组件的软件过程数量检验；不冒充现场或实物人工验收', 103, 1, '2026-10-06 12:46:51', 1, '2026-10-06 12:46:51', '0', NULL);
INSERT INTO `qc_ipqc` VALUES (2107526720884015106, '000000', 'IPQC-20261007-2107526720879820800', 2107352232221392898, 'SCGD202610060002', 2107524224165838850, 2107524224237142018, 54, 'QC', '质检', 2106761349704929281, 'IF20261004006', 'M12高强度镀锌螺栓连接组件', 6.0000, 0.0000, NULL, 'QUALIFIED', NULL, 1, 'admin', '2026-10-07 01:41:40', 'COMPLETED', '完整三个BOM用量项目自动判定；本地已备份测试环境，非实物检验。', 103, 1, '2026-10-07 01:41:41', 1, '2026-10-07 01:41:41', '0', NULL);
INSERT INTO `qc_ipqc` VALUES (2108675852910657537, '000000', 'IPQC-20261010-2108675852898074624', 2108617060583989249, 'SCGD202610080013', 2108660178645614593, 2108660178674974722, 54, 'QC', '质检', 2106761349704929281, 'IF20261004006', NULL, 3.0000, 0.0000, NULL, 'QUALIFIED', NULL, 1, 'admin', '2026-10-10 05:47:55', 'COMPLETED', '组件装配过程数量核对', 103, 1, '2026-10-10 05:47:55', 1, '2026-10-10 05:47:55', '0', NULL);
INSERT INTO `qc_ipqc` VALUES (2108677266978308097, '000000', 'IPQC-20261010-2108677266978308096', 2108617069803069441, 'SCGD202610080017', 2108660179664830465, 2108660179698384897, 54, 'QC', '质检', 2106761349704929281, 'IF20261004006', NULL, 3.0000, 0.0000, NULL, 'QUALIFIED', NULL, 1, 'admin', '2026-10-10 05:53:32', 'COMPLETED', '组件装配过程数量核对', 103, 1, '2026-10-10 05:53:32', 1, '2026-10-10 05:53:32', '0', NULL);
INSERT INTO `qc_ipqc` VALUES (2108738644816650242, '000000', 'IPQC-20261010-2108738644816650240', 2108617051121639426, 'SCGD202610080009', 2108660177370546178, 2108660177437655041, 54, 'QC', '质检', 2106761349704929281, 'IF20261004006', NULL, 3.0000, 0.0000, NULL, 'QUALIFIED', NULL, 1, 'admin', '2026-10-10 09:57:26', 'COMPLETED', '组件装配过程数量核对', 103, 1, '2026-10-10 09:57:26', 1, '2026-10-10 09:57:26', '0', NULL);

-- ----------------------------
-- Table structure for qc_iqc
-- ----------------------------
DROP TABLE IF EXISTS `qc_iqc`;
CREATE TABLE `qc_iqc`  (
  `iqc_id` bigint(20) NOT NULL COMMENT 'IQC ID(主键)',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '000000',
  `iqc_no` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'IQC编号',
  `receive_id` bigint(20) NULL DEFAULT NULL COMMENT 'ERP收货单ID',
  `material_id` bigint(20) NOT NULL COMMENT '物料ID',
  `material_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '物料编码(冗余)',
  `material_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '物料名称(冗余)',
  `vendor_id` bigint(20) NULL DEFAULT NULL COMMENT '供应商ID',
  `vendor_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '供应商名称(冗余)',
  `quantity` decimal(14, 4) NOT NULL COMMENT '检验数量',
  `sample_qty` decimal(14, 4) NULL DEFAULT NULL COMMENT '抽样数量',
  `inspect_result` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT 'PENDING' COMMENT '检验结果: QUALIFIED/UNQUALIFIED/PENDING',
  `defect_info` json NULL COMMENT '不良品信息(类型/数量/描述)',
  `inspector_id` bigint(20) NULL DEFAULT NULL COMMENT '检验员ID',
  `inspector_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '检验员姓名',
  `inspect_time` datetime(0) NULL DEFAULT NULL COMMENT '检验时间',
  `status` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT 'PENDING' COMMENT '状态: PENDING/INSPECTING/COMPLETED',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '备注',
  `create_dept` bigint(20) NULL DEFAULT NULL COMMENT '创建部门',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT '0' COMMENT '删除标志',
  `photo_oss_ids` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '检验照片附件ossId串(逗号分隔)',
  PRIMARY KEY (`iqc_id`) USING BTREE,
  UNIQUE INDEX `uk_iqc_no`(`tenant_id`, `iqc_no`) USING BTREE,
  UNIQUE INDEX `uk_iqc_receive_material`(`tenant_id`, `receive_id`, `material_id`) USING BTREE,
  INDEX `idx_status`(`status`) USING BTREE,
  INDEX `idx_receive_id`(`receive_id`) USING BTREE,
  INDEX `idx_material_id`(`material_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = 'MES来料检验' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of qc_iqc
-- ----------------------------
INSERT INTO `qc_iqc` VALUES (2106959154797019136, '000000', 'IQC-20261005-2106959154797019136', 2106767580603568130, 2106760678595317762, 'IF20261004003', '六角头螺栓 M12×50 8.8级 镀锌', 2, '江苏精密紧固件制造厂', 10.0000, NULL, 'QUALIFIED', NULL, 1, 'admin', '2026-10-05 12:08:32', 'COMPLETED', '本地开发业务软件验证的人工判定；不代表实物测量、供应商现场或人工端到端验收。', NULL, NULL, '2026-10-05 12:06:22', NULL, NULL, '0', NULL);
INSERT INTO `qc_iqc` VALUES (2106959517738532864, '000000', 'IQC-20261005-2106959517738532864', 2106767585661898753, 2106760679291572226, 'IF20261004004', '六角螺母 M12 8级 镀锌', 2, '江苏精密紧固件制造厂', 10.0000, NULL, 'QUALIFIED', NULL, 1, 'admin', '2026-10-05 12:08:46', 'COMPLETED', '本地开发业务软件验证的人工判定；不代表实物测量、供应商现场或人工端到端验收。', NULL, NULL, '2026-10-05 12:07:49', NULL, NULL, '0', NULL);
INSERT INTO `qc_iqc` VALUES (2106959556082860032, '000000', 'IQC-20261005-2106959556082860032', 2106767590309187585, 2106760679643893762, 'IF20261004005', '平垫圈 12 A级 镀锌', 2, '江苏精密紧固件制造厂', 20.0000, NULL, 'QUALIFIED', NULL, 1, 'admin', '2026-10-05 12:09:57', 'COMPLETED', '本地开发业务软件验证的人工判定；不代表实物测量、供应商现场或人工端到端验收。', NULL, NULL, '2026-10-05 12:07:58', NULL, NULL, '0', NULL);
INSERT INTO `qc_iqc` VALUES (2107310554534064128, '000000', 'IQC-20261006-2107310554534064128', 2107310517406085121, 2106760678595317762, 'IF20261004003', '六角头螺栓 M12×50 8.8级 镀锌', 2, '江苏精密紧固件制造厂', 2.0000, NULL, 'QUALIFIED', NULL, 1, 'admin', '2026-10-06 11:24:08', 'COMPLETED', '按三项模板完成软件业务检验记录；本地已备份测试环境，不作为实物质量验收证明', NULL, NULL, '2026-10-06 11:22:42', NULL, NULL, '0', NULL);
INSERT INTO `qc_iqc` VALUES (2107310616316162048, '000000', 'IQC-20261006-2107310616316162048', 2107310521491337217, 2106760679291572226, 'IF20261004004', '六角螺母 M12 8级 镀锌', 2, '江苏精密紧固件制造厂', 2.0000, NULL, 'QUALIFIED', NULL, 1, 'admin', '2026-10-06 11:24:19', 'COMPLETED', '按三项模板完成软件业务检验记录；本地已备份测试环境，不作为实物质量验收证明', NULL, NULL, '2026-10-06 11:22:57', NULL, NULL, '0', NULL);
INSERT INTO `qc_iqc` VALUES (2107310677737549824, '000000', 'IQC-20261006-2107310677737549824', 2107310525022941186, 2106760679643893762, 'IF20261004005', '平垫圈 12 A级 镀锌', 2, '江苏精密紧固件制造厂', 4.0000, NULL, 'QUALIFIED', NULL, 1, 'admin', '2026-10-06 11:24:41', 'COMPLETED', '按三项模板完成软件业务检验记录；本地已备份测试环境，不作为实物质量验收证明', NULL, NULL, '2026-10-06 11:23:12', NULL, NULL, '0', NULL);
INSERT INTO `qc_iqc` VALUES (2107312390305427456, '000000', 'IQC-20261006-2107312390305427456', 2107312358814593026, 2106760678595317762, 'IF20261004003', '六角头螺栓 M12×50 8.8级 镀锌', 2, '江苏精密紧固件制造厂', 4.0000, NULL, 'QUALIFIED', NULL, 1, 'admin', '2026-10-06 11:30:05', 'COMPLETED', '按三项模板完成软件业务检验记录；本地已备份测试环境，不作为实物质量验收证明', NULL, NULL, '2026-10-06 11:30:00', NULL, NULL, '0', NULL);
INSERT INTO `qc_iqc` VALUES (2107312454167900160, '000000', 'IQC-20261006-2107312454167900160', 2107312362652381186, 2106760679291572226, 'IF20261004004', '六角螺母 M12 8级 镀锌', 2, '江苏精密紧固件制造厂', 4.0000, NULL, 'QUALIFIED', NULL, 1, 'admin', '2026-10-06 11:30:26', 'COMPLETED', '按三项模板完成软件业务检验记录；本地已备份测试环境，不作为实物质量验收证明', NULL, NULL, '2026-10-06 11:30:15', NULL, NULL, '0', NULL);
INSERT INTO `qc_iqc` VALUES (2107312531259207680, '000000', 'IQC-20261006-2107312531259207680', 2107312366179790849, 2106760679643893762, 'IF20261004005', '平垫圈 12 A级 镀锌', 2, '江苏精密紧固件制造厂', 8.0000, NULL, 'QUALIFIED', NULL, 1, 'admin', '2026-10-06 11:30:42', 'COMPLETED', '按三项模板完成软件业务检验记录；本地已备份测试环境，不作为实物质量验收证明', NULL, NULL, '2026-10-06 11:30:34', NULL, NULL, '0', NULL);
INSERT INTO `qc_iqc` VALUES (2107516476623650816, '000000', 'IQC-20261007-2107516476623650816', 2107516436131840002, 2106760678595317762, 'IF20261004003', '六角头螺栓 M12×50 8.8级 镀锌', 2, '江苏精密紧固件制造厂', 2.0000, NULL, 'QUALIFIED', NULL, 1, 'admin', '2026-10-07 01:01:03', 'COMPLETED', '按三项模板完成软件业务检验记录；本地已备份测试环境，不作为实物质量验收证明', NULL, NULL, '2026-10-07 01:00:58', NULL, NULL, '0', NULL);
INSERT INTO `qc_iqc` VALUES (2107516539609513984, '000000', 'IQC-20261007-2107516539609513984', 2107516441114673153, 2106760679291572226, 'IF20261004004', '六角螺母 M12 8级 镀锌', 2, '江苏精密紧固件制造厂', 2.0000, NULL, 'QUALIFIED', NULL, 1, 'admin', '2026-10-07 01:01:21', 'COMPLETED', '按三项模板完成软件业务检验记录；本地已备份测试环境，不作为实物质量验收证明', NULL, NULL, '2026-10-07 01:01:13', NULL, NULL, '0', NULL);
INSERT INTO `qc_iqc` VALUES (2107516605988569088, '000000', 'IQC-20261007-2107516605988569088', 2107516444507865090, 2106760679643893762, 'IF20261004005', '平垫圈 12 A级 镀锌', 2, '江苏精密紧固件制造厂', 4.0000, NULL, 'QUALIFIED', NULL, 1, 'admin', '2026-10-07 01:01:37', 'COMPLETED', '按三项模板完成软件业务检验记录；本地已备份测试环境，不作为实物质量验收证明', NULL, NULL, '2026-10-07 01:01:29', NULL, NULL, '0', NULL);
INSERT INTO `qc_iqc` VALUES (2107518637990445056, '000000', 'IQC-20261007-2107518637990445056', 2107518606575108098, 2106760678595317762, 'IF20261004003', '六角头螺栓 M12×50 8.8级 镀锌', 2, '江苏精密紧固件制造厂', 4.0000, NULL, 'QUALIFIED', NULL, 1, 'admin', '2026-10-07 01:09:38', 'COMPLETED', '按三项模板完成软件业务检验记录；本地已备份测试环境，不作为实物质量验收证明', NULL, NULL, '2026-10-07 01:09:33', NULL, NULL, '0', NULL);
INSERT INTO `qc_iqc` VALUES (2107518702058438656, '000000', 'IQC-20261007-2107518702058438656', 2107518610215763969, 2106760679291572226, 'IF20261004004', '六角螺母 M12 8级 镀锌', 2, '江苏精密紧固件制造厂', 4.0000, NULL, 'QUALIFIED', NULL, 1, 'admin', '2026-10-07 01:09:59', 'COMPLETED', '按三项模板完成软件业务检验记录；本地已备份测试环境，不作为实物质量验收证明', NULL, NULL, '2026-10-07 01:09:49', NULL, NULL, '0', NULL);
INSERT INTO `qc_iqc` VALUES (2107518778629652480, '000000', 'IQC-20261007-2107518778629652480', 2107518613600567298, 2106760679643893762, 'IF20261004005', '平垫圈 12 A级 镀锌', 2, '江苏精密紧固件制造厂', 8.0000, NULL, 'QUALIFIED', NULL, 1, 'admin', '2026-10-07 01:10:15', 'COMPLETED', '按三项模板完成软件业务检验记录；本地已备份测试环境，不作为实物质量验收证明', NULL, NULL, '2026-10-07 01:10:07', NULL, NULL, '0', NULL);
INSERT INTO `qc_iqc` VALUES (2108007599179763712, '000000', 'IQC-20261008-2108007599179763712', 2108007550425174018, 2106760679643893762, 'IF20261004005', '平垫圈 12 A级 镀锌', 2, '江苏精密紧固件制造厂', 8.0000, NULL, 'QUALIFIED', NULL, 1, 'admin', '2026-10-08 09:35:55', 'COMPLETED', '本地业务检验资料；三项为软件流程定性输入，不代表实物抽检、尺寸测量或供应商签章。', NULL, NULL, '2026-10-08 09:32:31', NULL, NULL, '0', NULL);
INSERT INTO `qc_iqc` VALUES (2108593288606900224, '000000', 'IQC-20261010-2108593288606900224', 2108590538598899714, 2106760679291572226, 'IF20261004004', '六角螺母 M12 8级 镀锌', 2, '江苏精密紧固件制造厂', 22.0000, NULL, 'QUALIFIED', NULL, 1, 'admin', '2026-10-10 00:35:14', 'COMPLETED', '按本批检验资料核对规格、数量与外观', NULL, NULL, '2026-10-10 00:19:50', NULL, NULL, '0', NULL);
INSERT INTO `qc_iqc` VALUES (2108593346253414400, '000000', 'IQC-20261010-2108593346253414400', 2108592104873648129, 2106760679643893762, 'IF20261004005', '平垫圈 12 A级 镀锌', 2, '江苏精密紧固件制造厂', 44.0000, NULL, 'QUALIFIED', NULL, 1, 'admin', '2026-10-10 00:35:25', 'COMPLETED', '按本批检验资料核对规格、数量与外观', NULL, NULL, '2026-10-10 00:20:04', NULL, NULL, '0', NULL);
INSERT INTO `qc_iqc` VALUES (2108654961719967744, '000000', 'IQC-20261010-2108654961719967744', 2108654928614326274, 2106760678595317762, 'IF20261004003', '六角头螺栓 M12×50 8.8级 镀锌', 2, '江苏精密紧固件制造厂', 22.0000, NULL, 'QUALIFIED', NULL, 1, 'admin', '2026-10-10 04:25:07', 'COMPLETED', '按本批资料核对规格、数量与外观', NULL, NULL, '2026-10-10 04:24:54', NULL, NULL, '0', NULL);
INSERT INTO `qc_iqc` VALUES (2108659592160280576, '000000', 'IQC-20261010-2108659592160280576', 2108659559100776450, 2106760679643893762, 'IF20261004005', '平垫圈 12 A级 镀锌', 2, '江苏精密紧固件制造厂', 44.0000, NULL, 'QUALIFIED', NULL, 1, 'admin', '2026-10-10 04:43:22', 'COMPLETED', '按本批资料核对规格、数量与外观', NULL, NULL, '2026-10-10 04:43:18', NULL, NULL, '0', NULL);
INSERT INTO `qc_iqc` VALUES (2108660683627233280, '000000', 'IQC-20261010-2108660683627233280', 2108660649007448066, 2106760679291572226, 'IF20261004004', '六角螺母 M12 8级 镀锌', 2, '江苏精密紧固件制造厂', 22.0000, NULL, 'QUALIFIED', NULL, 1, 'admin', '2026-10-10 04:47:43', 'COMPLETED', '按本批资料核对规格、数量与外观', NULL, NULL, '2026-10-10 04:47:38', NULL, NULL, '0', NULL);
INSERT INTO `qc_iqc` VALUES (2108666698074619904, '000000', 'IQC-20261010-2108666698074619904', 2108666664755068930, 2106760678595317762, 'IF20261004003', '六角头螺栓 M12×50 8.8级 镀锌', 2, '江苏精密紧固件制造厂', 22.0000, NULL, 'QUALIFIED', NULL, 1, 'admin', '2026-10-10 05:11:37', 'COMPLETED', '按本批资料核对规格、数量与外观', NULL, NULL, '2026-10-10 05:11:32', NULL, NULL, '0', NULL);
INSERT INTO `qc_iqc` VALUES (2108667412372979712, '000000', 'IQC-20261010-2108667412372979712', 2108667379128926209, 2106760679643893762, 'IF20261004005', '平垫圈 12 A级 镀锌', 2, '江苏精密紧固件制造厂', 44.0000, NULL, 'QUALIFIED', NULL, 1, 'admin', '2026-10-10 05:14:27', 'COMPLETED', '按本批资料核对规格、数量与外观', NULL, NULL, '2026-10-10 05:14:22', NULL, NULL, '0', NULL);
INSERT INTO `qc_iqc` VALUES (2108668074506780672, '000000', 'IQC-20261010-2108668074506780672', 2108668040813936641, 2106760678595317762, 'IF20261004003', '六角头螺栓 M12×50 8.8级 镀锌', 2, '江苏精密紧固件制造厂', 22.0000, NULL, 'QUALIFIED', NULL, 1, 'admin', '2026-10-10 05:17:05', 'COMPLETED', '按本批资料核对规格、数量与外观', NULL, NULL, '2026-10-10 05:17:00', NULL, NULL, '0', NULL);
INSERT INTO `qc_iqc` VALUES (2108734172883279872, '000000', 'IQC-20261010-2108734172883279872', 2108734130407563265, 2106760679291572226, 'IF20261004004', '六角螺母 M12 8级 镀锌', 2, '江苏精密紧固件制造厂', 22.0000, NULL, 'QUALIFIED', NULL, 1, 'admin', '2026-10-10 09:39:46', 'COMPLETED', '按本批资料核对规格、数量与外观', NULL, NULL, '2026-10-10 09:39:39', NULL, NULL, '0', NULL);

-- ----------------------------
-- Table structure for qc_oqc
-- ----------------------------
DROP TABLE IF EXISTS `qc_oqc`;
CREATE TABLE `qc_oqc`  (
  `oqc_id` bigint(20) NOT NULL COMMENT 'OQC ID(主键)',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '000000',
  `oqc_no` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'OQC编号',
  `so_id` bigint(20) NULL DEFAULT NULL COMMENT 'ERP销售订单ID',
  `material_id` bigint(20) NOT NULL COMMENT '物料ID',
  `material_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '物料编码(冗余)',
  `material_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '物料名称(冗余)',
  `quantity` decimal(14, 4) NOT NULL COMMENT '检验数量',
  `sample_qty` decimal(14, 4) NULL DEFAULT NULL COMMENT '抽样数量',
  `inspect_result` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT 'PENDING' COMMENT '检验结果: QUALIFIED/UNQUALIFIED/PENDING',
  `defect_info` json NULL COMMENT '不良品信息(类型/数量/描述)',
  `inspector_id` bigint(20) NULL DEFAULT NULL COMMENT '检验员ID',
  `inspector_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '检验员姓名',
  `inspect_time` datetime(0) NULL DEFAULT NULL COMMENT '检验时间',
  `status` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT 'PENDING' COMMENT '状态: PENDING/INSPECTING/COMPLETED',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '备注',
  `create_dept` bigint(20) NULL DEFAULT NULL COMMENT '创建部门',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT '0' COMMENT '删除标志',
  `photo_oss_ids` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '检验照片附件ossId串(逗号分隔)',
  PRIMARY KEY (`oqc_id`) USING BTREE,
  UNIQUE INDEX `uk_oqc_no`(`tenant_id`, `oqc_no`) USING BTREE,
  UNIQUE INDEX `uk_oqc_so_material`(`tenant_id`, `so_id`, `material_id`) USING BTREE,
  INDEX `idx_status`(`status`) USING BTREE,
  INDEX `idx_so_id`(`so_id`) USING BTREE,
  INDEX `idx_material_id`(`material_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = 'MES出货检验' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of qc_oqc
-- ----------------------------
INSERT INTO `qc_oqc` VALUES (2107125050639298561, '000000', 'OQC-20261005-2107125050635104256', 2107110740248670209, 2106761349704929281, 'IF20261004006', 'M12高强度镀锌螺栓连接组件', 10.0000, 10.0000, 'QUALIFIED', NULL, 1, 'admin', '2026-10-05 23:05:35', 'COMPLETED', '按已启用出货标准完成十套软件输入自动判定，未发货，不作为现场测量凭证。', 103, 1, '2026-10-05 23:05:35', 1, '2026-10-05 23:05:35', '0', NULL);
INSERT INTO `qc_oqc` VALUES (2107337265527074817, '000000', 'OQC-20261006-2107337265522880512', 2107334400150548481, 2106761349704929281, 'IF20261004006', 'M12高强度镀锌螺栓连接组件', 6.0000, 6.0000, 'QUALIFIED', NULL, 1, 'admin', '2026-10-06 13:08:51', 'COMPLETED', '完整三项六件软件样本输入，判定由检验引擎生成；不冒充实物验收。', 103, 1, '2026-10-06 13:08:51', 1, '2026-10-06 13:08:51', '0', NULL);
INSERT INTO `qc_oqc` VALUES (2107530536031322113, '000000', 'OQC-20261007-2107530536031322112', 2107530359421763585, 2106761349704929281, 'IF20261004006', 'M12高强度镀锌螺栓连接组件', 6.0000, 6.0000, 'QUALIFIED', NULL, 1, 'admin', '2026-10-07 01:56:51', 'COMPLETED', '完整三项六件软件样本输入，判定由检验引擎生成；不冒充实物验收。', 103, 1, '2026-10-07 01:56:50', 1, '2026-10-07 01:56:50', '0', NULL);
INSERT INTO `qc_oqc` VALUES (2108683311272361986, '000000', 'OQC-20261010-2108683311268167680', 2108082641196507137, 2106761349704929281, 'IF20261004006', NULL, 22.0000, 3.0000, 'QUALIFIED', NULL, 1, 'admin', '2026-10-10 06:19:08', 'COMPLETED', NULL, 103, 1, '2026-10-10 06:17:34', 1, '2026-10-10 06:17:34', '0', NULL);
INSERT INTO `qc_oqc` VALUES (2108684286364155906, '000000', 'OQC-20261010-2108684286364155904', 2108082651871010817, 2106761349704929281, 'IF20261004006', NULL, 22.0000, 3.0000, 'QUALIFIED', NULL, 1, 'admin', '2026-10-10 06:21:47', 'COMPLETED', NULL, 103, 1, '2026-10-10 06:21:26', 1, '2026-10-10 06:21:26', '0', NULL);
INSERT INTO `qc_oqc` VALUES (2108747451672260609, '000000', 'OQC-20261010-2108747451659677696', 2108082631507664898, 2106761349704929281, 'IF20261004006', NULL, 22.0000, 3.0000, 'QUALIFIED', NULL, 1, 'admin', '2026-10-10 10:32:52', 'COMPLETED', NULL, 103, 1, '2026-10-10 10:32:26', 1, '2026-10-10 10:32:26', '0', NULL);

-- ----------------------------
-- Table structure for qc_receipt_iqc_birth
-- ----------------------------
DROP TABLE IF EXISTS `qc_receipt_iqc_birth`;
CREATE TABLE `qc_receipt_iqc_birth`  (
  `iqc_id` bigint(20) NOT NULL COMMENT '同事务新建的IQC身份',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '实际租户',
  `birth_id` bigint(20) NOT NULL COMMENT 'ERP永久出生登记身份',
  `receive_id` bigint(20) NOT NULL COMMENT '原始收货身份',
  `material_id` bigint(20) NOT NULL COMMENT '原始物料身份',
  `base_uom_id` bigint(20) NOT NULL COMMENT '出生原单位，不从未来当前单位反推',
  `quantity_scale` int(11) NOT NULL COMMENT '出生时原单位小数精度，取值0至4',
  `quantity` decimal(14, 4) NOT NULL COMMENT 'ERP冻结的原单位检验数量',
  `receipt_scope_sha256` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '冻结收货完整范围摘要',
  `birth_sha256` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'ERP出生事实完整性摘要，不独立授权',
  `captured_at` bigint(20) NOT NULL COMMENT 'ERP实际冻结毫秒时间戳',
  `receive_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '出生收货编码',
  `material_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '出生物料编码',
  `material_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '出生物料名称',
  `vendor_id` bigint(20) NOT NULL COMMENT '出生供应商身份',
  `vendor_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '出生供应商名称',
  `bound_at` datetime(3) NOT NULL COMMENT '同连接采样的全新INSERT出生绑定时间，保留毫秒',
  `binding_sha256` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'IQC与出生事实不可变绑定摘要',
  PRIMARY KEY (`iqc_id`) USING BTREE,
  UNIQUE INDEX `uk_native_iqc`(`tenant_id`, `iqc_id`) USING BTREE,
  UNIQUE INDEX `uk_native_birth`(`tenant_id`, `birth_id`) USING BTREE,
  UNIQUE INDEX `uk_native_scope`(`tenant_id`, `receive_id`, `material_id`) USING BTREE,
  CONSTRAINT `fk_native_iqc_birth` FOREIGN KEY (`iqc_id`) REFERENCES `qc_iqc` (`iqc_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '永久原生出生绑定，旧检验无绑定仍不具单位来源证明' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of qc_receipt_iqc_birth
-- ----------------------------
INSERT INTO `qc_receipt_iqc_birth` VALUES (2106959154797019136, '000000', 2106959148505563138, 2106767580603568130, 2106760678595317762, 26, 0, 10.0000, '2b6fd81d8ac1a7cb75cc615561cfffee0c1597b03ac35ce6c639b0f700fc7f40', '552a0b5fd3a60fc688403a2e9e211d0a23a9cf274f357b8e6c183299c381499c', 1791173181068, 'CGRK20261004001', 'IF20261004003', '六角头螺栓 M12×50 8.8级 镀锌', 2, '江苏精密紧固件制造厂', '2026-10-05 12:06:22.567', '5c0188359d3f0e88989c8e31f1c52fb22749892837202e8c18a7b77f519aeb54');
INSERT INTO `qc_receipt_iqc_birth` VALUES (2106959517738532864, '000000', 2106959508360069122, 2106767585661898753, 2106760679291572226, 26, 0, 10.0000, 'aa405069faff7456b3ef2cf73ba23f0b32bb3ed91310f04e1be26ffb64315b90', '0585c021de1d2481da69c1e2aa15deebb6f6360802f15b32d15ef45b6d51e99b', 1791173266864, 'CGRK20261004002', 'IF20261004004', '六角螺母 M12 8级 镀锌', 2, '江苏精密紧固件制造厂', '2026-10-05 12:07:49.100', 'e158f272d807de8bc2a1d053cf7a22b3c1dc09edbfd9a44ead2a35b380bdbd9c');
INSERT INTO `qc_receipt_iqc_birth` VALUES (2106959556082860032, '000000', 2106959550089199618, 2106767590309187585, 2106760679643893762, 26, 0, 20.0000, '26a774dfc3e95141f618853de85a46332d8ec78f0f30ae676e57a573626a8113', '21837801e1b8e5c10f30edb988aa215e19b023c0ab69fae58e0f420833d2edeb', 1791173276813, 'CGRK20261004003', 'IF20261004005', '平垫圈 12 A级 镀锌', 2, '江苏精密紧固件制造厂', '2026-10-05 12:07:58.241', 'a535bf4374f5d48cb16a6cadb4b844f71ada4c75f9efbd5a444e60d3a87655ba');
INSERT INTO `qc_receipt_iqc_birth` VALUES (2107310554534064128, '000000', 2107310548695592961, 2107310517406085121, 2106760678595317762, 26, 0, 2.0000, '0f62b3d48bcacc1a4306155923641105c79edbc56b398783f9a2c65f67e1ff02', '10811853bcd95cd6f66bfbbaa6e925470347cbe2ce334061106229cecab8bc61', 1791256961402, 'CGRK20261006001', 'IF20261004003', '六角头螺栓 M12×50 8.8级 镀锌', 2, '江苏精密紧固件制造厂', '2026-10-06 11:22:42.794', '35c91358494bb517104eff2d2f8fb3620d2c2d138bae21ba38e86644122f0b83');
INSERT INTO `qc_receipt_iqc_birth` VALUES (2107310616316162048, '000000', 2107310610830012417, 2107310521491337217, 2106760679291572226, 26, 0, 2.0000, 'b8856c77f83287265753794174dad119580943a08524d6099aab98061001bbc8', '663cd63b53937ae4c7840eb33989b468a5178616429355e00ab0916305d2b2a5', 1791256976217, 'CGRK20261006002', 'IF20261004004', '六角螺母 M12 8级 镀锌', 2, '江苏精密紧固件制造厂', '2026-10-06 11:22:57.524', '4fcb3298f402a6e9580943343fde863f974b98ce1dd13092aa188b9b1fb6b0fa');
INSERT INTO `qc_receipt_iqc_birth` VALUES (2107310677737549824, '000000', 2107310672268177410, 2107310525022941186, 2106760679643893762, 26, 0, 4.0000, '35bf214d3c9d34f10ced52f7f252e7917d0d1f82d3ecc2b193b9fc8aac9bd6df', '74a3f31c57fe3028101205695fbad16d1272ba98157b895d01a0ba2ba96ea587', 1791256990864, 'CGRK20261006003', 'IF20261004005', '平垫圈 12 A级 镀锌', 2, '江苏精密紧固件制造厂', '2026-10-06 11:23:12.168', '5d733069239b7bbf2321f39eab3411b9d6bf4a81c2fbbff8165b9c82192b85b2');
INSERT INTO `qc_receipt_iqc_birth` VALUES (2107312390305427456, '000000', 2107312384475344897, 2107312358814593026, 2106760678595317762, 26, 0, 4.0000, '9f6351b074a44a79e96097e4572502319f9d730218ade8f51723a3d75287be0f', '7bc2788e3ed8d5cd5886593ee166acd510e99b4c4df206a79ff9727b01e4ec07', 1791257399087, 'CGRK20261006004', 'IF20261004003', '六角头螺栓 M12×50 8.8级 镀锌', 2, '江苏精密紧固件制造厂', '2026-10-06 11:30:00.475', '0b19e4c2ed784a371a4ab3d6fef75cee2d836caad287d9b996ef5515f2f9e361');
INSERT INTO `qc_receipt_iqc_birth` VALUES (2107312454167900160, '000000', 2107312448371372034, 2107312362652381186, 2106760679291572226, 26, 0, 4.0000, '147d81a6af4408979432039042fde8226ba3b4ffb284e5bf65dc688852c6f2c2', '197d42a25fcfb7140c515e191822ea998bc409da39e7e241212c05ad4b915376', 1791257414321, 'CGRK20261006005', 'IF20261004004', '六角螺母 M12 8级 镀锌', 2, '江苏精密紧固件制造厂', '2026-10-06 11:30:15.702', '6c8862f757a97d47c2d0af88886962b3291cf2201c0f48e74e9128b0b813f47a');
INSERT INTO `qc_receipt_iqc_birth` VALUES (2107312531259207680, '000000', 2107312526007939074, 2107312366179790849, 2106760679643893762, 26, 0, 8.0000, '99a174466ef318ec13d201019c2b2de961e0425d050f44714baffc3613d6e8e9', '5ec98edf5a03570a5b4b90a594dfaf6375aa17214a117aaac18a5d7dedd9aa08', 1791257432830, 'CGRK20261006006', 'IF20261004005', '平垫圈 12 A级 镀锌', 2, '江苏精密紧固件制造厂', '2026-10-06 11:30:34.081', '15019bf82815646f7411087906e54063274bcfdfd0007fbcb265333311abfd4c');
INSERT INTO `qc_receipt_iqc_birth` VALUES (2107516476623650816, '000000', 2107516470864871425, 2107516436131840002, 2106760678595317762, 26, 0, 2.0000, 'bf89af6fa644bccf75627cd022679458845177fbdbad5ff21cf82e7d2f05cbc7', 'e33b47a3c995d1fa02bb25ef926acdcdf063abb6a2728ad3c98c68797d957359', 1791306057073, 'CGRK20261007001', 'IF20261004003', '六角头螺栓 M12×50 8.8级 镀锌', 2, '江苏精密紧固件制造厂', '2026-10-07 01:00:58.446', 'efe7ecaac25c383a4375a0cce73551d3a5707cf0239b62a81f4a4f01c812191f');
INSERT INTO `qc_receipt_iqc_birth` VALUES (2107516539609513984, '000000', 2107516533909454850, 2107516441114673153, 2106760679291572226, 26, 0, 2.0000, 'c91264a1835541b5cc5c450e28720f6be1580d29bb1e584f9d07809b186677fd', 'b05d8ce62e7c844ba688cd7ad7019216cba037909730af4e480a6e91768fb07b', 1791306072104, 'CGRK20261007002', 'IF20261004004', '六角螺母 M12 8级 镀锌', 2, '江苏精密紧固件制造厂', '2026-10-07 01:01:13.463', '0460062dcfc697fd8d14b2113f4ec79464a6108ae0944b9a9aa3fdfdee386fca');
INSERT INTO `qc_receipt_iqc_birth` VALUES (2107516605988569088, '000000', 2107516599680335873, 2107516444507865090, 2106760679643893762, 26, 0, 4.0000, '77320a14addd313334c334bf5ee97dd20073b2f9c9213dd153a0a80b0642b9d1', '132e2ca51b5435b74252adbb942a5a3eb3800f3b11b6b6c150f9801ff5a3107b', 1791306087785, 'CGRK20261007003', 'IF20261004005', '平垫圈 12 A级 镀锌', 2, '江苏精密紧固件制造厂', '2026-10-07 01:01:29.289', 'df3507a784d3872cd2c592f8257d7db43e5b9ddb7317b04f7f5426c7179741a7');
INSERT INTO `qc_receipt_iqc_birth` VALUES (2107518637990445056, '000000', 2107518632193916930, 2107518606575108098, 2106760678595317762, 26, 0, 4.0000, '8a1741ce30fedfedb85d71652a91775b3ea7abb199ed6d8fae4dd4b36c1e89c8', '432272285e22a5d1b37451e9a77ac955a555008e2255f2c5b68c83eae3dc802e', 1791306572374, 'CGRK20261007004', 'IF20261004003', '六角头螺栓 M12×50 8.8级 镀锌', 2, '江苏精密紧固件制造厂', '2026-10-07 01:09:33.756', '407246f4fdb55342e6b590554ac78ffcb66c03d9b15705d263ff27d777f3580b');
INSERT INTO `qc_receipt_iqc_birth` VALUES (2107518702058438656, '000000', 2107518696370962434, 2107518610215763969, 2106760679291572226, 26, 0, 4.0000, '710bb958ecb928ffb52dfb60c5ff9c677f0dcba5869bacd281778c31f2969fd8', 'e3bdf130758f3f501924c4bc43cb4bd18d204d40d34bac86cf64700b526f57bd', 1791306587675, 'CGRK20261007005', 'IF20261004004', '六角螺母 M12 8级 镀锌', 2, '江苏精密紧固件制造厂', '2026-10-07 01:09:49.031', '2fd0f701a8b3c31aef0eb830d8c688f246bab2185c364039bd5f5b0db0147f7e');
INSERT INTO `qc_receipt_iqc_birth` VALUES (2107518778629652480, '000000', 2107518773554544642, 2107518613600567298, 2106760679643893762, 26, 0, 8.0000, '74b3a4f0f07d368b8ef148e48fab393b125689f8e386754f57ebc2343290ad1b', '6f29d115122c08e2c207522521bdff508eefad8cc15ec4122fd95592abedcfd6', 1791306606078, 'CGRK20261007006', 'IF20261004005', '平垫圈 12 A级 镀锌', 2, '江苏精密紧固件制造厂', '2026-10-07 01:10:07.287', '18f0ddbda6c9cd2df6df8444ded47fb01a918d85ee222fb76c20a68452ab88f2');
INSERT INTO `qc_receipt_iqc_birth` VALUES (2108007599179763712, '000000', 2108007591479021570, 2108007550425174018, 2106760679643893762, 26, 0, 8.0000, '5cf4a8ed7748d61d2cffb99a45fab3a5e54d7648e3e86c8f84865252bf9ee4a9', 'caa057a0f21ba45609837a1dee4b99a1ccf603e142b1fd568ac87bd9891b0405', 1791423149353, 'CGRK20261008001', 'IF20261004005', '平垫圈 12 A级 镀锌', 2, '江苏精密紧固件制造厂', '2026-10-08 09:32:31.188', 'aedd3d63b90d99be7616004baa857b2c70d54de3f25a5e95bf773ca060c7aab0');
INSERT INTO `qc_receipt_iqc_birth` VALUES (2108593288606900224, '000000', 2108593283368214529, 2108590538598899714, 2106760679291572226, 26, 0, 22.0000, '7d788c501614f8f76e8d96b43fdf1276214e0be5421b8a2b957530931a264882', 'd08a9dcafe9dfff4312b6194817cef7271eb8057072ff919cba9e08ceff78b07', 1791562789180, 'CGRK20261010001', 'IF20261004004', '六角螺母 M12 8级 镀锌', 2, '江苏精密紧固件制造厂', '2026-10-10 00:19:50.429', '18af9902e0d937d80207b53666da44d74bb59c4ddf70754d9ccd6599d3840d2c');
INSERT INTO `qc_receipt_iqc_birth` VALUES (2108593346253414400, '000000', 2108593341031505922, 2108592104873648129, 2106760679643893762, 26, 0, 44.0000, 'd671e1e676fe8ed9862e68b4c825c01354cdd2dafc003a9b6fe0c75b074df462', 'd276e0c52a2bc2553b502154fecc8d5af18b4f78f7da6bf68a3c33dfd06e8c48', 1791562802928, 'CGRK20261010002', 'IF20261004005', '平垫圈 12 A级 镀锌', 2, '江苏精密紧固件制造厂', '2026-10-10 00:20:04.173', '17da3f0f213b3c81e154ba2f21a96323a012025f60d1990886d08d437ede7e43');
INSERT INTO `qc_receipt_iqc_birth` VALUES (2108654961719967744, '000000', 2108654956393201666, 2108654928614326274, 2106760678595317762, 26, 0, 22.0000, '4c27d43a11df39e64317572c628dbe55d9da2ebcb91d2f6c71e4943559bdfbf1', '5ea0d3e39259b2fa5ce6c4d79f5b308142e0b3f36e03850f199d1c7172ccd386', 1791577493175, 'CGRK20261010003', 'IF20261004003', '六角头螺栓 M12×50 8.8级 镀锌', 2, '江苏精密紧固件制造厂', '2026-10-10 04:24:54.445', '1d5f1fea04e40411d4f9433e28333f25f551f9a28b41ea449dbb564bef146742');
INSERT INTO `qc_receipt_iqc_birth` VALUES (2108659592160280576, '000000', 2108659586590244865, 2108659559100776450, 2106760679643893762, 26, 0, 44.0000, '756061d38a354bf35b6d455a883de0f9dd5286fbf8a6383c8cfd95c215018a8a', '636a1fea4f3aab31000b56b1814faa07afaa5eee770abe23ae3d7980fe10ec01', 1791578597101, 'CGRK20261010004', 'IF20261004005', '平垫圈 12 A级 镀锌', 2, '江苏精密紧固件制造厂', '2026-10-10 04:43:18.428', '69f445db532a332c90d1949c12e8b4e32913028bc744d25495dc93fe198e7af7');
INSERT INTO `qc_receipt_iqc_birth` VALUES (2108660683627233280, '000000', 2108660677801345025, 2108660649007448066, 2106760679291572226, 26, 0, 22.0000, '11931eec83f4a54c9d322b3a21751812543c20bceb5e255e80b05dae207dad95', '20c68daf635922e9d5b6f5f33191e99148b01f7ad2209a7f392180833800e207', 1791578857265, 'CGRK20261010005', 'IF20261004004', '六角螺母 M12 8级 镀锌', 2, '江苏精密紧固件制造厂', '2026-10-10 04:47:38.653', '0ca7660870b61755b6ad6f027f2a649a6fb5e4bef16e0644a232d46c12b2ee86');
INSERT INTO `qc_receipt_iqc_birth` VALUES (2108666698074619904, '000000', 2108666692517167106, 2108666664755068930, 2106760678595317762, 26, 0, 22.0000, 'feebac4d23aca5cb30cecc84a98ffee1aa70170975a4ba9ce1d7f3e46e36fb8a', 'a2aba02d6b238fd84ce30502ed7d2a2bc972147ca44b2e0d0b0f3a0a8216181f', 1791580291285, 'CGRK20261010006', 'IF20261004003', '六角头螺栓 M12×50 8.8级 镀锌', 2, '江苏精密紧固件制造厂', '2026-10-10 05:11:32.610', 'b89c15abd35cba2b3466ce99ceccf479d51b7fafc1234784609c457ec63ca723');
INSERT INTO `qc_receipt_iqc_birth` VALUES (2108667412372979712, '000000', 2108667406786166786, 2108667379128926209, 2106760679643893762, 26, 0, 44.0000, '5a679214b4fc1321e74e4ff5a7e83ee1c593684de9525c6c3f03a2cd125d6617', 'e67f9d119a49be8211822ac64d5e30497b24460ccf90de0a11f96627eabbc948', 1791580461581, 'CGRK20261010007', 'IF20261004005', '平垫圈 12 A级 镀锌', 2, '江苏精密紧固件制造厂', '2026-10-10 05:14:22.912', '8db0d4ac84ef19b69d96979f92874c8fc38affa8d7af6f15d6ffe9752c031576');
INSERT INTO `qc_receipt_iqc_birth` VALUES (2108668074506780672, '000000', 2108668068907384833, 2108668040813936641, 2106760678595317762, 26, 0, 22.0000, '474c982841c973f9f3e89d1165f09939c269d231dd12358549c1678887d6c66d', 'da8ab130ce775482f191a0262356f18ac8ef26049849aa01f3f430aea9200bff', 1791580619443, 'CGRK20261010008', 'IF20261004003', '六角头螺栓 M12×50 8.8级 镀锌', 2, '江苏精密紧固件制造厂', '2026-10-10 05:17:00.777', '4b0c03e14a92fe514e55eed75644a17459ea3078a529a8af73e2e5ab36bfdbcc');
INSERT INTO `qc_receipt_iqc_birth` VALUES (2108734172883279872, '000000', 2108734166289833985, 2108734130407563265, 2106760679291572226, 26, 0, 22.0000, '990e9b1b1e7e87c2e4c527da743e83211e78e3f55e8cdf1584d89bd6ace5957a', '302d5e3ad64586ce7f810471900b5600d4ade149bab66f0d6bbf4662e86d5345', 1791596378286, 'CGRK20261010009', 'IF20261004004', '六角螺母 M12 8级 镀锌', 2, '江苏精密紧固件制造厂', '2026-10-10 09:39:39.857', 'ef33af59f42983a58ccc701389d994d26b391a87e8eeb36686a94dfa5f736aee');

-- ----------------------------
-- Table structure for sop_document
-- ----------------------------
DROP TABLE IF EXISTS `sop_document`;
CREATE TABLE `sop_document`  (
  `sop_id` bigint(20) NOT NULL COMMENT 'SOP ID(主键)',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '000000',
  `sop_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT 'SOP编码',
  `sop_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT 'SOP名称',
  `sop_type` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '类型: PRODUCTION/INSPECTION/SAFETY/SETUP/CLEAN',
  `current_version` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '当前发布版本号',
  `status` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT 'DRAFT' COMMENT '状态: DRAFT/IN_REVIEW/PUBLISHED/ARCHIVED',
  `file_oss_id` bigint(20) NULL DEFAULT NULL COMMENT '当前发布文件OSS ID(私有桶存ID)',
  `file_type` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '文件类型: PDF/IMAGE/VIDEO/WORD',
  `description` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '说明',
  `approval_by` bigint(20) NULL DEFAULT NULL COMMENT '审批人ID',
  `approval_time` datetime(0) NULL DEFAULT NULL COMMENT '审批时间',
  `approval_remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '审批意见',
  `archive_reason` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '归档原因',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '备注',
  `create_dept` bigint(20) NULL DEFAULT NULL COMMENT '创建部门',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '删除标志',
  PRIMARY KEY (`sop_id`) USING BTREE,
  UNIQUE INDEX `uk_sop_code`(`tenant_id`, `sop_code`) USING BTREE,
  INDEX `idx_status`(`status`) USING BTREE,
  INDEX `idx_type`(`sop_type`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = 'MES SOP文档主档' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sop_document
-- ----------------------------
INSERT INTO `sop_document` VALUES (1, '000000', 'SOP20260914001', '激光切割作业指导书', 'PROCESS', 'V1.1', 'PUBLISHED', 2108122792569335808, 'PDF', '激光切割标准作业流程与关键控制点', 1, '2026-10-08 19:50:42', '初始发布', NULL, NULL, 103, 1, '2026-09-14 15:07:27', NULL, '2026-10-08 19:15:17', '0');
INSERT INTO `sop_document` VALUES (2, '000000', 'SOP20260914002', '等离子切割作业指导书', 'PRODUCTION', 'V1.0', 'DRAFT', 0, 'PDF', '等离子切割标准作业流程与关键控制点', 1, '2026-09-14 15:07:27', '初始发布', NULL, NULL, 103, 1, '2026-09-14 15:07:27', NULL, '2026-10-08 19:15:17', '0');
INSERT INTO `sop_document` VALUES (3, '000000', 'SOP20260914003', '剪板作业指导书', 'PRODUCTION', 'V1.0', 'DRAFT', 0, 'PDF', '剪板标准作业流程与关键控制点', 1, '2026-09-14 15:07:27', '初始发布', NULL, NULL, 103, 1, '2026-09-14 15:07:27', NULL, '2026-10-08 19:15:17', '0');
INSERT INTO `sop_document` VALUES (4, '000000', 'SOP20260914004', '锯切作业指导书', 'PRODUCTION', 'V1.0', 'DRAFT', 0, 'PDF', '锯切标准作业流程与关键控制点', 1, '2026-09-14 15:07:27', '初始发布', NULL, NULL, 103, 1, '2026-09-14 15:07:27', NULL, '2026-10-08 19:15:17', '0');
INSERT INTO `sop_document` VALUES (5, '000000', 'SOP20260914005', '冲压作业指导书', 'PRODUCTION', 'V1.0', 'DRAFT', 0, 'PDF', '冲压标准作业流程与关键控制点', 1, '2026-09-14 15:07:27', '初始发布', NULL, NULL, 103, 1, '2026-09-14 15:07:27', NULL, '2026-10-08 19:15:17', '0');
INSERT INTO `sop_document` VALUES (6, '000000', 'SOP20260914006', '折弯作业指导书', 'PRODUCTION', 'V1.0', 'DRAFT', 0, 'PDF', '折弯标准作业流程与关键控制点', 1, '2026-09-14 15:07:27', '初始发布', NULL, NULL, 103, 1, '2026-09-14 15:07:27', NULL, '2026-10-08 19:15:17', '0');
INSERT INTO `sop_document` VALUES (7, '000000', 'SOP20260914007', '卷圆作业指导书', 'PRODUCTION', 'V1.0', 'DRAFT', 0, 'PDF', '卷圆标准作业流程与关键控制点', 1, '2026-09-14 15:07:27', '初始发布', NULL, NULL, 103, 1, '2026-09-14 15:07:27', NULL, '2026-10-08 19:15:17', '0');
INSERT INTO `sop_document` VALUES (8, '000000', 'SOP20260914008', '拉深作业指导书', 'PRODUCTION', 'V1.0', 'DRAFT', 0, 'PDF', '拉深标准作业流程与关键控制点', 1, '2026-09-14 15:07:27', '初始发布', NULL, NULL, 103, 1, '2026-09-14 15:07:27', NULL, '2026-10-08 19:15:17', '0');
INSERT INTO `sop_document` VALUES (9, '000000', 'SOP20260914009', '锻造作业指导书', 'PRODUCTION', 'V1.0', 'DRAFT', 0, 'PDF', '锻造标准作业流程与关键控制点', 1, '2026-09-14 15:07:27', '初始发布', NULL, NULL, 103, 1, '2026-09-14 15:07:27', NULL, '2026-10-08 19:15:17', '0');
INSERT INTO `sop_document` VALUES (10, '000000', 'SOP20260914010', '车削作业指导书', 'PRODUCTION', 'V1.0', 'DRAFT', 0, 'PDF', '车削标准作业流程与关键控制点', 1, '2026-09-14 15:07:27', '初始发布', NULL, NULL, 103, 1, '2026-09-14 15:07:27', NULL, '2026-10-08 19:15:17', '0');
INSERT INTO `sop_document` VALUES (11, '000000', 'SOP20260914011', '铣削作业指导书', 'PRODUCTION', 'V1.0', 'DRAFT', 0, 'PDF', '铣削标准作业流程与关键控制点', 1, '2026-09-14 15:07:27', '初始发布', NULL, NULL, 103, 1, '2026-09-14 15:07:27', NULL, '2026-10-08 19:15:17', '0');
INSERT INTO `sop_document` VALUES (12, '000000', 'SOP20260914012', '钻孔作业指导书', 'PRODUCTION', 'V1.0', 'DRAFT', 0, 'PDF', '钻孔标准作业流程与关键控制点', 1, '2026-09-14 15:07:27', '初始发布', NULL, NULL, 103, 1, '2026-09-14 15:07:27', NULL, '2026-10-08 19:15:17', '0');
INSERT INTO `sop_document` VALUES (13, '000000', 'SOP20260914013', '磨削作业指导书', 'PRODUCTION', 'V1.0', 'DRAFT', 0, 'PDF', '磨削标准作业流程与关键控制点', 1, '2026-09-14 15:07:27', '初始发布', NULL, NULL, 103, 1, '2026-09-14 15:07:27', NULL, '2026-10-08 19:15:17', '0');
INSERT INTO `sop_document` VALUES (14, '000000', 'SOP20260914014', '镗孔作业指导书', 'PRODUCTION', 'V1.0', 'DRAFT', 0, 'PDF', '镗孔标准作业流程与关键控制点', 1, '2026-09-14 15:07:27', '初始发布', NULL, NULL, 103, 1, '2026-09-14 15:07:27', NULL, '2026-10-08 19:15:17', '0');
INSERT INTO `sop_document` VALUES (15, '000000', 'SOP20260914015', '滚齿作业指导书', 'PRODUCTION', 'V1.0', 'DRAFT', 0, 'PDF', '滚齿标准作业流程与关键控制点', 1, '2026-09-14 15:07:27', '初始发布', NULL, NULL, 103, 1, '2026-09-14 15:07:27', NULL, '2026-10-08 19:15:17', '0');
INSERT INTO `sop_document` VALUES (16, '000000', 'SOP20260914016', '插齿作业指导书', 'PRODUCTION', 'V1.0', 'DRAFT', 0, 'PDF', '插齿标准作业流程与关键控制点', 1, '2026-09-14 15:07:27', '初始发布', NULL, NULL, 103, 1, '2026-09-14 15:07:27', NULL, '2026-10-08 19:15:17', '0');
INSERT INTO `sop_document` VALUES (17, '000000', 'SOP20260914017', '线切割作业指导书', 'PRODUCTION', 'V1.0', 'DRAFT', 0, 'PDF', '线切割标准作业流程与关键控制点', 1, '2026-09-14 15:07:27', '初始发布', NULL, NULL, 103, 1, '2026-09-14 15:07:27', NULL, '2026-10-08 19:15:17', '0');
INSERT INTO `sop_document` VALUES (18, '000000', 'SOP20260914018', '电火花作业指导书', 'PRODUCTION', 'V1.0', 'DRAFT', 0, 'PDF', '电火花标准作业流程与关键控制点', 1, '2026-09-14 15:07:27', '初始发布', NULL, NULL, 103, 1, '2026-09-14 15:07:27', NULL, '2026-10-08 19:15:17', '0');
INSERT INTO `sop_document` VALUES (19, '000000', 'SOP20260914019', '铸造作业指导书', 'PRODUCTION', 'V1.0', 'DRAFT', 0, 'PDF', '铸造标准作业流程与关键控制点', 1, '2026-09-14 15:07:27', '初始发布', NULL, NULL, 103, 1, '2026-09-14 15:07:27', NULL, '2026-10-08 19:15:17', '0');
INSERT INTO `sop_document` VALUES (20, '000000', 'SOP20260914020', '压铸作业指导书', 'PRODUCTION', 'V1.0', 'DRAFT', 0, 'PDF', '压铸标准作业流程与关键控制点', 1, '2026-09-14 15:07:27', '初始发布', NULL, NULL, 103, 1, '2026-09-14 15:07:27', NULL, '2026-10-08 19:15:17', '0');
INSERT INTO `sop_document` VALUES (21, '000000', 'SOP20260914021', '注塑作业指导书', 'PRODUCTION', 'V1.0', 'DRAFT', 0, 'PDF', '注塑标准作业流程与关键控制点', 1, '2026-09-14 15:07:27', '初始发布', NULL, NULL, 103, 1, '2026-09-14 15:07:27', NULL, '2026-10-08 19:15:17', '0');
INSERT INTO `sop_document` VALUES (22, '000000', 'SOP20260914022', '吹塑作业指导书', 'PRODUCTION', 'V1.0', 'DRAFT', 0, 'PDF', '吹塑标准作业流程与关键控制点', 1, '2026-09-14 15:07:27', '初始发布', NULL, NULL, 103, 1, '2026-09-14 15:07:27', NULL, '2026-10-08 19:15:17', '0');
INSERT INTO `sop_document` VALUES (23, '000000', 'SOP20260914023', '氩弧焊作业指导书', 'PRODUCTION', 'V1.0', 'DRAFT', 0, 'PDF', '氩弧焊标准作业流程与关键控制点', 1, '2026-09-14 15:07:27', '初始发布', NULL, NULL, 103, 1, '2026-09-14 15:07:27', NULL, '2026-10-08 19:15:17', '0');
INSERT INTO `sop_document` VALUES (24, '000000', 'SOP20260914024', '二保焊作业指导书', 'PRODUCTION', 'V1.0', 'DRAFT', 0, 'PDF', '二保焊标准作业流程与关键控制点', 1, '2026-09-14 15:07:27', '初始发布', NULL, NULL, 103, 1, '2026-09-14 15:07:27', NULL, '2026-10-08 19:15:17', '0');
INSERT INTO `sop_document` VALUES (25, '000000', 'SOP20260914025', '点焊作业指导书', 'PRODUCTION', 'V1.0', 'DRAFT', 0, 'PDF', '点焊标准作业流程与关键控制点', 1, '2026-09-14 15:07:27', '初始发布', NULL, NULL, 103, 1, '2026-09-14 15:07:27', NULL, '2026-10-08 19:15:17', '0');
INSERT INTO `sop_document` VALUES (26, '000000', 'SOP20260914026', '激光焊作业指导书', 'PRODUCTION', 'V1.0', 'DRAFT', 0, 'PDF', '激光焊标准作业流程与关键控制点', 1, '2026-09-14 15:07:27', '初始发布', NULL, NULL, 103, 1, '2026-09-14 15:07:27', NULL, '2026-10-08 19:15:17', '0');
INSERT INTO `sop_document` VALUES (27, '000000', 'SOP20260914027', '淬火作业指导书', 'PRODUCTION', 'V1.0', 'DRAFT', 0, 'PDF', '淬火标准作业流程与关键控制点', 1, '2026-09-14 15:07:27', '初始发布', NULL, NULL, 103, 1, '2026-09-14 15:07:27', NULL, '2026-10-08 19:15:17', '0');
INSERT INTO `sop_document` VALUES (28, '000000', 'SOP20260914028', '回火作业指导书', 'PRODUCTION', 'V1.0', 'DRAFT', 0, 'PDF', '回火标准作业流程与关键控制点', 1, '2026-09-14 15:07:27', '初始发布', NULL, NULL, 103, 1, '2026-09-14 15:07:27', NULL, '2026-10-08 19:15:17', '0');
INSERT INTO `sop_document` VALUES (29, '000000', 'SOP20260914029', '渗碳作业指导书', 'PRODUCTION', 'V1.0', 'DRAFT', 0, 'PDF', '渗碳标准作业流程与关键控制点', 1, '2026-09-14 15:07:27', '初始发布', NULL, NULL, 103, 1, '2026-09-14 15:07:27', NULL, '2026-10-08 19:15:17', '0');
INSERT INTO `sop_document` VALUES (30, '000000', 'SOP20260914030', '时效作业指导书', 'PRODUCTION', 'V1.0', 'DRAFT', 0, 'PDF', '时效标准作业流程与关键控制点', 1, '2026-09-14 15:07:27', '初始发布', NULL, NULL, 103, 1, '2026-09-14 15:07:27', NULL, '2026-10-08 19:15:17', '0');
INSERT INTO `sop_document` VALUES (31, '000000', 'SOP20260914031', '电镀作业指导书', 'PRODUCTION', 'V1.0', 'DRAFT', 0, 'PDF', '电镀标准作业流程与关键控制点', 1, '2026-09-14 15:07:27', '初始发布', NULL, NULL, 103, 1, '2026-09-14 15:07:27', NULL, '2026-10-08 19:15:17', '0');
INSERT INTO `sop_document` VALUES (32, '000000', 'SOP20260914032', '阳极氧化作业指导书', 'PRODUCTION', 'V1.0', 'DRAFT', 0, 'PDF', '阳极氧化标准作业流程与关键控制点', 1, '2026-09-14 15:07:27', '初始发布', NULL, NULL, 103, 1, '2026-09-14 15:07:27', NULL, '2026-10-08 19:15:17', '0');
INSERT INTO `sop_document` VALUES (33, '000000', 'SOP20260914033', '喷塑作业指导书', 'PRODUCTION', 'V1.0', 'DRAFT', 0, 'PDF', '喷塑标准作业流程与关键控制点', 1, '2026-09-14 15:07:27', '初始发布', NULL, NULL, 103, 1, '2026-09-14 15:07:27', NULL, '2026-10-08 19:15:17', '0');
INSERT INTO `sop_document` VALUES (34, '000000', 'SOP20260914034', '喷漆作业指导书', 'PRODUCTION', 'V1.0', 'DRAFT', 0, 'PDF', '喷漆标准作业流程与关键控制点', 1, '2026-09-14 15:07:27', '初始发布', NULL, NULL, 103, 1, '2026-09-14 15:07:27', NULL, '2026-10-08 19:15:17', '0');
INSERT INTO `sop_document` VALUES (35, '000000', 'SOP20260914035', '丝印作业指导书', 'PRODUCTION', 'V1.0', 'DRAFT', 0, 'PDF', '丝印标准作业流程与关键控制点', 1, '2026-09-14 15:07:27', '初始发布', NULL, NULL, 103, 1, '2026-09-14 15:07:27', NULL, '2026-10-08 19:15:17', '0');
INSERT INTO `sop_document` VALUES (36, '000000', 'SOP20260914036', '抛光作业指导书', 'PRODUCTION', 'V1.0', 'DRAFT', 0, 'PDF', '抛光标准作业流程与关键控制点', 1, '2026-09-14 15:07:27', '初始发布', NULL, NULL, 103, 1, '2026-09-14 15:07:27', NULL, '2026-10-08 19:15:17', '0');
INSERT INTO `sop_document` VALUES (37, '000000', 'SOP20260914037', 'SMT贴片作业指导书', 'PRODUCTION', 'V1.0', 'DRAFT', 0, 'PDF', 'SMT贴片标准作业流程与关键控制点', 1, '2026-09-14 15:07:27', '初始发布', NULL, NULL, 103, 1, '2026-09-14 15:07:27', NULL, '2026-10-08 19:15:17', '0');
INSERT INTO `sop_document` VALUES (38, '000000', 'SOP20260914038', '插件作业指导书', 'PRODUCTION', 'V1.0', 'DRAFT', 0, 'PDF', '插件标准作业流程与关键控制点', 1, '2026-09-14 15:07:27', '初始发布', NULL, NULL, 103, 1, '2026-09-14 15:07:27', NULL, '2026-10-08 19:15:17', '0');
INSERT INTO `sop_document` VALUES (39, '000000', 'SOP20260914039', '波峰焊作业指导书', 'PRODUCTION', 'V1.0', 'DRAFT', 0, 'PDF', '波峰焊标准作业流程与关键控制点', 1, '2026-09-14 15:07:27', '初始发布', NULL, NULL, 103, 1, '2026-09-14 15:07:27', NULL, '2026-10-08 19:15:17', '0');
INSERT INTO `sop_document` VALUES (40, '000000', 'SOP20260914040', '手工焊作业指导书', 'PRODUCTION', 'V1.0', 'DRAFT', 0, 'PDF', '手工焊标准作业流程与关键控制点', 1, '2026-09-14 15:07:27', '初始发布', NULL, NULL, 103, 1, '2026-09-14 15:07:27', NULL, '2026-10-08 19:15:17', '0');
INSERT INTO `sop_document` VALUES (41, '000000', 'SOP20260914041', '绕线作业指导书', 'PRODUCTION', 'V1.0', 'DRAFT', 0, 'PDF', '绕线标准作业流程与关键控制点', 1, '2026-09-14 15:07:27', '初始发布', NULL, NULL, 103, 1, '2026-09-14 15:07:27', NULL, '2026-10-08 19:15:17', '0');
INSERT INTO `sop_document` VALUES (42, '000000', 'SOP20260914042', '浸漆作业指导书', 'PRODUCTION', 'V1.0', 'DRAFT', 0, 'PDF', '浸漆标准作业流程与关键控制点', 1, '2026-09-14 15:07:27', '初始发布', NULL, NULL, 103, 1, '2026-09-14 15:07:27', NULL, '2026-10-08 19:15:17', '0');
INSERT INTO `sop_document` VALUES (43, '000000', 'SOP20260914043', '固件刷写作业指导书', 'PRODUCTION', 'V1.0', 'DRAFT', 0, 'PDF', '固件刷写标准作业流程与关键控制点', 1, '2026-09-14 15:07:27', '初始发布', NULL, NULL, 103, 1, '2026-09-14 15:07:27', NULL, '2026-10-08 19:15:17', '0');
INSERT INTO `sop_document` VALUES (44, '000000', 'SOP20260914044', '装配作业指导书', 'PRODUCTION', 'V1.0', 'DRAFT', 0, 'PDF', '装配标准作业流程与关键控制点', 1, '2026-09-14 15:07:27', '初始发布', NULL, NULL, 103, 1, '2026-09-14 15:07:27', NULL, '2026-10-08 19:15:17', '0');
INSERT INTO `sop_document` VALUES (45, '000000', 'SOP20260914045', '压装作业指导书', 'PRODUCTION', 'V1.0', 'DRAFT', 0, 'PDF', '压装标准作业流程与关键控制点', 1, '2026-09-14 15:07:27', '初始发布', NULL, NULL, 103, 1, '2026-09-14 15:07:27', NULL, '2026-10-08 19:15:17', '0');
INSERT INTO `sop_document` VALUES (46, '000000', 'SOP20260914046', '点胶作业指导书', 'PRODUCTION', 'V1.0', 'DRAFT', 0, 'PDF', '点胶标准作业流程与关键控制点', 1, '2026-09-14 15:07:27', '初始发布', NULL, NULL, 103, 1, '2026-09-14 15:07:27', NULL, '2026-10-08 19:15:17', '0');
INSERT INTO `sop_document` VALUES (47, '000000', 'SOP20260914047', '功能测试作业指导书', 'INSPECTION', 'V1.0', 'DRAFT', 0, 'PDF', '功能测试标准作业流程与关键控制点', 1, '2026-09-14 15:07:27', '初始发布', NULL, NULL, 103, 1, '2026-09-14 15:07:27', NULL, '2026-10-08 19:15:17', '0');
INSERT INTO `sop_document` VALUES (48, '000000', 'SOP20260914048', '老化作业指导书', 'INSPECTION', 'V1.0', 'DRAFT', 0, 'PDF', '老化标准作业流程与关键控制点', 1, '2026-09-14 15:07:27', '初始发布', NULL, NULL, 103, 1, '2026-09-14 15:07:27', NULL, '2026-10-08 19:15:17', '0');
INSERT INTO `sop_document` VALUES (49, '000000', 'SOP20260914049', '气密测试作业指导书', 'INSPECTION', 'V1.0', 'DRAFT', 0, 'PDF', '气密测试标准作业流程与关键控制点', 1, '2026-09-14 15:07:27', '初始发布', NULL, NULL, 103, 1, '2026-09-14 15:07:27', NULL, '2026-10-08 19:15:17', '0');
INSERT INTO `sop_document` VALUES (50, '000000', 'SOP20260914050', '精度检验作业指导书', 'INSPECTION', 'V1.0', 'DRAFT', 0, 'PDF', '精度检验标准作业流程与关键控制点', 1, '2026-09-14 15:07:27', '初始发布', NULL, NULL, 103, 1, '2026-09-14 15:07:27', NULL, '2026-10-08 19:15:17', '0');
INSERT INTO `sop_document` VALUES (51, '000000', 'SOP20260914051', '动平衡作业指导书', 'INSPECTION', 'V1.0', 'DRAFT', 0, 'PDF', '动平衡标准作业流程与关键控制点', 1, '2026-09-14 15:07:27', '初始发布', NULL, NULL, 103, 1, '2026-09-14 15:07:27', NULL, '2026-10-08 19:15:17', '0');
INSERT INTO `sop_document` VALUES (52, '000000', 'SOP20260914052', 'ICT测试作业指导书', 'INSPECTION', 'V1.0', 'DRAFT', 0, 'PDF', 'ICT测试标准作业流程与关键控制点', 1, '2026-09-14 15:07:27', '初始发布', NULL, NULL, 103, 1, '2026-09-14 15:07:27', NULL, '2026-10-08 19:15:17', '0');
INSERT INTO `sop_document` VALUES (53, '000000', 'SOP20260914053', '防水测试作业指导书', 'INSPECTION', 'V1.0', 'DRAFT', 0, 'PDF', '防水测试标准作业流程与关键控制点', 1, '2026-09-14 15:07:27', '初始发布', NULL, NULL, 103, 1, '2026-09-14 15:07:27', NULL, '2026-10-08 19:15:17', '0');
INSERT INTO `sop_document` VALUES (54, '000000', 'SOP20260914054', '质检作业指导书', 'INSPECTION', 'V1.0', 'DRAFT', 0, 'PDF', '质检标准作业流程与关键控制点', 1, '2026-09-14 15:07:27', '初始发布', NULL, NULL, 103, 1, '2026-09-14 15:07:27', NULL, '2026-10-08 19:15:17', '0');
INSERT INTO `sop_document` VALUES (55, '000000', 'SOP20260914055', '包装作业指导书', 'PRODUCTION', 'V1.0', 'DRAFT', 0, 'PDF', '包装标准作业流程与关键控制点', 1, '2026-09-14 15:07:27', '初始发布', NULL, NULL, 103, 1, '2026-09-14 15:07:27', NULL, '2026-10-08 19:15:17', '0');
INSERT INTO `sop_document` VALUES (56, '000000', 'SOP20260914056', '清洗作业指导书', 'CLEAN', 'V1.0', 'DRAFT', 0, 'PDF', '清洗标准作业流程与关键控制点', 1, '2026-09-14 15:07:27', '初始发布', NULL, NULL, 103, 1, '2026-09-14 15:07:27', NULL, '2026-10-08 19:15:17', '0');
INSERT INTO `sop_document` VALUES (57, '000000', 'SOP20260914057', '去毛刺作业指导书', 'PRODUCTION', 'V1.0', 'DRAFT', 0, 'PDF', '去毛刺标准作业流程与关键控制点', 1, '2026-09-14 15:07:27', '初始发布', NULL, NULL, 103, 1, '2026-09-14 15:07:27', NULL, '2026-10-08 19:15:17', '0');
INSERT INTO `sop_document` VALUES (2100507000309788673, '000000', 'SOP20260917001', '测试', 'PRODUCTION', '1.0', 'ARCHIVED', 2100506990969073665, 'PDF', '', 1, '2026-09-17 16:48:30', NULL, NULL, '', 103, 1, '2026-09-17 16:47:49', 1, '2026-09-17 16:47:49', '0');

-- ----------------------------
-- Table structure for sop_process_binding
-- ----------------------------
DROP TABLE IF EXISTS `sop_process_binding`;
CREATE TABLE `sop_process_binding`  (
  `binding_id` bigint(20) NOT NULL COMMENT '绑定ID(主键)',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '000000',
  `process_id` bigint(20) NOT NULL COMMENT '工序ID(ERP bd_process.process_id, 工序主数据PK)',
  `process_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '工序编码(冗余)',
  `process_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '工序名称(冗余)',
  `process_category` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '工序类别(冗余, PROCESSING/ASSEMBLY/INSPECTION/PACKAGING)',
  `sop_id` bigint(20) NOT NULL COMMENT 'SOP ID',
  `version_no` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '指定版本号(空=当前发布版)',
  `is_default` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '是否该工序默认SOP(1/0)',
  `sort_order` int(11) NULL DEFAULT 0 COMMENT '排序',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '备注',
  `create_dept` bigint(20) NULL DEFAULT NULL COMMENT '创建部门',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '删除标志',
  PRIMARY KEY (`binding_id`) USING BTREE,
  INDEX `idx_process`(`process_id`) USING BTREE,
  INDEX `idx_sop_id`(`sop_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '工序SOP绑定' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sop_process_binding
-- ----------------------------
INSERT INTO `sop_process_binding` VALUES (1, '000000', 1, 'LASER', '激光切割', '下料', 1, '1', '1', 1, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_process_binding` VALUES (2, '000000', 2, 'PLASMA', '等离子切割', '下料', 2, '1', '1', 2, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_process_binding` VALUES (3, '000000', 3, 'SHEAR', '剪板', '下料', 3, '1', '1', 3, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_process_binding` VALUES (4, '000000', 4, 'SAW', '锯切', '下料', 4, '1', '1', 4, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_process_binding` VALUES (5, '000000', 5, 'PUNCH', '冲压', '成形', 5, '1', '1', 5, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_process_binding` VALUES (6, '000000', 6, 'BEND', '折弯', '成形', 6, '1', '1', 6, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_process_binding` VALUES (7, '000000', 7, 'ROLL', '卷圆', '成形', 7, '1', '1', 7, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_process_binding` VALUES (8, '000000', 8, 'DRAW', '拉深', '成形', 8, '1', '1', 8, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_process_binding` VALUES (9, '000000', 9, 'FORGE', '锻造', '成形', 9, '1', '1', 9, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_process_binding` VALUES (10, '000000', 10, 'TURN', '车削', '机加', 10, '1', '1', 10, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_process_binding` VALUES (11, '000000', 11, 'MILL', '铣削', '机加', 11, '1', '1', 11, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_process_binding` VALUES (12, '000000', 12, 'DRILL', '钻孔', '机加', 12, '1', '1', 12, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_process_binding` VALUES (13, '000000', 13, 'GRIND', '磨削', '机加', 13, '1', '1', 13, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_process_binding` VALUES (14, '000000', 14, 'BORE', '镗孔', '机加', 14, '1', '1', 14, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_process_binding` VALUES (15, '000000', 15, 'HOB', '滚齿', '机加', 15, '1', '1', 15, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_process_binding` VALUES (16, '000000', 16, 'SHAPE', '插齿', '机加', 16, '1', '1', 16, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_process_binding` VALUES (17, '000000', 17, 'WEDM', '线切割', '机加', 17, '1', '1', 17, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_process_binding` VALUES (18, '000000', 18, 'EDM', '电火花', '机加', 18, '1', '1', 18, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_process_binding` VALUES (19, '000000', 19, 'CAST', '铸造', '铸造注塑', 19, '1', '1', 19, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_process_binding` VALUES (20, '000000', 20, 'DIE_CAST', '压铸', '铸造注塑', 20, '1', '1', 20, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_process_binding` VALUES (21, '000000', 21, 'MOLD', '注塑', '铸造注塑', 21, '1', '1', 21, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_process_binding` VALUES (22, '000000', 22, 'BLOW', '吹塑', '铸造注塑', 22, '1', '1', 22, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_process_binding` VALUES (23, '000000', 23, 'TIG', '氩弧焊', '焊接', 23, '1', '1', 23, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_process_binding` VALUES (24, '000000', 24, 'MIG', '二保焊', '焊接', 24, '1', '1', 24, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_process_binding` VALUES (25, '000000', 25, 'SPOT', '点焊', '焊接', 25, '1', '1', 25, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_process_binding` VALUES (26, '000000', 26, 'LASER_WELD', '激光焊', '焊接', 26, '1', '1', 26, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_process_binding` VALUES (27, '000000', 27, 'QUENCH', '淬火', '热处理', 27, '1', '1', 27, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_process_binding` VALUES (28, '000000', 28, 'TEMPER', '回火', '热处理', 28, '1', '1', 28, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_process_binding` VALUES (29, '000000', 29, 'CARBURIZE', '渗碳', '热处理', 29, '1', '1', 29, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_process_binding` VALUES (30, '000000', 30, 'AGE', '时效', '热处理', 30, '1', '1', 30, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_process_binding` VALUES (31, '000000', 31, 'PLATE', '电镀', '表面', 31, '1', '1', 31, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_process_binding` VALUES (32, '000000', 32, 'ANODIZE', '阳极氧化', '表面', 32, '1', '1', 32, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_process_binding` VALUES (33, '000000', 33, 'POWDER', '喷塑', '表面', 33, '1', '1', 33, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_process_binding` VALUES (34, '000000', 34, 'PAINT', '喷漆', '表面', 34, '1', '1', 34, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_process_binding` VALUES (35, '000000', 35, 'SCREEN', '丝印', '表面', 35, '1', '1', 35, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_process_binding` VALUES (36, '000000', 36, 'POLISH', '抛光', '表面', 36, '1', '1', 36, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_process_binding` VALUES (37, '000000', 37, 'SMT', 'SMT贴片', '电子', 37, '1', '1', 37, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_process_binding` VALUES (38, '000000', 38, 'INSERT', '插件', '电子', 38, '1', '1', 38, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_process_binding` VALUES (39, '000000', 39, 'WAVE', '波峰焊', '电子', 39, '1', '1', 39, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_process_binding` VALUES (40, '000000', 40, 'SOLDER_MANUAL', '手工焊', '电子', 40, '1', '1', 40, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_process_binding` VALUES (41, '000000', 41, 'WINDING', '绕线', '电子', 41, '1', '1', 41, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_process_binding` VALUES (42, '000000', 42, 'VARNISH', '浸漆', '电子', 42, '1', '1', 42, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_process_binding` VALUES (43, '000000', 43, 'FLASH', '固件刷写', '电子', 43, '1', '1', 43, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_process_binding` VALUES (44, '000000', 44, 'ASM', '装配', '装配', 44, '1', '1', 44, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_process_binding` VALUES (45, '000000', 45, 'PRESS_FIT', '压装', '装配', 45, '1', '1', 45, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_process_binding` VALUES (46, '000000', 46, 'DISPENSE', '点胶', '装配', 46, '1', '1', 46, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_process_binding` VALUES (47, '000000', 47, 'FUNC_TEST', '功能测试', '测试', 47, '1', '1', 47, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_process_binding` VALUES (48, '000000', 48, 'AGING', '老化', '测试', 48, '1', '1', 48, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_process_binding` VALUES (49, '000000', 49, 'WP_TEST', '气密测试', '测试', 49, '1', '1', 49, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_process_binding` VALUES (50, '000000', 50, 'PRECISION', '精度检验', '测试', 50, '1', '1', 50, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_process_binding` VALUES (51, '000000', 51, 'BALANCE', '动平衡', '测试', 51, '1', '1', 51, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_process_binding` VALUES (52, '000000', 52, 'ICT', 'ICT测试', '测试', 52, '1', '1', 52, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_process_binding` VALUES (53, '000000', 53, 'WATER_PROOF', '防水测试', '测试', 53, '1', '1', 53, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_process_binding` VALUES (54, '000000', 54, 'QC', '质检', '通用', 54, '1', '1', 54, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_process_binding` VALUES (55, '000000', 55, 'PKG', '包装', '通用', 55, '1', '1', 55, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_process_binding` VALUES (56, '000000', 56, 'CLEAN', '清洗', '通用', 56, '1', '1', 56, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_process_binding` VALUES (57, '000000', 57, 'DEBURR', '去毛刺', '通用', 57, '1', '1', 57, NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');

-- ----------------------------
-- Table structure for sop_version
-- ----------------------------
DROP TABLE IF EXISTS `sop_version`;
CREATE TABLE `sop_version`  (
  `version_id` bigint(20) NOT NULL COMMENT '版本ID(主键)',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '000000',
  `sop_id` bigint(20) NOT NULL COMMENT 'SOP ID',
  `version_no` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '版本号(如1.0/1.1)',
  `file_oss_id` bigint(20) NOT NULL COMMENT '该版本文件OSS ID',
  `file_type` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '文件类型: PDF/IMAGE/VIDEO/WORD',
  `file_hash` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '该版本正文的 SM3(签名绑定正文用), 空表示尚未计算',
  `change_log` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '变更说明',
  `published_time` datetime(0) NULL DEFAULT NULL COMMENT '发布时间',
  `published_by` bigint(20) NULL DEFAULT NULL COMMENT '发布人ID',
  `status` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT 'PENDING' COMMENT '状态: PENDING/CURRENT/HISTORICAL',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '备注',
  `create_dept` bigint(20) NULL DEFAULT NULL COMMENT '创建部门',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '删除标志',
  PRIMARY KEY (`version_id`) USING BTREE,
  UNIQUE INDEX `uk_sop_version_no`(`sop_id`, `version_no`, `tenant_id`, `del_flag`) USING BTREE,
  INDEX `idx_sop_id`(`sop_id`) USING BTREE,
  INDEX `idx_status`(`status`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = 'SOP版本历史' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sop_version
-- ----------------------------
INSERT INTO `sop_version` VALUES (1, '000000', 1, 'V1.0', 0, 'PDF', NULL, '初始版本', '2026-09-14 15:07:27', 1, 'HISTORICAL', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (2, '000000', 2, 'V1.0', 0, 'PDF', NULL, '初始版本', '2026-09-14 15:07:27', 1, 'CURRENT', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (3, '000000', 3, 'V1.0', 0, 'PDF', NULL, '初始版本', '2026-09-14 15:07:27', 1, 'CURRENT', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (4, '000000', 4, 'V1.0', 0, 'PDF', NULL, '初始版本', '2026-09-14 15:07:27', 1, 'CURRENT', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (5, '000000', 5, 'V1.0', 0, 'PDF', NULL, '初始版本', '2026-09-14 15:07:27', 1, 'CURRENT', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (6, '000000', 6, 'V1.0', 0, 'PDF', NULL, '初始版本', '2026-09-14 15:07:27', 1, 'CURRENT', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (7, '000000', 7, 'V1.0', 0, 'PDF', NULL, '初始版本', '2026-09-14 15:07:27', 1, 'CURRENT', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (8, '000000', 8, 'V1.0', 0, 'PDF', NULL, '初始版本', '2026-09-14 15:07:27', 1, 'CURRENT', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (9, '000000', 9, 'V1.0', 0, 'PDF', NULL, '初始版本', '2026-09-14 15:07:27', 1, 'CURRENT', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (10, '000000', 10, 'V1.0', 0, 'PDF', NULL, '初始版本', '2026-09-14 15:07:27', 1, 'CURRENT', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (11, '000000', 11, 'V1.0', 0, 'PDF', NULL, '初始版本', '2026-09-14 15:07:27', 1, 'CURRENT', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (12, '000000', 12, 'V1.0', 0, 'PDF', NULL, '初始版本', '2026-09-14 15:07:27', 1, 'CURRENT', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (13, '000000', 13, 'V1.0', 0, 'PDF', NULL, '初始版本', '2026-09-14 15:07:27', 1, 'CURRENT', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (14, '000000', 14, 'V1.0', 0, 'PDF', NULL, '初始版本', '2026-09-14 15:07:27', 1, 'CURRENT', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (15, '000000', 15, 'V1.0', 0, 'PDF', NULL, '初始版本', '2026-09-14 15:07:27', 1, 'CURRENT', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (16, '000000', 16, 'V1.0', 0, 'PDF', NULL, '初始版本', '2026-09-14 15:07:27', 1, 'CURRENT', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (17, '000000', 17, 'V1.0', 0, 'PDF', NULL, '初始版本', '2026-09-14 15:07:27', 1, 'CURRENT', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (18, '000000', 18, 'V1.0', 0, 'PDF', NULL, '初始版本', '2026-09-14 15:07:27', 1, 'CURRENT', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (19, '000000', 19, 'V1.0', 0, 'PDF', NULL, '初始版本', '2026-09-14 15:07:27', 1, 'CURRENT', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (20, '000000', 20, 'V1.0', 0, 'PDF', NULL, '初始版本', '2026-09-14 15:07:27', 1, 'CURRENT', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (21, '000000', 21, 'V1.0', 0, 'PDF', NULL, '初始版本', '2026-09-14 15:07:27', 1, 'CURRENT', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (22, '000000', 22, 'V1.0', 0, 'PDF', NULL, '初始版本', '2026-09-14 15:07:27', 1, 'CURRENT', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (23, '000000', 23, 'V1.0', 0, 'PDF', NULL, '初始版本', '2026-09-14 15:07:27', 1, 'CURRENT', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (24, '000000', 24, 'V1.0', 0, 'PDF', NULL, '初始版本', '2026-09-14 15:07:27', 1, 'CURRENT', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (25, '000000', 25, 'V1.0', 0, 'PDF', NULL, '初始版本', '2026-09-14 15:07:27', 1, 'CURRENT', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (26, '000000', 26, 'V1.0', 0, 'PDF', NULL, '初始版本', '2026-09-14 15:07:27', 1, 'CURRENT', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (27, '000000', 27, 'V1.0', 0, 'PDF', NULL, '初始版本', '2026-09-14 15:07:27', 1, 'CURRENT', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (28, '000000', 28, 'V1.0', 0, 'PDF', NULL, '初始版本', '2026-09-14 15:07:27', 1, 'CURRENT', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (29, '000000', 29, 'V1.0', 0, 'PDF', NULL, '初始版本', '2026-09-14 15:07:27', 1, 'CURRENT', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (30, '000000', 30, 'V1.0', 0, 'PDF', NULL, '初始版本', '2026-09-14 15:07:27', 1, 'CURRENT', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (31, '000000', 31, 'V1.0', 0, 'PDF', NULL, '初始版本', '2026-09-14 15:07:27', 1, 'CURRENT', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (32, '000000', 32, 'V1.0', 0, 'PDF', NULL, '初始版本', '2026-09-14 15:07:27', 1, 'CURRENT', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (33, '000000', 33, 'V1.0', 0, 'PDF', NULL, '初始版本', '2026-09-14 15:07:27', 1, 'CURRENT', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (34, '000000', 34, 'V1.0', 0, 'PDF', NULL, '初始版本', '2026-09-14 15:07:27', 1, 'CURRENT', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (35, '000000', 35, 'V1.0', 0, 'PDF', NULL, '初始版本', '2026-09-14 15:07:27', 1, 'CURRENT', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (36, '000000', 36, 'V1.0', 0, 'PDF', NULL, '初始版本', '2026-09-14 15:07:27', 1, 'CURRENT', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (37, '000000', 37, 'V1.0', 0, 'PDF', NULL, '初始版本', '2026-09-14 15:07:27', 1, 'CURRENT', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (38, '000000', 38, 'V1.0', 0, 'PDF', NULL, '初始版本', '2026-09-14 15:07:27', 1, 'CURRENT', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (39, '000000', 39, 'V1.0', 0, 'PDF', NULL, '初始版本', '2026-09-14 15:07:27', 1, 'CURRENT', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (40, '000000', 40, 'V1.0', 0, 'PDF', NULL, '初始版本', '2026-09-14 15:07:27', 1, 'CURRENT', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (41, '000000', 41, 'V1.0', 0, 'PDF', NULL, '初始版本', '2026-09-14 15:07:27', 1, 'CURRENT', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (42, '000000', 42, 'V1.0', 0, 'PDF', NULL, '初始版本', '2026-09-14 15:07:27', 1, 'CURRENT', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (43, '000000', 43, 'V1.0', 0, 'PDF', NULL, '初始版本', '2026-09-14 15:07:27', 1, 'CURRENT', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (44, '000000', 44, 'V1.0', 0, 'PDF', NULL, '初始版本', '2026-09-14 15:07:27', 1, 'CURRENT', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (45, '000000', 45, 'V1.0', 0, 'PDF', NULL, '初始版本', '2026-09-14 15:07:27', 1, 'CURRENT', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (46, '000000', 46, 'V1.0', 0, 'PDF', NULL, '初始版本', '2026-09-14 15:07:27', 1, 'CURRENT', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (47, '000000', 47, 'V1.0', 0, 'PDF', NULL, '初始版本', '2026-09-14 15:07:27', 1, 'CURRENT', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (48, '000000', 48, 'V1.0', 0, 'PDF', NULL, '初始版本', '2026-09-14 15:07:27', 1, 'CURRENT', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (49, '000000', 49, 'V1.0', 0, 'PDF', NULL, '初始版本', '2026-09-14 15:07:27', 1, 'CURRENT', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (50, '000000', 50, 'V1.0', 0, 'PDF', NULL, '初始版本', '2026-09-14 15:07:27', 1, 'CURRENT', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (51, '000000', 51, 'V1.0', 0, 'PDF', NULL, '初始版本', '2026-09-14 15:07:27', 1, 'CURRENT', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (52, '000000', 52, 'V1.0', 0, 'PDF', NULL, '初始版本', '2026-09-14 15:07:27', 1, 'CURRENT', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (53, '000000', 53, 'V1.0', 0, 'PDF', NULL, '初始版本', '2026-09-14 15:07:27', 1, 'CURRENT', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (54, '000000', 54, 'V1.0', 0, 'PDF', NULL, '初始版本', '2026-09-14 15:07:27', 1, 'CURRENT', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (55, '000000', 55, 'V1.0', 0, 'PDF', NULL, '初始版本', '2026-09-14 15:07:27', 1, 'CURRENT', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (56, '000000', 56, 'V1.0', 0, 'PDF', NULL, '初始版本', '2026-09-14 15:07:27', 1, 'CURRENT', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (57, '000000', 57, 'V1.0', 0, 'PDF', NULL, '初始版本', '2026-09-14 15:07:27', 1, 'CURRENT', NULL, 103, 1, '2026-09-14 15:07:27', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (2100507000326565889, '000000', 2100507000309788673, '1.0', 2100506990969073665, 'PDF', NULL, '', '2026-09-17 16:48:30', 1, 'CURRENT', NULL, 103, 1, '2026-09-17 16:47:49', 1, '2026-09-17 16:47:49', '0');
INSERT INTO `sop_version` VALUES (2108122792569335809, '000000', 1, 'V1.1', 2108122792569335808, 'PDF', '555735470d9af7a4c087fd8630928a81d1177cc0b0b3ab6c2953c2db5ca7fb8b', '新增工序级中文参考 PDF，示例/待审核；不替换原版本或历史签名。', '2026-10-08 19:50:42', 1, 'CURRENT', 'NEXUS_SOP_REFERENCE_20261008；未经现场审批不得用于生产', NULL, NULL, '2026-10-08 19:15:17', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (2108122792569335811, '000000', 2, 'V1.1', 2108122792569335810, 'PDF', '5f60638c9277e986b2b7a9045116f8bcf628066a9a2749087c3695e5304caef1', '新增工序级中文参考 PDF，示例/待审核；不替换原版本或历史签名。', NULL, NULL, 'PENDING', 'NEXUS_SOP_REFERENCE_20261008；未经现场审批不得用于生产', NULL, NULL, '2026-10-08 19:15:17', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (2108122792569335813, '000000', 3, 'V1.1', 2108122792569335812, 'PDF', 'b5f8fc5c3a4349cb639b22f5b2a0d5940a588a8b3fc7c96aff76099671676296', '新增工序级中文参考 PDF，示例/待审核；不替换原版本或历史签名。', NULL, NULL, 'PENDING', 'NEXUS_SOP_REFERENCE_20261008；未经现场审批不得用于生产', NULL, NULL, '2026-10-08 19:15:17', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (2108122792569335815, '000000', 4, 'V1.1', 2108122792569335814, 'PDF', '79425db6151edb8edd75c41a4b6558b7e8c97a037eb71999e5f5e87c7b3ba856', '新增工序级中文参考 PDF，示例/待审核；不替换原版本或历史签名。', NULL, NULL, 'PENDING', 'NEXUS_SOP_REFERENCE_20261008；未经现场审批不得用于生产', NULL, NULL, '2026-10-08 19:15:17', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (2108122792569335817, '000000', 5, 'V1.1', 2108122792569335816, 'PDF', '84bbf9e45e26fbcf1aff6aa9eaa7020c676288cb500bbff282c503c483355a1f', '新增工序级中文参考 PDF，示例/待审核；不替换原版本或历史签名。', NULL, NULL, 'PENDING', 'NEXUS_SOP_REFERENCE_20261008；未经现场审批不得用于生产', NULL, NULL, '2026-10-08 19:15:17', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (2108122792569335819, '000000', 6, 'V1.1', 2108122792569335818, 'PDF', '6c102972060e34caf6fac3cea22025e30683d3d244289b1e83b87c8bca708f1c', '新增工序级中文参考 PDF，示例/待审核；不替换原版本或历史签名。', NULL, NULL, 'PENDING', 'NEXUS_SOP_REFERENCE_20261008；未经现场审批不得用于生产', NULL, NULL, '2026-10-08 19:15:17', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (2108122792569335821, '000000', 7, 'V1.1', 2108122792569335820, 'PDF', '8b661bc62bd72a72af858db72792eed870c104879210a826e16ff4af81264379', '新增工序级中文参考 PDF，示例/待审核；不替换原版本或历史签名。', NULL, NULL, 'PENDING', 'NEXUS_SOP_REFERENCE_20261008；未经现场审批不得用于生产', NULL, NULL, '2026-10-08 19:15:17', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (2108122792569335823, '000000', 8, 'V1.1', 2108122792569335822, 'PDF', '59c24ae4bd34a7526d1a5a543a45f91c997b197068f8ac990cc18e655810289d', '新增工序级中文参考 PDF，示例/待审核；不替换原版本或历史签名。', NULL, NULL, 'PENDING', 'NEXUS_SOP_REFERENCE_20261008；未经现场审批不得用于生产', NULL, NULL, '2026-10-08 19:15:17', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (2108122792569335825, '000000', 9, 'V1.1', 2108122792569335824, 'PDF', '5b38313f6189139e7d99c2b68be11a85966f1112025a36356d653390b9d68aee', '新增工序级中文参考 PDF，示例/待审核；不替换原版本或历史签名。', NULL, NULL, 'PENDING', 'NEXUS_SOP_REFERENCE_20261008；未经现场审批不得用于生产', NULL, NULL, '2026-10-08 19:15:17', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (2108122792569335827, '000000', 10, 'V1.1', 2108122792569335826, 'PDF', '225ba4be3094778bfbe1becab61e56db9f38b21ee818db1e79b0cd4263c18381', '新增工序级中文参考 PDF，示例/待审核；不替换原版本或历史签名。', NULL, NULL, 'PENDING', 'NEXUS_SOP_REFERENCE_20261008；未经现场审批不得用于生产', NULL, NULL, '2026-10-08 19:15:17', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (2108122792569335829, '000000', 11, 'V1.1', 2108122792569335828, 'PDF', '7a2819b6960076b6c44c7fc6f28a610ec2998a0e8f7ed1afa5453ec03bcc872d', '新增工序级中文参考 PDF，示例/待审核；不替换原版本或历史签名。', NULL, NULL, 'PENDING', 'NEXUS_SOP_REFERENCE_20261008；未经现场审批不得用于生产', NULL, NULL, '2026-10-08 19:15:17', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (2108122792569335831, '000000', 12, 'V1.1', 2108122792569335830, 'PDF', '67373a722ed9c231d09babd4afd7ee721f3fed41137193b86506fe8c38df171b', '新增工序级中文参考 PDF，示例/待审核；不替换原版本或历史签名。', NULL, NULL, 'PENDING', 'NEXUS_SOP_REFERENCE_20261008；未经现场审批不得用于生产', NULL, NULL, '2026-10-08 19:15:17', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (2108122792569335833, '000000', 13, 'V1.1', 2108122792569335832, 'PDF', '069b764782e77320c236ef548c08db7c6f8a651e34dca344c183d427ddf185cc', '新增工序级中文参考 PDF，示例/待审核；不替换原版本或历史签名。', NULL, NULL, 'PENDING', 'NEXUS_SOP_REFERENCE_20261008；未经现场审批不得用于生产', NULL, NULL, '2026-10-08 19:15:17', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (2108122792569335835, '000000', 14, 'V1.1', 2108122792569335834, 'PDF', 'bc6d4814e935fd655880edb6d4e79dde9ea34ab962446d5417302d76c74db797', '新增工序级中文参考 PDF，示例/待审核；不替换原版本或历史签名。', NULL, NULL, 'PENDING', 'NEXUS_SOP_REFERENCE_20261008；未经现场审批不得用于生产', NULL, NULL, '2026-10-08 19:15:17', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (2108122792569335837, '000000', 15, 'V1.1', 2108122792569335836, 'PDF', 'd6d6d4aef91e3940c0e39ac41745eba702e84c27cea4d0555dd20e2fc156025f', '新增工序级中文参考 PDF，示例/待审核；不替换原版本或历史签名。', NULL, NULL, 'PENDING', 'NEXUS_SOP_REFERENCE_20261008；未经现场审批不得用于生产', NULL, NULL, '2026-10-08 19:15:17', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (2108122792569335839, '000000', 16, 'V1.1', 2108122792569335838, 'PDF', 'b42f46dee1a6f79e145f3f0fb1f74bababb4b33583c5bb624575b1257c288328', '新增工序级中文参考 PDF，示例/待审核；不替换原版本或历史签名。', NULL, NULL, 'PENDING', 'NEXUS_SOP_REFERENCE_20261008；未经现场审批不得用于生产', NULL, NULL, '2026-10-08 19:15:17', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (2108122792569335841, '000000', 17, 'V1.1', 2108122792569335840, 'PDF', '9ffaa1f2b0c92d9cb57edd3328ac39402dd941cd8b9b52a9659fbeac499a7733', '新增工序级中文参考 PDF，示例/待审核；不替换原版本或历史签名。', NULL, NULL, 'PENDING', 'NEXUS_SOP_REFERENCE_20261008；未经现场审批不得用于生产', NULL, NULL, '2026-10-08 19:15:17', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (2108122792569335843, '000000', 18, 'V1.1', 2108122792569335842, 'PDF', '503dd861d3c00710b4e22dc2bccba11af699baabc6080e5f624a8aaa03d2fc20', '新增工序级中文参考 PDF，示例/待审核；不替换原版本或历史签名。', NULL, NULL, 'PENDING', 'NEXUS_SOP_REFERENCE_20261008；未经现场审批不得用于生产', NULL, NULL, '2026-10-08 19:15:17', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (2108122792569335845, '000000', 19, 'V1.1', 2108122792569335844, 'PDF', '9ecf541d25a0b12f08912907b7d61041eb8fdf06e722ea396c9b9bdfa5ec0190', '新增工序级中文参考 PDF，示例/待审核；不替换原版本或历史签名。', NULL, NULL, 'PENDING', 'NEXUS_SOP_REFERENCE_20261008；未经现场审批不得用于生产', NULL, NULL, '2026-10-08 19:15:17', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (2108122792569335847, '000000', 20, 'V1.1', 2108122792569335846, 'PDF', '292f3ac3c1887484e1641fb96c4162b2775abf67fe1dc1489907505d4c93eed1', '新增工序级中文参考 PDF，示例/待审核；不替换原版本或历史签名。', NULL, NULL, 'PENDING', 'NEXUS_SOP_REFERENCE_20261008；未经现场审批不得用于生产', NULL, NULL, '2026-10-08 19:15:17', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (2108122792569335849, '000000', 21, 'V1.1', 2108122792569335848, 'PDF', '9de93c1471b0ab68539aac791d093c41aaefbc566631950b6b1c0c16cc2839e7', '新增工序级中文参考 PDF，示例/待审核；不替换原版本或历史签名。', NULL, NULL, 'PENDING', 'NEXUS_SOP_REFERENCE_20261008；未经现场审批不得用于生产', NULL, NULL, '2026-10-08 19:15:17', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (2108122792569335851, '000000', 22, 'V1.1', 2108122792569335850, 'PDF', 'fc8c3785fc1e61935b5b7826d89eb4f881ad163bbfde19cac983f9e54548a5d6', '新增工序级中文参考 PDF，示例/待审核；不替换原版本或历史签名。', NULL, NULL, 'PENDING', 'NEXUS_SOP_REFERENCE_20261008；未经现场审批不得用于生产', NULL, NULL, '2026-10-08 19:15:17', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (2108122792569335853, '000000', 23, 'V1.1', 2108122792569335852, 'PDF', '868ce6d3bcb1ff92071fcb38aa132449554a7bd10bdb8309b9993a9f67f1b3a9', '新增工序级中文参考 PDF，示例/待审核；不替换原版本或历史签名。', NULL, NULL, 'PENDING', 'NEXUS_SOP_REFERENCE_20261008；未经现场审批不得用于生产', NULL, NULL, '2026-10-08 19:15:17', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (2108122792569335855, '000000', 24, 'V1.1', 2108122792569335854, 'PDF', '9597278d4b95d8612f7de31ffb99f792ca5721032965a866c0e2eefa51715a74', '新增工序级中文参考 PDF，示例/待审核；不替换原版本或历史签名。', NULL, NULL, 'PENDING', 'NEXUS_SOP_REFERENCE_20261008；未经现场审批不得用于生产', NULL, NULL, '2026-10-08 19:15:17', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (2108122792569335857, '000000', 25, 'V1.1', 2108122792569335856, 'PDF', 'c305934f391b9cdf927f24b343ffd3f0b452a0311b6e584797768de40215167d', '新增工序级中文参考 PDF，示例/待审核；不替换原版本或历史签名。', NULL, NULL, 'PENDING', 'NEXUS_SOP_REFERENCE_20261008；未经现场审批不得用于生产', NULL, NULL, '2026-10-08 19:15:17', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (2108122792569335859, '000000', 26, 'V1.1', 2108122792569335858, 'PDF', 'f85bdc8947cd4065b933df73576a857cff65e2feb29567b63fe51bf5d0226f18', '新增工序级中文参考 PDF，示例/待审核；不替换原版本或历史签名。', NULL, NULL, 'PENDING', 'NEXUS_SOP_REFERENCE_20261008；未经现场审批不得用于生产', NULL, NULL, '2026-10-08 19:15:17', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (2108122792569335861, '000000', 27, 'V1.1', 2108122792569335860, 'PDF', 'f2afa704289a0d33777e5990604558454a9cc0a307d2a27f4dafee15bb378271', '新增工序级中文参考 PDF，示例/待审核；不替换原版本或历史签名。', NULL, NULL, 'PENDING', 'NEXUS_SOP_REFERENCE_20261008；未经现场审批不得用于生产', NULL, NULL, '2026-10-08 19:15:17', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (2108122792569335863, '000000', 28, 'V1.1', 2108122792569335862, 'PDF', '37f1881519de2f05180a8c734492b4f24aa5a20d4760d9fa098fb7d323a07da3', '新增工序级中文参考 PDF，示例/待审核；不替换原版本或历史签名。', NULL, NULL, 'PENDING', 'NEXUS_SOP_REFERENCE_20261008；未经现场审批不得用于生产', NULL, NULL, '2026-10-08 19:15:17', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (2108122792569335865, '000000', 29, 'V1.1', 2108122792569335864, 'PDF', 'fd357b8cf6997989e4c8878365f5d546003d437568d9799307845c6d295169d5', '新增工序级中文参考 PDF，示例/待审核；不替换原版本或历史签名。', NULL, NULL, 'PENDING', 'NEXUS_SOP_REFERENCE_20261008；未经现场审批不得用于生产', NULL, NULL, '2026-10-08 19:15:17', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (2108122792569335867, '000000', 30, 'V1.1', 2108122792569335866, 'PDF', '6e322ac0034fcec70945d06bb1ee649c8ae0603fca210205e0bd3cba7d066108', '新增工序级中文参考 PDF，示例/待审核；不替换原版本或历史签名。', NULL, NULL, 'PENDING', 'NEXUS_SOP_REFERENCE_20261008；未经现场审批不得用于生产', NULL, NULL, '2026-10-08 19:15:17', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (2108122792569335869, '000000', 31, 'V1.1', 2108122792569335868, 'PDF', 'cd790d1715761aba78e16f2d22e702ed1637f0c5903c8bbb0bbe408ff0a3cd5f', '新增工序级中文参考 PDF，示例/待审核；不替换原版本或历史签名。', NULL, NULL, 'PENDING', 'NEXUS_SOP_REFERENCE_20261008；未经现场审批不得用于生产', NULL, NULL, '2026-10-08 19:15:17', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (2108122792569335871, '000000', 32, 'V1.1', 2108122792569335870, 'PDF', 'b4f426aa6955dd89b0b424427af1b598e05ae5c961076b44431514dbc8580406', '新增工序级中文参考 PDF，示例/待审核；不替换原版本或历史签名。', NULL, NULL, 'PENDING', 'NEXUS_SOP_REFERENCE_20261008；未经现场审批不得用于生产', NULL, NULL, '2026-10-08 19:15:17', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (2108122792569335873, '000000', 33, 'V1.1', 2108122792569335872, 'PDF', 'caa2480ef61e87bdbf80cf93df072a861538e83109ddfa4c6f4ab46d48db5874', '新增工序级中文参考 PDF，示例/待审核；不替换原版本或历史签名。', NULL, NULL, 'PENDING', 'NEXUS_SOP_REFERENCE_20261008；未经现场审批不得用于生产', NULL, NULL, '2026-10-08 19:15:17', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (2108122792569335875, '000000', 34, 'V1.1', 2108122792569335874, 'PDF', '908d1b9f69e6161bc3daec9206b8f614c60630dc951b47e81cf4888739480404', '新增工序级中文参考 PDF，示例/待审核；不替换原版本或历史签名。', NULL, NULL, 'PENDING', 'NEXUS_SOP_REFERENCE_20261008；未经现场审批不得用于生产', NULL, NULL, '2026-10-08 19:15:17', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (2108122792569335877, '000000', 35, 'V1.1', 2108122792569335876, 'PDF', '9e48ddf24579b947d93aee1eb1a0ef82cfb94556940b61d2fdaf155269b9fde5', '新增工序级中文参考 PDF，示例/待审核；不替换原版本或历史签名。', NULL, NULL, 'PENDING', 'NEXUS_SOP_REFERENCE_20261008；未经现场审批不得用于生产', NULL, NULL, '2026-10-08 19:15:17', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (2108122792569335879, '000000', 36, 'V1.1', 2108122792569335878, 'PDF', '7c2f393897739f3274684e1136dd904d97e4cd17caff053b796e091044c3db57', '新增工序级中文参考 PDF，示例/待审核；不替换原版本或历史签名。', NULL, NULL, 'PENDING', 'NEXUS_SOP_REFERENCE_20261008；未经现场审批不得用于生产', NULL, NULL, '2026-10-08 19:15:17', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (2108122792569335881, '000000', 37, 'V1.1', 2108122792569335880, 'PDF', '7a28c2ebc1aeeb192ccd17ca7901b9ee80de3b776f9944db5325f2781a486f76', '新增工序级中文参考 PDF，示例/待审核；不替换原版本或历史签名。', NULL, NULL, 'PENDING', 'NEXUS_SOP_REFERENCE_20261008；未经现场审批不得用于生产', NULL, NULL, '2026-10-08 19:15:17', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (2108122792569335883, '000000', 38, 'V1.1', 2108122792569335882, 'PDF', '9309a84febdbfab4c5cc4e271f3f8212f2b7b88c7ff5f59837a80fa85e4e30aa', '新增工序级中文参考 PDF，示例/待审核；不替换原版本或历史签名。', NULL, NULL, 'PENDING', 'NEXUS_SOP_REFERENCE_20261008；未经现场审批不得用于生产', NULL, NULL, '2026-10-08 19:15:17', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (2108122792569335885, '000000', 39, 'V1.1', 2108122792569335884, 'PDF', '5587bb70fe5ff04491e0d5b39ef843bd37dd90401ea4b0383b29307ce1366892', '新增工序级中文参考 PDF，示例/待审核；不替换原版本或历史签名。', NULL, NULL, 'PENDING', 'NEXUS_SOP_REFERENCE_20261008；未经现场审批不得用于生产', NULL, NULL, '2026-10-08 19:15:17', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (2108122792569335887, '000000', 40, 'V1.1', 2108122792569335886, 'PDF', 'f4032541a9f6365074fe3d59744aec45325ea997f98c1222f047fa8383bce322', '新增工序级中文参考 PDF，示例/待审核；不替换原版本或历史签名。', NULL, NULL, 'PENDING', 'NEXUS_SOP_REFERENCE_20261008；未经现场审批不得用于生产', NULL, NULL, '2026-10-08 19:15:17', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (2108122792569335889, '000000', 41, 'V1.1', 2108122792569335888, 'PDF', 'c20302b9f597f7b10d24d3d96690a7efe50167f4d5581ef6a110407ccd529d73', '新增工序级中文参考 PDF，示例/待审核；不替换原版本或历史签名。', NULL, NULL, 'PENDING', 'NEXUS_SOP_REFERENCE_20261008；未经现场审批不得用于生产', NULL, NULL, '2026-10-08 19:15:17', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (2108122792569335891, '000000', 42, 'V1.1', 2108122792569335890, 'PDF', 'd19163d95ca7b31ebf9cac4ea32f0d929414889d71393bac7699659648ca0977', '新增工序级中文参考 PDF，示例/待审核；不替换原版本或历史签名。', NULL, NULL, 'PENDING', 'NEXUS_SOP_REFERENCE_20261008；未经现场审批不得用于生产', NULL, NULL, '2026-10-08 19:15:17', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (2108122792569335893, '000000', 43, 'V1.1', 2108122792569335892, 'PDF', '0b597ea3d2695b7b5a2cb65b7834ca8acb94c754cbe58344b118ec71f3386a39', '新增工序级中文参考 PDF，示例/待审核；不替换原版本或历史签名。', NULL, NULL, 'PENDING', 'NEXUS_SOP_REFERENCE_20261008；未经现场审批不得用于生产', NULL, NULL, '2026-10-08 19:15:17', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (2108122792569335895, '000000', 44, 'V1.1', 2108122792569335894, 'PDF', 'acbec4f7bb3532356f859cedfdb8ec016c8fe2d9ac1bd98d32b5702673174ab7', '新增工序级中文参考 PDF，示例/待审核；不替换原版本或历史签名。', NULL, NULL, 'PENDING', 'NEXUS_SOP_REFERENCE_20261008；未经现场审批不得用于生产', NULL, NULL, '2026-10-08 19:15:17', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (2108122792569335897, '000000', 45, 'V1.1', 2108122792569335896, 'PDF', '18ece0c0771997ebc526bdd37b1f271496dcb938d425f6be1c919c3496ed0d5c', '新增工序级中文参考 PDF，示例/待审核；不替换原版本或历史签名。', NULL, NULL, 'PENDING', 'NEXUS_SOP_REFERENCE_20261008；未经现场审批不得用于生产', NULL, NULL, '2026-10-08 19:15:17', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (2108122792569335899, '000000', 46, 'V1.1', 2108122792569335898, 'PDF', '70a0791af2dd2526c7c690af1717ca4790fe8e39b1381b048175586d9a04c8ee', '新增工序级中文参考 PDF，示例/待审核；不替换原版本或历史签名。', NULL, NULL, 'PENDING', 'NEXUS_SOP_REFERENCE_20261008；未经现场审批不得用于生产', NULL, NULL, '2026-10-08 19:15:17', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (2108122792569335901, '000000', 47, 'V1.1', 2108122792569335900, 'PDF', '073ec8537e91b28854f64e1e223748eed47136213e97554070a247fa2cdb810f', '新增工序级中文参考 PDF，示例/待审核；不替换原版本或历史签名。', NULL, NULL, 'PENDING', 'NEXUS_SOP_REFERENCE_20261008；未经现场审批不得用于生产', NULL, NULL, '2026-10-08 19:15:17', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (2108122792569335903, '000000', 48, 'V1.1', 2108122792569335902, 'PDF', '57c34893688e0cd4f1487c415e8ea10ce9b593b9481a47d42ed3d780698d4471', '新增工序级中文参考 PDF，示例/待审核；不替换原版本或历史签名。', NULL, NULL, 'PENDING', 'NEXUS_SOP_REFERENCE_20261008；未经现场审批不得用于生产', NULL, NULL, '2026-10-08 19:15:17', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (2108122792569335905, '000000', 49, 'V1.1', 2108122792569335904, 'PDF', '8d527ca9b655ebe39b1b1d05c7415a00eeb8ee72754befecd43e69bc206a9074', '新增工序级中文参考 PDF，示例/待审核；不替换原版本或历史签名。', NULL, NULL, 'PENDING', 'NEXUS_SOP_REFERENCE_20261008；未经现场审批不得用于生产', NULL, NULL, '2026-10-08 19:15:17', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (2108122792569335907, '000000', 50, 'V1.1', 2108122792569335906, 'PDF', '9cd6d169ffde20256340aca4e9ea258cbcd8503f04ea734fc7395a3c707bdf53', '新增工序级中文参考 PDF，示例/待审核；不替换原版本或历史签名。', NULL, NULL, 'PENDING', 'NEXUS_SOP_REFERENCE_20261008；未经现场审批不得用于生产', NULL, NULL, '2026-10-08 19:15:17', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (2108122792569335909, '000000', 51, 'V1.1', 2108122792569335908, 'PDF', 'bcaa73723537bd89def62382a7761b04d15d5e984bade70f40ed76d35203b26c', '新增工序级中文参考 PDF，示例/待审核；不替换原版本或历史签名。', NULL, NULL, 'PENDING', 'NEXUS_SOP_REFERENCE_20261008；未经现场审批不得用于生产', NULL, NULL, '2026-10-08 19:15:17', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (2108122792569335911, '000000', 52, 'V1.1', 2108122792569335910, 'PDF', '21da611835c5ce6c0ac0f486472907b4e24c957c3fa57d06d6f10c4dbb4a77c2', '新增工序级中文参考 PDF，示例/待审核；不替换原版本或历史签名。', NULL, NULL, 'PENDING', 'NEXUS_SOP_REFERENCE_20261008；未经现场审批不得用于生产', NULL, NULL, '2026-10-08 19:15:17', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (2108122792569335913, '000000', 53, 'V1.1', 2108122792569335912, 'PDF', '8fdff1e14453ba7c3b5d2c145ab2a61d879f2aa3915b19da662ca08937b9fb12', '新增工序级中文参考 PDF，示例/待审核；不替换原版本或历史签名。', NULL, NULL, 'PENDING', 'NEXUS_SOP_REFERENCE_20261008；未经现场审批不得用于生产', NULL, NULL, '2026-10-08 19:15:17', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (2108122792569335915, '000000', 54, 'V1.1', 2108122792569335914, 'PDF', '855d0e0cc7c2198292eea37d6f7d452aaf05947cf3e6817b4fd3e33bcab4560b', '新增工序级中文参考 PDF，示例/待审核；不替换原版本或历史签名。', NULL, NULL, 'PENDING', 'NEXUS_SOP_REFERENCE_20261008；未经现场审批不得用于生产', NULL, NULL, '2026-10-08 19:15:17', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (2108122792569335917, '000000', 55, 'V1.1', 2108122792569335916, 'PDF', '1061248044a4d89c9d002dcf200727631dccead832c22174d2e028e921bb19a1', '新增工序级中文参考 PDF，示例/待审核；不替换原版本或历史签名。', NULL, NULL, 'PENDING', 'NEXUS_SOP_REFERENCE_20261008；未经现场审批不得用于生产', NULL, NULL, '2026-10-08 19:15:17', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (2108122792569335919, '000000', 56, 'V1.1', 2108122792569335918, 'PDF', 'b0bc36642154b1f886b0bfc95a635edb1610b54889f8ec305bf779f85c22d3c8', '新增工序级中文参考 PDF，示例/待审核；不替换原版本或历史签名。', NULL, NULL, 'PENDING', 'NEXUS_SOP_REFERENCE_20261008；未经现场审批不得用于生产', NULL, NULL, '2026-10-08 19:15:17', NULL, NULL, '0');
INSERT INTO `sop_version` VALUES (2108122792569335921, '000000', 57, 'V1.1', 2108122792569335920, 'PDF', '19b9be7240b1359f97becddfaf1a4f22cc1c986713518d89e9650715524412ea', '新增工序级中文参考 PDF，示例/待审核；不替换原版本或历史签名。', NULL, NULL, 'PENDING', 'NEXUS_SOP_REFERENCE_20261008；未经现场审批不得用于生产', NULL, NULL, '2026-10-08 19:15:17', NULL, NULL, '0');

-- ----------------------------
-- Table structure for sop_view_log
-- ----------------------------
DROP TABLE IF EXISTS `sop_view_log`;
CREATE TABLE `sop_view_log`  (
  `log_id` bigint(20) NOT NULL COMMENT '查阅记录ID(主键)',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '000000',
  `sop_id` bigint(20) NOT NULL COMMENT 'SOP ID',
  `version_no` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '查阅的版本号',
  `viewer_id` bigint(20) NOT NULL COMMENT '查阅人ID',
  `viewer_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '查阅人姓名(冗余)',
  `view_time` datetime(0) NOT NULL COMMENT '查阅时间',
  `wo_id` bigint(20) NULL DEFAULT NULL COMMENT '关联工单ID',
  `wo_no` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '工单编号(冗余)',
  `process_id` bigint(20) NULL DEFAULT NULL COMMENT '关联工序ID',
  `process_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '工序名称(冗余)',
  `workstation_id` bigint(20) NULL DEFAULT NULL COMMENT '工位ID',
  `signature_id` bigint(20) NULL DEFAULT NULL COMMENT '电子签名记录ID(预留,P0-6接入)',
  `ip_address` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT 'IP地址',
  `user_agent` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT 'User-Agent',
  `create_dept` bigint(20) NULL DEFAULT NULL COMMENT '创建部门',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '删除标志',
  PRIMARY KEY (`log_id`) USING BTREE,
  INDEX `idx_sop_id`(`sop_id`) USING BTREE,
  INDEX `idx_viewer`(`viewer_id`) USING BTREE,
  INDEX `idx_wo_id`(`wo_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = 'SOP查阅记录' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sop_view_log
-- ----------------------------
INSERT INTO `sop_view_log` VALUES (2100060819691597826, '000000', 1, NULL, 1, NULL, '2026-09-16 11:14:51', NULL, NULL, NULL, NULL, NULL, 2100060819590934530, '127.0.0.1', 'Mozilla/5.0', 103, 1, '2026-09-16 11:14:51', 1, '2026-09-16 11:14:51', '0');
INSERT INTO `sop_view_log` VALUES (2100494119950241794, '000000', 1, 'V1.0', 1, NULL, '2026-09-17 15:56:38', NULL, '', NULL, NULL, NULL, 2100494119832801281, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36', 103, 1, '2026-09-17 15:56:38', 1, '2026-09-17 15:56:38', '0');
INSERT INTO `sop_view_log` VALUES (2100494127311245314, '000000', 1, 'V1.0', 1, NULL, '2026-09-17 15:56:40', NULL, '', NULL, NULL, NULL, 2100494127235747842, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36', 103, 1, '2026-09-17 15:56:40', 1, '2026-09-17 15:56:40', '0');
INSERT INTO `sop_view_log` VALUES (2100494183586222081, '000000', 1, 'V1.0', 1, NULL, '2026-09-17 15:56:53', NULL, '', NULL, NULL, NULL, 2100494183548473345, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36', 103, 1, '2026-09-17 15:56:53', 1, '2026-09-17 15:56:53', '0');
INSERT INTO `sop_view_log` VALUES (2100494328474259457, '000000', 1, 'V1.0', 1, NULL, '2026-09-17 15:57:28', NULL, '', NULL, NULL, NULL, 2100494328436510722, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36', 103, 1, '2026-09-17 15:57:28', 1, '2026-09-17 15:57:28', '0');
INSERT INTO `sop_view_log` VALUES (2100507265939255297, '000000', 2100507000309788673, '1.0', 1, NULL, '2026-09-17 16:48:52', NULL, '', NULL, NULL, NULL, 2100507265863757825, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36', 103, 1, '2026-09-17 16:48:52', 1, '2026-09-17 16:48:52', '0');
INSERT INTO `sop_view_log` VALUES (2100507463168012289, '000000', 2100507000309788673, '1.0', 1, NULL, '2026-09-17 16:49:39', NULL, '', NULL, NULL, NULL, 2100507463088320514, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36', 103, 1, '2026-09-17 16:49:39', 1, '2026-09-17 16:49:39', '0');
INSERT INTO `sop_view_log` VALUES (2108163223414865922, '000000', 1, 'V1.1', 1, NULL, '2026-10-08 19:50:55', NULL, '', NULL, NULL, NULL, 2108163223289036801, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36', 103, 1, '2026-10-08 19:50:55', 1, '2026-10-08 19:50:55', '0');

-- ----------------------------
-- Table structure for spc_control_chart
-- ----------------------------
DROP TABLE IF EXISTS `spc_control_chart`;
CREATE TABLE `spc_control_chart`  (
  `chart_id` bigint(20) NOT NULL COMMENT '控制图ID(主键)',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '000000',
  `chart_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '控制图名称',
  `chart_type` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'X_BAR_R/X_BAR_S/P/C/U',
  `point_id` bigint(20) NULL DEFAULT NULL COMMENT '关联采集点ID',
  `material_id` bigint(20) NULL DEFAULT NULL COMMENT '关联物料ID',
  `process_id` bigint(20) NULL DEFAULT NULL COMMENT '关联工序ID',
  `ucl` decimal(14, 4) NULL DEFAULT NULL COMMENT '上控制限(analyze计算回写)',
  `cl` decimal(14, 4) NULL DEFAULT NULL COMMENT '中心线',
  `lcl` decimal(14, 4) NULL DEFAULT NULL COMMENT '下控制限',
  `r_ucl` decimal(14, 4) NULL DEFAULT NULL COMMENT '次级图(R/S/MR)上控制限',
  `r_cl` decimal(14, 4) NULL DEFAULT NULL COMMENT '次级图(R/S/MR)中心线',
  `r_lcl` decimal(14, 4) NULL DEFAULT NULL COMMENT '次级图(R/S/MR)下控制限',
  `usl` decimal(14, 4) NULL DEFAULT NULL COMMENT '规格上限(USL, 用户维护)',
  `lsl` decimal(14, 4) NULL DEFAULT NULL COMMENT '规格下限(LSL, 用户维护)',
  `cp` decimal(10, 4) NULL DEFAULT NULL COMMENT '过程能力指数Cp(analyze回写)',
  `cpk` decimal(10, 4) NULL DEFAULT NULL COMMENT '过程能力指数Cpk(analyze回写)',
  `cpk_grade` varchar(8) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '能力等级: A+(>=1.67)/A(>=1.33)/B(>=1.0)/C(<1.0)',
  `pp` decimal(10, 4) NULL DEFAULT NULL COMMENT '过程性能指数Pp(长期)',
  `ppk` decimal(10, 4) NULL DEFAULT NULL COMMENT '过程性能指数Ppk(长期)',
  `sample_size` int(11) NULL DEFAULT 5 COMMENT '样本大小',
  `status` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT 'ACTIVE' COMMENT 'ACTIVE/INACTIVE',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '备注',
  `create_dept` bigint(20) NULL DEFAULT NULL COMMENT '创建部门',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT '0' COMMENT '删除标志',
  PRIMARY KEY (`chart_id`) USING BTREE,
  INDEX `idx_point_id`(`point_id`) USING BTREE,
  INDEX `idx_status`(`status`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = 'MES SPC控制图' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for spc_data_point
-- ----------------------------
DROP TABLE IF EXISTS `spc_data_point`;
CREATE TABLE `spc_data_point`  (
  `data_id` bigint(20) NOT NULL COMMENT '数据点ID(主键)',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '000000',
  `chart_id` bigint(20) NOT NULL COMMENT '控制图ID',
  `sample_group` int(11) NOT NULL COMMENT '样本组号',
  `sample_index` int(11) NULL DEFAULT NULL COMMENT '组内序号',
  `value` decimal(14, 4) NOT NULL COMMENT '值(组均值/不良率/缺陷数等)',
  `sub_value` decimal(14, 4) NULL DEFAULT NULL COMMENT '组内离散度(R极差/S标准差/MR移动极差)',
  `is_ooc` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT '0' COMMENT '是否超控制限(0/1)',
  `ooc_rule` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '违规规则(RULE1/2/3/4, 多规则逗号拼接)',
  `collect_time` datetime(0) NULL DEFAULT NULL COMMENT '采集时间',
  `create_dept` bigint(20) NULL DEFAULT NULL COMMENT '创建部门',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT '0' COMMENT '删除标志',
  PRIMARY KEY (`data_id`) USING BTREE,
  UNIQUE INDEX `uk_chart_group`(`tenant_id`, `chart_id`, `sample_group`) USING BTREE,
  INDEX `idx_chart_id`(`chart_id`) USING BTREE,
  INDEX `idx_group`(`chart_id`, `sample_group`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = 'MES SPC数据点' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tg_maintenance_plan
-- ----------------------------
DROP TABLE IF EXISTS `tg_maintenance_plan`;
CREATE TABLE `tg_maintenance_plan`  (
  `plan_id` bigint(20) NOT NULL COMMENT '计划ID(主键)',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '000000',
  `tooling_id` bigint(20) NOT NULL COMMENT '工装ID',
  `plan_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '计划名称',
  `trigger_type` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '触发类型: BY_COUNT/BY_HOURS/PERIODIC',
  `trigger_value` int(11) NULL DEFAULT NULL COMMENT '触发阈值(次数/小时/天数)',
  `last_maintain_time` datetime(0) NULL DEFAULT NULL COMMENT '上次保养时间',
  `next_maintain_time` datetime(0) NULL DEFAULT NULL COMMENT '下次保养时间(PERIODIC)',
  `next_maintain_count` int(11) NULL DEFAULT NULL COMMENT '下次保养次数阈值(BY_COUNT)',
  `next_maintain_hours` decimal(14, 2) NULL DEFAULT NULL COMMENT '下次保养时长阈值(BY_HOURS)',
  `enabled` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '1' COMMENT '是否启用(1/0)',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '备注',
  `create_dept` bigint(20) NULL DEFAULT NULL COMMENT '创建部门',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '删除标志',
  PRIMARY KEY (`plan_id`) USING BTREE,
  UNIQUE INDEX `uk_tooling_trigger`(`tooling_id`, `trigger_type`, `tenant_id`, `del_flag`) USING BTREE,
  INDEX `idx_tooling_id`(`tooling_id`) USING BTREE,
  INDEX `idx_enabled`(`enabled`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = 'MES工装保养计划' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tg_maintenance_plan
-- ----------------------------
INSERT INTO `tg_maintenance_plan` VALUES (2108880250207117313, '000000', 2108880196335476737, '液压虎钳累计使用保养', 'BY_COUNT', 300, '2026-10-10 19:20:50', NULL, 300, NULL, '1', '检查液压密封、钳口平行度和定位挡块。', 103, 1, '2026-10-10 19:20:07', 1, '2026-10-10 19:20:07', '0');
INSERT INTO `tg_maintenance_plan` VALUES (2108880250815291394, '000000', 2108880197405024257, '零点托盘运行时长保养', 'BY_HOURS', 250, '2026-10-10 19:20:50', NULL, NULL, 250.00, '1', '清洁定位面并检查拉钉锁紧力。', 103, 1, '2026-10-10 19:20:08', 1, '2026-10-10 19:20:08', '0');
INSERT INTO `tg_maintenance_plan` VALUES (2108880251331190786, '000000', 2108880197405024257, '零点托盘季度精度保养', 'PERIODIC', 90, NULL, '2027-01-08 19:20:08', NULL, NULL, '1', '按季度复核重复定位精度。', 103, 1, '2026-10-10 19:20:08', 1, '2026-10-10 19:20:08', '0');
INSERT INTO `tg_maintenance_plan` VALUES (2108880251893227521, '000000', 2108880198109667330, '焊接定位夹具使用保养', 'BY_COUNT', 3, NULL, NULL, 3, NULL, '1', '检查定位销、压紧块和气路接头。', 103, 1, '2026-10-10 19:20:08', 1, '2026-10-10 19:20:08', '0');
INSERT INTO `tg_maintenance_plan` VALUES (2108880252409126914, '000000', 2108880198797533185, '连续冲压模具冲次保养', 'BY_COUNT', 5000, NULL, NULL, 5000, NULL, '1', '检查刃口、卸料板和导柱导套。', 103, 1, '2026-10-10 19:20:08', 1, '2026-10-10 19:20:08', '0');
INSERT INTO `tg_maintenance_plan` VALUES (2108880252954386433, '000000', 2108880198797533185, '连续冲压模具周期保养', 'PERIODIC', 60, NULL, '2026-12-09 19:20:08', NULL, NULL, '1', '按双月周期实施拆检与防锈保养。', 103, 1, '2026-10-10 19:20:08', 1, '2026-10-10 19:20:08', '0');
INSERT INTO `tg_maintenance_plan` VALUES (2108880253482868737, '000000', 2108880199468621825, '立铣刀累计时长检查', 'BY_HOURS', 40, NULL, NULL, NULL, 40.00, '1', '检查刃口磨损、崩刃和涂层状态。', 103, 1, '2026-10-10 19:20:08', 1, '2026-10-10 19:20:08', '0');
INSERT INTO `tg_maintenance_plan` VALUES (2108880254057488385, '000000', 2108880200139710465, '可换钻套使用次数保养', 'BY_COUNT', 500, NULL, NULL, 500, NULL, '1', '检查内孔磨损和法兰定位面。', 103, 1, '2026-10-10 19:20:08', 1, '2026-10-10 19:20:08', '0');
INSERT INTO `tg_maintenance_plan` VALUES (2108880254552416257, '000000', 2108880200789827585, '主轴锥孔规周期保养', 'PERIODIC', 180, NULL, '2027-04-08 19:20:08', NULL, NULL, '1', '清洁工作面并核验防锈和校准状态。', 103, 1, '2026-10-10 19:20:08', 1, '2026-10-10 19:20:08', '0');
INSERT INTO `tg_maintenance_plan` VALUES (2108880255026372609, '000000', 2108880201465110530, '扭矩扳手周期保养', 'PERIODIC', 90, NULL, '2027-01-08 19:20:09', NULL, NULL, '1', '检查传感器零点、棘轮机构和电池状态。', 103, 1, '2026-10-10 19:20:09', 1, '2026-10-10 19:20:09', '0');

-- ----------------------------
-- Table structure for tg_maintenance_record
-- ----------------------------
DROP TABLE IF EXISTS `tg_maintenance_record`;
CREATE TABLE `tg_maintenance_record`  (
  `record_id` bigint(20) NOT NULL COMMENT '记录ID(主键)',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '000000',
  `tooling_id` bigint(20) NOT NULL COMMENT '工装ID',
  `plan_id` bigint(20) NULL DEFAULT NULL COMMENT '关联计划ID',
  `maintain_type` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '保养类型: PLANNED/REPAIR',
  `maintain_time` datetime(0) NOT NULL COMMENT '保养时间',
  `maintainer_id` bigint(20) NULL DEFAULT NULL COMMENT '保养人ID',
  `maintainer_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '保养人姓名(冗余)',
  `used_count_before` int(11) NULL DEFAULT NULL COMMENT '保养前次数',
  `used_count_after` int(11) NULL DEFAULT NULL COMMENT '保养后次数(归零=0)',
  `used_hours_before` decimal(14, 2) NULL DEFAULT NULL COMMENT '保养前时长',
  `used_hours_after` decimal(14, 2) NULL DEFAULT NULL COMMENT '保养后时长(归零=0)',
  `description` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '保养内容',
  `cost` decimal(14, 2) NULL DEFAULT NULL COMMENT '保养成本',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '备注',
  `create_dept` bigint(20) NULL DEFAULT NULL COMMENT '创建部门',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '删除标志',
  PRIMARY KEY (`record_id`) USING BTREE,
  INDEX `idx_tooling_id`(`tooling_id`) USING BTREE,
  INDEX `idx_plan_id`(`plan_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = 'MES工装保养记录' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tg_maintenance_record
-- ----------------------------
INSERT INTO `tg_maintenance_record` VALUES (2108880427869446146, '000000', 2108880196335476737, 2108880250207117313, 'PLANNED', '2026-10-10 19:20:50', 112, '吴静', 120, 0, 18.50, 0.00, '清洁钳口和滑轨，检查液压密封及定位挡块，补充润滑脂并复核夹紧动作。', 680.00, '保养项目完成，动作与定位状态正常。', 103, 1, '2026-10-10 19:20:50', 1, '2026-10-10 19:20:50', '0');
INSERT INTO `tg_maintenance_record` VALUES (2108880428850913281, '000000', 2108880197405024257, 2108880250815291394, 'PLANNED', '2026-10-10 19:20:50', 112, '吴静', 45, 0, 72.00, 0.00, '清洁零点定位面，检查拉钉和锁紧机构，复核重复定位并更换防尘密封。', 1260.00, '锁紧机构和重复定位复核完成。', 103, 1, '2026-10-10 19:20:50', 1, '2026-10-10 19:20:50', '0');

-- ----------------------------
-- Table structure for tg_tooling
-- ----------------------------
DROP TABLE IF EXISTS `tg_tooling`;
CREATE TABLE `tg_tooling`  (
  `tooling_id` bigint(20) NOT NULL COMMENT '工装ID(主键)',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '000000',
  `tooling_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '工装编码',
  `tooling_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '工装名称',
  `tooling_type` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '类型: MOLD/FIXTURE/CUTTER/GAUGE/OTHER',
  `spec` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '规格',
  `workshop_id` bigint(20) NULL DEFAULT NULL COMMENT '所属车间ID',
  `workshop_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '车间名称(冗余)',
  `status` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT 'IDLE' COMMENT '状态: IDLE/IN_USE/CALIBRATING/MAINTENANCE/SCRAPPED',
  `total_life_count` int(11) NULL DEFAULT NULL COMMENT '总寿命(次数)',
  `total_life_hours` decimal(14, 2) NULL DEFAULT NULL COMMENT '总寿命(小时)',
  `used_count` int(11) NULL DEFAULT 0 COMMENT '已使用次数',
  `used_hours` decimal(14, 2) NULL DEFAULT 0.00 COMMENT '已使用时长',
  `last_maintain_time` datetime(0) NULL DEFAULT NULL COMMENT '上次保养时间',
  `calibration_cycle_days` int(11) NULL DEFAULT NULL COMMENT '校准周期(天), 空=未纳入校准管理',
  `last_calibration_date` date NULL DEFAULT NULL COMMENT '上次校准日期',
  `next_calibration_date` date NULL DEFAULT NULL COMMENT '下次校准日期, 到期/超期即拦截领用与进站',
  `calibrated_by` bigint(20) NULL DEFAULT NULL COMMENT '校准人ID',
  `calibration_result` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '校准结果: PASS/FAIL/ADJUSTED',
  `calibration_remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '校准备注',
  `purchase_date` date NULL DEFAULT NULL COMMENT '采购日期',
  `purchase_cost` decimal(14, 2) NULL DEFAULT NULL COMMENT '采购成本',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '备注',
  `create_dept` bigint(20) NULL DEFAULT NULL COMMENT '创建部门',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '删除标志',
  PRIMARY KEY (`tooling_id`) USING BTREE,
  UNIQUE INDEX `uk_tooling_code`(`tenant_id`, `tooling_code`) USING BTREE,
  INDEX `idx_status`(`status`) USING BTREE,
  INDEX `idx_type`(`tooling_type`) USING BTREE,
  INDEX `idx_workshop`(`workshop_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = 'MES工装台账' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tg_tooling
-- ----------------------------
INSERT INTO `tg_tooling` VALUES (2108880196335476737, '000000', 'TG20261010001', 'CNC液压虎钳夹具', 'FIXTURE', '125 mm钳口，可调定位挡块', 2, '机加车间', 'IDLE', 120000, 8000.00, 0, 0.00, '2026-10-10 19:20:50', NULL, NULL, NULL, NULL, NULL, NULL, '2025-03-18', 18600.00, '进入液压虎钳预防保养。', 103, 1, '2026-10-10 19:19:55', 1, '2026-10-10 19:19:55', '0');
INSERT INTO `tg_tooling` VALUES (2108880197405024257, '000000', 'TG20261010002', '加工中心零点定位托盘', 'FIXTURE', '400×400 mm，四点拉钉定位', 2, '机加车间', 'IDLE', 80000, 12000.00, 0, 0.00, '2026-10-10 19:20:50', NULL, NULL, NULL, NULL, NULL, NULL, '2025-06-12', 32800.00, '进入零点托盘精度保养。', 103, 1, '2026-10-10 19:19:55', 1, '2026-10-10 19:19:55', '0');
INSERT INTO `tg_tooling` VALUES (2108880198109667330, '000000', 'TG20261010003', '焊接总成定位夹具', 'FIXTURE', '基准销定位，气动压紧', 5, '焊接车间', 'IDLE', 30000, 6000.00, 3, 6.50, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-09-08', 24600.00, '用于焊接总成装夹，按使用次数检查定位销、压紧块和气路。', 103, 1, '2026-10-10 19:19:55', 1, '2026-10-10 19:19:55', '0');
INSERT INTO `tg_tooling` VALUES (2108880198797533185, '000000', 'TG20261010004', '端子支架连续冲压模具', 'MOLD', '八工位级进模，材料宽度80 mm', 3, '冲压车间', 'IDLE', 1000000, 10000.00, 850, 9.50, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-11-26', 185000.00, '用于端子支架连续冲压，按冲次和日历周期实施刃口及导向机构保养。', 103, 1, '2026-10-10 19:19:55', 1, '2026-10-10 19:19:55', '0');
INSERT INTO `tg_tooling` VALUES (2108880199468621825, '000000', 'TG20261010005', '硬质合金立铣刀', 'CUTTER', 'D16×40×100 mm，四刃涂层', 2, '机加车间', 'IDLE', 6000, 1200.00, 36, 12.75, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-02-20', 1680.00, '用于钢件侧铣和型腔加工，按累计切削时长检查刃口磨损。', 103, 1, '2026-10-10 19:19:55', 1, '2026-10-10 19:19:55', '0');
INSERT INTO `tg_tooling` VALUES (2108880200139710465, '000000', 'TG20261010006', '精密可换钻套', 'CUTTER', '内径12H7，法兰式快换', 2, '机加车间', 'IN_USE', 20000, 3000.00, 0, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-04-16', 980.00, '用于钻床导向定位，领用后由责任人保管并登记归还。', 103, 1, '2026-10-10 19:19:55', 1, '2026-10-10 19:19:55', '0');
INSERT INTO `tg_tooling` VALUES (2108880200789827585, '000000', 'TG20261010007', '主轴锥孔通止规', 'GAUGE', 'BT40 7:24锥度，成套通止规', 2, '机加车间', 'IDLE', 10000, 2000.00, 8, 2.00, NULL, 180, '2026-10-10', '2027-04-08', 108, 'PASS', '通端顺畅、止端有效，工作面无磕碰，校准结论合格。', '2025-08-05', 7600.00, '用于加工中心主轴锥孔状态核验，纳入半年校准周期。', 103, 1, '2026-10-10 19:19:56', 1, '2026-10-10 19:19:56', '0');
INSERT INTO `tg_tooling` VALUES (2108880201465110530, '000000', 'TG20261010008', '装配扭矩校验扳手', 'GAUGE', '20-200 N·m，数显可追溯', 12, '装配车间', 'IDLE', 30000, 5000.00, 16, 3.25, NULL, 90, '2026-10-10', '2027-01-08', 110, 'ADJUSTED', '完成零点与满量程调整，复核后示值满足内部使用要求。', '2025-12-10', 12800.00, '用于装配扭矩核验，调整后须保留校准结论并按季度复校。', 103, 1, '2026-10-10 19:19:56', 1, '2026-10-10 19:19:56', '0');

-- ----------------------------
-- Table structure for tg_usage_record
-- ----------------------------
DROP TABLE IF EXISTS `tg_usage_record`;
CREATE TABLE `tg_usage_record`  (
  `usage_id` bigint(20) NOT NULL COMMENT '使用记录ID(主键)',
  `tenant_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '000000',
  `tooling_id` bigint(20) NOT NULL COMMENT '工装ID',
  `wo_id` bigint(20) NULL DEFAULT NULL COMMENT '工单ID',
  `wo_no` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '工单编号(冗余)',
  `workstation_id` bigint(20) NULL DEFAULT NULL COMMENT '工位ID',
  `workstation_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '工位名称(冗余)',
  `operator_id` bigint(20) NULL DEFAULT NULL COMMENT '操作员ID',
  `operator_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '操作员姓名(冗余)',
  `checkout_time` datetime(0) NOT NULL COMMENT '领用时间',
  `return_time` datetime(0) NULL DEFAULT NULL COMMENT '归还时间',
  `usage_count` int(11) NULL DEFAULT 1 COMMENT '使用次数',
  `usage_hours` decimal(14, 2) NULL DEFAULT NULL COMMENT '使用时长',
  `status` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT 'OUT' COMMENT '状态: OUT/RETURNED',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '备注',
  `create_dept` bigint(20) NULL DEFAULT NULL COMMENT '创建部门',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '删除标志',
  PRIMARY KEY (`usage_id`) USING BTREE,
  INDEX `idx_tooling_id`(`tooling_id`) USING BTREE,
  INDEX `idx_wo_id`(`wo_id`) USING BTREE,
  INDEX `idx_status`(`status`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = 'MES工装使用领用记录' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tg_usage_record
-- ----------------------------
INSERT INTO `tg_usage_record` VALUES (2108880351575056385, '000000', 2108880196335476737, NULL, NULL, 5, '数控车床A', 105, '张明', '2026-10-10 19:20:32', '2026-10-10 19:20:32', 120, 18.50, 'RETURNED', '作业结束清洁后归还，累计使用数据已登记。', 103, 1, '2026-10-10 19:20:32', 1, '2026-10-10 19:20:32', '0');
INSERT INTO `tg_usage_record` VALUES (2108880352451665921, '000000', 2108880197405024257, NULL, NULL, 7, '加工中心A', 106, '李芳华', '2026-10-10 19:20:32', '2026-10-10 19:20:32', 45, 72.00, 'RETURNED', '定位面清洁并复核锁紧机构后归还。', 103, 1, '2026-10-10 19:20:32', 1, '2026-10-10 19:20:32', '0');
INSERT INTO `tg_usage_record` VALUES (2108880353244389378, '000000', 2108880198109667330, NULL, NULL, 20, '氩弧焊工位', 109, '陈志强', '2026-10-10 19:20:32', '2026-10-10 19:20:32', 3, 6.50, 'RETURNED', '完成三批装夹后归还，等待到期保养。', 103, 1, '2026-10-10 19:20:32', 1, '2026-10-10 19:20:32', '0');
INSERT INTO `tg_usage_record` VALUES (2108880354066472961, '000000', 2108880198797533185, 2104803729263751169, 'SCGD202609280001', 12, '冲床A', 107, '王思远', '2026-10-10 19:20:32', '2026-10-10 19:20:32', 850, 9.50, 'RETURNED', '停机清洁并完成模面防锈后归还。', 103, 1, '2026-10-10 19:20:32', 1, '2026-10-10 19:20:32', '0');
INSERT INTO `tg_usage_record` VALUES (2108880354846613506, '000000', 2108880199468621825, NULL, NULL, 7, '加工中心A', 111, '周涛', '2026-10-10 19:20:32', '2026-10-10 19:20:32', 36, 12.75, 'RETURNED', '刃口检查无崩刃，完成清洁后归还。', 103, 1, '2026-10-10 19:20:32', 1, '2026-10-10 19:20:32', '0');
INSERT INTO `tg_usage_record` VALUES (2108880355656114177, '000000', 2108880200139710465, NULL, NULL, 10, '钻床', 105, '张明', '2026-10-10 19:20:33', NULL, 1, NULL, 'OUT', '钻孔导向作业领用，当前由机加责任人保管。', 103, 1, '2026-10-10 19:20:33', 1, '2026-10-10 19:20:33', '0');
INSERT INTO `tg_usage_record` VALUES (2108880356155236354, '000000', 2108880200789827585, NULL, NULL, 7, '加工中心A', 108, '刘薇薇', '2026-10-10 19:20:33', '2026-10-10 19:20:33', 8, 2.00, 'RETURNED', '使用后清洁、涂防锈油并归还量具柜。', 103, 1, '2026-10-10 19:20:33', 1, '2026-10-10 19:20:33', '0');
INSERT INTO `tg_usage_record` VALUES (2108880356939571201, '000000', 2108880201465110530, 2107352232221392898, 'SCGD202610060002', 46, '装配线A', 110, '赵琳', '2026-10-10 19:20:33', '2026-10-10 19:20:33', 16, 3.25, 'RETURNED', '扭矩核验结束，卸载归零后归还。', 103, 1, '2026-10-10 19:20:33', 1, '2026-10-10 19:20:33', '0');

-- ----------------------------
-- Procedure structure for nexus_p2_add_column
-- ----------------------------
DROP PROCEDURE IF EXISTS `nexus_p2_add_column`;
delimiter ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `nexus_p2_add_column`(IN p_table VARCHAR(64), IN p_column VARCHAR(64), IN p_ddl TEXT)
BEGIN
  IF (SELECT COUNT(*) FROM information_schema.COLUMNS
       WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = p_table AND COLUMN_NAME = p_column) = 0 THEN
    SET @nexus_sql := CONCAT('ALTER TABLE `', p_table, '` ADD COLUMN ', p_ddl);
    PREPARE nexus_stmt FROM @nexus_sql; EXECUTE nexus_stmt; DEALLOCATE PREPARE nexus_stmt;
  END IF;
END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for nexus_p2_add_unique
-- ----------------------------
DROP PROCEDURE IF EXISTS `nexus_p2_add_unique`;
delimiter ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `nexus_p2_add_unique`(IN p_table VARCHAR(64), IN p_index VARCHAR(64), IN p_columns VARCHAR(255))
BEGIN
  IF (SELECT COUNT(*) FROM information_schema.STATISTICS
       WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = p_table AND INDEX_NAME = p_index) = 0 THEN
    SET @nexus_sql := CONCAT('ALTER TABLE `', p_table, '` ADD UNIQUE INDEX `', p_index, '`(', p_columns, ')');
    PREPARE nexus_stmt FROM @nexus_sql; EXECUTE nexus_stmt; DEALLOCATE PREPARE nexus_stmt;
  END IF;
END
;;
delimiter ;

SET FOREIGN_KEY_CHECKS = 1;
